from pathlib import Path
p=Path('src/main.rs');s=p.read_text();s='mod json;\n'+s;p.write_text(s)
p=Path('src/funcs.rs');s=p.read_text();s='use crate::json::{Json, Object};\n'+s
s=s.replace('serde_json::Value','Json').replace('serde_json::Map::new()','Object::new()').replace('use Json as J;','use crate::json::Json as J;')
s=s.replace('V::Int(i) => serde_json::json!(i),','V::Int(i) => Json::Number((*i).into()),')
s=s.replace('V::Real(f) => serde_json::json!(f),','V::Real(f) => Json::Number(serde_json::Number::from_f64(*f).unwrap_or_else(||serde_json::from_str(if f.is_sign_negative(){"-9e999"}else{"9e999"}).unwrap())),')
s=s.replace('serde_json::from_str::<Json>(&a[0].text()).is_ok()', 'Json::parse(&a[0].text()).is_ok()')
s=s.replace('serde_json::from_str::<Json>(&a[i].text()).is_ok()', 'Json::parse(&a[i].text()).is_ok()')
s=s.replace('if let Ok(v) = serde_json::from_str(&a[i].text()) {','if let Ok(v) = Json::parse(&a[i].text()) {')
s=s.replace('if let Ok(v) = serde_json::from_str(s) { return Ok((v, minify_json(s))) }','if let Ok(v) = Json::parse(s) { return Ok((v, minify_json(s))) }')
s=s.replace('let v = serde_json::from_str(&normalized).map_err(|_| "malformed JSON")?;','let v = Json::parse(&normalized).map_err(|_| "malformed JSON")?;')
# Ordered object patch updates the first matching label.
s=s.replace('''                let dest = t.entry(k).or_insert(J::Null);
                merge_patch(dest, v)''','''                if !t.contains_key(k){t.insert(k.clone(),J::Null)}
                merge_patch(t.get_mut(k).unwrap(),v)''')
# json_pretty default indentation is 4 spaces; optional argument may be any text.
s=s.replace('''        "json_pretty" =>
            Ok(V::Text(serde_json::to_string_pretty(&v).unwrap_or_default())),''','''        "json_pretty" => {
            let indent=if a.get(1).is_some_and(|v|!v.null()){a[1].text()}else{"    ".into()};
            let mut out=Vec::new();let formatter=serde_json::ser::PrettyFormatter::with_indent(indent.as_bytes());
            let mut serializer=serde_json::Serializer::with_formatter(&mut out,formatter);
            serde::Serialize::serialize(&v,&mut serializer).map_err(|e|e.to_string())?;
            Ok(V::Text(String::from_utf8(out).map_err(|e|e.to_string())?))
        },''')
s=s.replace('''                        Ok(V::Int(1))
                    } else { Err("malformed JSON".into()) }''','''                        let text=a[0].text();let position=Json::parse(&text).err().unwrap_or(1);Ok(V::Int(text[..position.saturating_sub(1).min(text.len())].chars().count() as i64+1))
                    } else { Err("malformed JSON".into()) }''')
a=s.index("fn json_path<'a>");b=s.index('pub fn json_extract_op',a)
s=s[:a]+'''fn json_path<'a>(v:&'a Json,path:&str)->Res<Option<&'a Json>>{
    let mut value=v;
    for part in split_path(path)?{
        let next=match(part,value){
            (PathPart::Key(key),Json::Object(o))=>o.get(&key),
            (PathPart::Index(i),Json::Array(a))=>a.get(i as usize),
            (PathPart::FromEnd(i),Json::Array(a))=>a.len().checked_sub(i as usize).and_then(|i|a.get(i)),
            _=>None
        };
        match next{Some(v)=>value=v,None=>return Ok(None)}
    }
    Ok(Some(value))
}
'''+s[b:]
s=s.replace('enum PathPart { Key(String), Index(i64), Append, }','enum PathPart { Key(String), Index(u64), FromEnd(u64), Append, }')
s=s.replace('''                    PathPart::Index(-n.parse::<i64>().map_err(|_|
                                        "bad JSON path")?)''','''                    if n.is_empty()||!n.bytes().all(|b|b.is_ascii_digit()){return Err("bad JSON path".into())}
                    PathPart::FromEnd(n.parse::<u64>().map_err(|_|"bad JSON path")?)''')
s=s.replace('''                    PathPart::Index(raw.parse().map_err(|_| "bad JSON path")?)''','''                    if raw.is_empty()||!raw.bytes().all(|b|b.is_ascii_digit()){return Err("bad JSON path".into())}
                    PathPart::Index(raw.parse().map_err(|_| "bad JSON path")?)''')
s=s.replace('''                k = s[..i].to_string();
                s = &s[i..]
            }
            out.push''','''                if i==0{return Err("bad JSON path".into())}
                k = s[..i].to_string();
                s = &s[i..]
            }
            out.push''')
s=s.replace('''                        PathPart::Index(i) =>
                            if *i < 0 { a.len() as i64 + i } else { *i },''','''                        PathPart::Index(i)=>if *i>i64::MAX as u64{return false}else{*i as i64},
                        PathPart::FromEnd(i)=>if *i>a.len() as u64{return false}else{a.len() as i64-*i as i64},''')
# Don't leave partial objects after an unsuccessful insertion into a missing descendant.
old='''                        m.insert(k.clone(),
                            if matches!(path[1],PathPart::Key(_)) {
                                J::Object(Object::new())
                            } else { J::Array(vec![]) });
                    }
                    modify_json(m.get_mut(k).unwrap(), &path[1..], new, mode)'''
new='''                        let mut child=if matches!(path[1],PathPart::Key(_)){J::Object(Object::new())}else{J::Array(vec![])};
                        if modify_json(&mut child,&path[1..],new,mode){m.insert(k.clone(),child);return true}else{return false}
                    }
                    modify_json(m.get_mut(k).unwrap(), &path[1..], new, mode)'''
assert old in s;s=s.replace(old,new)
old='''                        a.push(if matches!(path[1],PathPart::Key(_)) {
                                J::Object(Object::new())
                            } else { J::Array(vec![]) })
                    }
                    modify_json(&mut a[i], &path[1..], new, mode)'''
new='''                        let mut child=if matches!(path[1],PathPart::Key(_)){J::Object(Object::new())}else{J::Array(vec![])};
                        if modify_json(&mut child,&path[1..],new,mode){a.push(child);return true}else{return false}
                    }
                    modify_json(&mut a[i], &path[1..], new, mode)'''
assert old in s;s=s.replace(old,new)
# Table function paths quote punctuation-bearing object labels.
s=s.replace('&format!("{}.{}",full,k)', '&json_member_path(full,k)')
s=s.replace('&format!("{}.{}",root,k)', '&json_member_path(&root,k)')
s += '''
fn json_member_path(parent:&str,key:&str)->String{
    if !key.is_empty()&&key.chars().all(|c|c.is_alphanumeric()||c=='_'){format!("{}.{}",parent,key)}else{format!("{}.{}",parent,serde_json::to_string(key).unwrap())}
}
'''
p.write_text(s)
