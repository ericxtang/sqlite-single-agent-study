from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
a=s.index('        for (n, cols, cq) in &q.ctes {',s.index('pub fn query'))
b=s.index('            let names =\n                if cols.is_empty()',a)
# first occurrence after huge branch? internal names indent 20 differs yes.
s=s[:a]+'''        for ci in cte_order(q)? {
            let (n,cols,cq)=&q.ctes[ci];
            let r=if query_table_references(cq,n)>0{self.recursive_cte(n,cols,cq,&base,depth+1)?}else{self.query(cq,&base,depth+1)?};
'''+s[b:]
a=s.index('    pub fn query(')
s=s[:a]+'''    fn recursive_cte(&self,name:&str,columns:&[String],q:&Query,ctx:&Ctx,depth:usize)->Res<ResultSet>{
        let first=q.compound.iter().position(|(_,b)|query_table_references(b,name)>0).ok_or_else(||format!("circular reference: {}",name))?;
        let mut anchor=q.clone();anchor.compound.truncate(first);anchor.order.clear();anchor.limit=None;anchor.offset=None;
        if query_table_references(&anchor,name)>0{return Err(format!("circular reference: {}",name))}
        let op=&q.compound[first].0;
        if op!="UNION"&&op!="UNION ALL"{return Err("recursive CTE requires UNION or UNION ALL".into())}
        let distinct=op=="UNION";
        let mut result=self.query(&anchor,ctx,depth+1)?;
        let names=if columns.is_empty(){result.columns.clone()}else{columns.to_vec()};
        if names.len()!=result.columns.len(){return Err("CTE column count mismatch".into())}
        let fields=names.iter().enumerate().map(|(i,n)|{let(a,c)=result.affinities.get(i).cloned().unwrap_or(('B',"BINARY".into()));field(name,n,a,&c,false)}).collect::<Vec<_>>();
        let mut recursive_ctx=ctx.clone();
        recursive_ctx.ctes.insert(key(name),Data{fields,rows:vec![]});
        let mut bind=recursive_ctx.clone();bind.binding=true;
        let mut branches=vec![result.items.clone()];
        for (branch_op,branch) in &q.compound[first..]{
            let direct=branch.from.iter().filter(|j|matches!(&j.source,Source::Table(t) if t.eq_ignore_ascii_case(name))).count();
            if branch_op!=op||direct!=1||query_table_references(branch,name)!=1{return Err("invalid recursive reference or compound operator".into())}
            if !branch.group.is_empty()||branch.having.is_some()||branch.items.iter().any(|i|has_agg(&i.e)||has_window(&i.e)){return Err("recursive queries may not use aggregate or window functions".into())}
            let r=self.query(branch,&bind,depth+1)?;
            if r.columns.len()!=names.len(){return Err("recursive SELECT column count mismatch".into())}
            inherit_compound_collations(&mut result,&r);
            branches.push(r.items);
        }
        let order_indices=resolve_order(&q.order,&branches,true)?;
        if ctx.binding{result.rows.clear();return Ok(result)}
        let limit=if let Some(e)=&q.limit{let n=limit_int(&self.eval(e,ctx,None,depth+1)?)?;if n<0{usize::MAX}else{n as usize}}else{usize::MAX};
        let mut offset=if let Some(e)=&q.offset{limit_int(&self.eval(e,ctx,None,depth+1)?)?.max(0) as usize}else{0};
        let row_equal=|a:&[V],b:&[V]|a.len()==b.len()&&a.iter().zip(b).enumerate().all(|(i,(a,b))|cmp(a,b,result.affinities.get(i).map(|x|x.1.as_str()).unwrap_or("BINARY"))==Ordering::Equal);
        let mut seen:Vec<Vec<V>>=vec![];
        let mut queue=std::collections::VecDeque::new();
        for row in result.rows.drain(..){if !distinct||!seen.iter().any(|r|row_equal(r,&row)){if distinct{seen.push(row.clone())}queue.push_back(row)}}
        let mut output=vec![];let mut steps=0usize;
        while !queue.is_empty()&&output.len()<limit{
            steps+=1;if steps>1_000_000||queue.len()>1_000_000{return Err("recursive query resource limit exceeded".into())}
            let index=if q.order.is_empty(){0}else{queue.iter().enumerate().min_by(|(_,a),(_,b)|{
                for (oi,o) in q.order.iter().enumerate(){let col=order_indices[oi].unwrap();let coll=explicit_coll(&o.e).unwrap_or_else(||result.affinities.get(col).map(|x|x.1.as_str()).unwrap_or("BINARY"));let c=sort_compare(&a[col],&b[col],coll,o);if c!=Ordering::Equal{return c}}
                Ordering::Equal
            }).map(|(i,_)|i).unwrap()};
            let row=queue.remove(index).unwrap();
            if offset>0{offset-=1}else{output.push(row.clone())}
            if output.len()>=limit{break}
            recursive_ctx.ctes.get_mut(&key(name)).unwrap().rows=vec![row];
            for (_,branch) in &q.compound[first..]{
                for row in self.query(branch,&recursive_ctx,depth+1)?.rows{
                    if !distinct||!seen.iter().any(|r|row_equal(r,&row)){if distinct{seen.push(row.clone())}queue.push_back(row)}
                }
            }
        }
        result.rows=output;
        Ok(result)
    }
'''+s[a:]
# remove obsolete roweq
a=s.index('fn roweq(');b=s.index('fn order_position',a);s=s[:a]+s[b:]
helpers='''
fn sort_compare(a:&V,b:&V,coll:&str,order:&Order)->Ordering{
    let mut c=cmp(a,b,coll);
    if a.null()!=b.null(){if let Some(last)=order.nulls{c=if a.null()^last{Ordering::Less}else{Ordering::Greater}}else if order.desc{c=c.reverse()}}else if order.desc{c=c.reverse()}
    c
}
fn expression_table_references(e:&E,name:&str)->usize{
    match e{
        E::Sub(q)|E::SubCol(q,_)|E::Exists(q)=>query_table_references(q,name),
        E::In(e,a,q,_)=>expression_table_references(e,name)+a.iter().map(|e|expression_table_references(e,name)).sum::<usize>()+q.as_ref().map_or(0,|q|query_table_references(q,name)),
        E::Window(e,w)=>expression_table_references(e,name)+w.partition.iter().map(|e|expression_table_references(e,name)).sum::<usize>()+w.order.iter().map(|o|expression_table_references(&o.e,name)).sum::<usize>(),
        _=>child_exprs(e).iter().map(|e|expression_table_references(e,name)).sum()
    }
}
fn query_table_references(q:&Query,name:&str)->usize{
    if q.ctes.iter().any(|(n,_,_)|n.eq_ignore_ascii_case(name)){return 0}
    let sources=q.from.iter().map(|j|{
        (match &j.source{Source::Table(n)=>usize::from(n.eq_ignore_ascii_case(name)),Source::Query(q)=>query_table_references(q,name),Source::Function(_,a)=>a.iter().map(|e|expression_table_references(e,name)).sum()})+
        j.on.as_ref().map_or(0,|e|expression_table_references(e,name))
    }).sum::<usize>();
    sources+q.items.iter().map(|i|expression_table_references(&i.e,name)).sum::<usize>()+
    q.filter.as_ref().map_or(0,|e|expression_table_references(e,name))+
    q.having.as_ref().map_or(0,|e|expression_table_references(e,name))+
    q.group.iter().chain(q.order.iter().map(|o|&o.e)).chain(q.limit.iter()).chain(q.offset.iter()).chain(q.values.iter().flatten()).map(|e|expression_table_references(e,name)).sum::<usize>()+
    q.compound.iter().map(|(_,q)|query_table_references(q,name)).sum::<usize>()+
    q.ctes.iter().map(|(_,_,q)|query_table_references(q,name)).sum::<usize>()
}
fn cte_order(q:&Query)->Res<Vec<usize>>{
    let mut names=std::collections::BTreeSet::new();
    for(n,_,_)in &q.ctes{if !names.insert(key(n)){return Err(format!("duplicate WITH table name: {}",n))}}
    let mut body=q.clone();body.ctes.clear();
    let mut needed=q.ctes.iter().map(|(n,_,_)|query_table_references(&body,n)>0).collect::<Vec<_>>();
    let deps=q.ctes.iter().map(|(_,_,c)|q.ctes.iter().map(|(n,_,_)|query_table_references(c,n)>0).collect::<Vec<_>>()).collect::<Vec<_>>();
    loop{let mut changed=false;for i in 0..needed.len(){if needed[i]{for j in 0..needed.len(){if deps[i][j]&&!needed[j]{needed[j]=true;changed=true}}}}if !changed{break}}
    let mut done=vec![false;needed.len()];let mut order=vec![];
    while done.iter().zip(&needed).any(|(d,n)|*n&&!*d){
        let i=(0..needed.len()).find(|&i|needed[i]&&!done[i]&&(0..needed.len()).all(|j|i==j||!deps[i][j]||done[j])).ok_or("circular reference in WITH clause")?;
        done[i]=true;order.push(i);
    }
    Ok(order)
}
'''
s=s.replace('fn order_position',helpers+'\nfn order_position')
p.write_text(s)
