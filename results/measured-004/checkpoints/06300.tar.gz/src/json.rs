// Ordered JSON values preserve both object member order and duplicate labels.
use serde::ser::{Serialize, Serializer, SerializeMap, SerializeSeq};
#[derive(Clone,Debug)]
pub enum Json { Null, Bool(bool), Number(serde_json::Number), String(String), Array(Vec<Json>), Object(Object) }
#[derive(Clone,Debug,Default)]
pub struct Object(pub Vec<(String,Json)>);
impl Object {
    pub fn new()->Self{Self::default()}
    pub fn get(&self,key:&str)->Option<&Json>{self.0.iter().find(|(k,_)|k==key).map(|(_,v)|v)}
    pub fn get_mut(&mut self,key:&str)->Option<&mut Json>{self.0.iter_mut().find(|(k,_)|k==key).map(|(_,v)|v)}
    pub fn contains_key(&self,key:&str)->bool{self.get(key).is_some()}
    pub fn insert(&mut self,key:String,value:Json){if let Some(v)=self.get_mut(&key){*v=value}else{self.0.push((key,value))}}
    pub fn remove(&mut self,key:&str)->Option<Json>{let i=self.0.iter().position(|(k,_)|k==key)?;Some(self.0.remove(i).1)}
}
impl<'a> IntoIterator for &'a Object {
    type Item=&'a (String,Json);type IntoIter=std::slice::Iter<'a,(String,Json)>;
    fn into_iter(self)->Self::IntoIter{self.0.iter()}
}
impl Json{
    pub fn is_array(&self)->bool{matches!(self,Self::Array(_))}
    pub fn is_object(&self)->bool{matches!(self,Self::Object(_))}
    pub fn is_null(&self)->bool{matches!(self,Self::Null)}
    pub fn as_array(&self)->Option<&Vec<Json>>{if let Self::Array(v)=self{Some(v)}else{None}}
    pub fn as_object_mut(&mut self)->Option<&mut Object>{if let Self::Object(v)=self{Some(v)}else{None}}
    pub fn parse(s:&str)->Result<Self,usize>{let mut parser=Parser{s,pos:0};let value=parser.value(0)?;parser.whitespace();if parser.pos!=s.len(){Err(parser.pos+1)}else{Ok(value)}}
}
impl std::fmt::Display for Json{
    fn fmt(&self,f:&mut std::fmt::Formatter<'_>)->std::fmt::Result{f.write_str(&serde_json::to_string(self).map_err(|_|std::fmt::Error)?)}
}
impl Serialize for Json{
    fn serialize<S:Serializer>(&self,s:S)->Result<S::Ok,S::Error>{match self{
        Self::Null=>s.serialize_none(),Self::Bool(b)=>s.serialize_bool(*b),Self::Number(n)=>n.serialize(s),Self::String(v)=>s.serialize_str(v),
        Self::Array(a)=>{let mut seq=s.serialize_seq(Some(a.len()))?;for v in a{seq.serialize_element(v)?}seq.end()},
        Self::Object(o)=>{let mut map=s.serialize_map(Some(o.0.len()))?;for (k,v) in o{map.serialize_entry(k,v)?}map.end()}
    }}
}
struct Parser<'a>{s:&'a str,pos:usize}
impl Parser<'_>{
    fn whitespace(&mut self){while self.s.as_bytes().get(self.pos).is_some_and(|b|b" \t\r\n".contains(b)){self.pos+=1}}
    fn string(&mut self)->Result<String,usize>{
        let start=self.pos;self.pos+=1;let mut escaped=false;
        while let Some(&b)=self.s.as_bytes().get(self.pos){self.pos+=1;if escaped{escaped=false}else if b==b'\\'{escaped=true}else if b==b'"'{return serde_json::from_str(&self.s[start..self.pos]).map_err(|e|start+e.column().max(1))}}
        Err(self.pos+1)
    }
    fn value(&mut self,depth:usize)->Result<Json,usize>{
        self.whitespace();if depth>1000{return Err(self.pos+1)}
        let b=*self.s.as_bytes().get(self.pos).ok_or(self.pos+1)?;
        Ok(match b{
            b'n'|b't'|b'f'=>{let word=match b{b'n'=>"null",b't'=>"true",_=>"false"};if !self.s[self.pos..].starts_with(word){return Err(self.pos+1)}self.pos+=word.len();match b{b'n'=>Json::Null,b't'=>Json::Bool(true),_=>Json::Bool(false)}},
            b'"'=>Json::String(self.string()?),
            b'['=>{self.pos+=1;self.whitespace();let mut out=vec![];if self.s.as_bytes().get(self.pos)==Some(&b']'){self.pos+=1;return Ok(Json::Array(out))}loop{out.push(self.value(depth+1)?);self.whitespace();match self.s.as_bytes().get(self.pos){Some(b']')=>{self.pos+=1;break},Some(b',')=>self.pos+=1,_=>return Err(self.pos+1)}}Json::Array(out)},
            b'{'=>{self.pos+=1;self.whitespace();let mut out=Object::new();if self.s.as_bytes().get(self.pos)==Some(&b'}'){self.pos+=1;return Ok(Json::Object(out))}loop{self.whitespace();if self.s.as_bytes().get(self.pos)!=Some(&b'"'){return Err(self.pos+1)}let key=self.string()?;self.whitespace();if self.s.as_bytes().get(self.pos)!=Some(&b':'){return Err(self.pos+1)}self.pos+=1;let value=self.value(depth+1)?;out.0.push((key,value));self.whitespace();match self.s.as_bytes().get(self.pos){Some(b'}')=>{self.pos+=1;break},Some(b',')=>self.pos+=1,_=>return Err(self.pos+1)}}Json::Object(out)},
            b'-'|b'0'..=b'9'=>{let start=self.pos;while self.s.as_bytes().get(self.pos).is_some_and(|b|b.is_ascii_digit()||b"-+.eE".contains(b)){self.pos+=1}let n=serde_json::from_str::<serde_json::Number>(&self.s[start..self.pos]).map_err(|_|start+1)?;Json::Number(n)},
            _=>return Err(self.pos+1)
        })
    }
}
