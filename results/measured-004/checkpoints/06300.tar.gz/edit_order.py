from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('pub struct ResultSet {\n','pub struct ResultSet {\n    pub items: Vec<Item>,\n    pub coll_sources: Vec<bool>,\n')
# Default metadata for each existing multiline result constructor.
s=s.replace('ResultSet {\n                        columns:','ResultSet {\n                        items: vec![], coll_sources: vec![],\n                        columns:')
s=s.replace('ResultSet {\n                    affinities: vec![],','ResultSet {\n                    items: q.values[0].iter().enumerate().map(|(i,e)|Item{e:e.clone(),name:format!("column{}",i+1),alias:None}).collect(),\n                    coll_sources:q.values[0].iter().map(|e|explicit_coll(e).is_some()||self.collation_source(e,&base)).collect(),\n                    affinities: q.values[0].iter().map(|e|self.metadata(e,&base)).collect(),')
s=s.replace('ResultSet {\n                    affinities: items','ResultSet {\n                    items: items.clone(), coll_sources: items.iter().map(|i|explicit_coll(&i.e).is_some()||self.collation_source(&i.e,&base)).collect(),\n                    affinities: items')
s=s.replace('ResultSet {\n                affinities: vec![],','ResultSet {\n                items: vec![], coll_sources: vec![],\n                affinities: vec![],')
s=s.replace('ResultSet {\n                            affinities: vec![],','ResultSet {\n                            items: vec![], coll_sources: vec![],\n                            affinities: vec![],')
old='if base.binding {let result=ResultSet{columns:items.iter().map(|i|i.name.clone()).collect(),rows:vec![],affinities:items.iter().map(|i|self.metadata(&i.e,&base)).collect()};for(_,branch)in &q.compound{let r=self.query(branch,&base,depth+1)?;if r.columns.len()!=result.columns.len(){return Err("compound column count mismatch".into())}}return Ok(result)}'
new='''if base.binding {
                let mut result=ResultSet{items:items.clone(),coll_sources:items.iter().map(|i|explicit_coll(&i.e).is_some()||self.collation_source(&i.e,&base)).collect(),columns:items.iter().map(|i|i.name.clone()).collect(),rows:vec![],affinities:items.iter().map(|i|self.metadata(&i.e,&base)).collect()};
                let mut branches=vec![items.clone()];
                for(_,branch)in &q.compound{
                    let r=self.query(branch,&base,depth+1)?;
                    if r.columns.len()!=result.columns.len(){return Err("compound column count mismatch".into())}
                    inherit_compound_collations(&mut result,&r);
                    branches.push(r.items);
                }
                resolve_order(&q.order,&branches,!q.compound.is_empty())?;
                return Ok(result)
            }'''
assert old in s;s=s.replace(old,new)
s=s.replace('        for (op, branch) in &q.compound {\n            let r = self.query(branch, &base, depth + 1)?;', '        let mut order_branches=vec![result.items.clone()];\n        for (op, branch) in &q.compound {\n            let r = self.query(branch, &base, depth + 1)?;')
s=s.replace('            let eq=|x:&[V],y:&[V]|','            order_branches.push(r.items.clone());\n            inherit_compound_collations(&mut result,&r);\n            let eq=|x:&[V],y:&[V]|')
s=s.replace('        if base.binding{return Ok(result)}\n        if !q.order.is_empty() {','        let order_indices=resolve_order(&q.order,&order_branches,!q.compound.is_empty())?;\n        if base.binding{return Ok(result)}\n        if !q.order.is_empty() {')
s=s.replace('fields: result.columns.iter().map(|n|\n                                            field("", n, \'B\', "BINARY", false)).collect(),','fields: result.columns.iter().enumerate().map(|(i,n)|{let(a,c)=result.affinities.get(i).cloned().unwrap_or((\'B\',"BINARY".into()));field("",n,a,&c,false)}).collect(),')
start=s.index('                for o in &q.order {\n                    let v =',s.index('let order_indices='))
end=s.index('                sorted.push',start)
s=s[:start]+'''                for (oi,o) in q.order.iter().enumerate() {
                    let (v,coll)=if let Some(index)=order_indices[oi] {
                        (row[index].clone(),explicit_coll(&o.e).map(str::to_string).unwrap_or_else(||result.affinities.get(index).map(|x|x.1.clone()).unwrap_or("BINARY".into())))
                    } else {(self.eval(&o.e,&c,g,depth+1)?,self.metadata(&o.e,&c).1)};
                    keys.push((v,coll));
                }
'''+s[end:]
# integer positions include unary signs and COLLATE; ordinary validation uses resolved expression.
s=s.replace('if let E::Val(V::Int(i)) = e {\n        if *i < 1 || *i as usize > items.len()', 'if let Some(i) = order_position(e) {\n        if i < 1 || i as usize > items.len()')
s=s.replace('Ok(&items[*i as usize - 1].e)', 'Ok(&items[i as usize - 1].e)')
helpers=r'''
fn order_position(e:&E)->Option<i64>{
    match e {E::Val(V::Int(i))=>Some(*i),E::Collate(e,_)=>order_position(e),E::Unary(op,e) if op=="+"=>order_position(e),E::Unary(op,e) if op=="-"=>order_position(e)?.checked_neg(),_=>None}
}
fn order_expression(e:&E)->&E{if let E::Collate(e,_)=e{order_expression(e)}else{e}}
fn same_expression(a:&E,b:&E)->bool{
    match (a,b){
        (E::Col(a),E::Col(b))=>a.last().zip(b.last()).is_some_and(|(a,b)|a.eq_ignore_ascii_case(b))&&(a.len()==1||b.len()==1||a.iter().zip(b).all(|(a,b)|a.eq_ignore_ascii_case(b))),
        (E::Call(a,aa,ad,af),E::Call(b,ba,bd,bf))=>a.eq_ignore_ascii_case(b)&&ad==bd&&aa.len()==ba.len()&&aa.iter().zip(ba).all(|(a,b)|same_expression(a,b))&&match(af,bf){(None,None)=>true,(Some(a),Some(b))=>same_expression(a,b),_=>false},
        (E::Bin(a,al,ar),E::Bin(b,bl,br))=>a==b&&same_expression(al,bl)&&same_expression(ar,br),
        (E::Unary(a,ae),E::Unary(b,be))|(E::Cast(ae,a),E::Cast(be,b))|(E::Collate(ae,a),E::Collate(be,b))=>a.eq_ignore_ascii_case(b)&&same_expression(ae,be),
        _=>serde_json::to_value(a).ok()==serde_json::to_value(b).ok()
    }
}
fn resolve_order(orders:&[Order],branches:&[Vec<Item>],compound:bool)->Res<Vec<Option<usize>>>{
    let width=branches.first().map_or(0,Vec::len);
    orders.iter().map(|order|{
        if let Some(n)=order_position(&order.e){if n<1||n as usize>width{return Err("ORDER BY term out of range".into())}return Ok(Some(n as usize-1))}
        let e=order_expression(&order.e);
        for items in branches{
            if let E::Col(n)=e{if n.len()==1{if let Some(i)=items.iter().position(|item|item.alias.as_ref().unwrap_or(&item.name).eq_ignore_ascii_case(&n[0])){return Ok(Some(i))}}}
            if let Some(i)=items.iter().position(|item|same_expression(e,order_expression(&item.e))){return Ok(Some(i))}
        }
        if compound{Err("ORDER BY term does not match any column in the result set".into())}else{Ok(None)}
    }).collect()
}
fn inherit_compound_collations(left:&mut ResultSet,right:&ResultSet){
    for i in 0..left.affinities.len(){if !left.coll_sources.get(i).copied().unwrap_or(false)&&right.coll_sources.get(i).copied().unwrap_or(false){
        if let Some((_,coll))=right.affinities.get(i){left.affinities[i].1=coll.clone();if let Some(src)=left.coll_sources.get_mut(i){*src=true}}
    }}
}
'''
s=s.replace("fn ordinal<'a>",helpers+"\nfn ordinal<'a>")
p.write_text(s)
