from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text().replace('pub struct WinSpec {\n','pub struct WinSpec {\n    #[serde(default)] pub reference_only: bool,\n').replace('WinSpec { base: Some(self.ident()?), ..Default::default() }','WinSpec { reference_only:true, base: Some(self.ident()?), ..Default::default() }');p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
a=s.index('        let mut spec = spec.clone();',s.index('fn window_eval'))
b=s.index('        let mut partition = vec![];',a)
s=s[:a]+'''        let spec = resolve_window(spec,&env.named,&mut vec![])?;
        self.validate_window_frame(&spec,ctx)?;
'''+s[b:]
s=s.replace('let offset = at(e, pos)?;', "let offset = at(e, pos)?.apply('N');")
s=s.replace('pos as i64 +\n                                        if *following { offset.i64() } else { -offset.i64() }','(pos as i64).saturating_add(if *following { offset.i64() } else { -offset.i64() })')
s=s.replace('groupids[pos] +\n                                            if *following { offset.i64() } else { -offset.i64() }','(groupids[pos] as i64).saturating_add(if *following { offset.i64() } else { -offset.i64() })')
s=s.replace('pos as i64 + if name == "lag" { -offset } else { offset }','(pos as i64).saturating_add(if name == "lag" { offset.saturating_neg() } else { offset })')
# bindctx resolves windows even when no rows qualify
s=s.replace('Ctx { row: vec![V::Null;base.fields.len()], ..base.clone() };\n            for item', 'Ctx { row: vec![V::Null;base.fields.len()],win:Some(WinCtx{rows:vec![],groups:vec![],index:0,named:q.windows.iter().map(|(n,w)|(key(n),w.clone())).collect()}), ..base.clone() };\n            for (_,w) in &q.windows { let w=resolve_window(w,&bindctx.win.as_ref().unwrap().named,&mut vec![])?; self.validate_window_frame(&w,&bindctx)?; for e in &w.partition{self.validate_expr(e,&bindctx)?;} for o in &w.order{self.validate_expr(&o.e,&bindctx)?;} }\n            for item')
# Move aggregate detection and HAVING validation before early binding return
old='''            let aggregated =
                !q.group.is_empty() || items.iter().any(|i| has_agg(&i.e)) ||
                    q.having.as_ref().map_or(false, has_agg);
            if q.having.is_some() && !aggregated {
                return Err("HAVING clause on a non-aggregate query".into())
            }
'''
assert old in s;s=s.replace(old,'')
at=s.index('            if base.binding {\n                let mut result=ResultSet')
s=s[:at]+'''            let aggregated = !q.group.is_empty()||items.iter().any(|i|has_agg(&i.e))||q.having.as_ref().is_some_and(has_agg)||q.order.iter().any(|o|has_agg(&o.e));
            if q.having.is_some()&&!aggregated{return Err("HAVING clause on a non-aggregate query".into())}
'''+s[at:]
s=s.replace('if has_agg(e) || has_window(e) {\n                    return Err("misuse of aggregate or window function".into())','if self.alias_has_kind(e,&items,&base,false)||self.alias_has_kind(e,&items,&base,true) {\n                    return Err("misuse of aggregate or window function".into())',1)
s=s.replace('''                if has_agg(e) || has_window(e) {
                    return Err("aggregate functions are not allowed in GROUP BY".into())
                }
                self.validate_expr(ordinal(e, &items)?, &bindctx)?;''','''                let e=ordinal(e,&items)?;
                if self.alias_has_kind(e,&items,&base,false)||self.alias_has_kind(e,&items,&base,true){return Err("aggregate or window functions are not allowed in GROUP BY".into())}
                self.validate_expr(e,&bindctx)?;''')
s=s.replace('if let Some(e) = &q.having { self.validate_expr(e, &bindctx)?; }','if let Some(e) = &q.having {if self.alias_has_kind(e,&items,&base,true){return Err("misuse of window function".into())}self.validate_expr(e, &bindctx)?; }')
# validation generic call
s=s.replace('''            E::Call(n, args, _, filter) => {
                let n = n.to_ascii_lowercase();
                crate::funcs::check_arity(&n, args.len())?;''','''            E::Call(n, args, distinct, filter) => {
                let n = n.to_ascii_lowercase();
                crate::funcs::check_arity(&n, args.len())?;
                let aggregate=is_aggregate(&n,args.len());
                if is_window_builtin(&n){return Err(format!("misuse of window function {}()",n))}
                if args.iter().any(|e|matches!(e,E::Star(_)))&&(n!="count"||*distinct){return Err("invalid use of * in function".into())}
                if *distinct&&aggregate&&args.len()!=1{return Err("DISTINCT aggregates must have exactly one argument".into())}
                if filter.is_some()&&!aggregate{return Err("FILTER may only be used with aggregate functions".into())}
                if aggregate&&(args.iter().any(|e|has_agg(e)||has_window(e))||filter.as_ref().is_some_and(|e|has_agg(e)||has_window(e))){return Err("misuse of nested aggregate or window function".into())}''')
a=s.index('            E::Window(call, w) => {',s.index('fn validate_expr'))
b=s.index('            E::Between(',a)
s=s[:a]+'''            E::Window(call,w)=>{
                let (name,args,distinct,filter)=match call.as_ref(){E::Call(n,a,d,f)=>(key(n),a,*d,f),_=>return Err("ORDER BY arguments are not supported for window functions".into())};
                crate::funcs::check_arity(&name,args.len())?;
                if !is_window_builtin(&name)&&!is_aggregate(&name,args.len()){return Err(format!("{}() may not be used as a window function",name))}
                if distinct{return Err("DISTINCT is not supported for window functions".into())}
                if filter.is_some()&&!is_aggregate(&name,args.len()){return Err("FILTER may only be used with aggregate window functions".into())}
                for e in args{if has_window(e){return Err("misuse of nested window function".into())}if matches!(e,E::Star(_)){if name!="count"{return Err("invalid use of *".into())}}else{self.validate_expr(e,c)?}}
                if let Some(e)=filter{if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function in FILTER".into())}self.validate_expr(e,c)?}
                let named=c.win.as_ref().ok_or("misuse of window function")?;
                let w=resolve_window(w,&named.named,&mut vec![])?;
                self.validate_window_frame(&w,c)?;
                for e in w.partition.iter().chain(w.order.iter().map(|o|&o.e)){if has_window(e){return Err("misuse of nested window function".into())}self.validate_expr(e,c)?;}
            }
            E::OrderedCall(call,orders)=>{
                if !matches!(call.as_ref(),E::Call(n,a,_,_) if is_aggregate(&key(n),a.len())){return Err("ORDER BY may only be used with aggregate functions".into())}
                self.validate_expr(call,c)?;
                for o in orders{if has_agg(&o.e)||has_window(&o.e){return Err("misuse of nested aggregate or window function".into())}self.validate_expr(&o.e,c)?;}
            }
'''+s[b:]
# methods
a=s.index('    fn validate_expr(')
s=s[:a]+'''    fn alias_has_kind(&self,e:&E,items:&[Item],ctx:&Ctx,window:bool)->bool{
        if if window{has_window(e)}else{has_agg(e)}{return true}
        if let E::Col(n)=e{if n.len()==1&&Self::colindex(ctx,n).ok().flatten().is_none(){if let Some(item)=items.iter().find(|i|i.alias.as_ref().is_some_and(|a|a.eq_ignore_ascii_case(&n[0]))){return if window{has_window(&item.e)}else{has_agg(&item.e)}}}}
        child_exprs(e).iter().any(|e|self.alias_has_kind(e,items,ctx,window))
    }
    fn validate_window_frame(&self,w:&WinSpec,c:&Ctx)->Res<()>{
        let start=w.start.as_ref().unwrap_or(&Bound::Unbounded(false));
        let end=w.end.as_ref().unwrap_or(&Bound::Current);
        let category=|b:&Bound|match b{Bound::Unbounded(false)=>0,Bound::Offset(_,false)=>1,Bound::Current=>2,Bound::Offset(_,true)=>3,Bound::Unbounded(true)=>4};
        if matches!(start,Bound::Unbounded(true))||matches!(end,Bound::Unbounded(false))||category(end)<category(start){return Err("unsupported frame specification".into())}
        for b in [start,end]{if let Bound::Offset(e,_)=b{
            if !column_refs(e).is_empty()||has_subquery(e)||has_agg(e)||has_window(e)||nondeterministic(e){return Err("frame offset must be constant".into())}
            self.validate_expr(e,c)?;
            let v=self.eval(e,c,None,0)?.apply('N');
            if !matches!(v,V::Int(_)|V::Real(_))||!v.f64().is_finite()||v.f64()<0.0{return Err("frame offset must be a non-negative number".into())}
            if w.frame.as_deref()!=Some("RANGE")&&v.f64().fract()!=0.0{return Err("frame offset must be a non-negative integer".into())}
            if w.frame.as_deref()==Some("RANGE")&&w.order.len()!=1{return Err("RANGE with offset requires one ORDER BY expression".into())}
        }}
        Ok(())
    }
'''+s[a:]
a=s.index('fn has_agg(e:');b=s.index('fn roweq(',a)
s=s[:a]+'''fn has_agg(e:&E)->bool{
    match e{
        E::Call(n,a,_,_)=>is_aggregate(&key(n),a.len())||child_exprs(e).iter().any(|e|has_agg(e)),
        E::Window(call,w)=>{let nested=match call.as_ref(){E::Call(_,a,_,f)=>a.iter().any(has_agg)||f.as_ref().is_some_and(|f|has_agg(f)),_=>false};nested||w.partition.iter().any(has_agg)||w.order.iter().any(|o|has_agg(&o.e))},
        _=>child_exprs(e).iter().any(|e|has_agg(e))
    }
}
fn is_window_builtin(n:&str)->bool{["row_number","rank","dense_rank","percent_rank","cume_dist","ntile","lag","lead","first_value","last_value","nth_value"].contains(&n)}
fn resolve_window(w:&WinSpec,named:&BTreeMap<String,WinSpec>,stack:&mut Vec<String>)->Res<WinSpec>{
    let mut out=w.clone();
    if let Some(name)=&w.base{
        let k=key(name);if stack.contains(&k){return Err("circular window definition".into())}stack.push(k.clone());
        let base=named.get(&k).ok_or_else(||format!("no such window: {}",name))?;
        let base=resolve_window(base,named,stack)?;stack.pop();
        if w.reference_only{return Ok(base)}
        if !out.partition.is_empty(){return Err("cannot override PARTITION clause of window".into())}
        if !out.order.is_empty()&&!base.order.is_empty(){return Err("cannot override ORDER BY clause of window".into())}
        if base.frame.is_some(){return Err("cannot override frame specification of window".into())}
        out.partition=base.partition;if out.order.is_empty(){out.order=base.order}
        out.base=None;
    }
    Ok(out)
}
'''+s[b:]
# Walk filters and argument order clauses in aggregate detection/validation utilities.
s=s.replace('''        E::Unary(_, a) | E::Cast(a, _) | E::Collate(a, _) |
            E::OrderedCall(a, _) => vec![a],''','''        E::Unary(_, a) | E::Cast(a, _) | E::Collate(a, _) => vec![a],
        E::OrderedCall(a,orders)=>{let mut v=vec![a.as_ref()];v.extend(orders.iter().map(|o|&o.e));v},''')
s=s.replace('        E::Call(_, a, _, _) | E::Tuple(a) => a.iter().collect(),','        E::Call(_, a, _, f) => {let mut v=a.iter().collect::<Vec<_>>();if let Some(f)=f{v.push(f)}v},\n        E::Tuple(a)=>a.iter().collect(),')
p.write_text(s)
