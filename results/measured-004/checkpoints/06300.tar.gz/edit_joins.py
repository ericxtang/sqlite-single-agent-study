from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text().replace('pub enum Source {\n','pub enum Source {\n    Join(Vec<Join>),\n')
s=s.replace('''                    let a = self.query()?;
                    self.expect(")")?;
                    Source::Query(Box::new(a))''','''                    let source=if self.at("SELECT")||self.at("WITH")||self.at("VALUES"){Source::Query(Box::new(self.query()?))}else{Source::Join(self.sources()?)};
                    self.expect(")")?;
                    source''')
s=s.replace('''            from.push(Join {
                    source,''','''            if on.is_some()&&!using.is_empty(){return Err("a join cannot have both ON and USING clauses".into())}
            if natural&&(on.is_some()||!using.is_empty()){return Err("a NATURAL join may not have ON or USING clauses".into())}
            from.push(Join {
                    source,''')
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
a=s.index('            let mut data = Data { fields: vec![], rows: vec![vec![]] };',s.index('pub fn query'))
b=s.index('            base.fields = data.fields.clone();',a)
join=s[a:b].replace('for j in &q.from','for j in from').replace('&base,','ctx,').replace('..base.clone()','..ctx.clone()').replace('base.binding','ctx.binding')
# Always bind ON before processing rows, including empty inputs.
join=join.replace('if ctx.binding {let row=vec![V::Null;fields.len()];', '''if let Some(e)=&j.on{if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function in ON".into())}let c=Ctx{fields:fields.clone(),row:vec![V::Null;fields.len()],..ctx.clone()};self.validate_expr(e,&c)?}
                    if ctx.binding {let row=vec![V::Null;fields.len()];''')
join=join.replace('''cmp(&l[*a], &r[*b], &data.fields[*a].coll) !=
                                        Ordering::Equal''','''self.compare(&E::Bound(l[*a].clone(),data.fields[*a].aff,data.fields[*a].coll.clone(),true),&E::Bound(r[*b].clone(),right.fields[*b].aff,right.fields[*b].coll.clone(),true),&l[*a],&r[*b],&c)!=Ordering::Equal''')
s=s[:a]+'''            let data=self.join_sources(&q.from,&base,depth)?;
'''+s[b:]
at=s.index('    fn recursive_cte(')
s=s[:at]+'''    fn join_sources(&self,from:&[Join],ctx:&Ctx,depth:usize)->Res<Data>{
        if depth>80{return Err("join nesting limit exceeded".into())}
'''+join+'''        Ok(data)
    }
'''+s[at:]
a=s.index('            Source::Query(q) => {',s.index('    fn source'))
s=s[:a]+'''            Source::Join(joins)=>{
                let mut data=self.join_sources(joins,ctx,depth+1)?;
                if let Some(alias)=alias{for f in &mut data.fields{f.table=alias.clone()}}
                Ok(data)
            }
'''+s[a:]
s=s.replace('Source::Query(_) => "SUBQUERY".into(),','Source::Query(_) => "SUBQUERY".into(),\n                                    Source::Join(_) => "JOIN".into(),')
# Recursive-reference and dependency searches use existing Query walker for groups.
s=s.replace('Source::Query(q)=>query_table_references(q,name),Source::Function', 'Source::Query(q)=>query_table_references(q,name),Source::Join(joins)=>query_table_references(&Query{from:joins.clone(),..Default::default()},name),Source::Function')
s=s.replace('Source::Query(q) => query_uses(q, n),','Source::Query(q) => query_uses(q, n),\n                        Source::Join(joins)=>query_uses(&Query{from:joins.clone(),..Default::default()},n),')
p.write_text(s)
