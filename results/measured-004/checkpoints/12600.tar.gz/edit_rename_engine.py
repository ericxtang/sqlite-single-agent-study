from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text().replace('Stmt::CreateTrigger(t)=>','Stmt::CreateTrigger(t,_)=>');p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
start=s.index('            Alter::Rename(new) =>')
end=s.index('            Alter::Add(',start)
part=s[start:end].replace('rewrite_identifier(', 'rewrite_table_identifier(')
part=part.replace(', n, &new)?', ', &self.namespace, n, &new)?')
part=part.replace('if self.db.tables.contains_key(&key(&new)) {','if self.db.tables.contains_key(&key(&new))||self.db.views.contains_key(&key(&new))||self.db.indexes.contains_key(&key(&new))||key(&new).starts_with("sqlite_") {')
# Let the parser identify dependencies even in scalar subqueries.
part=part.replace('if query_uses(&view.q, n) {','{')
# Correct internal autoindex names and their statistics.
needle='''                for child in self.db.tables.values_mut() {'''
part=part.replace(needle,'''                let old_prefix=format!("sqlite_autoindex_{}_",n);
                let renamed_indexes=self.db.indexes.iter().filter(|(_,idx)|idx.table.eq_ignore_ascii_case(&new)&&idx.origin!="c").map(|(k,idx)|(k.clone(),idx.name.clone())).collect::<Vec<_>>();
                for(oldkey,oldname)in renamed_indexes{
                    let mut idx=self.db.indexes.remove(&oldkey).unwrap();
                    if oldname.len()>=old_prefix.len(){
                        idx.name=format!("sqlite_autoindex_{}_{}",new,&oldname[old_prefix.len()..]);
                        if let Some(stat)=self.db.tables.get_mut("sqlite_stat1"){
                            for row in &mut stat.rows{if row.v[1].text()==oldname{row.v[1]=V::Text(idx.name.clone());}}
                        }
                    }
                    self.db.indexes.insert(key(&idx.name),idx);
                }
'''+needle,1)
s=s[:start]+part+s[end:]
# Rename column requires immutable access to old bindings before editing dependent objects.
start=s.index('            Alter::RenameCol(old, new) =>')
end=s.index('                self.db.tables.insert(k, t);',start)
part=s[start:end]
part=part.replace('t.sql = rewrite_identifier(&t.sql, &old, &new)?;','let schema=self.clone();\n                t.sql = schema.rewrite_column_identifier(&t.sql,n,&old,&new)?;')
part=part.replace('rewrite_identifier(&idx.sql, &old, &new)?','schema.rewrite_column_identifier(&idx.sql,n,&old,&new)?')
part=part.replace('if query_uses(&view.q, n) {','{')
part=part.replace('rewrite_identifier(&view.sql, &old, &new)?','schema.rewrite_column_identifier(&view.sql,n,&old,&new)?')
part=part.replace('''self.db.triggers.values_mut().filter(|tr|
                            tr.table.eq_ignore_ascii_case(n))''','self.db.triggers.values_mut()')
part=part.replace('rewrite_identifier(&trigger.sql, &old, &new)?','schema.rewrite_column_identifier(&trigger.sql,n,&old,&new)?')
part=part.replace('''                for child in self.db.tables.values_mut() {
                    for f in &mut child.foreign {''','''                for child in self.db.tables.values_mut() {
                    child.sql=schema.rewrite_column_identifier(&child.sql,n,&old,&new)?;
                    for f in &mut child.foreign {''')
s=s[:start]+part+s[end:]
# Retain original query binding after the complete rename; ambiguity must abort.
needle='''        self.db.schema_version += 1;
        Ok(ResultSet::default())
    }
}
fn integer_pk'''
s=s.replace(needle,'''        self.db.schema_version += 1;
        Ok(ResultSet::default())
    }
    fn rewrite_column_identifier(&self,sql:&str,table:&str,old:&str,new:&str)->Res<String>{
        if sql.is_empty(){return Ok(sql.into())}
        let mut p=Parser::new(sql)?;p.tracking=true;p.statement()?;
        let mut positions=std::collections::BTreeSet::new();
        for sites in &p.column_sites{
            let pos=*sites.last().unwrap();
            if !p.ts[pos].s.eq_ignore_ascii_case(old){continue}
            let qualifier=if sites.len()>1{Some(p.ts[sites[sites.len()-2]].s.as_str())}else{None};
            if self.rename_column_binding(&p,pos,qualifier,table,old)?{positions.insert(pos);}
        }
        for &pos in &p.declarations{
            if p.ts[pos].s.eq_ignore_ascii_case(old)&&self.rename_column_binding(&p,pos,None,table,old)?{positions.insert(pos);}
        }
        for(parent,pos)in &p.foreign_sites{
            if same_schema_table(parent,&self.namespace,table)&&p.ts[*pos].s.eq_ignore_ascii_case(old){positions.insert(*pos);}
        }
        replace_sites(sql,&p.ts,&positions,new)
    }
    fn rename_column_binding(&self,p:&Parser,pos:usize,qualifier:Option<&str>,table:&str,column:&str)->Res<bool>{
        for scope in rename_scopes(p,pos){
            let mut candidates=vec![];
            for(source,alias)in rename_sources(&scope.query.from){
                let name=match source{Source::Table(n)=>n.as_str(),_=>""};
                let visible=alias.as_deref().unwrap_or_else(||name.rsplit('.').next().unwrap_or(name));
                if qualifier.is_some_and(|q|!q.eq_ignore_ascii_case(visible)){continue}
                // A CTE shadows a persistent table of the same name.
                if !name.contains('.')&&cte_shadows(p,pos,name){
                    if qualifier.is_some(){return Ok(false)}
                    continue
                }
                let target=same_schema_table(name,&self.namespace,table);
                let has_column=if target{true}else{
                    self.source(source,alias,&Ctx{binding:true,..Default::default()},0).map(|d|d.fields.iter().any(|f|f.name.eq_ignore_ascii_case(column))).unwrap_or(false)
                };
                if has_column{candidates.push(target);}
                else if qualifier.is_some(){return Ok(false)}
            }
            if !candidates.is_empty(){
                if candidates.iter().any(|b|*b)&&candidates.iter().any(|b|!*b){return Err(format!("ambiguous column name: {}",column))}
                return Ok(candidates[0])
            }
        }
        Ok(false)
    }
}
fn integer_pk''',1)
start=s.index('fn rewrite_identifier(');end=s.index('fn query_uses(',start)
s=s[:start]+'''fn replace_sites(sql:&str,ts:&[Tok],positions:&std::collections::BTreeSet<usize>,new:&str)->Res<String>{
    let mut out=String::new();let mut last=0;
    for &i in positions{let t=&ts[i];out.push_str(&sql[last..t.start]);out.push_str(&quote_ident(new));last=t.end;}
    out.push_str(&sql[last..]);Ok(out)
}
fn same_schema_table(name:&str,namespace:&str,table:&str)->bool{
    match name.rsplit_once('.'){Some((schema,name))=>schema.eq_ignore_ascii_case(namespace)&&name.eq_ignore_ascii_case(table),None=>name.eq_ignore_ascii_case(table)}
}
fn rename_scopes<'a>(p:&'a Parser,pos:usize)->Vec<&'a RenameScope>{
    let mut scopes=p.scopes.iter().filter(|s|s.start<=pos&&pos<s.end).collect::<Vec<_>>();
    scopes.sort_by_key(|s|s.end-s.start);scopes
}
fn rename_sources(joins:&[Join])->Vec<(&Source,&Option<String>)>{
    let mut out=vec![];
    for j in joins{if let Source::Join(nested)=&j.source{if j.alias.is_none(){out.extend(rename_sources(nested));continue}}
        out.push((&j.source,&j.alias));}
    out
}
fn cte_shadows(p:&Parser,pos:usize,name:&str)->bool{
    rename_scopes(p,pos).iter().any(|s|s.query.ctes.iter().any(|(n,_,_)|n.eq_ignore_ascii_case(name)))
}
fn rewrite_table_identifier(sql:&str,namespace:&str,old:&str,new:&str)->Res<String>{
    if sql.is_empty(){return Ok(sql.into())}
    let mut p=Parser::new(sql)?;p.tracking=true;p.statement()?;
    let mut positions=std::collections::BTreeSet::new();
    for &i in &p.table_sites{
        if !p.ts[i].s.eq_ignore_ascii_case(old){continue}
        if i>=2&&p.ts[i-1].s=="."{if !p.ts[i-2].s.eq_ignore_ascii_case(namespace){continue}}
        else if cte_shadows(&p,i,old){continue}
        positions.insert(i);
    }
    for sites in &p.column_sites{
        if sites.len()<2{continue}
        let i=sites[sites.len()-2];
        if !p.ts[i].s.eq_ignore_ascii_case(old){continue}
        if sites.len()>2&&!p.ts[sites[sites.len()-3]].s.eq_ignore_ascii_case(namespace){continue}
        for scope in rename_scopes(&p,i){
            let mut found=None;
            for(source,alias)in rename_sources(&scope.query.from){
                let name=match source{Source::Table(n)=>n.as_str(),_=>""};
                if alias.as_deref().is_some_and(|a|a.eq_ignore_ascii_case(old)){found=Some(false);break}
                if alias.is_none()&&name.rsplit('.').next().is_some_and(|n|n.eq_ignore_ascii_case(old)){
                    found=Some(same_schema_table(name,namespace,old)&&!cte_shadows(&p,i,name));break
                }
            }
            if let Some(rename)=found{if rename{positions.insert(i);}break}
        }
    }
    replace_sites(sql,&p.ts,&positions,new)
}
'''+s[end:]
p.write_text(s)
