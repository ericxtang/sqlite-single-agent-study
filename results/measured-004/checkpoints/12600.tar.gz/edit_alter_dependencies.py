from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
# Keep every row-independent piece of a renamed schema expression.
start=s.index('fn rename_expr(');end=s.index('\nfn find_minmax',start)
s=s[:start]+'''fn rename_expr(e:&mut E,old:&str,new:&str){
    match e{
        E::Col(n)=>{if n.last().is_some_and(|n|n.eq_ignore_ascii_case(old)){*n.last_mut().unwrap()=new.into();}}
        E::Quoted(n)=>{if n.eq_ignore_ascii_case(old){*n=new.into()}}
        E::Unary(_,a)|E::Cast(a,_)|E::Collate(a,_)=>rename_expr(a,old,new),
        E::Bin(_,a,b)=>{rename_expr(a,old,new);rename_expr(b,old,new);}
        E::Call(_,args,_,filter)=>{for e in args{rename_expr(e,old,new)}if let Some(e)=filter{rename_expr(e,old,new)}}
        E::Tuple(es)=>{for e in es{rename_expr(e,old,new)}}
        E::Between(a,b,c,_)|E::Like(a,b,Some(c),_,_)=>{rename_expr(a,old,new);rename_expr(b,old,new);rename_expr(c,old,new);}
        E::Like(a,b,None,_,_)=>{rename_expr(a,old,new);rename_expr(b,old,new);}
        E::In(a,args,_,_)=>{rename_expr(a,old,new);for e in args{rename_expr(e,old,new)}}
        E::Case(base,arms,end)=>{if let Some(e)=base{rename_expr(e,old,new)}for(a,b)in arms{rename_expr(a,old,new);rename_expr(b,old,new)}if let Some(e)=end{rename_expr(e,old,new)}}
        _=>{}
    }
}
'''+s[end:]
start=s.index('            Alter::Drop(n) => {');end=s.index('            Alter::RenameCol(',start)
s=s[:start]+'''            Alter::Drop(column)=>{
                let i=t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(&column)).ok_or_else(||format!("no such column: {}",column))?;
                if t.cols.len()==1||t.cols[i].pk>0||t.cols[i].unique{return Err("cannot drop constrained column".into())}
                let refers=|e:&E|column_refs(e).iter().any(|c|c.eq_ignore_ascii_case(&column));
                if t.cols.iter().enumerate().filter(|(j,_)|*j!=i).filter_map(|(_,c)|c.generated.as_ref()).any(&refers)
                    ||self.db.indexes.values().filter(|x|x.table.eq_ignore_ascii_case(&t.name)).any(|idx|idx.expr.iter().any(&refers)||idx.filter.as_ref().is_some_and(&refers)){
                    return Err("cannot drop column referenced by generated column or index".into())
                }
                if t.foreign.iter().any(|f|f.cols.iter().any(|n|n.eq_ignore_ascii_case(&column)))
                    ||self.db.tables.values().flat_map(|t|&t.foreign).any(|f|f.table.eq_ignore_ascii_case(&t.name)&&f.target.iter().any(|n|n.eq_ignore_ascii_case(&column))){
                    return Err("cannot drop column used by a foreign key".into())
                }
                for trigger in self.db.triggers.values(){
                    let tokens=lex(&trigger.sql)?;
                    let related=trigger.table.eq_ignore_ascii_case(&t.name)||tokens.iter().any(|tok|tok.k!=1&&tok.s.eq_ignore_ascii_case(&t.name));
                    if related&&tokens.iter().any(|tok|tok.k!=1&&tok.s.eq_ignore_ascii_case(&column)){return Err(format!("cannot drop column referenced by trigger {}",trigger.name))}
                }
                t.sql=drop_column_sql(&t.sql,&column)?;
                let parsed=match Parser::parse(&t.sql)?{Stmt::Temp(s)=>*s,s=>s};
                if let Stmt::CreateTable{checks,..}=parsed{t.checks=checks}
                else{return Err("invalid CREATE TABLE definition".into())}
                t.cols.remove(i);for row in &mut t.rows{row.v.remove(i);}
                let ctx=self.rowctx(&t,&Row{id:0,v:vec![V::Null;t.cols.len()]},None);
                for e in &t.checks{self.validate_expr(e,&ctx)?;}
                let mut schema=self.clone();schema.db.tables.insert(k.clone(),t.clone());
                for v in schema.db.views.values(){
                    schema.source(&Source::Table(format!("{}.{}",self.namespace,v.name)),&None,&Ctx{binding:true,..Default::default()},0)?;
                }
                self.db.tables.insert(k,t);
            }
'''+s[end:]
# Self-references require updating the table clone as well as other stored tables.
needle='''                t.name = new.clone();
                for idx in self.db.indexes.values_mut() {'''
assert needle in s;s=s.replace(needle,'''                t.name = new.clone();
                for f in &mut t.foreign{if f.table.eq_ignore_ascii_case(n){f.table=new.clone();}}
                for idx in self.db.indexes.values_mut() {''',1)
needle='''                for cols in &mut t.unique {'''
assert needle in s;s=s.replace(needle,'''                for (cols,_)in &mut t.policies{for c in cols{if c.eq_ignore_ascii_case(&old){*c=new.clone()}}}
                for cols in &mut t.unique {''',1)
needle='''                for f in &mut t.foreign {
                    for c in &mut f.cols {
                        if c.eq_ignore_ascii_case(&old) { *c = new.clone() }
                    }
                }'''
assert needle in s;s=s.replace(needle,'''                for f in &mut t.foreign {
                    for c in &mut f.cols {
                        if c.eq_ignore_ascii_case(&old) { *c = new.clone() }
                    }
                    if f.table.eq_ignore_ascii_case(n){for c in &mut f.target{if c.eq_ignore_ascii_case(&old){*c=new.clone()}}}
                }''')
# Strict ANY generated values retain the expression's storage class.
needle='''                    row.v[i] =
                        self.eval(e, &ctx, None, 0)?.apply(affinity(&c.typ))'''
assert needle in s;s=s.replace(needle,'''                    let value=self.eval(e,&ctx,None,0)?;
                    row.v[i]=if t.strict&&c.typ.eq_ignore_ascii_case("ANY"){value}else{value.apply(affinity(&c.typ))}''')
p.write_text(s)
