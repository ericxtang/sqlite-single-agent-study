from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace("pub struct Parser<'a> {",'''#[derive(Clone,Debug)]
pub struct RenameScope { pub start:usize,pub end:usize,pub query:Query }
pub struct Parser<'a> {
    pub tracking:bool,
    pub table_sites:Vec<usize>,
    pub column_sites:Vec<Vec<usize>>,
    pub declarations:Vec<usize>,
    pub foreign_sites:Vec<(String,usize)>,
    pub scopes:Vec<RenameScope>,''')
s=s.replace('Ok(Self { ts: lex(sql)?, p: 0, sql })','''Ok(Self { ts: lex(sql)?, p: 0, sql,tracking:false,table_sites:vec![],column_sites:vec![],declarations:vec![],foreign_sites:vec![],scopes:vec![] })''')
pos=s.index('    fn names(&mut self)')
s=s[:pos]+'''    fn table_name(&mut self)->Res<String>{
        let name=self.name()?;if self.tracking{self.table_sites.push(self.p-1);}Ok(name)
    }
    fn column_ident(&mut self)->Res<String>{
        let name=self.ident()?;if self.tracking{self.declarations.push(self.p-1);}Ok(name)
    }
    fn column_names(&mut self)->Res<Vec<String>>{
        let start=self.p;let names=self.names()?;
        if self.tracking{
            let mut p=start+1;
            while p<self.p-1{self.declarations.push(p);p+=1;while p<self.p-1&&!self.ts[p].s.eq(","){p+=1;}p+=1;}
        }
        Ok(names)
    }
    fn record_scope(&mut self,start:usize,q:Query){
        if self.tracking{self.scopes.push(RenameScope{start,end:self.p,query:q});}
    }
'''+s[pos:]
# Table names used in references, declarations, and DML targets.
s=s.replace('let table = self.name()?;','let table = self.table_name()?;')
s=s.replace('let name = self.name()?;\n                        q =','let name = self.table_name()?;\n                        q =',1)
a=s.index('            if self.eat("TABLE") {')
b=s.index('            if self.eat("INDEX") {',a)
part=s[a:b].replace('let name = self.name()?;','let name = self.table_name()?;',1)
part=part.replace('let n = self.names()?;','let n = self.column_names()?;',1)
s=s[:a]+part+s[b:]
a=s.index('    fn sources(');b=s.index('    fn window(',a)
part=s[a:b].replace('let n = self.name()?;','let n = self.table_name()?;',1)
part=part.replace('if self.eat("(") {\n                        let args =','if self.eat("(") {\n                        if self.tracking{self.table_sites.pop();}\n                        let args =',1)
part=part.replace('if self.eat("USING") { self.names()? }','if self.eat("USING") { self.column_names()? }')
s=s[:a]+part+s[b:]
# Expression column spans retain each qualifier and the final column.
s=s.replace('let mut n = vec![t.s];','let mut sites=vec![self.p-1];\n                            let mut n = vec![t.s];',1)
s=s.replace('if self.eat("*") { return Ok(E::Star(Some(n.join(".")))) }','''if self.eat("*") {
                                    sites.push(self.p-1);if self.tracking{self.column_sites.push(sites);}
                                    return Ok(E::Star(Some(n.join("."))))
                                }''',1)
s=s.replace('n.push(self.ident()?)','n.push(self.ident()?);sites.push(self.p-1)',1)
s=s.replace('if n.len() == 1 && t.k == 4 {','if self.tracking{self.column_sites.push(sites);}\n                            if n.len() == 1 && t.k == 4 {',1)
a=s.index('    fn key_columns');b=s.index('    pub fn expr',a)
s=s[:a]+s[a:b].replace('let n = self.ident()?;','let n = self.column_ident()?;',1)+s[b:]
a=s.index('    fn column(');b=s.index('    fn sets(',a)
s=s[:a]+s[a:b].replace('let name = self.ident()?;','let name = self.column_ident()?;',1)+s[b:]
a=s.index('    fn foreign(');b=s.index('    fn column(',a)
part=s[a:b].replace('let target = if self.at("(") { self.names()? } else { vec![] };','''let start=self.p;
        let target = if self.at("(") { self.names()? } else { vec![] };
        if self.tracking&&!target.is_empty(){let mut p=start+1;while p<self.p-1{self.foreign_sites.push((table.clone(),p));p+=1;while p<self.p-1&&self.ts[p].s!=","{p+=1;}p+=1;}}''')
s=s[:a]+part+s[b:]
a=s.index('    fn sets(');b=s.index('    fn returning(',a)
part=s[a:b].replace('self.names()?','self.column_names()?').replace('let n = self.ident()?;','let n = self.column_ident()?;')
s=s[:a]+part+s[b:]
# Capture query scopes, including separate compound SELECT cores.
s=s.replace('    pub fn query(&mut self) -> Res<Query> {','''    pub fn query(&mut self)->Res<Query>{
        let start=self.p;let q=self.query_inner()?;if self.tracking{self.record_scope(start,q.clone());}Ok(q)
    }
    fn query_inner(&mut self) -> Res<Query> {''',1)
s=s.replace('    fn core(&mut self, q: &mut Query) -> Res<()> {','''    fn core(&mut self,q:&mut Query)->Res<()>{
        let start=self.p;self.core_inner(q)?;if self.tracking{self.record_scope(start,q.clone());}Ok(())
    }
    fn core_inner(&mut self, q: &mut Query) -> Res<()> {''',1)
s=s.replace('    pub fn statement(&mut self) -> Res<Stmt> {','''    pub fn statement(&mut self)->Res<Stmt>{
        let start=self.p;let stmt=self.statement_inner()?;
        if self.tracking{
            let mut q=Query::default();
            let source=|table:&String,alias:Option<String>|Join{source:Source::Table(table.clone()),alias,kind:"INNER".into(),on:None,using:vec![],natural:false};
            match &stmt{
                Stmt::CreateTable{name,..}=>q.from.push(source(name,None)),
                Stmt::CreateIndex{table,..}=>q.from.push(source(table,None)),
                Stmt::CreateTrigger(t)=>{
                    q.from.push(source(&t.table,Some("old".into())));
                    q.from.push(source(&t.table,Some("new".into())));
                }
                Stmt::Insert{table,alias,..}|Stmt::Delete{table,alias,..}=>q.from.push(source(table,alias.clone())),
                Stmt::Update{table,alias,from,..}=>{q.from.push(source(table,alias.clone()));q.from.extend(from.clone());}
                _=>{}
            }
            if !q.from.is_empty(){self.record_scope(start,q);}
        }
        Ok(stmt)
    }
    fn statement_inner(&mut self) -> Res<Stmt> {''',1)
# Explicit insert columns and trigger event columns are declarations.
s=s.replace('columns.push(self.ident()?);','columns.push(self.column_ident()?);',1)
a=s.index('        if self.at("INSERT")');b=s.index('        if self.eat("UPDATE")',a)
part=s[a:b].replace('let cols = if self.at("(") { self.names()? }','let cols = if self.at("(") { self.column_names()? }',1)
s=s[:a]+part+s[b:]
p.write_text(s)
