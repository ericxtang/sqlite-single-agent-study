from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('''    Add(Column),
    Drop(String),''','''    Add(Column,Vec<E>,Vec<Foreign>,String),
    NotNull(String,bool,String),
    Drop(String),''')
old='''                } else if self.eat("ADD") {
                    self.eat("COLUMN");
                    Alter::Add(self.column(&mut vec![], &mut vec![])?)
                } else {'''
new='''                } else if self.eat("ADD") {
                    self.eat("COLUMN");
                    let start=self.ts.get(self.p).ok_or("incomplete column definition")?.start;
                    let mut checks=vec![];let mut foreign=vec![];
                    let c=self.column(&mut checks,&mut foreign)?;
                    let raw=self.sql[start..self.ts[self.p-1].end].to_string();
                    Alter::Add(c,checks,foreign,raw)
                } else if self.eat("ALTER"){
                    self.eat("COLUMN");let column=self.ident()?;
                    let enable=if self.eat("SET"){true}else{self.expect("DROP")?;false};
                    self.expect("NOT")?;self.expect("NULL")?;
                    let policy=if enable{self.conflict()?}else{"ABORT".into()};
                    Alter::NotNull(column,enable,policy)
                } else {'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
# Canonical CREATE TABLE text for CTAS remains parseable after ALTER.
needle='''                let mut rows = vec![];
                if let Some(q) = asq {'''
assert needle in s;s=s.replace(needle,'''                let mut rows = vec![];
                let ctas=asq.is_some();
                if let Some(q) = asq {''',1)
needle='''                let t =
                    Table {
                        temporary: false,
                        name,
                        cols,''';
assert needle in s;s=s.replace(needle,'''                let table_sql=if ctas{format!("CREATE TABLE {}({})",quote_ident(&name),cols.iter().map(column_sql).collect::<Vec<_>>().join(", "))}else{sql.trim().trim_end_matches(';').into()};
                let t =
                    Table {
                        temporary: false,
                        name,
                        cols,''',1)
# Replace just the table SQL assignment.
start=s.index('                let table_sql=');end=s.index('                if t.cols.iter().any',start)
part=s[start:end].replace('''sql: sql.trim().trim_end_matches(';').into(),''','''sql: table_sql,''')
s=s[:start]+part+s[end:]
start=s.index('            Alter::Add(');end=s.index('            Alter::Drop(',start)
s=s[:start]+'''            Alter::Add(c,checks,foreign,raw)=>{
                if t.cols.iter().any(|x|x.name.eq_ignore_ascii_case(&c.name)){return Err(format!("duplicate column name: {}",c.name))}
                if c.pk>0||c.unique{return Err("Cannot add a PRIMARY KEY or UNIQUE column".into())}
                if c.stored{return Err("cannot add a STORED column".into())}
                if !["binary","nocase","rtrim"].contains(&key(&c.coll).as_str()){return Err(format!("no such collation sequence: {}",c.coll))}
                if t.strict&&!["INT","INTEGER","REAL","TEXT","BLOB","ANY"].contains(&c.typ.to_ascii_uppercase().as_str()){return Err(format!("unknown datatype: {}",c.typ))}
                if c.generated.is_some()&&c.default.is_some(){return Err("generated column cannot have a DEFAULT".into())}
                if let Some(e)=&c.default{
                    if c.default_sql.as_ref().is_some_and(|s|s.starts_with('('))||!literal_default(e){return Err("Cannot add a column with non-constant default".into())}
                    self.validate_expr(e,&self.root_ctx())?;
                }
                let value=if let Some(e)=&c.default{self.eval(e,&self.root_ctx(),None,0)?}else{V::Null};
                if c.notnull&&c.generated.is_none()&&value.null(){return Err("Cannot add a NOT NULL column with default value NULL".into())}
                if self.foreign_keys&&!foreign.is_empty()&&!value.null(){return Err("Cannot add a REFERENCES column with non-NULL default value".into())}
                let added_foreign=t.foreign.len();
                for row in &mut t.rows{row.v.push(value.clone());}
                let pos=table_definition_end(&t.sql)?;
                t.sql.insert_str(pos,&format!(", {}",raw));
                t.cols.push(c.clone());t.checks.extend(checks.clone());t.foreign.extend(foreign.clone());
                let ctx=self.rowctx(&t,&Row{id:0,v:vec![V::Null;t.cols.len()]},None);
                for e in &checks{
                    if has_agg(e)||has_window(e)||has_subquery(e){return Err("invalid CHECK constraint".into())}
                    self.validate_expr(e,&ctx)?;
                }
                if let Some(e)=&c.generated{
                    if has_agg(e)||has_window(e)||has_subquery(e)||nondeterministic(e){return Err("invalid generated column expression".into())}
                    self.validate_expr(e,&ctx)?;
                }
                for f in &foreign{if !f.target.is_empty()&&f.cols.len()!=f.target.len(){return Err("foreign key column count mismatch".into())}}
                for i in 0..t.cols.len(){if generated_cycle(&t,i,&mut vec![]){return Err("generated column loop".into())}}
                for i in 0..t.rows.len(){let old=t.rows[i].clone();t.rows[i]=self.prepare_row(&t,old.v,None,Some(old.id))?;}
                if self.foreign_keys{for row in &t.rows{for i in added_foreign..t.foreign.len(){self.db.foreign_pending.insert((k.clone(),row.id,i));}}}
                self.db.tables.insert(k,t);
            }
            Alter::NotNull(name,enable,policy)=>{
                let i=t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(&name)).ok_or_else(||format!("no such column: {}",name))?;
                if t.cols[i].notnull==enable{return Ok(ResultSet::default())}
                t.sql=alter_nullability_sql(&t.sql,&name,enable,&policy)?;
                t.cols[i].notnull=enable;
                if enable{t.cols[i].policies.insert("nn".into(),policy);for row in &t.rows{self.validate_row(&t,row)?;}}
                else{t.cols[i].policies.remove("nn");}
                self.db.tables.insert(k,t);
            }
'''+s[end:]
# Add helpers that preserve original constraint SQL.
i=s.index('fn column_sql(')
s=s[:i]+'''fn literal_default(e:&E)->bool{
    match e{
        E::Val(_)|E::Quoted(_)=>true,
        E::Unary(op,e) if op=="+"||op=="-"=>matches!(e.as_ref(),E::Val(_)),
        E::Col(n)=>n.len()==1&&["true","false"].contains(&key(&n[0]).as_str()),
        _=>false,
    }
}
fn table_definition_end(sql:&str)->Res<usize>{
    let mut depth=0;
    for t in lex(sql)?{
        if t.k!=0{continue}
        if t.s=="("{depth+=1}else if t.s==")"{depth-=1;if depth==0{return Ok(t.start)}}
    }
    Err("invalid CREATE TABLE definition".into())
}
fn alter_nullability_sql(sql:&str,name:&str,enable:bool,policy:&str)->Res<String>{
    let tokens=lex(sql)?;let mut depth=0;let mut start=0;let mut segment=None;
    for(i,t)in tokens.iter().enumerate(){
        if t.k==0&&t.s=="("{depth+=1;if depth==1{start=i+1;}}
        else if t.k==0&&t.s==")"{
            if depth==1&&tokens.get(start).is_some_and(|t|t.s.eq_ignore_ascii_case(name)){segment=Some((start,i));break}
            depth-=1;
        }else if t.k==0&&t.s==","&&depth==1{
            if tokens.get(start).is_some_and(|t|t.s.eq_ignore_ascii_case(name)){segment=Some((start,i));break}start=i+1;
        }
    }
    let(start,end)=segment.ok_or("column definition missing from schema")?;
    let mut result=sql.to_string();
    if enable{result.insert_str(tokens[end].start,&format!(" NOT NULL ON CONFLICT {} ",policy));return Ok(result)}
    let mut removals=vec![];let mut depth=0;let mut i=start+1;
    while i<end{
        if tokens[i].k==0&&tokens[i].s=="("{depth+=1}
        else if tokens[i].k==0&&tokens[i].s==")"{depth-=1}
        else if depth==0&&tokens[i].k==0&&tokens[i].s.eq_ignore_ascii_case("NOT")&&tokens.get(i+1).is_some_and(|t|t.s.eq_ignore_ascii_case("NULL")){
            let begin=if i>=start+3&&tokens[i-2].s.eq_ignore_ascii_case("CONSTRAINT"){i-2}else{i};
            let mut last=i+1;
            if tokens.get(i+2).is_some_and(|t|t.s.eq_ignore_ascii_case("ON"))&&tokens.get(i+3).is_some_and(|t|t.s.eq_ignore_ascii_case("CONFLICT")){last=i+4;}
            removals.push((tokens[begin].start,tokens[last].end));i=last;
        }
        i+=1;
    }
    for(start,end)in removals.into_iter().rev(){result.replace_range(start..end,"");}
    Ok(result)
}
'''+s[i:]
p.write_text(s)
