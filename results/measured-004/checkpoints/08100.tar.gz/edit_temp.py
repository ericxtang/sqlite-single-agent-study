from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
old='''            if a.eq_ignore_ascii_case("main") ||
                    a.eq_ignore_ascii_case("temp") {
                Ok(b)
            } else { Ok(format!("{}.{}",a,b)) }'''
assert old in s;s=s.replace(old,'''            Ok(format!("{}.{}",a,b))''')
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('pub struct Engine {\n','pub struct Engine {\n    pub namespace:String,\n    pub fallback:Option<Arc<Engine>>,\n    pub bypass_temp:bool,\n')
s=s.replace('''            Self {
                snapshot_active: false,''','''            Self {
                namespace:"main".into(),fallback:None,bypass_temp:false,
                snapshot_active: false,''',1)
# Distinguish explicitly-qualified main writes from temp/attached writes.
s=s.replace("if target.contains('.'){return false}",'''if let Some((schema,_))=target.split_once('.'){return schema.eq_ignore_ascii_case(&self.namespace)}''')
# Actual text still dense writes_main from prior edit.
needle='''    fn writes_main(&self,s:&Stmt)->bool{
'''
assert needle in s;s=s.replace(needle,needle+'''        if matches!(s,Stmt::Temp(_)){return false}
        if !self.bypass_temp&&self.temp_target(s).is_some(){return false}
''')
# source's qualified schema handling
a=s.index("                if let Some((schema, table)) = n.split_once('.') {",s.index('    fn source'))
b=s.index('                let a = alias.as_deref().unwrap_or(n);',a)
s=s[:a]+'''                if let Some((schema,table))=n.split_once('.'){
                    let mut db=if schema.eq_ignore_ascii_case(&self.namespace){let mut db=self.clone();db.attached.remove("temp");db}
                    else if let Some(db)=self.attached.get(&key(schema)){let mut db=db.clone();db.fallback=Some(Arc::new(self.clone()));db.last=self.last;db.total=self.total;db.changes=self.changes;db}
                    else if let Some(parent)=&self.fallback{return parent.source(source,alias,ctx,depth+1)}
                    else if schema.eq_ignore_ascii_case("temp")&&["sqlite_master","sqlite_schema"].contains(&key(table).as_str()){
                        let mut empty=self.clone();empty.db=Db::default();empty.attached.clear();empty.fallback=None;empty.namespace="temp".into();return empty.source(&Source::Table(table.into()),alias,ctx,depth+1)
                    }else{return Err(format!("unknown database {}",schema))};
                    if db.txn.is_empty(){db.refresh()?}
                    let mut data=db.source(&Source::Table(table.into()),alias,ctx,depth+1)?;
                    if alias.is_none(){for f in &mut data.fields{f.table=format!("{}.{}",schema,f.table)}}
                    return Ok(data)
                }
'''+s[b:]
# Insert temp precedence after CTE resolution.
needle='''                if let Some(t) = self.db.tables.get(&key(n)) {
                    return Ok(self.table_data(t, a))
                }'''
assert needle in s;s=s.replace(needle,'''                if self.namespace=="main"{
                    if let Some(temp)=self.attached.get("temp"){
                        if temp.db.tables.contains_key(&key(n))||temp.db.views.contains_key(&key(n))||(n.eq_ignore_ascii_case("sqlite_sequence")&&temp.db.sequence_created){
                            return self.source(&Source::Table(format!("temp.{}",n)),alias,ctx,depth+1)
                        }
                        if ["sqlite_temp_master","sqlite_temp_schema"].contains(&key(n).as_str()){
                            let mut data=self.source(&Source::Table("temp.sqlite_schema".into()),alias,ctx,depth+1)?;
                            for f in &mut data.fields{f.table=a.into()}
                            return Ok(data)
                        }
                    }
                }
'''+needle)
# Persistent views resolve in their own schema.
s=s.replace('''                    let r = self.query(&v.q, ctx, depth + 1)?;
                    let cols =''','''                    let r=if self.namespace=="main"&&!v.temporary{let mut db=self.clone();db.attached.remove("temp");db.query(&v.q,ctx,depth+1)?}else{self.query(&v.q,ctx,depth+1)?};
                    let cols =''',1)
s=s.replace('''                Err(format!("no such table: {}",n))
            }
        }
    }
    fn join_sources''','''                if let Some(parent)=&self.fallback{return parent.source(&Source::Table(n.clone()),alias,ctx,depth+1)}
                Err(format!("no such table: {}",n))
            }
        }
    }
    fn join_sources''',1)
# Namespace methods and pre-routing.
at=s.index('    fn run(&mut self, mut s: Stmt, sql: &str)')
s=s[:at]+'''    fn ensure_temp(&mut self)->Res<()>{
        if !self.attached.contains_key("temp"){
            let mut db=Self::open(":memory:")?;db.namespace="temp".into();db.foreign_keys=self.foreign_keys;db.pragmas=self.pragmas.clone();
            db.txn=self.txn.iter().map(|(n,_)|(n.clone(),db.db.clone())).collect();
            self.attached.insert("temp".into(),db);
        }
        Ok(())
    }
    fn temp_target(&self,s:&Stmt)->Option<String>{
        if self.namespace!="main"{return None}let temp=self.attached.get("temp")?;
        match s{
            Stmt::Insert{table,..}|Stmt::Update{table,..}|Stmt::Delete{table,..}|Stmt::Alter(table,_) if !table.contains('.')&&(temp.db.tables.contains_key(&key(table))||temp.db.views.contains_key(&key(table)))=>Some(table.clone()),
            Stmt::Drop(_,name,_) if !name.contains('.')&&(temp.db.tables.contains_key(&key(name))||temp.db.views.contains_key(&key(name))||temp.db.indexes.contains_key(&key(name))||temp.db.triggers.contains_key(&key(name)))=>Some(name.clone()),
            Stmt::CreateIndex{name,table,..} if !name.contains('.')&&(temp.db.tables.contains_key(&key(table))||table.to_ascii_lowercase().starts_with("temp."))=>Some(name.clone()),
            Stmt::CreateTrigger(t,_) if !t.name.contains('.')&&(temp.db.tables.contains_key(&key(t.table))||temp.db.views.contains_key(&key(t.table))||t.table.to_ascii_lowercase().starts_with("temp."))=>Some(t.name.clone()),
            _=>None
        }
    }
'''+s[at:]
needle='''    fn run(&mut self, mut s: Stmt, sql: &str) -> Res<ResultSet> {
'''
assert needle in s;s=s.replace(needle,needle+'''        if let Stmt::Temp(inner)=&s{
            if !matches!(inner.as_ref(),Stmt::CreateTrigger(_,_)){
                let mut inner=*inner.clone();
                if let Some(name)=statement_target(&inner){
                    if let Some((schema,_))=name.split_once('.'){if !schema.eq_ignore_ascii_case("temp"){return Err("temporary table name must be unqualified".into())}}
                }
                self.ensure_temp()?;set_target_schema(&mut inner,"temp");
                return self.run(inner,sql)
            }
        }
        if !self.bypass_temp&&self.temp_target(&s).is_some(){set_target_schema(&mut s,"temp")}
        if let Some(target)=statement_target(&s){
            if target.to_ascii_lowercase().starts_with("temp.")&&self.namespace=="main"{self.ensure_temp()?}
            if target.split_once('.').is_some_and(|(schema,_)|schema.eq_ignore_ascii_case(&self.namespace)){
                let mut local=s.clone();strip_only_target(&mut local,&self.namespace);
                let saved=self.bypass_temp;self.bypass_temp=true;let result=self.run(local,sql);self.bypass_temp=saved;return result
            }
        }
''',1)
# Routed child statement has a read-only parent fallback and shared counters.
s=s.replace('''                let db =
                    self.attached.get_mut(&key(&schema)).ok_or_else(||''','''                let fallback=Arc::new(self.clone());
                let db =
                    self.attached.get_mut(&key(&schema)).ok_or_else(||''',1)
s=s.replace('''                let before_total = db.total;
                let result =''','''                db.fallback=Some(fallback);db.last=self.last;db.changes=self.changes;db.total=self.total;
                let before_total = db.total;
                let result =''',1)
s=s.replace('''                    db.execute_stmt(routed, &strip_schema(sql, &schema)?);
                self.total''','''                    db.execute_stmt(routed, &strip_schema(sql, &schema)?);
                db.fallback=None;
                self.total''',1)
# Ensure attached connections identify their schema for explicit qualifiers.
s=s.replace('''                let mut db = Self::open(&path)?;
                db.foreign_keys''','''                let mut db = Self::open(&path)?;
                db.namespace=k.clone();
                db.foreign_keys''',1)
s=s.replace('if self.attached.len() >= 10 {','if self.attach_order.len() >= 10 {',1)
# Old TEMP trigger wrapper strips the main target qualifier for local trigger lookup.
s=s.replace('''            Stmt::Temp(stmt) => {
                let version''','''            Stmt::Temp(mut stmt) => {
                if let Stmt::CreateTrigger(t,_) = stmt.as_mut(){
                    if t.table.to_ascii_lowercase().starts_with("main."){strip_name(&mut t.table,"main")}
                    else if self.temp_target(&stmt).is_some(){let mut local=*stmt;set_target_schema(&mut local,"temp");return self.run(local,sql)}
                }
                let version''',1)
# database_list's existing rows have no temp: add when needed below through separate replacement.
# Metadata respects the owning namespace.
s=s.replace('vec![V::Text("main".into()),V::Text(t.name.clone()),V::Text("table".into())','vec![V::Text(self.namespace.clone()),V::Text(t.name.clone()),V::Text("table".into())')
helpers='''
fn set_target_schema(s:&mut Stmt,schema:&str){
    let target=match s{
        Stmt::Insert{table,..}|Stmt::Update{table,..}|Stmt::Delete{table,..}=>table,
        Stmt::CreateTable{name,..}|Stmt::CreateView{name,..}|Stmt::CreateIndex{name,..}=>name,
        Stmt::CreateTrigger(t,_)=>&mut t.name,
        Stmt::Drop(_,n,_)|Stmt::Alter(n,_)=>n,
        _=>return
    };
    if let Some((_,name))=target.split_once('.') {*target=format!("{}.{}",schema,name)}else{*target=format!("{}.{}",schema,target)}
}
fn strip_only_target(s:&mut Stmt,schema:&str){
    match s{
        Stmt::Insert{table,..}|Stmt::Update{table,..}|Stmt::Delete{table,..}=>strip_name(table,schema),
        Stmt::CreateTable{name,foreign,..}=>{strip_name(name,schema);for f in foreign{strip_name(&mut f.table,schema)}},
        Stmt::CreateView{name,..}=>strip_name(name,schema),
        Stmt::CreateIndex{name,table,..}=>{strip_name(name,schema);strip_name(table,schema)},
        Stmt::CreateTrigger(t,_)=>{strip_name(&mut t.name,schema);strip_name(&mut t.table,schema)},
        Stmt::Drop(_,n,_)|Stmt::Alter(n,_)|Stmt::Pragma(n,_)=>strip_name(n,schema),
        _=>{}
    }
}
'''
s+=helpers
p.write_text(s)
