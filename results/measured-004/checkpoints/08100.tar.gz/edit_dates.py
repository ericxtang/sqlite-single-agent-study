from pathlib import Path
p=Path('src/funcs.rs');s=p.read_text()
a=s.index('fn now() -> f64');b=s.index('pub fn date_current',a)
s=s[:a]+'''thread_local!{static DATE_CLOCK:std::cell::Cell<(usize,Option<f64>)>=const{std::cell::Cell::new((0,None))};}
pub struct StatementClock;
pub fn statement_clock()->StatementClock{DATE_CLOCK.with(|c|{let(d,t)=c.get();c.set((d+1,if d==0{None}else{t}))});StatementClock}
impl Drop for StatementClock{fn drop(&mut self){DATE_CLOCK.with(|c|{let(d,t)=c.get();c.set((d.saturating_sub(1),if d<=1{None}else{t}))})}}
fn now()->f64{
    DATE_CLOCK.with(|c|{let(d,t)=c.get();if let Some(t)=t{return t}let t=(SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs_f64()*1000.0).floor()/1000.0;if d>0{c.set((d,Some(t)))}t})
}
fn valid_date(t:f64)->bool{t.is_finite()&&(-210866760000.0..253402300800.0).contains(&t)}
fn numeric_time(v:&V)->Option<f64>{if v.null(){None}else{v.text().trim().parse::<f64>().ok().filter(|f|f.is_finite())}}
fn year_text(y:i64)->String{if y<0{format!("-{:04}",-y)}else{format!("{:04}",y)}}
fn date_digits(s:&str)->Option<i64>{if s.is_empty()||!s.bytes().all(|b|b.is_ascii_digit()){None}else{s.parse().ok()}}
fn clock_seconds(s:&str)->Option<f64>{
    let parts=s.split(':').collect::<Vec<_>>();if !(2..=3).contains(&parts.len())||parts[0].len()!=2||parts[1].len()!=2{return None}
    let h=date_digits(parts[0])?;let m=date_digits(parts[1])?;
    let sec=if parts.len()==3{let whole=parts[2].split('.').next()?;if whole.len()!=2{return None}date_digits(whole)?;if let Some((_,f))=parts[2].split_once('.'){date_digits(f)?;}parts[2].parse::<f64>().ok()?}else{0.0};
    if h>24||m>59||sec>=60.0||!sec.is_finite(){return None}
    Some(h as f64*3600.0+m as f64*60.0+sec)
}
#[repr(C)]
struct LocalTime{sec:std::ffi::c_int,min:std::ffi::c_int,hour:std::ffi::c_int,mday:std::ffi::c_int,mon:std::ffi::c_int,year:std::ffi::c_int,wday:std::ffi::c_int,yday:std::ffi::c_int,isdst:std::ffi::c_int,gmtoff:std::ffi::c_long,zone:*const std::ffi::c_char}
unsafe extern "C"{fn localtime_r(time:*const std::ffi::c_long,out:*mut LocalTime)->*mut LocalTime;fn mktime(time:*mut LocalTime)->std::ffi::c_long;}
fn timezone_shift(t:f64,local:bool)->Option<f64>{
    if !valid_date(t){return None}
    let seconds=t.floor() as std::ffi::c_long;
    if local{
        let mut out=std::mem::MaybeUninit::<LocalTime>::uninit();
        if unsafe{localtime_r(&seconds,out.as_mut_ptr())}.is_null(){return None}
        Some(t+unsafe{out.assume_init()}.gmtoff as f64)
    }else{
        let(y,m,d)=from_days((t/86400.0).floor()as i64);let day=t.rem_euclid(86400.0);
        let mut out=LocalTime{sec:day.floor()as i32%60,min:(day/60.0).floor()as i32%60,hour:(day/3600.0).floor()as i32,mday:d as i32,mon:m as i32-1,year:y as i32-1900,wday:0,yday:0,isdst:-1,gmtoff:0,zone:std::ptr::null()};
        Some(unsafe{mktime(&mut out)} as f64+t.rem_euclid(1.0))
    }
}
fn shift_months(t:f64,months:i64)->(f64,i64){
    let(y,m,d)=from_days((t/86400.0).floor()as i64);let total=y*12+m-1+months;
    let ty=total.div_euclid(12);let tm=total.rem_euclid(12)+1;
    let days=civil_days(ty+(tm==12)as i64,if tm==12{1}else{tm+1},1)-civil_days(ty,tm,1);
    (civil_days(ty,tm,d)as f64*86400.0+t.rem_euclid(86400.0),(d-days).max(0))
}
'''+s[b:]
a=s.index('fn parse_date(');b=s.index('fn date_func(',a)
s=s[:a]+'''fn parse_date(v:&V)->Option<f64>{
    if v.null(){return None}
    let s=v.text();let s=s.trim();if s.is_empty(){return None}
    if s.eq_ignore_ascii_case("now"){return Some(now())}
    if let Some(n)=numeric_time(v){return Some(((n-2440587.5)*86400000.0).round()/1000.0)}
    let yearlen=if s.starts_with('-'){5}else{4};let date_len=yearlen+6;
    let mut rest=s;let mut t=civil_days(2000,1,1)as f64*86400.0;
    if s.as_bytes().get(yearlen)==Some(&b'-')&&s.as_bytes().get(yearlen+3)==Some(&b'-'){
        let y=date_digits(s.get(usize::from(yearlen==5)..yearlen)?)?*if yearlen==5{-1}else{1};
        let m=date_digits(s.get(yearlen+1..yearlen+3)?)?;let d=date_digits(s.get(yearlen+4..date_len)?)?;
        if m<1||m>12||d<1||d>31{return None}t=civil_days(y,m,d)as f64*86400.0;rest=s.get(date_len..)?;
        if rest.trim().is_empty(){return Some(t)}
        if !rest.starts_with([' ','T']){return None}rest=rest.trim_start_matches([' ','T']);
    }
    if rest.is_empty(){return None}
    let end=rest.find(|c:char|!c.is_ascii_digit()&&c!=':'&&c!='.').unwrap_or(rest.len());
    t+=clock_seconds(&rest[..end])?;
    rest=rest[end..].trim();
    if rest.starts_with('+')||rest.starts_with('-'){
        if rest.len()!=6||rest.as_bytes()[3]!=b':'{return None}
        let h=date_digits(rest.get(1..3)?)?;let m=date_digits(rest.get(4..6)?)?;if h>14||m>59{return None}
        t-=if rest.starts_with('-'){-1.0}else{1.0}*(h*3600+m*60)as f64;
    }else if !rest.is_empty()&&!rest.eq_ignore_ascii_case("z"){return None}
    Some((t*1000.0).round()/1000.0)
}
'''+s[b:]
a=s.index('    let mut subsec = subsec_first;',s.index('fn date_func'))
b=s.index('    let days = (t / 86400.0).floor() as i64;',a)
# first let days lies inside months branch; take end loop via nearest after this block old marker
b=s.index('    let days = (t / 86400.0).floor() as i64;\n    let (y, mo, d)',a)
s=s[:a]+'''    let mut subsec=subsec_first;let mut overflow_days=0i64;
    for (index,modifier) in args.iter().enumerate().skip(1){
        if modifier.null(){return Ok(V::Null)}
        let m=modifier.text().to_ascii_lowercase();
        if ["unixepoch","julianday","auto"].contains(&m.as_str()){
            if index!=1||subsec_first{return Ok(V::Null)}
            if let Some(raw)=numeric_time(&args[0]){
                t=match m.as_str(){"unixepoch"=>raw,"auto" if !(0.0..=5373484.499999).contains(&raw)=>raw,_=>(raw-2440587.5)*86400.0};
                t=(t*1000.0).round()/1000.0;
            }else if m!="auto"{return Ok(V::Null)}
            if !valid_date(t){return Ok(V::Null)}continue
        }
        if !valid_date(t){return Ok(V::Null)}
        if m=="subsec"||m=="subsecond"{subsec=true}
        else if m=="floor"{t-=overflow_days as f64*86400.0;overflow_days=0}
        else if m=="ceiling"{overflow_days=0}
        else if m=="start of day"{t=t.div_euclid(86400.0)*86400.0;overflow_days=0}
        else if m=="start of month"||m=="start of year"{let(y,mo,_)=from_days((t/86400.0).floor()as i64);t=civil_days(y,if m=="start of year"{1}else{mo},1)as f64*86400.0;overflow_days=0}
        else if let Some(w)=m.strip_prefix("weekday "){let w=match w.parse::<f64>(){Ok(w)if w>=0.0&&w<=6.0&&w.fract()==0.0=>w as i64,_=>return Ok(V::Null)};let curr=((t/86400.0).floor()as i64+4).rem_euclid(7);t+=(w-curr).rem_euclid(7)as f64*86400.0;overflow_days=0}
        else if m=="utc"||m=="localtime"{t=match timezone_shift(t,m=="localtime"){Some(t)=>t,None=>return Ok(V::Null)};overflow_days=0}
        else if m.starts_with(['+','-'])&&m.as_bytes().get(5)==Some(&b'-')&&m.as_bytes().get(8)==Some(&b'-'){
            let sign=if m.starts_with('-'){-1}else{1};
            let fields=(m.get(1..5).and_then(date_digits),m.get(6..8).and_then(date_digits),m.get(9..11).and_then(date_digits));
            let(yr,mo,dd)=match fields{(Some(y),Some(m),Some(d))if m<=11&&d<=30=>(y,m,d),_=>return Ok(V::Null)};
            let(shifted,overflow)=shift_months(t,sign*(yr*12+mo));t=shifted+sign as f64*dd as f64*86400.0;overflow_days=overflow;
            if m.len()>11{if m.as_bytes()[11]!=b' '{return Ok(V::Null)}let sec=match clock_seconds(m[11..].trim()){Some(s)=>s,None=>return Ok(V::Null)};t+=sign as f64*sec;}
        }
        else if m.contains(':'){
            let sign=if m.starts_with('-'){-1.0}else{1.0};let raw=m.trim_start_matches(['+','-']);
            match clock_seconds(raw){Some(s)=>t+=sign*s,None=>return Ok(V::Null)}overflow_days=0;
        }
        else{
            let parts=m.split_whitespace().collect::<Vec<_>>();if parts.len()!=2{return Ok(V::Null)}
            let x=match parts[0].parse::<f64>(){Ok(x)if x.is_finite()=>x,_=>return Ok(V::Null)};
            overflow_days=0;
            match parts[1].strip_suffix('s').unwrap_or(parts[1]){
                "day"=>t+=x*86400.0,"hour"=>t+=x*3600.0,"minute"=>t+=x*60.0,"second"=>t+=x,
                unit @ ("month"|"year")=>{
                    if x.abs()>1_000_000.0{return Ok(V::Null)}
                    let months=x.trunc()as i64*if unit=="year"{12}else{1};let(shifted,overflow)=shift_months(t,months);
                    t=shifted+x.fract()*if unit=="year"{365.0*86400.0}else{30.0*86400.0};overflow_days=overflow;
                },
                _=>return Ok(V::Null)
            }
        }
        t=(t*1000.0).round()/1000.0;
    }
    if !valid_date(t){return Ok(V::Null)}
'''+s[b:]
s=s.replace('let date = format!("{:04}-{:02}-{:02}",y,mo,d);','let date = format!("{}-{:02}-{:02}",year_text(y),mo,d);')
s=s.replace("Some('Y') => format!(\"{:04}\",y),","Some('Y') => year_text(y),")
s=s.replace("Some('T') => time.clone(),","Some('T') => format!(\"{:02}:{:02}:{:02}\",h,mi,sec.floor()as i64),")
s=s.replace("Some('s') => (t.floor() as i64).to_string(),","Some('s') => if subsec{format!(\"{:.3}\",t)}else{(t.floor() as i64).to_string()},")
a=s.index('fn time_difference(');b=s.index('fn parse_json(',a)
s=s[:a]+'''fn time_difference(args:&[V])->Res<V>{
    if args.len()!=2{return Err("wrong number of arguments to timediff".into())}
    let a=match parse_date(&args[0]){Some(a)if valid_date(a)=>a,_=>return Ok(V::Null)};
    let b=match parse_date(&args[1]){Some(b)if valid_date(b)=>b,_=>return Ok(V::Null)};
    let sign=if a>=b{1}else{-1};let(ay,am,_)=from_days((a/86400.0).floor()as i64);let(by,bm,_)=from_days((b/86400.0).floor()as i64);
    let mut months=((ay-by)*12+am-bm).abs();
    let pivot=loop{let(p,_)=shift_months(b,sign*months);if months==0||(a-p)*sign as f64>=0.0{break p}months-=1};
    let diff=((a-pivot).abs()*1000.0).round()as i64;
    Ok(V::Text(format!("{}{:04}-{:02}-{:02} {:02}:{:02}:{:02}.{:03}",if sign<0{"-"}else{"+"},months/12,months%12,diff/86400000,diff/3600000%24,diff/60000%60,diff/1000%60,diff%1000)))
}
'''+s[b:]
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text().replace('pub fn execute(&mut self, sql: &str) -> Res<ResultSet> {','pub fn execute(&mut self, sql: &str) -> Res<ResultSet> {\n        let _date_clock=crate::funcs::statement_clock();');p.write_text(s)
