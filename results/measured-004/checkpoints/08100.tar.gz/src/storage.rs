use crate::syntax::Res;
use std::fs::{File, OpenOptions};
use std::io::Write;
use std::path::{Path,PathBuf};
use std::sync::atomic::{AtomicU64,Ordering};
static NEXT_FILE:AtomicU64=AtomicU64::new(0);
fn unique_path(path:&Path,kind:&str)->PathBuf{
    let clock=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
    path.with_file_name(format!("{}.agent-{}-{}-{}-{}",path.file_name().unwrap().to_string_lossy(),kind,std::process::id(),clock,NEXT_FILE.fetch_add(1,Ordering::Relaxed)))
}
fn sync_directory(path:&Path)->Res<()>{
    if let Some(parent)=path.parent(){File::open(parent).and_then(|f|f.sync_all()).map_err(|e|e.to_string())?}
    Ok(())
}
// Staging every participant before installing any prevents partial commits on
// serialization, preparation, or permission failures. Backups allow recovery
// from an installation error within the running process.
pub struct Prepared {
    target:PathBuf,
    staged:PathBuf,
    backup:Option<PathBuf>,
    installed:bool,
    preserve_backup:bool,
}
impl Prepared{
    pub fn new(path:&Path,bytes:&[u8])->Res<Self>{
        if let Ok(metadata)=path.symlink_metadata(){if !metadata.file_type().is_file(){return Err("database target is not a regular file".into())}}
        let staged=unique_path(path,"tmp");
        let mut state=Self{target:path.to_path_buf(),staged,backup:None,installed:false,preserve_backup:false};
        let mut f=OpenOptions::new().write(true).create_new(true).open(&state.staged).map_err(|e|e.to_string())?;
        if let Ok(metadata)=path.metadata(){f.set_permissions(metadata.permissions()).map_err(|e|e.to_string())?}
        f.write_all(bytes).and_then(|_|f.sync_all()).map_err(|e|e.to_string())?;
        if path.exists(){let backup=unique_path(path,"backup");std::fs::hard_link(path,&backup).map_err(|e|e.to_string())?;state.backup=Some(backup);}
        sync_directory(path)?;
        Ok(state)
    }
    fn install(&mut self)->Res<()>{
        std::fs::rename(&self.staged,&self.target).map_err(|e|e.to_string())?;self.installed=true;
        sync_directory(&self.target)
    }
    fn restore(&mut self)->Res<()>{
        if self.installed{
            if let Some(backup)=&self.backup{std::fs::rename(backup,&self.target).map_err(|e|e.to_string())?}
            else{std::fs::remove_file(&self.target).map_err(|e|e.to_string())?}
            self.installed=false;sync_directory(&self.target)?;
        }
        Ok(())
    }
}
impl Drop for Prepared{
    fn drop(&mut self){let _=std::fs::remove_file(&self.staged);if !self.preserve_backup{if let Some(backup)=&self.backup{let _=std::fs::remove_file(backup);}}}
}
pub fn install_all(prepared:&mut [Prepared])->Res<()>{
    for i in 0..prepared.len(){if let Err(error)=prepared[i].install(){
        let mut recovery=None;
        for p in prepared[..=i].iter_mut().rev(){if let Err(e)=p.restore(){p.preserve_backup=true;recovery=Some(e)}}
        return Err(if let Some(e)=recovery{format!("{}; rollback of database files failed: {}",error,e)}else{error})
    }}
    Ok(())
}

// ASTs have more serialization levels than their SQL expression depth. Decode
// them with a bounded document depth and an explicitly-sized parsing stack.
pub fn decode_database(bytes:&[u8])->Res<crate::engine::Db>{
    let mut depth=0usize;let mut quoted=false;let mut escaped=false;
    for &b in bytes{
        if quoted{if escaped{escaped=false}else if b==b'\\'{escaped=true}else if b==b'"'{quoted=false}}
        else{match b{b'"'=>quoted=true,b'['|b'{'=>{depth+=1;if depth>4096{return Err("database schema nesting limit exceeded".into())}},b']'|b'}'=>depth=depth.checked_sub(1).ok_or("file is not a database")?,_=>{}}}
    }
    let db=std::thread::scope(|scope|{
        std::thread::Builder::new().name("snapshot-decoder".into()).stack_size(32*1024*1024).spawn_scoped(scope,||{
            use serde::Deserialize;
            let mut decoder=serde_json::Deserializer::from_slice(bytes);decoder.disable_recursion_limit();
            let db=crate::engine::Db::deserialize(&mut decoder).map_err(|_|"file is not a database".to_string())?;
            decoder.end().map_err(|_|"file is not a database".to_string())?;
            Ok::<_,String>(db)
        }).map_err(|e|e.to_string())?.join().map_err(|_|"database decoding failed".to_string())?
    })?;
    for (name,table) in &db.tables{
        if !name.eq_ignore_ascii_case(&table.name)||table.cols.is_empty(){return Err("malformed database schema".into())}
        let mut ids=std::collections::BTreeSet::new();
        for row in &table.rows{
            if row.v.len()!=table.cols.len()||!ids.insert(row.id)||row.v.iter().any(|v|matches!(v,crate::value::V::Real(f) if f.is_nan())){return Err("malformed database record".into())}
        }
    }
    if db.sequences.iter().any(|r|r.v.len()!=2){return Err("malformed sequence record".into())}
    Ok(db)
}
