from pathlib import Path
p=Path('src/main.rs');s=p.read_text();s='mod storage;\n'+s;p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('use std::io::Write;\n','')
s=s.replace('pub struct Db {\n','pub struct Db {\n    #[serde(default)] pub generation:u64,\n')
s=s.replace('''                Some(clean)
            };''','''                if clean.exists(){clean=clean.canonicalize().map_err(|e|e.to_string())?}
                else{let file=clean.file_name().ok_or("invalid database path")?.to_owned();clean=clean.parent().ok_or("invalid database path")?.canonicalize().map_err(|e|e.to_string())?.join(file)}
                Some(clean)
            };''',1)
s=s.replace('''        let e =
            Self {''','''        let mut e =
            Self {''',1)
s=s.replace('''            e.persist()?;
        }
        Ok(e)''','''            e.acquire_writer()?;
            if e.path.as_ref().is_some_and(|p|p.exists()&&p.metadata().is_ok_and(|m|m.len()>0)){e.refresh()?}else{e.persist()?}
            e.writer_lock=None;
        }
        Ok(e)''',1)
a=s.index('    pub fn persist(');b=s.index('    pub fn execute(',a)
s=s[:a]+'''    pub fn persist(&mut self)->Res<()>{
        if let Some(path)=&self.path{
            let mut db=persistent_db(&self.db);db.generation=db.generation.wrapping_add(1);
            let bytes=serde_json::to_vec(&db).map_err(|e|e.to_string())?;
            let mut prepared=vec![crate::storage::Prepared::new(path,&bytes)?];
            crate::storage::install_all(&mut prepared)?;
            self.db.generation=db.generation;
        }
        Ok(())
    }
    fn persist_transaction(&mut self)->Res<()>{
        let mut prepared=vec![];let mut generations=vec![];
        for (name,db) in std::iter::once((None,&*self)).chain(self.attached.iter().map(|(n,db)|(Some(n.clone()),db))){
            if db.writer_lock.is_none(){continue}
            if let Some(path)=&db.path{let mut value=persistent_db(&db.db);value.generation=value.generation.wrapping_add(1);
                let bytes=serde_json::to_vec(&value).map_err(|e|e.to_string())?;
                prepared.push(crate::storage::Prepared::new(path,&bytes)?);generations.push((name,value.generation));
            }
        }
        crate::storage::install_all(&mut prepared)?;
        for(name,generation)in generations{if let Some(name)=name{self.attached.get_mut(&name).unwrap().db.generation=generation}else{self.db.generation=generation}}
        Ok(())
    }
    fn finish_transaction(&mut self){
        self.txn.clear();self.writer_lock=None;self.snapshot_active=false;self.pragmas.insert("defer_foreign_keys".into(),V::Int(0));
        for db in self.attached.values_mut(){db.finish_transaction()}
    }
    fn writes_main(&self,s:&Stmt)->bool{
        if let Stmt::With(_,s)=s{return self.writes_main(s)}
        if let Some(target)=statement_target(s){
            if target.contains('.'){return false}
            if matches!(s,Stmt::Insert{..}|Stmt::Update{..}|Stmt::Delete{..}|Stmt::Drop(_,_,_)|Stmt::Alter(_,_))&&!self.db.tables.contains_key(&key(target))&&!self.db.views.contains_key(&key(target))&&!self.db.indexes.contains_key(&key(target))&&!self.db.triggers.contains_key(&key(target)){
                if self.attached.values().any(|db|db.db.tables.contains_key(&key(target))||db.db.views.contains_key(&key(target))||db.db.indexes.contains_key(&key(target))||db.db.triggers.contains_key(&key(target))){return false}
            }
        }
        statement_writes(s)
    }
'''+s[b:]
s=s.replace('let write = statement_writes(&stmt);','let write = statement_writes(&stmt);\n        let main_write=self.writes_main(&stmt);',1)
s=s.replace('if write || immediate { self.acquire_writer()?; }','if main_write || immediate { self.acquire_writer()?; }',1)
s=s.replace('if write && self.writer_lock.is_some() {','if main_write && self.writer_lock.is_some() {',1)
s=s.replace('''                            self.db = before;
                            self.writer_lock = None;
                            return Err(e)''','''                            self.db = before;
                            self.changes=changes;self.total=total;self.last=last;
                            self.attached=attached_before;self.attach_order=order_before;
                            self.writer_lock = None;
                            return Err(e)''',1)
# busy_timeout applies to writer lock acquisition.
s=s.replace('file.try_lock().map_err(|_| "database is locked")?;','''let timeout=std::time::Duration::from_millis(self.pragmas.get("busy_timeout").map(V::i64).unwrap_or(0).clamp(0,i32::MAX as i64)as u64);
        let start=std::time::Instant::now();
        loop{match file.try_lock(){Ok(())=>break,Err(std::fs::TryLockError::WouldBlock)=>{let elapsed=start.elapsed();if elapsed>=timeout{return Err("database is locked".into())}std::thread::sleep(std::time::Duration::from_millis(5).min(timeout-elapsed));},Err(std::fs::TryLockError::Error(e))=>return Err(e.to_string())}}''')
s=s.replace('''                for db in self.attached.values_mut() {
                    if !db.txn.is_empty() { db.execute("COMMIT")?; }
                }
                if self.writer_lock.is_some() { self.persist()?; }
                self.txn.clear();''','''                self.persist_transaction()?;
                self.finish_transaction();''')
s=s.replace('''                    self.db = self.txn[0].1.clone();
                    self.txn.clear()
                }
                Ok(ResultSet::default())
            }
            Stmt::Savepoint''','''                    self.db = self.txn[0].1.clone();
                    self.finish_transaction()
                }
                Ok(ResultSet::default())
            }
            Stmt::Savepoint''')
s=s.replace('''                for db in self.attached.values_mut() { db.execute(sql)?; }
                if i == 0 && self.writer_lock.is_some() { self.persist()?; }
                self.txn.truncate(i);''','''                if i==0{self.persist_transaction()?;self.finish_transaction()}
                else{for db in self.attached.values_mut(){db.execute(sql)?;}self.txn.truncate(i)}''')
s=s.replace('''                if !self.txn.is_empty() { db.execute("BEGIN")?; }''','''                if !self.txn.is_empty(){db.txn=self.txn.iter().map(|(n,_)|(n.clone(),db.db.clone())).collect();}''')
# Propagate connection-wide settings to existing attached databases.
old='''                    self.pragmas.insert(n.clone(),
                        if matches!(v,V::Text(_)) { V::Int(on) } else { v });'''
new='''                    let value=if matches!(v,V::Text(_)){V::Int(on)}else{v};
                    self.pragmas.insert(n.clone(),value.clone());
                    if ["query_only","count_changes","ignore_check_constraints","recursive_triggers","case_sensitive_like","defer_foreign_keys","busy_timeout"].contains(&n.as_str()){
                        for db in self.attached.values_mut(){db.pragmas.insert(n.clone(),value.clone());}
                    }'''
assert old in s;s=s.replace(old,new)
# A full transaction rollback by a conflict policy resets deferral too.
s=s.replace('''                    self.db = self.txn[0].1.clone();
                    self.txn.clear()
                } else if !fail''','''                    self.db = self.txn[0].1.clone();
                    self.txn.clear();self.pragmas.insert("defer_foreign_keys".into(),V::Int(0));
                } else if !fail''')
p.write_text(s)
