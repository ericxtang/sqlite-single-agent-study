# sqlite-agent implementation state

Build: cargo build --release --offline --bin sqlite-agent.
Test: python3 tests/run_all.py. All tests exercise our executable using documentation-derived expectations; no reference database/parser was used.
Continue making useful progress until the controller ends the work period.

## Architecture
- syntax.rs: handwritten tokenizer, Pratt expression parser, SELECT/DDL/DML/transaction parser, serializable AST.
- value.rs: NULL/integer/real/text/blob values, affinity, comparison, casting, typed JSON response encoding.
- engine.rs: relational execution and binding, schema/constraints/triggers, snapshots/savepoints, persistence and connection management.
- funcs.rs: scalar/math/date/JSON/JSON5 functions, JSON/series table functions, iterative pattern matching, formatting.
- json.rs: ordered JSON AST/parser preserving object order and duplicate labels.
- main.rs: persistent JSON-lines interface; stdout contains only flushed protocol responses.
- CTE data and window input data use shared immutable Arc values; row context clones avoid copying entire input relations.

## Integrated behavior
SELECT aliases, DISTINCT, sorting/limits, ordinary/outer/natural/USING/parenthesized joins, aggregates (FILTER and argument ORDER BY), correlated/scalar/row subqueries, ordinary/recursive CTEs, compounds, windows. Compound ordering resolves aliases/expressions across branches and applies result collations. Lazy CASE/coalesce/iif branches bind without evaluating unused subqueries. BETWEEN freezes its left operand once.

Window ranking/offset/value/aggregate functions; named windows/chaining, partitions, ROWS/GROUPS/RANGE, exclusions, grouped aggregates within windows, static placement/frame checks. Recursive CTEs use a single-row work queue, FIFO or ORDER BY priority, LIMIT/OFFSET, UNION deduplication, multiple anchors/recursive terms; optional RECURSIVE keyword. Forward CTE dependencies work, unused SELECT CTEs are skipped. A one-million-step/queued-row resource limit prevents unlimited recursion.

Tables/views/indexes/triggers; INSERT/UPDATE/DELETE with RETURNING, UPSERT, UPDATE FROM, WITH DML; ALTER rename/add/drop common dependency rewrites. Rowid/integer-PK/autoincrement and writable sqlite_sequence; affinity, collations, generated/strict/without-rowid tables; UNIQUE/NOT NULL/CHECK/FK constraints and conflict policies. Foreign-key actions, deferred checks, BEFORE/AFTER/INSTEAD OF triggers, RAISE and trigger change accounting. Introspection pragmas, autoindex metadata, integrity/FK checks, scan-oriented EXPLAIN QUERY PLAN.

BEGIN/COMMIT/ROLLBACK, savepoints, statement rollback and FAIL/ROLLBACK/IGNORE/REPLACE behavior. BEGIN DEFERRED activates a snapshot on database access. OS writer locks, committed-file refresh, stale snapshot rejection. Synced unique temporary snapshot, atomic rename, parent directory sync. Uncommitted data is memory-only and discarded on close/crash. Path confinement to /work and symlink checks. ATTACH/DETACH, qualified reads/writes, joins, copied DML/CTAS, attached transactions/savepoints. Temporary objects excluded from persistence.

Core/math/date/strftime subset, unistr/unistr_quote, printf/format. SQL text conversion uses 15-digit real formatting; typed JSON responses preserve available real precision. JSON and JSON5 syntax/validation, constructors, paths/extraction/operators, mutation/merge-patch, aggregation, each/tree, pretty formatting. Ordered JSON values preserve duplicate labels; extraction/edits target the first matching label. JSON nesting limit 1000. LIKE/GLOB use iterative matching.

## Validation
Regression suites cover expressions/types, storage/reopen, transactions/concurrent writers/crash rollback, schema/constraints, triggers/cascades, views/temp, attached files, ALTER, aggregate/window binding, compound ordering/collation, row subqueries, CTE queues/dependencies, joins, JSON/JSON5/order, formatting/casts and autoincrement resets. A seeded 500-operation transaction model checks combined DML/snapshot behavior. A 12,000-row recursive query verifies iterative execution and guards the former context-copy performance issue.

## Known limitations / useful next directions
- Persistence is an internal JSON snapshot, **not native SQLite binary format**. No B-tree, physical index optimizer, native journal or WAL. Reported storage pragmas are approximations. Isolation resembles snapshot/WAL behavior; cross-file commits are not crash-atomic.
- Main/temp name shadowing remains incomplete: temporary objects work when names are distinct. Main/temp qualifiers are mostly normalized away. Attached statement routing has limitations for some UPDATE/subquery/RETURNING cross-schema references, and snapshot activation is shared across attachments.
- Comprehensive SQL binding still has gaps. Uncorrelated subqueries are not cached; EXISTS with compounds/offset may evaluate projection values. Some unusual alias/compound collation/aggregate/window corner cases remain. WITH DML materializes CTEs eagerly. Recursive references inside parenthesized FROM groups are not yet counted as direct references.
- JSONB is unavailable (binary details are not supplied). JSON subtype propagation is syntax-based and incomplete. JSON5 escaped identifiers and some malformed-input positions are incomplete. Table JSON ids are internal counters, not stable binary offsets.
- Date range/invalid input/modifier behavior needs further review; localtime/utc currently no-op, fractional month/year shifts incomplete, exact timediff month-end cases incomplete.
- Plain EXPLAIN returns an unsupported error; there is no VDBE. Some pragmas/virtual extensions/physical index behaviors are absent.
- Rustfmt is unavailable. Source can be formatted offline using the installed compiler's parser printer: RUSTC_BOOTSTRAP=1 rustc -Zunpretty=normal --edition=2021 src/<file>.rs, capturing stdout into that file via Python after successful completion. This was used successfully, followed by a full build/test run.

Next: improve documented date/time semantics and malformed-input handling; review storage/transaction durability and recovery tests; address remaining schema/binding gaps. Keep the integrated executable usable.
