from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('''    Attach(E, String),
''','''    Attach(E, String),
    Vacuum(Option<String>,Option<E>),
''',1)
old='''        if self.eat("VACUUM") || self.eat("ANALYZE") || self.eat("REINDEX") {'''
new='''        if self.eat("VACUUM"){
            let schema=if self.p==self.ts.len()||self.at(";")||self.at("INTO"){None}else{Some(self.ident()?)};
            let into=if self.eat("INTO"){Some(self.expr()?)}else{None};
            return Ok(Stmt::Vacuum(schema,into))
        }
        if self.eat("ANALYZE") || self.eat("REINDEX") {'''
assert old in s;s=s.replace(old,new)
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
start=s.index('    pub fn open(path: &str)')
end=s.index('        if let Some(p) = &path { crate::storage::recover_database(p)?; }',start)
part=s[start:end]
part=part.replace('''    pub fn open(path: &str) -> Res<Self> {''','''    fn database_path(path:&str)->Res<Option<std::path::PathBuf>>{''',1)
part+='''        Ok(path)
    }
    pub fn open(path: &str) -> Res<Self> {
        let path=Self::database_path(path)?;
'''
s=s[:start]+part+s[end:]
i=s.index('    pub fn persist(')
s=s[:i]+'''    fn vacuum(&mut self,schema:Option<&str>,into:Option<&E>)->Res<ResultSet>{
        if !self.txn.is_empty(){return Err("cannot VACUUM from within a transaction".into())}
        if into.is_none()&&self.pragmas.get("query_only").is_some_and(|v|v.i64()!=0){return Err("attempt to write a readonly database".into())}
        self.refresh()?;
        let destination=if let Some(e)=into{
            self.validate_expr(e,&self.root_ctx())?;
            let value=self.eval(e,&self.root_ctx(),None,0)?;
            let V::Text(path)=value else{return Err("VACUUM INTO filename must be text".into())};
            Some(Self::database_path(&path)?)
        }else{None};
        let schema=schema.unwrap_or("main");
        if schema.eq_ignore_ascii_case("temp")&&self.namespace=="main"{self.ensure_temp()?;}
        let source=if schema.eq_ignore_ascii_case(&self.namespace){&mut *self}
            else{self.attached.get_mut(&key(schema)).ok_or_else(||format!("unknown database {}",schema))?};
        if let Some(destination)=destination{
            source.refresh()?;
            if let Some(path)=destination{
                let mut output=Self::open(":memory:")?;
                output.path=Some(path.clone());output.pragmas=source.pragmas.clone();
                output.acquire_writer()?;
                if path.metadata().is_ok_and(|m|!m.is_file()||m.len()!=0){return Err("output file already exists".into())}
                output.db=persistent_db(&source.db);
                output.persist()?;
            }
        }else{
            source.acquire_writer()?;
            let result=source.refresh().and_then(|_|source.persist());
            source.writer_lock=None;result?;
        }
        Ok(ResultSet::default())
    }
'''+s[i:]
needle='''    fn execute_stmt(&mut self, stmt: Stmt, sql: &str) -> Res<ResultSet> {
        let write'''
assert needle in s;s=s.replace(needle,'''    fn execute_stmt(&mut self, stmt: Stmt, sql: &str) -> Res<ResultSet> {
        if let Stmt::Vacuum(schema,into)=&stmt{return self.vacuum(schema.as_deref(),into.as_ref())}
        let write''')
needle='''            Stmt::Noop => Ok(ResultSet::default()),'''
assert needle in s;s=s.replace(needle,'''            Stmt::Vacuum(schema,into)=>self.vacuum(schema.as_deref(),into.as_ref()),
            Stmt::Noop => Ok(ResultSet::default()),''',1)
needle='''        Stmt::Noop => false,
        _ => true,'''
assert needle in s;s=s.replace(needle,'''        Stmt::Vacuum(_,into)=>into.is_none(),
        Stmt::Noop => false,
        _ => true,''',1)
p.write_text(s)
