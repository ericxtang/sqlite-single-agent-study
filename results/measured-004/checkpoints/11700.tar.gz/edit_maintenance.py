from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('''    Vacuum(Option<String>,Option<E>),
''','''    Vacuum(Option<String>,Option<E>),
    Analyze(Option<String>),
    Reindex(Option<String>),
''',1)
old='''        if self.eat("ANALYZE") || self.eat("REINDEX") {
            while self.p < self.ts.len() && !self.at(";") { self.p += 1 }
            return Ok(Stmt::Noop)
        }'''
new='''        if self.at("ANALYZE")||self.at("REINDEX"){
            let analyze=self.eat("ANALYZE");if !analyze{self.expect("REINDEX")?;}
            let target=if self.p==self.ts.len()||self.at(";"){None}else{Some(self.name()?)};
            return Ok(if analyze{Stmt::Analyze(target)}else{Stmt::Reindex(target)})
        }'''
assert old in s;s=s.replace(old,new)
# Noop is no longer constructed.
s=s.replace('''    Noop,
''','')
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('''            Stmt::Noop => Ok(ResultSet::default()),''','''            Stmt::Analyze(target)=>self.maintenance(true,target.as_deref()),
            Stmt::Reindex(target)=>self.maintenance(false,target.as_deref()),''')
s=s.replace('''        Stmt::Noop => false,
''','')
s=s.replace('''            Stmt::Noop | Stmt::Explain(_, _) => false,''','''            Stmt::Explain(_, _) => false,''')
i=s.index('    fn returning(')
s=s[:i]+'''    fn index_records(&self,t:&Table,index:&Index)->Res<Vec<Vec<V>>>{
        let mut records=vec![];
        let ctx=self.rowctx(t,&Row{id:0,v:vec![V::Null;t.cols.len()]},None);
        let coll=index.expr.iter().map(|e|self.metadata(e,&ctx).1).collect::<Vec<_>>();
        for row in &t.rows{
            let ctx=self.rowctx(t,row,None);
            if let Some(e)=&index.filter{if self.eval(e,&ctx,None,0)?.truth()!=Some(true){continue}}
            records.push(index.expr.iter().map(|e|self.eval(e,&ctx,None,0)).collect::<Res<Vec<_>>>()?);
        }
        records.sort_by(|a,b|{
            for(i,(a,b))in a.iter().zip(b).enumerate(){let c=cmp(a,b,&coll[i]);if c!=Ordering::Equal{return c}}
            Ordering::Equal
        });
        if index.unique&&records.windows(2).any(|pair|!pair[0].iter().any(V::null)&&pair[0].iter().zip(&pair[1]).enumerate().all(|(i,(a,b))|cmp(a,b,&coll[i])==Ordering::Equal)){
            return Err(self.unique_error(t))
        }
        Ok(records)
    }
    fn maintenance(&mut self,analyze:bool,target:Option<&str>)->Res<ResultSet>{
        if let Some(target)=target{
            if let Some((schema,object))=target.split_once('.'){
                if schema.eq_ignore_ascii_case(&self.namespace){return self.maintenance_local(analyze,Some(object))}
                let child=self.attached.get_mut(&key(schema)).ok_or_else(||format!("unknown database {}",schema))?;
                return child.execute_stmt(if analyze{Stmt::Analyze(Some(object.into()))}else{Stmt::Reindex(Some(object.into()))},"");
            }
            if analyze&&target.eq_ignore_ascii_case(&self.namespace){return self.maintenance_local(true,None)}
            if analyze&&self.attached.contains_key(&key(target)){
                let child=self.attached.get_mut(&key(target)).unwrap();
                return child.execute_stmt(Stmt::Analyze(None),"");
            }
            if !analyze&&["binary","nocase","rtrim","expressions"].contains(&key(target).as_str()){
                self.maintenance_local(false,Some(target))?;
                for child in self.attached.values_mut(){child.execute_stmt(Stmt::Reindex(Some(target.into())),"")?;}
                return Ok(ResultSet::default())
            }
            if self.namespace=="main"{
                if let Some(temp)=self.attached.get_mut("temp"){
                    if temp.db.tables.contains_key(&key(target))||temp.db.indexes.contains_key(&key(target)){
                        return temp.execute_stmt(if analyze{Stmt::Analyze(Some(target.into()))}else{Stmt::Reindex(Some(target.into()))},"");
                    }
                }
            }
            if self.db.tables.contains_key(&key(target))||self.db.indexes.contains_key(&key(target))||self.db.views.contains_key(&key(target))||["sqlite_schema","sqlite_master"].contains(&key(target).as_str()){
                return self.maintenance_local(analyze,Some(target))
            }
            for name in self.attach_order.clone(){
                let child=self.attached.get_mut(&name).unwrap();
                if child.db.tables.contains_key(&key(target))||child.db.indexes.contains_key(&key(target)){
                    return child.execute_stmt(if analyze{Stmt::Analyze(Some(target.into()))}else{Stmt::Reindex(Some(target.into()))},"");
                }
            }
            return Err(format!("no such table or index: {}",target))
        }
        self.maintenance_local(analyze,None)?;
        let schemas=if analyze{self.attach_order.clone()}else{self.attached.keys().cloned().collect()};
        for schema in schemas{
            let child=self.attached.get_mut(&schema).unwrap();
            child.execute_stmt(if analyze{Stmt::Analyze(None)}else{Stmt::Reindex(None)},"")?;
        }
        Ok(ResultSet::default())
    }
    fn maintenance_local(&mut self,analyze:bool,target:Option<&str>)->Res<ResultSet>{
        let object=target.map(key);
        let collation=if analyze{None}else{object.as_deref().filter(|n|["binary","nocase","rtrim"].contains(n))};
        let expressions=!analyze&&object.as_deref()==Some("expressions");
        let index=self.db.indexes.get(object.as_deref().unwrap_or("")).cloned();
        let table=index.as_ref().map(|i|key(&i.table)).or_else(||object.clone());
        let mut stats=vec![];
        for t in self.db.tables.values().filter(|t|!key(&t.name).starts_with("sqlite_")){
            if analyze&&table.as_ref().is_some_and(|n|!t.name.eq_ignore_ascii_case(n)){continue}
            for idx in self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&t.name)){
                if let Some(wanted)=&index{if !wanted.name.eq_ignore_ascii_case(&idx.name){continue}}
                if !analyze{
                    let ctx=self.rowctx(t,&Row{id:0,v:vec![V::Null;t.cols.len()]},None);
                    let matches=if let Some(collation)=collation{idx.expr.iter().any(|e|self.metadata(e,&ctx).1.eq_ignore_ascii_case(collation))}
                        else if expressions{idx.expr.iter().any(|e|!matches!(order_expression(e),E::Col(_)))||object.as_ref().is_some_and(|n|idx.name.eq_ignore_ascii_case(n)||t.name.eq_ignore_ascii_case(n))}
                        else{object.as_ref().is_none_or(|n|idx.name.eq_ignore_ascii_case(n)||t.name.eq_ignore_ascii_case(n))};
                    if !matches{continue}
                }
                let records=self.index_records(t,idx)?;
                if !analyze||records.is_empty(){continue}
                let ctx=self.rowctx(t,&Row{id:0,v:vec![V::Null;t.cols.len()]},None);
                let coll=idx.expr.iter().map(|e|self.metadata(e,&ctx).1).collect::<Vec<_>>();
                let mut distinct=vec![1usize;idx.expr.len()];
                for pair in records.windows(2){
                    if let Some(first)=pair[0].iter().zip(&pair[1]).enumerate().position(|(i,(a,b))|cmp(a,b,&coll[i])!=Ordering::Equal){
                        for count in &mut distinct[first..]{*count+=1;}
                    }
                }
                let mut numbers=vec![records.len().to_string()];
                for(i,d)in distinct.iter().enumerate(){numbers.push(if idx.unique&&i+1==distinct.len(){1}else{records.len().div_ceil(*d)}.to_string());}
                let name=if t.without&&idx.origin=="pk"{t.name.clone()}else{idx.name.clone()};
                stats.push(vec![V::Text(t.name.clone()),V::Text(name),V::Text(numbers.join(" "))]);
            }
            if analyze&&index.is_none()&&!t.rows.is_empty()&&!self.db.indexes.values().any(|i|i.table.eq_ignore_ascii_case(&t.name)&&i.filter.is_none()){
                stats.push(vec![V::Text(t.name.clone()),V::Null,V::Text(t.rows.len().to_string())]);
            }
        }
        if analyze{
            if !self.db.tables.contains_key("sqlite_stat1"){
                let cols=["tbl","idx","stat"].iter().map(|n|Column{policies:Default::default(),name:n.to_string(),typ:String::new(),notnull:false,pk:0,unique:false,default:None,default_sql:None,coll:"BINARY".into(),auto:false,pk_desc:false,generated:None,stored:false}).collect();
                self.db.tables.insert("sqlite_stat1".into(),Table{temporary:false,name:"sqlite_stat1".into(),cols,unique:vec![],policies:vec![],checks:vec![],foreign:vec![],without:false,strict:false,rows:vec![],seq:0,sql:"CREATE TABLE sqlite_stat1(tbl,idx,stat)".into()});
                self.db.schema_version+=1;
            }
            let stat=self.db.tables.get_mut("sqlite_stat1").unwrap();
            if !object.as_deref().is_some_and(|n|["sqlite_schema","sqlite_master","sqlite_stat1"].contains(&n)){
                stat.rows.retain(|r|{
                    if let Some(idx)=&index{!(r.v[0].text().eq_ignore_ascii_case(&idx.table)&&(r.v[1].text().eq_ignore_ascii_case(&idx.name)||(idx.origin=="pk"&&r.v[1].text().eq_ignore_ascii_case(&idx.table))))}
                    else{table.as_ref().is_some_and(|n|!r.v[0].text().eq_ignore_ascii_case(n))}
                });
                let mut id=stat.rows.iter().map(|r|r.id).max().unwrap_or(0);
                for v in stats{id+=1;stat.rows.push(Row{id,v});}
            }
        }
        Ok(ResultSet::default())
    }
'''+s[i:]
# SQLite reserves alterations of internal statistics tables.
needle='''    fn alter(&mut self, n: &str, a: Alter) -> Res<ResultSet> {
        let k = key(n);'''
assert needle in s;s=s.replace(needle,'''    fn alter(&mut self, n: &str, a: Alter) -> Res<ResultSet> {
        let k = key(n);
        if k.starts_with("sqlite_"){return Err("table may not be altered".into())}''')
# Enforce expression-index evaluation on every inserted/updated row.
needle='''    fn conflicts(&self, t: &Table, row: &Row, skip: Option<usize>)
        -> Res<Vec<usize>> {
        let mut out = vec![];'''
assert needle in s;s=s.replace(needle,'''    fn conflicts(&self, t: &Table, row: &Row, skip: Option<usize>)
        -> Res<Vec<usize>> {
        let ctx=self.rowctx(t,row,None);
        for idx in self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&t.name)&&!i.unique){
            if let Some(e)=&idx.filter{if self.eval(e,&ctx,None,0)?.truth()!=Some(true){continue}}
            for e in &idx.expr{self.eval(e,&ctx,None,0)?;}
        }
        let mut out = vec![];''')
needle='''                if let Some(e) = &filter { self.validate_expr(e, &c)?; }
                let mut seen'''
assert needle in s;s=s.replace(needle,'''                if let Some(e)=&filter{
                    if has_agg(e)||has_window(e)||has_subquery(e)||nondeterministic(e){return Err("invalid expression in partial index WHERE clause".into())}
                    self.validate_expr(e,&c)?;
                }
                let mut seen''')
# Analysis limit is retained as a setting; exact statistics are currently computed.
s=s.replace('''                "freelist_count" | "cache_size" | "synchronous" |''','''                "freelist_count" | "cache_size" | "synchronous" | "analysis_limit" |''')
p.write_text(s)
