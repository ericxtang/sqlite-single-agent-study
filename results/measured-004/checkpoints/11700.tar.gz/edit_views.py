from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
needle='''        if view { return self.mutate_view(s) }
        match &s {'''
assert needle in s;s=s.replace(needle,'''        if view { return self.mutate_view(s) }
        if let Stmt::Insert{table,returning,..}|Stmt::Update{table,returning,..}|Stmt::Delete{table,returning,..}=&s{
            if let Some(t)=self.db.tables.get(&key(table)){self.returning(returning,t,&[])?;}
        }
        match &s {''')
needle='''        for item in items {
            if matches!(item.e,E::Star(_)) {'''
assert needle in s;s=s.replace(needle,'''        for item in items {
            if matches!(item.e,E::Star(Some(_))){return Err("RETURNING may not use table.* wildcards".into())}
            if matches!(item.e,E::Star(_)) {''',1)
start=s.index('    fn mutate_view(');end=s.index('    fn in_trigger(',start)
s=s[:start]+'''    fn mutate_view(&mut self,s:Stmt)->Res<ResultSet>{
        let(name,event)=match &s{
            Stmt::Insert{table,upsert,..}=>{
                if !upsert.is_empty(){return Err("cannot UPSERT a view".into())}
                (table,"INSERT")
            }
            Stmt::Update{table,..}=>(table,"UPDATE"),
            Stmt::Delete{table,..}=>(table,"DELETE"),
            _=>unreachable!(),
        };
        let v=self.db.views[&key(name)].clone();
        if !self.db.triggers.values().any(|t|t.table.eq_ignore_ascii_case(name)&&t.event==event&&t.timing=="INSTEAD OF"){
            return Err(format!("cannot modify {} because it is a view",name))
        }
        let source=Source::Table(format!("{}.{}",self.namespace,name));
        let result=self.source(&source,&Some(v.name.clone()),&Ctx{binding:event=="INSERT",..Default::default()},0)?;
        let names=result.fields.iter().map(|f|f.name.clone()).collect::<Vec<_>>();
        let cols=result.fields.iter().map(|f|Column{
            policies:Default::default(),name:f.name.clone(),typ:affinity_name(f.aff).into(),
            notnull:false,pk:0,unique:false,default:None,default_sql:None,coll:f.coll.clone(),auto:false,
            pk_desc:false,generated:None,stored:false,
        }).collect();
        let t=Table{
            temporary:v.temporary,name:v.name.clone(),cols,unique:vec![],policies:vec![],checks:vec![],
            foreign:vec![],without:false,strict:false,
            rows:result.rows.into_iter().enumerate().map(|(i,v)|Row{id:i as i64+1,v}).collect(),seq:0,sql:v.sql.clone()
        };
        if let Stmt::Insert{returning,..}|Stmt::Update{returning,..}|Stmt::Delete{returning,..}=&s{self.returning(returning,&t,&[])?;}
        let mut output=vec![];let returning;
        match s{
            Stmt::Insert{cols,q,default,returning:r,..}=>{
                returning=r;
                let target=if cols.is_empty(){names}else{cols};
                let mapping=target.iter().map(|n|t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("no such column in view")).collect::<Result<Vec<_>,_>>()?;
                let inputs=if let Some(q)=q{
                    let result=self.query(&q,&self.root_ctx(),0)?;
                    if result.columns.len()!=target.len(){return Err("view column count mismatch".into())}
                    result.rows
                }else{vec![vec![]]};
                for input in inputs{
                    let mut values=vec![V::Null;t.cols.len()];
                    if !default{for(&i,value)in mapping.iter().zip(input){values[i]=value}}
                    let row=Row{id:-1,v:values};
                    if self.fire(&t,"INSERT","INSTEAD OF",None,Some(&row),&[])?{output.push(row)}
                }
            }
            Stmt::Update{alias,from,sets,filter,returning:r,..}=>{
                returning=r;
                let nullctx=self.rowctx(&t,&Row{id:0,v:vec![V::Null;t.cols.len()]},alias.as_deref());
                let mapping=sets.iter().map(|(n,_)|t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("no such column in view")).collect::<Result<Vec<_>,_>>()?;
                for(_,e)in &sets{if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function".into())}}
                if let Some(e)=&filter{if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function".into())}}
                let from_query=Query{
                    items:sets.iter().map(|(n,e)|Item{e:e.clone(),name:n.clone(),alias:None}).collect(),
                    from:from.clone(),filter:filter.clone(),limit:Some(E::Val(V::Int(1))),..Default::default()
                };
                if from.is_empty(){
                    for(_,e)in &sets{self.validate_expr(e,&nullctx)?;}
                    if let Some(e)=&filter{self.validate_expr(e,&nullctx)?;}
                }else{let mut bind=nullctx.clone();bind.binding=true;self.query(&from_query,&bind,0)?;}
                for old in &t.rows{
                    let ctx=self.rowctx(&t,old,alias.as_deref());
                    let assigned=if from.is_empty(){
                        if let Some(e)=&filter{if self.eval(e,&ctx,None,0)?.truth()!=Some(true){continue}}
                        self.eval_list(&sets.iter().map(|(_,e)|e).collect::<Vec<_>>(),&ctx,None,0)?
                    }else{
                        let result=self.query(&from_query,&ctx,0)?;
                        let Some(row)=result.rows.into_iter().next()else{continue};row
                    };
                    let mut row=old.clone();
                    for(&i,value)in mapping.iter().zip(assigned){row.v[i]=value;}
                    let updated=sets.iter().map(|(n,_)|n.clone()).collect::<Vec<_>>();
                    if self.fire(&t,"UPDATE","INSTEAD OF",Some(old),Some(&row),&updated)?{output.push(row)}
                }
            }
            Stmt::Delete{alias,filter,returning:r,..}=>{
                returning=r;
                let nullctx=self.rowctx(&t,&Row{id:0,v:vec![V::Null;t.cols.len()]},alias.as_deref());
                if let Some(e)=&filter{
                    if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function".into())}
                    self.validate_expr(e,&nullctx)?;
                }
                for old in &t.rows{
                    let ctx=self.rowctx(&t,old,alias.as_deref());
                    if let Some(e)=&filter{if self.eval(e,&ctx,None,0)?.truth()!=Some(true){continue}}
                    if self.fire(&t,"DELETE","INSTEAD OF",Some(old),None,&[])?{output.push(old.clone())}
                }
            }
            _=>unreachable!(),
        }
        self.changes=0;
        if returning.is_empty()&&self.pragmas.get("count_changes").is_some_and(|v|v.i64()!=0){
            return Ok(ResultSet{columns:vec![format!("rows {}",match event{"INSERT"=>"inserted","UPDATE"=>"updated",_=>"deleted"})],rows:vec![vec![V::Int(output.len()as i64)]],..Default::default()})
        }
        self.returning(&returning,&t,&output)
    }
'''+s[end:]
p.write_text(s)
