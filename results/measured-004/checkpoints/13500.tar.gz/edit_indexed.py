from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('pub struct Join {\n','pub struct Join {\n    #[serde(default)]\n    pub indexed:Option<String>,\n',1)
s=s.replace('''    Update {
        table: String,''','''    Update {
        indexed:Option<String>,
        table: String,''',1)
s=s.replace('''    Delete {
        table: String,''','''    Delete {
        indexed:Option<String>,
        table: String,''',1)
# Record clauses for source tables.
a=s.index('            if self.eat("INDEXED") {',s.index('    fn sources('));b=s.index('            let on =',a)
s=s[:a]+'''            let indexed=self.index_clause()?;
            if indexed.is_some()&&!matches!(source,Source::Table(_)){return Err("INDEXED BY requires a table".into())}
'''+s[b:]
s=s.replace('''            from.push(Join {
                    source,''','''            from.push(Join {
                    indexed,
                    source,''',1)
s=s.replace('Join{source:', 'Join{indexed:None,source:')
# Rename-analysis-only source scopes have no index requirement.
s=s.replace('''                    Join {
                        source:''','''                    Join {
                        indexed:None,
                        source:''',1)
pos=s.index('    fn window(')
s=s[:pos]+'''    fn index_clause(&mut self)->Res<Option<String>>{
        if self.eat("INDEXED"){self.expect("BY")?;Ok(Some(self.ident()?))}
        else if self.eat("NOT"){self.expect("INDEXED")?;Ok(Some(String::new()))}else{Ok(None)}
    }
'''+s[pos:]
a=s.index('        if self.eat("UPDATE") {',s.index('    fn statement_inner'))
b=s.index('        if self.eat("BEGIN")',a)
part=s[a:b].replace('let alias = self.alias()?;','let alias = self.alias()?;\n            let indexed=self.index_clause()?;')
part=part.replace('''return Ok(Stmt::Update {
                        table,''','''return Ok(Stmt::Update {
                        indexed,
                        table,''',1).replace('''return Ok(Stmt::Delete {
                        table,''','''return Ok(Stmt::Delete {
                        indexed,
                        table,''',1)
s=s[:a]+part+s[b:]
# Trigger DML does not permit index selection clauses.
s=s.replace('''Stmt::Update { returning, .. } | Stmt::Delete { returning,
                            .. } => {''','''Stmt::Update { returning,indexed, .. } | Stmt::Delete { returning,indexed,
                            .. } => {
                            if indexed.is_some(){return Err("INDEXED BY is not allowed on trigger DML".into())}''',1)
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text().replace('Join{source:', 'Join{indexed:None,source:')
# Pass enclosing WHERE terms to nested joins.
s=s.replace('pub struct Ctx {\n','pub struct Ctx {\n    pub index_predicates:Vec<E>,\n',1)
s=s.replace('''            let data = self.join_sources(&q.from, &base, depth)?;''','''            base.index_predicates=q.filter.iter().cloned().collect();
            let data = self.join_sources(&q.from, &base, depth)?;''',1)
a=s.index('    fn join_sources(');b=s.index('    fn recursive_cte(',a)
part=s[a:b]
# One ordinary right-side source call, separate table-function lateral path unchanged.
old='self.source(&j.source, &j.alias, ctx, depth + 1)?'
assert old in part
part=part.replace(old,'''if let Some(index)=&j.indexed{
                    let Source::Table(name)=&j.source else{return Err("INDEXED BY requires a table".into())};
                    let mut predicates=ctx.index_predicates.clone();
                    if j.kind!="RIGHT"&&j.kind!="FULL"{predicates.extend(j.on.iter().cloned());}
                    self.indexed_source(name,index,&j.alias,ctx,&predicates,depth+1)?
                }else{self.source(&j.source,&j.alias,ctx,depth+1)?}''',1)
s=s[:a]+part+s[b:]
# Own-table DML obtains its candidate rows through the requested index.
a=s.index('            Stmt::Update { table, alias, from, sets, filter, mode, returning }',s.index('    fn run_inner'))
b=s.index('            Stmt::Pragma(',a)
part=s[a:b].replace('Stmt::Update { table, alias, from, sets, filter, mode, returning }','Stmt::Update { table, alias, from, sets, filter, mode, returning,indexed }',1)
part=part.replace('Stmt::Delete { table, alias, filter, returning }','Stmt::Delete { table, alias, filter, returning,indexed }',1)
part=part.replace('''                let original = t.rows.clone();''','''                let original=self.requested_index_rows(&t,indexed.as_deref(),alias.as_deref(),&filter.iter().cloned().collect::<Vec<_>>(),false)?;''')
s=s[:a]+part+s[b:]
# Reject indexes on views before dispatching INSTEAD OF triggers.
a=s.index('    fn mutate_view(');b=s.index('    fn root_ctx(',a)
part=s[a:b]
needle='''        let (name, event) ='''
if needle not in part: print('mutate view anchor missing')
else: part=part.replace(needle,'''        if let Stmt::Update{indexed:Some(index),..}|Stmt::Delete{indexed:Some(index),..}=&s{
            if !index.is_empty(){return Err(format!("no such index: {}",index))}
        }
'''+needle,1)
s=s[:a]+part+s[b:]
# EXPLAIN reports a forced index while binding still verifies usability.
s=s.replace('''j.alias.as_ref().unwrap_or(&name)))])''','''j.alias.as_ref().unwrap_or(&name))+&j.indexed.as_ref().filter(|n|!n.is_empty()).map(|n|format!(" USING INDEX {}",n)).unwrap_or_default())])''',1)
# Core index selection, row scan and schema routing.
pos=s.index('    fn join_sources(')
s=s[:pos]+'''    fn requested_index_rows(&self,t:&Table,index:Option<&str>,alias:Option<&str>,predicates:&[E],binding:bool)->Res<Vec<Row>>{
        let Some(name)=index.filter(|n|!n.is_empty())else{return Ok(if binding{vec![]}else{t.rows.clone()})};
        let idx=self.db.indexes.get(&key(name)).filter(|idx|idx.table.eq_ignore_ascii_case(&t.name)).ok_or_else(||format!("no such index: {}",name))?;
        if let Some(filter)=&idx.filter{
            if !partial_index_implied(predicates,filter,alias.unwrap_or(&t.name),&t.name){return Err("no query solution: requested partial index cannot be used".into())}
        }
        if binding{return Ok(vec![])}
        let proto=self.schema_ctx(t,&Row{id:0,v:vec![V::Null;t.cols.len()]});
        let coll=idx.expr.iter().map(|e|self.metadata(e,&proto).1).collect::<Vec<_>>();
        let mut entries=vec![];
        for row in &t.rows{
            let ctx=self.schema_ctx(t,row);
            if let Some(e)=&idx.filter{if self.eval(e,&ctx,None,0)?.truth()!=Some(true){continue}}
            let values=idx.expr.iter().map(|e|self.eval(e,&ctx,None,0)).collect::<Res<Vec<_>>>()?;
            entries.push((values,row.clone()));
        }
        entries.sort_by(|(a,ar),(b,br)|{
            for(i,(a,b))in a.iter().zip(b).enumerate(){let mut c=cmp(a,b,&coll[i]);if idx.desc.get(i)==Some(&true){c=c.reverse()}if c!=Ordering::Equal{return c}}
            ar.id.cmp(&br.id)
        });
        Ok(entries.into_iter().map(|(_,r)|r).collect())
    }
    fn indexed_source(&self,name:&str,index:&str,alias:&Option<String>,ctx:&Ctx,predicates:&[E],depth:usize)->Res<Data>{
        if depth>80{return Err("source recursion limit exceeded".into())}
        if index.is_empty(){return self.source(&Source::Table(name.into()),alias,ctx,depth+1)}
        if let Some((schema,table))=name.split_once('.'){
            let mut db=if schema.eq_ignore_ascii_case(&self.namespace){let mut db=self.clone();db.attached.remove("temp");db}
                else if let Some(db)=self.attached.get(&key(schema)){db.clone()}
                else if let Some(parent)=&self.fallback{return parent.indexed_source(name,index,alias,ctx,predicates,depth+1)}
                else{return Err(format!("unknown database {}",schema))};
            if db.txn.is_empty(){db.refresh()?}
            let mut local=ctx.clone();local.ctes.remove(&key(table));
            let mut data=db.indexed_source(table,index,alias,&local,predicates,depth+1)?;
            if alias.is_none(){for f in &mut data.fields{f.table=format!("{}.{}",schema,f.table)}}
            return Ok(data)
        }
        if ctx.ctes.contains_key(&key(name)){return Err(format!("no such index: {}",index))}
        if self.namespace=="main"{
            if let Some(temp)=self.attached.get("temp"){
                if temp.db.tables.contains_key(&key(name))||temp.db.views.contains_key(&key(name)){
                    return self.indexed_source(&format!("temp.{}",name),index,alias,ctx,predicates,depth+1)
                }
            }
        }
        if let Some(t)=self.db.tables.get(&key(name)){
            let rows=self.requested_index_rows(t,Some(index),alias.as_deref(),predicates,ctx.binding)?;
            let fields=self.table_fields(t,alias.as_deref().unwrap_or(name));let extra=fields.len()-t.cols.len();
            return Ok(Data{fields,rows:rows.into_iter().map(|row|{let mut v=row.v;v.extend((0..extra).map(|_|V::Int(row.id)));v}).collect()})
        }
        if self.db.views.contains_key(&key(name)){return Err(format!("no such index: {}",index))}
        for schema in &self.attach_order{
            let db=&self.attached[schema];if db.db.tables.contains_key(&key(name))||db.db.views.contains_key(&key(name)){
                return self.indexed_source(&format!("{}.{}",schema,name),index,alias,ctx,predicates,depth+1)
            }
        }
        if let Some(parent)=&self.fallback{return parent.indexed_source(name,index,alias,ctx,predicates,depth+1)}
        Err(format!("no such table: {}",name))
    }
'''+s[pos:]
# Documentation's two partial-index implication rules, plus exact conjunctions.
pos=s.index('fn column_name(')
s=s[:pos]+'''fn partial_index_implied(predicates:&[E],filter:&E,alias:&str,table:&str)->bool{
    fn terms<'a>(e:&'a E,op:&str,out:&mut Vec<&'a E>){
        if let E::Bin(n,a,b)=e{if n==op{terms(a,op,out);terms(b,op,out);return}}out.push(e)
    }
    fn local(e:&E,alias:&str,table:&str)->bool{
        if let E::Col(n)=e{if n.len()>1&&!n[n.len()-2].eq_ignore_ascii_case(alias)&&!n[n.len()-2].eq_ignore_ascii_case(table){return false}}
        !has_subquery(e)&&child_exprs(e).iter().all(|e|local(e,alias,table))
    }
    if let E::Bin(op,a,b)=filter{if op=="AND"{return partial_index_implied(predicates,a,alias,table)&&partial_index_implied(predicates,b,alias,table)}}
    let mut wanted=vec![];terms(filter,"OR",&mut wanted);
    let mut available=vec![];for e in predicates{terms(e,"AND",&mut available);}
    wanted.iter().any(|x|available.iter().any(|w|{
        if !local(w,alias,table){return false}
        if same_expression(w,x){return true}
        if let(E::Bin(op,a,b),E::Bin(xop,xa,xb))=(*w,*x){
            if ["=","=="].contains(&op.as_str())&&["=","=="].contains(&xop.as_str())&&column_name(xa).is_some()&&same_expression(a,xb)&&same_expression(b,xa){return true}
        }
        let notnull=match x{E::Unary(op,e)if op=="NOTNULL"=>Some(e.as_ref()),E::Bin(op,a,b)if op=="IS NOT"&&matches!(b.as_ref(),E::Val(V::Null))=>Some(a.as_ref()),_=>None};
        if let Some(z)=notnull{
            match w{
                E::Bin(op,a,b)if ["=","==","!=","<>","<",">","<=",">="].contains(&op.as_str())=>same_expression(z,a)||same_expression(z,b),
                E::In(e,_,_,_)|E::Like(e,_,_,_,_)|E::Between(e,_,_,_)=>same_expression(z,e),
                _=>false,
            }
        }else{false}
    }))
}
'''+s[pos:]
p.write_text(s)
