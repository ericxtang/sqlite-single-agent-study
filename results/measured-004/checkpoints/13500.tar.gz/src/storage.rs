use crate::syntax::Res;
use std::fs::{File, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
static NEXT_FILE: AtomicU64 = AtomicU64::new(0);
fn unique_path(path: &Path, kind: &str) -> PathBuf {
    let clock =
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
    path.with_file_name(format!("{}.agent-{}-{}-{}-{}",path.file_name().unwrap().to_string_lossy(),kind,std::process::id(),clock,NEXT_FILE.fetch_add(1,Ordering::Relaxed)))
}
fn sync_directory(path: &Path) -> Res<()> {
    if let Some(parent) = path.parent() {
        File::open(parent).and_then(|f|
                        f.sync_all()).map_err(|e| e.to_string())?
    }
    Ok(())
}
// Staging every participant before installing any prevents partial commits on
// serialization, preparation, or permission failures. Backups allow recovery
// from an installation error within the running process.
pub struct Prepared {
    target: PathBuf,
    staged: PathBuf,
    backup: Option<PathBuf>,
    installed: bool,
    preserve_backup: bool,
    journal_owned: bool,
}
impl Prepared {
    pub fn new(path: &Path, bytes: &[u8]) -> Res<Self> {
        if let Ok(metadata) = path.symlink_metadata() {
            if !metadata.file_type().is_file() {
                return Err("database target is not a regular file".into())
            }
        }
        let staged = unique_path(path, "tmp");
        let mut state =
            Self {
                target: path.to_path_buf(),
                staged,
                backup: None,
                installed: false,
                preserve_backup: false,
                journal_owned: false,
            };
        let mut f =
            OpenOptions::new().write(true).create_new(true).open(&state.staged).map_err(|e|
                        e.to_string())?;
        if let Ok(metadata) = path.metadata() {
            f.set_permissions(metadata.permissions()).map_err(|e|
                        e.to_string())?
        }
        f.write_all(bytes).and_then(|_|
                        f.sync_all()).map_err(|e| e.to_string())?;
        if path.exists() {
            let backup = unique_path(path, "backup");
            std::fs::hard_link(path, &backup).map_err(|e| e.to_string())?;
            state.backup = Some(backup);
        }
        sync_directory(path)?;
        Ok(state)
    }
    fn install(&mut self) -> Res<()> {
        std::fs::rename(&self.staged,
                    &self.target).map_err(|e| e.to_string())?;
        self.installed = true;
        sync_directory(&self.target)
    }
    fn restore(&mut self) -> Res<()> {
        if self.installed {
            if let Some(backup) = &self.backup {
                std::fs::rename(backup,
                            &self.target).map_err(|e| e.to_string())?
            } else {
                std::fs::remove_file(&self.target).map_err(|e| e.to_string())?
            }
            self.installed = false;
            sync_directory(&self.target)?;
        }
        Ok(())
    }
}
impl Drop for Prepared {
    fn drop(&mut self) {
        if self.journal_owned { return }
        let _ = std::fs::remove_file(&self.staged);
        if !self.preserve_backup {
            if let Some(backup) = &self.backup {
                let _ = std::fs::remove_file(backup);
            }
        }
    }
}
pub fn install_all(prepared: &mut [Prepared]) -> Res<()> {
    if prepared.len() > 1 { return install_journaled(prepared) }
    for i in 0..prepared.len() {
        if let Err(error) = prepared[i].install() {
            let mut recovery = None;
            for p in prepared[..=i].iter_mut().rev() {
                if let Err(e) = p.restore() {
                    p.preserve_backup = true;
                    recovery = Some(e)
                }
            }
            return Err(if let Some(e) = recovery {
                        format!("{}; rollback of database files failed: {}",error,e)
                    } else { error })
        }
    }
    Ok(())
}

// ASTs have more serialization levels than their SQL expression depth. Decode
// them with a bounded document depth and an explicitly-sized parsing stack.
pub fn decode_database(bytes: &[u8]) -> Res<crate::engine::Db> {
    let mut depth = 0usize;
    let mut quoted = false;
    let mut escaped = false;
    for &b in bytes {
        if quoted {
            if escaped {
                escaped = false
            } else if b == b'\\' {
                escaped = true
            } else if b == b'"' { quoted = false }
        } else {
            match b {
                b'"' => quoted = true,
                b'[' | b'{' => {
                    depth += 1;
                    if depth > 4096 {
                        return Err("database schema nesting limit exceeded".into())
                    }
                }
                b']' | b'}' =>
                    depth =
                        depth.checked_sub(1).ok_or("file is not a database")?,
                _ => {}
            }
        }
    }
    let db =
        std::thread::scope(|scope|
                    {
                        std::thread::Builder::new().name("snapshot-decoder".into()).stack_size(32
                                                            * 1024 *
                                                        1024).spawn_scoped(scope,
                                                ||
                                                    {
                                                        use serde::Deserialize;
                                                        let mut decoder =
                                                            serde_json::Deserializer::from_slice(bytes);
                                                        decoder.disable_recursion_limit();
                                                        let db =
                                                            crate::engine::Db::deserialize(&mut decoder).map_err(|_|
                                                                        "file is not a database".to_string())?;
                                                        decoder.end().map_err(|_|
                                                                    "file is not a database".to_string())?;
                                                        Ok::<_, String>(db)
                                                    }).map_err(|e|
                                                e.to_string())?.join().map_err(|_|
                                    "database decoding failed".to_string())?
                    })?;
    for (name, table) in &db.tables {
        if !name.eq_ignore_ascii_case(&table.name) || table.cols.is_empty() {
            return Err("malformed database schema".into())
        }
        let mut ids = std::collections::BTreeSet::new();
        for row in &table.rows {
            if row.v.len() != table.cols.len() || !ids.insert(row.id) ||
                    row.v.iter().any(|v|
                            matches!(v,crate::value::V::Real(f) if f.is_nan())) {
                return Err("malformed database record".into())
            }
        }
    }
    if db.sequences.iter().any(|r| r.v.len() != 2) {
        return Err("malformed sequence record".into())
    }
    Ok(db)
}

#[derive(serde::Serialize,serde::Deserialize)]
struct JournalRecord {
    entries: Vec<JournalEntry>,
}
#[derive(serde::Serialize,serde::Deserialize)]
struct JournalEntry {
    target: PathBuf,
    staged: PathBuf,
    backup: Option<PathBuf>,
}
fn journal_path(target: &Path) -> PathBuf {
    target.with_file_name(format!("{}.agent-journal",target.file_name().unwrap().to_string_lossy()))
}
fn prepared_manifest(path: &Path) -> PathBuf {
    path.with_file_name(format!("{}.prepared",path.file_name().unwrap().to_string_lossy()))
}
fn write_synced(path: &Path, bytes: &[u8]) -> Res<()> {
    let mut f =
        OpenOptions::new().create_new(true).write(true).open(path).map_err(|e|
                    e.to_string())?;
    let result =
        f.write_all(bytes).and_then(|_|
                        f.sync_all()).map_err(|e|
                    e.to_string()).and_then(|_| sync_directory(path));
    if result.is_err() {
        let _ = std::fs::remove_file(path);
        let _ = sync_directory(path);
    }
    result
}
fn coordinator_lock() -> Res<File> {
    let path = Path::new("/work/.agent-commit-lock");
    if path.symlink_metadata().is_ok_and(|m| m.file_type().is_symlink()) {
        return Err("invalid transaction coordinator lock".into())
    }
    let file =
        OpenOptions::new().read(true).write(true).create(true).open(path).map_err(|e|
                    e.to_string())?;
    file.try_lock().map_err(|_| "database commit is busy")?;
    Ok(file)
}
fn create_journal(prepared: &[Prepared]) -> Res<(PathBuf, JournalRecord)> {
    let manifest =
        unique_path(Path::new("/work/.agent-transaction"), "commit");
    let record =
        JournalRecord {
            entries: prepared.iter().map(|p|
                        JournalEntry {
                            target: p.target.clone(),
                            staged: p.staged.clone(),
                            backup: p.backup.clone(),
                        }).collect(),
        };
    let pending = prepared_manifest(&manifest);
    let mut markers = vec![];
    let attempt =
        (||
                    {
                        write_synced(&pending,
                                &serde_json::to_vec(&record).map_err(|e| e.to_string())?)?;
                        for entry in &record.entries {
                            let marker = journal_path(&entry.target);
                            write_synced(&marker,
                                    &serde_json::to_vec(&manifest).map_err(|e|
                                                    e.to_string())?)?;
                            markers.push(marker);
                        }
                        std::fs::rename(&pending,
                                    &manifest).map_err(|e| e.to_string())?;
                        sync_directory(&manifest)?;
                        Ok::<_, String>(())
                    })();
    if let Err(e) = attempt {
        for marker in markers { let _ = std::fs::remove_file(marker); }
        let _ = std::fs::remove_file(&pending);
        let _ = std::fs::remove_file(&manifest);
        return Err(e)
    }
    Ok((manifest, record))
}
fn finish_journal(manifest: &Path, record: &JournalRecord, committed: bool)
    -> Res<()> {
    for entry in &record.entries {
        if committed {
            if entry.staged.exists() {
                std::fs::rename(&entry.staged,
                            &entry.target).map_err(|e| e.to_string())?
            } else if !entry.target.exists() {
                return Err("incomplete committed transaction".into())
            }
        } else if let Some(backup) = &entry.backup {
            if backup.exists() {
                std::fs::rename(backup,
                            &entry.target).map_err(|e| e.to_string())?
            }
        } else if !entry.staged.exists() && entry.target.exists() {
            std::fs::remove_file(&entry.target).map_err(|e| e.to_string())?;
        }
        sync_directory(&entry.target)?;
    }
    // All target files reach the chosen outcome before any marker disappears.
    for entry in &record.entries {
        let marker = journal_path(&entry.target);
        if marker.exists() {
            std::fs::remove_file(&marker).map_err(|e| e.to_string())?;
            sync_directory(&marker)?
        }
    }
    for entry in &record.entries {
        let _ = std::fs::remove_file(&entry.staged);
        if let Some(backup) = &entry.backup {
            let _ = std::fs::remove_file(backup);
        }
    }
    for path in [manifest.to_path_buf(), prepared_manifest(manifest)] {
        if path.exists() {
            std::fs::remove_file(&path).map_err(|e| e.to_string())?;
        }
    }
    sync_directory(manifest)
}
fn install_journaled(prepared: &mut [Prepared]) -> Res<()> {
    let _coordinator = coordinator_lock()?;
    let (manifest, record) = create_journal(prepared)?;
    for p in prepared.iter_mut() { p.journal_owned = true }
    for i in 0..prepared.len() {
        if let Err(error) = prepared[i].install() {
            // Switch the durable decision to rollback before restoring files.
            let pending = prepared_manifest(&manifest);
            std::fs::rename(&manifest,
                        &pending).map_err(|e|
                        format!("{}; transaction recovery required: {}",error,e))?;
            sync_directory(&pending)?;
            finish_journal(&manifest, &record, false)?;
            for p in prepared.iter_mut() { p.journal_owned = false }
            return Err(error)
        }
    }
    finish_journal(&manifest, &record, true)?;
    for p in prepared.iter_mut() { p.journal_owned = false }
    Ok(())
}
fn confined_journal_file(path: &Path) -> bool {
    path.is_absolute() && path.starts_with("/work") &&
                path.components().all(|p|
                        !matches!(p,std::path::Component::ParentDir)) &&
            path.parent().and_then(|p|
                        p.canonicalize().ok()).is_some_and(|p|
                    p.starts_with("/work")) &&
        !path.symlink_metadata().is_ok_and(|m| m.file_type().is_symlink())
}
pub fn recover_database(target: &Path) -> Res<()> {
    let marker = journal_path(target);
    if !marker.exists() { return Ok(()) }
    if !confined_journal_file(&marker) {
        return Err("invalid database recovery journal".into())
    }
    let _coordinator = coordinator_lock()?;
    if !marker.exists() { return Ok(()) }
    let manifest: PathBuf =
        serde_json::from_slice(&std::fs::read(&marker).map_err(|e|
                                    e.to_string())?).map_err(|_|
                    "invalid database recovery journal")?;
    if !confined_journal_file(&manifest) ||
                manifest.parent() != Some(Path::new("/work")) ||
            !manifest.file_name().unwrap().to_string_lossy().starts_with(".agent-transaction.agent-commit-")
        {
        return Err("invalid transaction manifest path".into())
    }
    let committed = manifest.exists();
    let data_path =
        if committed {
            manifest.clone()
        } else { prepared_manifest(&manifest) };
    if !confined_journal_file(&data_path) {
        return Err("invalid transaction manifest".into())
    }
    let record: JournalRecord =
        serde_json::from_slice(&std::fs::read(&data_path).map_err(|e|
                                    e.to_string())?).map_err(|_|
                    "invalid transaction manifest")?;
    if record.entries.is_empty() || record.entries.len() > 32 ||
            !record.entries.iter().any(|e| e.target == target) {
        return Err("invalid transaction manifest".into())
    }
    let mut targets = std::collections::BTreeSet::new();
    for entry in &record.entries {
        let prefix =
            entry.target.file_name().ok_or("invalid recovery target")?.to_string_lossy();
        if !confined_journal_file(&entry.target) ||
                                !targets.insert(entry.target.clone()) ||
                            !confined_journal_file(&entry.staged) ||
                        entry.staged.parent() != entry.target.parent() ||
                    !entry.staged.file_name().unwrap().to_string_lossy().starts_with(&format!("{}.agent-tmp-",prefix))
                ||
                entry.backup.as_ref().is_some_and(|p|
                        !confined_journal_file(p) ||
                                p.parent() != entry.target.parent() ||
                            !p.file_name().unwrap().to_string_lossy().starts_with(&format!("{}.agent-backup-",prefix)))
            {
            return Err("invalid transaction recovery path".into())
        }
    }
    let mut locks = vec![];
    for target in targets {
        let lockpath =
            target.with_file_name(format!("{}.agent-lock",target.file_name().unwrap().to_string_lossy()));
        if !confined_journal_file(&lockpath) {
            return Err("invalid database lock file".into())
        }
        let file =
            OpenOptions::new().read(true).write(true).create(true).open(lockpath).map_err(|e|
                        e.to_string())?;
        file.try_lock().map_err(|_|
                    "database is locked during transaction recovery")?;
        locks.push(file);
    }
    finish_journal(&manifest, &record, committed)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn crash_child() {
        let Ok(mode) =
            std::env::var("AGENT_STORAGE_CRASH_MODE") else { return };
        let root =
            PathBuf::from(std::env::var("AGENT_STORAGE_TEST_DIR").unwrap());
        let a = root.join("a.db");
        let b = root.join("b.db");
        let database_format =
            std::env::var("AGENT_STORAGE_TEST_FORMAT").is_ok();
        let new_bytes =
            |path: &Path, label: &[u8]|
                {
                    if !database_format { return label.to_vec() }
                    let mut db =
                        decode_database(&std::fs::read(path).unwrap()).unwrap();
                    db.tables.get_mut("t").unwrap().rows[0].v[0] =
                        crate::value::V::Int(2);
                    db.generation += 1;
                    serde_json::to_vec(&db).unwrap()
                };
        let mut prepared =
            vec![Prepared::new(&a,&new_bytes(&a,b"new-a")).unwrap(),Prepared::new(&b,&new_bytes(&b,b"new-b")).unwrap()];
        let _coordinator = coordinator_lock().unwrap();
        let (manifest, _) = create_journal(&prepared).unwrap();
        for p in &mut prepared { p.journal_owned = true }
        match mode.as_str() {
            "prepared" => {
                std::fs::rename(&manifest,
                        prepared_manifest(&manifest)).unwrap();
                sync_directory(&manifest).unwrap();
            }
            "before_install" => {}
            "after_one" => { prepared[0].install().unwrap(); }
            "after_all" => {
                for p in &mut prepared { p.install().unwrap(); }
            }
            "rollback_one" => {
                prepared[0].install().unwrap();
                std::fs::rename(&manifest,
                        prepared_manifest(&manifest)).unwrap();
                sync_directory(&manifest).unwrap();
            }
            "rollback_restored" => {
                for p in &mut prepared { p.install().unwrap(); }
                std::fs::rename(&manifest,
                        prepared_manifest(&manifest)).unwrap();
                sync_directory(&manifest).unwrap();
                prepared[0].restore().unwrap();
            }
            "cleanup" => {
                for p in &mut prepared { p.install().unwrap(); }
                std::fs::remove_file(journal_path(&a)).unwrap();
                sync_directory(&a).unwrap();
            }
            _ => panic!("unknown simulated crash stage"),
        }
        std::process::exit(77)
    }
    #[test]
    fn opening_database_recovers_attached_commit() {
        let root =
            PathBuf::from(format!("/work/recovery-open-test-{}",std::process::id()));
        std::fs::create_dir(&root).unwrap();
        let a = root.join("a.db");
        let b = root.join("b.db");
        for path in [&a, &b] {
            let mut engine =
                crate::engine::Engine::open(path.to_str().unwrap()).unwrap();
            engine.execute("CREATE TABLE t(v)").unwrap();
            engine.execute("INSERT INTO t VALUES(1)").unwrap();
        }
        let status =
            std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact",
                                                "storage::tests::crash_child"]).env("AGENT_STORAGE_CRASH_MODE",
                                    "after_one").env("AGENT_STORAGE_TEST_DIR",
                                &root).env("AGENT_STORAGE_TEST_FORMAT",
                            "database").stdout(std::process::Stdio::null()).status().unwrap();
        assert_eq!(status.code(),Some(77));
        // Opening either participant must finish the entire committed group.
        for path in [&b, &a] {
            let mut engine =
                crate::engine::Engine::open(path.to_str().unwrap()).unwrap();
            assert_eq!(engine.execute("SELECT * FROM t").unwrap().rows,vec![vec![crate::value::V::Int(2)]]);
        }
        for file in std::fs::read_dir(&root).unwrap() {
            std::fs::remove_file(file.unwrap().path()).unwrap();
        }
        std::fs::remove_dir(root).unwrap();
    }
    #[test]
    fn recover_interrupted_multifile_commits() {
        for mode in
            ["prepared", "before_install", "after_one", "after_all",
                    "rollback_one", "rollback_restored", "cleanup"] {
            let root =
                PathBuf::from(format!("/work/recovery-test-{}-{}",std::process::id(),mode));
            std::fs::create_dir(&root).unwrap();
            let a = root.join("a.db");
            let b = root.join("b.db");
            std::fs::write(&a, b"old-a").unwrap();
            std::fs::write(&b, b"old-b").unwrap();
            let status =
                std::process::Command::new(std::env::current_exe().unwrap()).args(["--exact",
                                                "storage::tests::crash_child",
                                                "--nocapture"]).env("AGENT_STORAGE_CRASH_MODE",
                                    mode).env("AGENT_STORAGE_TEST_DIR",
                                &root).stdout(std::process::Stdio::null()).status().unwrap();
            assert_eq!(status.code(),Some(77));
            recover_database(if mode == "cleanup" {
                        &b
                    } else { &a }).unwrap();
            let old = mode == "prepared" || mode.starts_with("rollback");
            assert_eq!(std::fs::read(&a).unwrap(),if
            old{b"old-a"}else{b"new-a"}, "stage {}",mode);
            assert_eq!(std::fs::read(&b).unwrap(),if
            old{b"old-b"}else{b"new-b"}, "stage {}",mode);
            for file in std::fs::read_dir(&root).unwrap() {
                let file = file.unwrap();
                let name = file.file_name().to_string_lossy().into_owned();
                assert!(!name.contains("agent-journal")&&!name.contains("agent-tmp")&&!name.contains("agent-backup"));
                std::fs::remove_file(file.path()).unwrap();
            }
            std::fs::remove_dir(&root).unwrap();
        }
    }
}
