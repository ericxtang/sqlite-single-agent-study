exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
sql('CREATE TABLE empty(a,b)')
for expression in (
 '(1,2)', '(SELECT 1,2)', '(1,2)+3', 'length((1,2))',
 '(1,2)=(1,2,3)', '(1,2) BETWEEN (1,0) AND (1,2,3)',
 '(1,2) IN (SELECT 1)', '1 IN (SELECT 1,2)',
 '(1,2) IN ((1,2),(3,4))',
 'CASE WHEN 1 THEN (1,2) ELSE 3 END',
 'CASE (1,2) WHEN (1,2,3) THEN 1 END',
 'CAST((SELECT 1,2) AS TEXT)', '(1,2) IS NULL',
):
 err(f'SELECT {expression} FROM empty')
 err(f'SELECT CASE WHEN false THEN {expression} ELSE NULL END')
err('UPDATE empty SET a=(SELECT 1,2)')
err('UPDATE empty SET a=1 RETURNING (1,2)')
err('SELECT 1 FROM empty WHERE (1,2)')
err('SELECT 1 FROM empty ORDER BY (1,2)')
err('SELECT 1 FROM empty GROUP BY (1,2)')
err('SELECT EXISTS(SELECT (1,2) FROM empty)')
eq('SELECT EXISTS(SELECT 1,2)',[[1]])
eq('SELECT (1,2)=(SELECT 1,2),(1,2) IN (VALUES(1,2)),(1,2) BETWEEN (0,9) AND (2,0)',[[1,1,1]])
eq('SELECT (1,2) IN (), (1,2) NOT IN ()',[[0,1]])
eq('SELECT 2 IS TRUE,2 IS FALSE,0 IS FALSE,1 IS +TRUE',[[1,0,1,1]])
sql('CREATE TABLE bools("true","false")')
sql('INSERT INTO bools VALUES(2,3)')
eq('SELECT 1 IS TRUE,1 IS FALSE,2 IS TRUE,3 IS FALSE FROM bools',[[0,0,1,1]])
eq('SELECT (SELECT 1 IS TRUE),(SELECT 2 IS TRUE) FROM bools',[[0,1]])
eq('SELECT 1 IS TRUE FROM (SELECT 2 AS true)',[[0]])
p.terminate()
print('row-value binding and shadowed boolean identifier tests passed')
