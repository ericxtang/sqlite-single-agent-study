exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
sql('CREATE TABLE t(a INTEGER,b TEXT COLLATE NOCASE)')
sql("INSERT INTO t VALUES(1,'x'),(2,'X'),(3,'y'),(4,'y')")
eq('SELECT count(*) IN (4),sum(a) BETWEEN 1 AND 11 FROM t',[[1,1]])
eq('SELECT b,sum(a),sum(sum(a)) OVER (ORDER BY b) FROM t GROUP BY b',[['x',3,3],['y',7,10]])
eq('SELECT sum(sum(a)) OVER () FROM t',[[10]])
eq('SELECT b,sum(sum(a)) OVER (PARTITION BY count(*)) FROM t GROUP BY b',[['x',10],['y',10]])
eq('SELECT b,sum(sum(a)) FILTER(WHERE count(*)>1) OVER () FROM t GROUP BY b',[['x',10],['y',10]])
eq('SELECT count(DISTINCT b),group_concat(DISTINCT b) FROM t',[[2,'x,y']])
eq('SELECT a,sum(a) OVER (win ROWS 1 PRECEDING) FROM t WINDOW win AS (ORDER BY a)',[[1,1],[2,3],[3,5],[4,7]])
eq('SELECT a,sum(a) OVER win FROM t WINDOW win AS (ORDER BY a ROWS 1 PRECEDING)',[[1,1],[2,3],[3,5],[4,7]])
eq('SELECT a,sum(a) OVER child FROM t WINDOW base AS (PARTITION BY b),child AS (base ORDER BY a)',[[1,1],[2,3],[3,3],[4,7]])
for q in [
 'SELECT sum(sum(a)) FROM t',
 'SELECT sum(row_number() OVER ()) FROM t',
 'SELECT sum(a) AS total FROM t WHERE total>0',
 'SELECT count(*) FROM t GROUP BY 1',
 'SELECT count(*) AS n FROM t GROUP BY n',
 'SELECT row_number() OVER () AS r FROM t GROUP BY r',
 'SELECT count(*) FROM t HAVING row_number() OVER ()>0',
 'SELECT a FROM t HAVING sum(a)>0',
 'SELECT a FROM t ORDER BY sum(a)',
 'SELECT abs(a) FILTER(WHERE 1) FROM t',
 'SELECT abs(a ORDER BY a) FROM t',
 'SELECT row_number() FROM t',
 'SELECT sum(a) OVER missing FROM t',
 'SELECT sum(DISTINCT a) OVER () FROM t',
 'SELECT abs(a) OVER () FROM t',
 'SELECT row_number() FILTER(WHERE 1) OVER () FROM t',
 'SELECT sum(a) OVER (win) FROM t WINDOW win AS (ROWS UNBOUNDED PRECEDING)',
 'SELECT sum(a) OVER (win PARTITION BY b) FROM t WINDOW win AS (ORDER BY a)',
 'SELECT sum(a) OVER (win ORDER BY b) FROM t WINDOW win AS (ORDER BY a)',
 "SELECT sum(a) OVER (ORDER BY a GROUPS 0.5 PRECEDING) FROM t",
 "SELECT sum(a) OVER (ORDER BY a ROWS 'bad' PRECEDING) FROM t",
 'SELECT sum(a) OVER (ORDER BY a,b RANGE 1 PRECEDING) FROM t',
 'SELECT sum(a) OVER (ORDER BY a ROWS a PRECEDING) FROM t',
 'SELECT sum(a) OVER (ORDER BY a ROWS BETWEEN CURRENT ROW AND 1 PRECEDING) FROM t',
 'SELECT a FROM t ORDER BY 1 COLLATE missing',
]:
 err(q)
 sql('DELETE FROM t')
 err(q)
 sql("INSERT INTO t VALUES(1,'x'),(2,'X'),(3,'y'),(4,'y')")
p.terminate();print('aggregate and window validation edge tests passed')
