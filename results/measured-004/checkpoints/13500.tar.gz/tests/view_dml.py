exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
sql('CREATE TABLE base(id INTEGER PRIMARY KEY,value TEXT COLLATE NOCASE)')
sql('CREATE VIEW v AS SELECT id,value FROM base')
sql('CREATE TRIGGER vi INSTEAD OF INSERT ON v BEGIN INSERT INTO base VALUES(NEW.id,NEW.value); END')
sql('CREATE TRIGGER vu INSTEAD OF UPDATE ON v BEGIN UPDATE base SET value=NEW.value WHERE id=OLD.id; END')
sql('CREATE TRIGGER vd INSTEAD OF DELETE ON v BEGIN DELETE FROM base WHERE id=OLD.id; END')
for stmt in (
 'INSERT INTO v(missing) SELECT 1 WHERE false',
 'UPDATE v SET missing=1',
 'UPDATE v SET value=missing',
 'UPDATE v SET value=sum(id)',
 'DELETE FROM v WHERE missing',
 'DELETE FROM v WHERE count(*)>0',
 'INSERT INTO v VALUES(1,2) ON CONFLICT DO NOTHING',
 'INSERT INTO v VALUES(1,2) RETURNING missing',
):
 err(stmt)
eq("INSERT INTO v VALUES(1,'A'),(2,'B') RETURNING *",[[1,'A'],[2,'B']])
eq('SELECT changes()',[[0]])
eq("UPDATE v SET value='changed' WHERE id='1' RETURNING id,value",[[1,'changed']])
sql("UPDATE v SET value='lower' WHERE value='b'")
eq('SELECT * FROM base ORDER BY id',[[1,'changed'],[2,'lower']])
sql('CREATE TABLE src(id,label)')
sql("INSERT INTO src VALUES(1,'one'),(2,'two')")
eq('UPDATE v SET value=src.label FROM src WHERE v.id=src.id RETURNING id,value',[[1,'one'],[2,'two']])
err('UPDATE v SET value=src.label FROM src WHERE v.id=src.id RETURNING src.label')
sql('PRAGMA count_changes=ON')
eq("UPDATE v SET value=value||'!'",[[2]])
eq('SELECT changes()',[[0]])
eq('DELETE FROM v WHERE id=2',[[1]])
sql('PRAGMA count_changes=OFF')
# Permanent views read their own schema even when a temp table shadows a base table.
sql('CREATE TEMP TABLE base(id,value)')
sql("INSERT INTO temp.base VALUES(99,'temp')")
eq("UPDATE main.v SET value='main' WHERE id=1 RETURNING id,value",[[1,'main']])
eq('SELECT * FROM main.base',[[1,'main']])
eq('SELECT * FROM temp.base',[[99,'temp']])
# INSERT only needs the view's column definitions, not its existing projection values.
sql("CREATE VIEW unevaluated AS SELECT json('bad') AS value FROM main.base")
sql('CREATE TRIGGER uv INSTEAD OF INSERT ON unevaluated BEGIN INSERT INTO main.base(value) VALUES(NEW.value); END')
sql("INSERT INTO unevaluated VALUES('inserted')")
eq('SELECT value FROM main.base ORDER BY id',[['main'],['inserted']])
sql('CREATE VIEW duplicated AS SELECT id AS a,value AS a FROM main.base')
sql('CREATE TRIGGER du INSTEAD OF UPDATE ON duplicated BEGIN UPDATE main.base SET value=NEW."a:1" WHERE id=OLD.a; END')
sql('UPDATE duplicated SET "a:1"=\'renamed\' WHERE a=1')
eq('SELECT value FROM main.base WHERE id=1',[['renamed']])
# RETURNING binds before a FAIL statement can preserve partial mutations.
sql('CREATE TABLE constrained(a UNIQUE)')
err('INSERT OR FAIL INTO constrained VALUES(1),(1) RETURNING missing')
eq('SELECT * FROM constrained',[])
sql('INSERT INTO constrained VALUES(1),(2)')
err('UPDATE OR FAIL constrained SET a=3 RETURNING missing')
eq('SELECT * FROM constrained ORDER BY a',[[1],[2]])
err('INSERT INTO constrained VALUES(3) RETURNING constrained.*')
err('DELETE FROM constrained RETURNING other.*')
eq('UPDATE constrained SET a=a RETURNING a,(SELECT count(*) FROM constrained)',[[1,2],[2,2]])
sql('CREATE TRIGGER after_value AFTER INSERT ON constrained WHEN NEW.a=5 BEGIN UPDATE constrained SET a=6 WHERE a=5; END')
eq('INSERT INTO constrained VALUES(5) RETURNING a',[[5]])
eq('SELECT a FROM constrained ORDER BY a',[[1],[2],[6]])
p.terminate()
print('view DML binding, affinity, scope, UPDATE FROM, count_changes, and RETURNING tests passed')
