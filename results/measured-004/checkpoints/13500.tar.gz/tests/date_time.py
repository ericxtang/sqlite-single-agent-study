exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
import random,datetime
req('open',path=':memory:')
eq("SELECT datetime(1092941466,'unixepoch'),datetime(1092941466,'auto'),datetime('2001-02-03','auto'),datetime(2451545,'julianday')",
   [['2004-08-19 18:51:06','2004-08-19 18:51:06','2001-02-03 00:00:00','2000-01-01 12:00:00']])
eq("SELECT datetime('2013-10-07T04:23:19.120-04:00','subsec'),strftime('%s','1970-01-01 00:00:01.234','subsec'),strftime('%T','12:34:56.789','subsec')",
   [['2013-10-07 08:23:19.120','1.234','12:34:56']])
eq("SELECT date('2024-02-29','+1 year'),date('2024-02-29','+1 year','floor'),date('2023-12-31','+2 months','floor')",
   [['2025-03-01','2025-02-28','2024-02-29']])
eq("SELECT datetime('2000-01-01','01:30'),datetime('2000-01-01','+0001-02-03 04:05'),date('2024-01-01','weekday 2.0')",
   [['2000-01-01 01:30:00','2001-03-04 04:05:00','2024-01-02']])
eq("SELECT date(0),date('0000-01-01'),date('0000-01-01','-1 day')",[['-4713-11-24','0000-01-01','-0001-12-31']])
for expression in [
 "date('')","date('bad')","date('éé-01-02')","date('2000-01-01x12:00')",
 "datetime('12:00+01x00')","datetime('12:00+01:99')","datetime('12:00+01:00tail')",
 "date('2000-01-01','julianday')","date(2451545,'+1 day','julianday')",
 "date('2000-01-01','+1 day','auto')","date(1e99)","date(1e99,'auto')",
 "date('9999-12-31','+1 day')","date('2000-01-01','+1e99 months')",
 "date('2000-01-01','+1e99 years')","date('2000-01-01','NaN days')",
 "date('2000-01-01','--01:00')","date('2000-01-01',NULL)","strftime(NULL,'2000-01-01')",
]:
 eq('SELECT '+expression,[[None]])
eq("SELECT count(DISTINCT unixepoch('subsec')) FROM generate_series(1,2000)",[[1]])
# The documented timediff invariant applies in both directions across month ends.
dates=['2024-02-29 12:34:56.123','2023-02-28 23:59:59.999','2023-03-31 00:00:00',
       '2000-01-31 11:00:00','2025-03-01 09:20:00','1900-02-28 18:00:00','2023-03-01 01:00:00']
for a in dates:
 for b in dates:
  eq("SELECT datetime("+repr(b)+",timediff("+repr(a)+","+repr(b)+"),'subsec')=datetime("+repr(a)+",'subsec')",[[1]])
rng=random.Random(173)
for _ in range(100):
 start=datetime.datetime(1980,1,1)+datetime.timedelta(seconds=rng.randrange(1500000000))
 delta=rng.randrange(-864000,864000)
 expected=start+datetime.timedelta(seconds=delta)
 eq("SELECT datetime("+repr(start.isoformat(' '))+","+repr(str(delta)+' seconds')+")",[[expected.isoformat(' ')]])
p.terminate()
# The date functions use the process timezone through the documented OS service.
p=subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,env=dict(os.environ,TZ='America/New_York'))
req('open',path=':memory:')
eq("SELECT datetime('2024-01-15 12:00:00','localtime'),datetime('2024-07-15 12:00:00','localtime')",
   [['2024-01-15 07:00:00','2024-07-15 08:00:00']])
eq("SELECT datetime('2024-01-15 07:00:00','utc'),datetime('2024-07-15 08:00:00','utc')",
   [['2024-01-15 12:00:00','2024-07-15 12:00:00']])
p.terminate();print('date/time formats, modifiers, clock, timezone, and roundtrip tests passed')
