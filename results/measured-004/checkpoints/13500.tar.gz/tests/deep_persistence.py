exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
from pathlib import Path
path=Path('/work/deep-persistence.db')
for f in [path,Path(str(path)+'.agent-lock')]:
 try:f.unlink()
 except FileNotFoundError:pass
assert req('open',path=str(path))['ok']
e='x'
for _ in range(70):e='('+e+'+1)'
sql('CREATE TABLE t(x,y GENERATED ALWAYS AS ('+e+') STORED)')
sql('INSERT INTO t(x) VALUES(1)')
eq('SELECT * FROM t',[[1,71]])
req('close');assert req('open',path=str(path))['ok']
eq('SELECT * FROM t',[[1,71]])
sql('UPDATE t SET x=5')
req('close');assert req('open',path=str(path))['ok'];eq('SELECT * FROM t',[[5,75]])
req('close')
# A malformed record must produce an operational error, not a process crash.
saved=path.read_bytes()
db=json.loads(saved);db['tables']['t']['rows'][0]['v'].pop();path.write_text(json.dumps(db))
assert not req('open',path=str(path))['ok']
assert req('open',path=':memory:')['ok'];eq('SELECT 1',[[1]]);req('close')
path.write_bytes(saved)
assert req('open',path=str(path))['ok'];eq('SELECT * FROM t',[[5,75]])
p.terminate();path.unlink();Path(str(path)+'.agent-lock').unlink()
print('deep schema persistence and malformed-record handling tests passed')
