exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
import random
r=random.Random(190926)
req('open',path=':memory:');sql('CREATE TABLE t(id INTEGER PRIMARY KEY,v INTEGER NOT NULL)')
model={};snapshot=None
for turn in range(500):
 op=r.randrange(8);i=r.randrange(30);v=r.randrange(-1000,1000)
 if op==0:
  if i in model:err(f'INSERT INTO t VALUES({i},{v})')
  else:sql(f'INSERT INTO t VALUES({i},{v})');model[i]=v
 elif op==1:
  sql(f'INSERT OR IGNORE INTO t VALUES({i},{v})');model.setdefault(i,v)
 elif op==2:
  sql(f'INSERT OR REPLACE INTO t VALUES({i},{v})');model[i]=v
 elif op==3:
  sql(f'UPDATE t SET v=v+{v} WHERE id={i}')
  if i in model:model[i]+=v
 elif op==4:
  sql(f'DELETE FROM t WHERE id={i}');model.pop(i,None)
 elif op==5 and snapshot is None:
  sql('BEGIN');snapshot=dict(model)
 elif op==6 and snapshot is not None:
  sql('ROLLBACK');model=snapshot;snapshot=None
 elif op==7 and snapshot is not None:
  sql('COMMIT');snapshot=None
 if turn%17==0:eq('SELECT id,v FROM t ORDER BY id',[[i,v] for i,v in sorted(model.items())])
eq('SELECT id,v FROM t ORDER BY id',[[i,v] for i,v in sorted(model.items())])
p.terminate();print('500-operation transactional model test passed')
