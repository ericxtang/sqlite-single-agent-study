exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
sql('CREATE TABLE t(a TEXT COLLATE NOCASE,b INTEGER)')
for query in ['SELECT missing FROM t','SELECT a FROM t WHERE missing=1','SELECT no_function(a) FROM t','SELECT length(a,b) FROM t','CREATE INDEX nope ON t(missing)','SELECT a FROM t WHERE count(*)>0']:
 err(query)
sql("INSERT INTO t VALUES('a',1)")
eq("SELECT a=1,b='1' FROM (SELECT a,b FROM t)",[[0,1]])
sql('CREATE VIEW v AS SELECT b,a FROM t')
eq("SELECT b='1',a='A' FROM v",[[1,1]])
eq("SELECT '1' IN (SELECT b FROM t)",[[1]])
for ddl in ['CREATE TABLE z(a PRIMARY KEY,b PRIMARY KEY)','CREATE TABLE z(a,UNIQUE(missing))','CREATE TABLE z(a,b AS (b+1))','CREATE TABLE z(a,b AS (c+1),c AS (b+1))','CREATE TABLE z(a AS (1))','CREATE TABLE z(a,b AS (random()))','CREATE TABLE z(a COLLATE nonexistent)']:
 err(ddl)
sql('CREATE TABLE gen(a,b AS (a*3) STORED,c AS (a+1))')
assert [r[-1] for r in vals('PRAGMA table_xinfo(gen)')]==[0,3,2]
sql('CREATE TABLE auto(id INTEGER PRIMARY KEY AUTOINCREMENT,u UNIQUE)')
sql("INSERT INTO auto(u) VALUES('a')");sql("INSERT OR IGNORE INTO auto(u) VALUES('a')");sql("INSERT INTO auto(u) VALUES('b')")
eq('SELECT id FROM auto ORDER BY id',[[1],[3]])
sql('CREATE TABLE wr(a,b,PRIMARY KEY(a,b)) WITHOUT ROWID');sql('INSERT INTO wr VALUES(2,3),(1,2)');eq('SELECT * FROM wr',[[1,2],[2,3]]);err('SELECT rowid FROM wr')
path='/work/float-persist.db'
try:os.unlink(path)
except FileNotFoundError:pass
req('open',path=path);sql('CREATE TABLE nums(n)');sql('INSERT INTO nums VALUES(1e999),(2.25)');req('close');assert req('open',path=path)['ok'];eq('SELECT n FROM nums ORDER BY n',[[2.25],[float('inf')]])
p.terminate();os.unlink(path);print('schema and binding tests passed')
