import subprocess,json,os,time,threading
from pathlib import Path
root=Path('/work/storage-edge-tests');root.mkdir(exist_ok=True)
main=root/'main.db';aux=root/'aux.db';alias=root/'alias.db';saved=root/'main.saved'
for path in root.iterdir():
 if path.is_dir():path.rmdir()
 else:path.unlink()
def spawn():return subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(p,op,**kw):
 p.stdin.write(json.dumps(dict(op=op,**kw))+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(p,s):
 r=req(p,'execute',sql=s);assert r['ok'],(s,r);return r
def fail(p,s):
 r=req(p,'execute',sql=s);assert not r['ok'],(s,r)
def cells(p,s):
 return [[c.get('value')for c in row]for row in sql(p,s)['rows']]
p=spawn();q=spawn()
assert req(p,'open',path=str(main))['ok'];sql(p,'CREATE TABLE t(x)');sql(p,'INSERT INTO t VALUES(1)')
alias.symlink_to(main.name);assert req(q,'open',path=str(alias))['ok']
sql(q,'INSERT INTO t VALUES(2)')
assert alias.is_symlink();assert cells(p,'SELECT sum(x) FROM t')==[['3']]
sql(p,'BEGIN IMMEDIATE')
sql(q,'PRAGMA busy_timeout=80')
started=time.monotonic();fail(q,'INSERT INTO t VALUES(3)');assert time.monotonic()-started>=.05
sql(q,'PRAGMA busy_timeout=1000')
def release():
 time.sleep(.04);sql(p,'COMMIT')
thread=threading.Thread(target=release);thread.start();sql(q,'INSERT INTO t VALUES(3)');thread.join()
# Content returning to its former state still represents a newer commit.
sql(q,'BEGIN');sql(q,'SELECT * FROM t')
sql(p,'UPDATE t SET x=9 WHERE x=1');sql(p,'UPDATE t SET x=1 WHERE x=9')
fail(q,'INSERT INTO t VALUES(4)');sql(q,'ROLLBACK')
sql(q,f"ATTACH '{aux}' AS aux");sql(q,'CREATE TABLE aux.u(y)');sql(q,'INSERT INTO aux.u VALUES(1)')
sql(p,'BEGIN IMMEDIATE')
sql(q,'INSERT INTO aux.u VALUES(2)') # Writing aux does not require main's writer lock.
sql(p,'ROLLBACK')
sql(q,'BEGIN');sql(q,'UPDATE t SET x=x+10');sql(q,'UPDATE aux.u SET y=y+10')
main.rename(saved);main.mkdir()
fail(q,'COMMIT')
# A preparation failure must leave every other participant uncommitted.
r=spawn();assert req(r,'open',path=str(aux))['ok'];assert cells(r,'SELECT * FROM u')==[['1'],['2']]
main.rmdir();saved.rename(main)
sql(q,'COMMIT')
assert cells(p,'SELECT * FROM t ORDER BY x')==[['11'],['12'],['13']]
assert cells(r,'SELECT * FROM u ORDER BY y')==[['11'],['12']]
assert not list(root.glob('*.agent-tmp-*'));assert not list(root.glob('*.agent-backup-*'))
# Deferred-FK state resets at transaction end and propagates to attachments.
sql(q,'PRAGMA foreign_keys=ON');sql(q,'CREATE TABLE aux.parent(id PRIMARY KEY)');sql(q,'CREATE TABLE aux.child(pid REFERENCES parent)')
sql(q,'BEGIN');sql(q,'PRAGMA defer_foreign_keys=ON');sql(q,'INSERT INTO aux.child VALUES(99)')
fail(q,'COMMIT');sql(q,'ROLLBACK');assert cells(q,'PRAGMA defer_foreign_keys')==[['0']]
fail(q,'INSERT INTO aux.child VALUES(99)')
sql(q,'SAVEPOINT s');sql(q,"ATTACH ':memory:' AS late");sql(q,'CREATE TABLE late.v(x)');sql(q,'ROLLBACK TO s');sql(q,'RELEASE s')
fail(q,'SELECT * FROM late.v')
for p in [p,q,r]:p.terminate();p.wait()
for path in root.iterdir():path.unlink()
root.rmdir();print('storage failure recovery, busy timeout, aliases, and transaction settings tests passed')
