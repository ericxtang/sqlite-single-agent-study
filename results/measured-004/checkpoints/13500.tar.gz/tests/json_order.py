exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
eq("""SELECT json_extract('{"z":1,"a":2,"z":3}','$.z'),
 json_remove('{"z":1,"a":2,"z":3}','$.z'),
 json_set('{"z":1,"a":2,"z":3}','$.z',4)""",[[1,'{"a":2,"z":3}','{"z":4,"a":2,"z":3}']])
eq("""SELECT key,value FROM json_each('{"z":1,"a":2,"z":3}')""",[['z',1],['a',2],['z',3]])
eq("""SELECT json_extract('{"o":{"z":1,"a":2}}','$.o')""",[['{"z":1,"a":2}']])
eq("""SELECT json_set('{}','$.a[3]',1),json_set('[]','$[0][2]',1),json_set('{}','$.a[0]',1)""",[['{}','[]','{"a":[1]}']])
eq("""SELECT json_extract('[1,2]','$[#]'),json_extract('[1,2]','$[#-0]'),json_extract('[1,2]','$[#-1]')""",[[None,None,2]])
eq("""SELECT json_set('[1,2]','$[#-0]',3),json_insert('[1,2]','$[#]',3)""",[['[1,2,3]','[1,2,3]']])
eq("""SELECT json_patch('{"z":1,"a":2}','{"z":3,"b":4}')""",[['{"z":3,"a":2,"b":4}']])
eq("""SELECT json_pretty('{"z":1,"a":[2]}')""",[['{\n    "z": 1,\n    "a": [\n        2\n    ]\n}']])
eq("""SELECT json_pretty('{"a":[1,2]}','--')""",[['{\n--"a": [\n----1,\n----2\n--]\n}']])
eq("""SELECT fullkey FROM json_tree('{"a.b":1,"":2,"simple":3}') WHERE atom IS NOT NULL""",[['$."a.b"'],['$.""'],['$.simple']])
eq("""SELECT json_extract('{"a.b":1,"":2}','$."a.b"'),json_extract('{"a.b":1,"":2}','$.""')""",[[1,2]])
for path in ['$[-1]','$[+1]','$[]','$.','$[#-]']:
 err("SELECT json_extract('[1,2]',"+repr(path)+")")
eq("""SELECT json_error_position('{"a":}'),json_error_position('[1,]'),json_error_position('{"é":}'),json_error_position('{a:1,}')""",[[6,0,6,0]])
# Limits refer to JSON nesting, independent of SQL expression depth.
doc='['*1000+'0'+']'*1000
eq("SELECT json_valid('"+doc+"')",[[1]])
eq("SELECT json_valid('["+doc+"]')",[[0]])
p.terminate();print('ordered JSON, paths, and pretty printing tests passed')
