exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
from pathlib import Path
main=Path('/work/atomic-main.db');aux=Path('/work/atomic-aux.db')
for path in [main,aux]:
 for f in [path,Path(str(path)+'.agent-lock')]:
  try:f.unlink()
  except FileNotFoundError:pass
req('open',path=str(main));sql(f"ATTACH '{aux}' AS aux")
sql('CREATE TABLE t(id INTEGER PRIMARY KEY)')
sql('CREATE TABLE aux.audit(id UNIQUE)')
sql("""CREATE TEMP TRIGGER cross_write AFTER INSERT ON main.t BEGIN
 INSERT INTO audit VALUES(new.id);
 SELECT CASE WHEN new.id=2 THEN RAISE(ABORT,'stop') END;
 END""")
err('INSERT INTO t VALUES(1),(2)')
eq('SELECT * FROM t',[]);eq('SELECT * FROM aux.audit',[])
# Verify on-disk state from another connection as well.
q=subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def other(op,**kw):
 q.stdin.write(json.dumps(dict(op=op,**kw))+'\n');q.stdin.flush();return json.loads(q.stdout.readline())
assert other('open',path=str(aux))['ok']
assert other('execute',sql='SELECT * FROM audit')['rows']==[]
sql('DROP TRIGGER cross_write')
sql("""CREATE TEMP TRIGGER cross_fail AFTER INSERT ON main.t BEGIN
 INSERT INTO audit VALUES(new.id);
 SELECT CASE WHEN new.id=2 THEN RAISE(FAIL,'stop') END;
 END""")
err('INSERT INTO t VALUES(1),(2),(3)')
eq('SELECT * FROM t',[[1],[2]]);eq('SELECT * FROM aux.audit',[[1],[2]])
assert len(other('execute',sql='SELECT * FROM audit')['rows'])==2
sql('DROP TRIGGER cross_fail')
sql("""CREATE TEMP TRIGGER cross_rollback AFTER INSERT ON main.t WHEN new.id=20 BEGIN
 INSERT OR ROLLBACK INTO audit VALUES(1);
 END""")
sql('BEGIN');sql('INSERT INTO t VALUES(10)')
err('INSERT INTO t VALUES(20)')
eq('SELECT * FROM t',[[1],[2]]);eq('SELECT * FROM aux.audit',[[1],[2]])
err('COMMIT')
# Explicit transactions retain both participants after an ordinary ABORT error.
sql('BEGIN');sql('INSERT INTO t VALUES(30)');sql('INSERT INTO aux.audit VALUES(30)')
err('INSERT INTO aux.audit VALUES(1)')
sql('COMMIT')
eq('SELECT * FROM t',[[1],[2],[30]]);eq('SELECT * FROM aux.audit',[[1],[2],[30]])
p.terminate();q.terminate();p.wait();q.wait()
for path in [main,aux]:
 path.unlink();Path(str(path)+'.agent-lock').unlink()
print('cross-schema trigger statement atomicity and conflict policy tests passed')
