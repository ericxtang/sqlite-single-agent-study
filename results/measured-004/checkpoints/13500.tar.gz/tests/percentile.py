exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
sql('CREATE TABLE t(g,x,p)')
sql("INSERT INTO t VALUES('a',0,25),('a',10,25),('a',20,25),('a',30,25),('a',NULL,25),('b',7,50)")
eq('SELECT g,median(x),percentile(x,p),percentile_cont(x,p/100.0),percentile_disc(x,p/100.0),count() FROM t GROUP BY g ORDER BY g',
 [['a',15.0,7.5,7.5,0.0,5],['b',7.0,7.0,7.0,7.0,1]])
r=sql('SELECT median(x),percentile_disc(x,0.5) FROM t')
assert all(c['type']=='real' for c in r['rows'][0]),r
eq("SELECT median(x) FILTER(WHERE g='a'),median(DISTINCT p),percentile(x,0),percentile(x,100) FROM t",[[15.0,37.5,0.0,30.0]])
eq('SELECT median(x),percentile(x,50),count() FROM t WHERE false',[[None,None,0]])
eq('SELECT median(NULL),percentile(NULL,25)',[[None,None]])
eq("SELECT x,median(x) OVER(ORDER BY x ROWS BETWEEN 1 PRECEDING AND CURRENT ROW) FROM t WHERE g='a' AND x IS NOT NULL ORDER BY x",
 [[0,0.0],[10,5.0],[20,15.0],[30,25.0]])
eq("SELECT x,percentile_cont(x,0.25) OVER(PARTITION BY g ORDER BY x ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING),percentile_disc(x,0.5) OVER(PARTITION BY g) FROM t WHERE g='a' ORDER BY x",
 [[None,7.5,10.0],[0,7.5,10.0],[10,7.5,10.0],[20,7.5,10.0],[30,7.5,10.0]])
for q in ("SELECT median('bad')","SELECT median(x'01')","SELECT median(9e999)",
          "SELECT percentile(1,NULL)","SELECT percentile(1,-1)","SELECT percentile(1,101)",
          "SELECT percentile_cont(1,2)","SELECT percentile_disc(1,9e999)",
          "SELECT percentile(x,p) FROM t","SELECT median()","SELECT percentile(1)",
          "SELECT median(x) FROM t WHERE median(x)>0"):
 err(q)
eq('WITH input(x,p) AS(VALUES(1,50.0),(3,50.0005)) SELECT percentile(x,p) FROM input',[[2.0]])
err('WITH input(x,p) AS(VALUES(1,50.0),(3,50.01)) SELECT percentile(x,p) FROM input')
eq('WITH input(x) AS(VALUES(-1e308),(1e308)) SELECT median(x) FROM input',[[0.0]])
eq('WITH input(x) AS(VALUES(1e308),(1e308)) SELECT median(x) FROM input',[[1e308]])
p.terminate()
print('median and percentile aggregate, validation, and window tests passed')
