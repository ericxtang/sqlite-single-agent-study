exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
eq('SELECT ?,?1,:name,@name,$name,$foo::bar(a-b/c),?32766',[[None]*7])
eq('SELECT :same,:same,?32766,?32766',[[None]*4])
eq('WITH c AS (SELECT ?32765 AS n) SELECT ?,n FROM c',[[None,None]])
eq('SELECT coalesce(:x,7), ? IS NULL, typeof(@x)',[[7,1,'null']])
for query in ['SELECT ?0','SELECT ?32767','SELECT ?999999999999999999999999','SELECT ?32766,?',
              'SELECT ?32766,:new','SELECT :','SELECT @','SELECT $','SELECT $var(bad text)',
              'CREATE TABLE ?(a)','SELECT 1 AS ?']:
 err(query)
sql('CREATE TABLE t(a,b)')
sql('INSERT INTO t VALUES(?,coalesce(:value,5))')
eq('SELECT * FROM t',[[None,5]])
sql('CREATE TABLE copied AS SELECT ? AS a')
eq('SELECT * FROM copied',[[None]])
for statement in ['CREATE TABLE bad(a DEFAULT (?))','CREATE TABLE bad(a CHECK(a>?))',
                  'CREATE TABLE bad(a,b AS (a+?))','CREATE INDEX bad ON t(a+?)',
                  'CREATE INDEX bad ON t(a) WHERE b>?',
                  'CREATE VIEW bad AS SELECT ?',
                  'CREATE TRIGGER bad AFTER INSERT ON t BEGIN SELECT ?; END',
                  'ALTER TABLE t ADD bad DEFAULT (?)',
                  'ALTER TABLE t ADD bad CHECK(bad>?)']:
 err(statement)
eq('SELECT "NULL","true","false","current_date"', [['NULL','true','false','current_date']])
sql('CREATE TABLE quoted("NULL", "true", "false", "current_date")')
sql('INSERT INTO quoted VALUES(1,2,3,4)')
eq('SELECT "NULL","true","false","current_date" FROM quoted',[[1,2,3,4]])
eq('SELECT [NULL],'+chr(96)+'true'+chr(96)+' FROM quoted',[[1,2]])
err('SELECT [NULL]')
err('SELECT [true]')
err('SELECT [current_date]')
eq('SELECT 2 AS n UNION ALL SELECT 1 ORDER BY "n"',[[1],[2]])
err('CREATE TABLE invalid_default(a DEFAULT "text")')
err('CREATE TABLE invalid_default(a DEFAULT ("text"))')
err('ALTER TABLE t ADD bad DEFAULT "text"')
sql("CREATE TABLE good_default(a DEFAULT ('text'),b DEFAULT (abs(-2)),c DEFAULT TRUE)")
sql('INSERT INTO good_default DEFAULT VALUES')
eq('SELECT * FROM good_default',[['text',2,1]])
sql('CREATE TABLE q1(a)');sql('CREATE TABLE q2(a)')
err('SELECT "a" FROM q1,q2')
eq('SELECT "unbound" FROM q1,q2',[])
p.terminate()
print('Parameter tokens, numbering limits, schema restrictions, defaults, and quoted names passed')
