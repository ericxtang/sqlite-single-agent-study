exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
sql('CREATE TABLE a(id INTEGER,x)')
sql('CREATE TABLE b(id TEXT,y)')
sql('CREATE TABLE c(id INTEGER,z)')
sql("INSERT INTO a VALUES(1,'a'),(2,'b')")
sql("INSERT INTO b VALUES('01','one'),('3','three')")
sql("INSERT INTO c VALUES(1,'first'),(3,'third')")
eq('SELECT * FROM a JOIN b USING(id)',[[1,'a','one']])
eq('SELECT * FROM a NATURAL JOIN b',[[1,'a','one']])
eq('SELECT a.id,b.id FROM a JOIN b USING(id)',[[1,'01']])
eq('SELECT * FROM (a)',[[1,'a'],[2,'b']])
eq('SELECT a.id,x,y FROM (a JOIN b USING(id))',[[1,'a','one']])
eq('SELECT id,x,y FROM (a JOIN b USING(id)) AS joined',[[1,'a','one']])
eq('SELECT joined.id,joined.x,joined.y FROM (a JOIN b USING(id)) AS joined',[[1,'a','one']])
eq('SELECT a.id,x,y,z FROM a LEFT JOIN (b INNER JOIN c USING(id)) ON a.id=b.id ORDER BY a.id',[[1,'a','one','first'],[2,'b',None,None]])
eq('SELECT a.id,x,y,z FROM (a LEFT JOIN b USING(id)) LEFT JOIN c ON a.id=c.id ORDER BY a.id',[[1,'a','one','first'],[2,'b',None,None]])
eq('SELECT a.*,b.* FROM ((a JOIN b USING(id)))',[[1,'a','01','one']])
eq('SELECT * FROM (a JOIN (b JOIN c USING(id)) USING(id))',[[1,'a','one','first']])
eq('SELECT id,x,y FROM a FULL JOIN b USING(id) ORDER BY id',[[1,'a','one'],[2,'b',None],['3',None,'three']])
for q in [
 'SELECT * FROM a NATURAL JOIN b ON a.id=b.id',
 'SELECT * FROM a JOIN b ON a.id=b.id USING(id)',
 'SELECT * FROM a JOIN b ON missing=1',
 'SELECT * FROM a JOIN b ON count(*)=1',
]:
 err(q)
sql('DELETE FROM b')
err('SELECT * FROM a JOIN b ON missing=1')
err('SELECT * FROM a JOIN b ON count(*)=1')
p.terminate();print('parenthesized joins and affinity tests passed')
