import subprocess,json,os
path='/work/concurrent.db'
for f in [path,path+'.agent-lock']:
 try:os.unlink(f)
 except FileNotFoundError:pass
def spawn():return subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(p,op,**kw):
 p.stdin.write(json.dumps(dict(op=op,**kw))+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(p,s):return req(p,'execute',sql=s)
def ok(p,s):
 r=sql(p,s);assert r['ok'],(s,r);return r
p=spawn();q=spawn();assert req(p,'open',path=path)['ok'];ok(p,'CREATE TABLE t(v)');assert req(q,'open',path=path)['ok'];ok(p,'INSERT INTO t VALUES(1)');assert ok(q,'SELECT * FROM t')['rows'][0][0]['value']=='1'
ok(q,'BEGIN');ok(q,'SELECT 1');ok(p,'INSERT INTO t VALUES(99)');assert len(ok(q,'SELECT * FROM t')['rows'])==2;ok(q,'ROLLBACK');ok(p,'DELETE FROM t WHERE v=99')
ok(p,'BEGIN IMMEDIATE');ok(p,'INSERT INTO t VALUES(2)');assert len(ok(q,'SELECT * FROM t')['rows'])==1;assert not sql(q,'INSERT INTO t VALUES(3)')['ok'];ok(p,'COMMIT');assert len(ok(q,'SELECT * FROM t')['rows'])==2
ok(q,'BEGIN');ok(q,'SELECT * FROM t');ok(p,'INSERT INTO t VALUES(4)');assert len(ok(q,'SELECT * FROM t')['rows'])==2;assert not sql(q,'INSERT INTO t VALUES(5)')['ok'];ok(q,'ROLLBACK');assert len(ok(q,'SELECT * FROM t')['rows'])==3
ok(p,'BEGIN');ok(p,'INSERT INTO t VALUES(9)');p.kill();p.wait();ok(q,'INSERT INTO t VALUES(10)');assert len(ok(q,'SELECT * FROM t')['rows'])==4
q.terminate();q.wait();os.unlink(path);os.unlink(path+'.agent-lock');print('concurrency and crash rollback tests passed')
