exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
eq('WITH RECURSIVE c(x) AS (VALUES(1) UNION ALL SELECT 2) SELECT * FROM c',[[1],[2]])
eq('WITH c(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM c WHERE x<5) SELECT sum(x) FROM c',[[15]])
eq('WITH c(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM c LIMIT 3 OFFSET 2) SELECT * FROM c',[[3],[4],[5]])
eq('WITH c(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM c LIMIT 0) SELECT * FROM c',[])
eq('WITH c(x) AS (VALUES(1),(10) UNION ALL SELECT x+1 FROM c WHERE x<3) SELECT * FROM c',[[1],[10],[2],[3]])
eq('WITH c(x) AS (SELECT 1 UNION SELECT 10 UNION ALL SELECT x+1 FROM c WHERE x<3) SELECT * FROM c',[[1],[10],[2],[3]])
eq('WITH c(x) AS (VALUES(NULL),(NULL) UNION SELECT x FROM c) SELECT * FROM c',[[None]])
eq("WITH c(x) AS (SELECT 'x' COLLATE NOCASE UNION SELECT 'X' FROM c) SELECT * FROM c",[['x']])
eq('WITH a AS (SELECT * FROM b),b(x) AS (VALUES(9)) SELECT * FROM a',[[9]])
eq('WITH unused AS (SELECT abs(-9223372036854775808)) SELECT 1',[[1]])
eq('WITH unused AS (SELECT * FROM missing) SELECT 1',[[1]])
sql('CREATE TABLE edges(parent,child)')
sql("INSERT INTO edges VALUES('A','B'),('A','C'),('B','D'),('B','E'),('C','F')")
prefix="""WITH walk(node,level) AS (
 VALUES('A',0) UNION ALL
 SELECT child,level+1 FROM edges JOIN walk ON parent=node"""
eq(prefix+' ORDER BY 2) SELECT * FROM walk',[['A',0],['B',1],['C',1],['D',2],['E',2],['F',2]])
eq(prefix+' ORDER BY 2 DESC) SELECT * FROM walk',[['A',0],['B',1],['D',2],['E',2],['C',1],['F',2]])
eq(prefix+' ORDER BY 2 DESC LIMIT 3 OFFSET 1) SELECT * FROM walk',[['B',1],['D',2],['E',2]])
eq('WITH c(x) AS (VALUES(1) UNION SELECT x+1 FROM c WHERE x<3 UNION SELECT x+2 FROM c WHERE x<3) SELECT * FROM c',[[1],[2],[3],[4]])
for q in [
 'WITH a AS (SELECT * FROM b), b AS (SELECT * FROM a) SELECT * FROM a',
 'WITH c(x) AS (SELECT x FROM c) SELECT * FROM c',
 'WITH c(x) AS (VALUES(1) UNION ALL SELECT a.x FROM c a,c b) SELECT * FROM c',
 'WITH c(x) AS (VALUES(1) UNION ALL SELECT (SELECT x FROM c) FROM c) SELECT * FROM c',
 'WITH c(x) AS (VALUES(1) UNION ALL SELECT sum(x) FROM c) SELECT * FROM c',
 'WITH c(x) AS (VALUES(1) UNION SELECT x+1 FROM c WHERE x<3 UNION ALL SELECT x+2 FROM c WHERE x<3) SELECT * FROM c',
 'WITH c(x) AS (VALUES(1) UNION ALL SELECT missing FROM c WHERE 0) SELECT * FROM c',
 'WITH c(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM c ORDER BY missing LIMIT 1) SELECT * FROM c',
]:
 err(q)
# Larger finite recursion verifies that execution is iterative rather than stack-recursive.
eq('WITH c(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM c WHERE x<12000) SELECT count(*),sum(x) FROM c',[[12000,72006000]])
p.terminate();print('recursive queue and CTE dependency tests passed')
