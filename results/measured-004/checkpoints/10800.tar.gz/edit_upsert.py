from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('''    Insert {
        table: String,''','''    Insert {
        table: String,
        alias: Option<String>,''',1)
s=s.replace('upsert: Option<Upsert>','upsert: Vec<Upsert>')
s=s.replace('''pub struct Upsert {
    pub target: Vec<String>,''','''pub struct Upsert {
    pub target: Vec<E>,
    pub target_filter: Option<E>,''')
s=s.replace('''            if self.eat("AS") { self.ident()?; }
            let cols''','''            let alias=if self.eat("AS"){Some(self.ident()?)}else{None};
            let cols''',1)
a=s.index('            let upsert =',s.index('if self.at("INSERT")'));b=s.index('            return Ok(Stmt::Insert {',a)
s=s[:a]+'''            let mut upsert=vec![];
            while self.eat("ON"){
                if default{return Err("UPSERT is not allowed after DEFAULT VALUES".into())}
                if upsert.last().is_some_and(|u:&Upsert|u.target.is_empty()){return Err("only the final ON CONFLICT clause may omit its target".into())}
                self.expect("CONFLICT")?;
                let mut target=vec![];
                if self.eat("("){loop{target.push(self.expr()?);self.eat("ASC");self.eat("DESC");if !self.eat(","){break}}self.expect(")")?;}
                let target_filter=if self.eat("WHERE"){if target.is_empty(){return Err("conflict WHERE requires a target".into())}Some(self.expr()?)}else{None};
                self.expect("DO")?;
                let(sets,filter)=if self.eat("NOTHING"){(vec![],None)}else{self.expect("UPDATE")?;self.expect("SET")?;let sets=self.sets()?;let filter=if self.eat("WHERE"){Some(self.expr()?)}else{None};(sets,filter)};
                upsert.push(Upsert{target,target_filter,sets,filter});
            }
'''+s[b:]
s=s.replace('''            return Ok(Stmt::Insert {
                        table,
                        cols,''','''            return Ok(Stmt::Insert {
                        table, alias,
                        cols,''',1)
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('''Stmt::Insert { table, cols, q, default, mode, returning, upsert }''','''Stmt::Insert { table, alias, cols, q, default, mode, returning, upsert }''',1)
a=s.index('                if let Some(u) = &upsert {',s.index('Stmt::Insert { table, alias'))
b=s.index('                let inputs =',a)
s=s[:a]+'''                let mut upsert_targets=vec![];
                let nullrow=Row{id:0,v:vec![V::Null;t.cols.len()]};
                let mut bind=self.rowctx(&t,&nullrow,alias.as_deref());
                let mut excluded=self.rowctx(&t,&nullrow,Some("excluded"));for f in &mut excluded.fields{f.hidden=true}
                bind.fields.extend(excluded.fields);bind.row.extend(excluded.row);
                for u in &upsert{
                    upsert_targets.push(self.resolve_upsert_target(&t,u)?);
                    for(n,e)in &u.sets{
                        if let Some(col)=t.cols.iter().find(|c|c.name.eq_ignore_ascii_case(n)){if col.generated.is_some(){return Err("cannot UPDATE generated column".into())}}
                        else if t.without||!["rowid","oid","_rowid_"].contains(&key(n).as_str()){return Err(format!("no such column: {}",n))}
                        if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function".into())}self.validate_expr(e,&bind)?;
                    }
                    if let Some(e)=&u.filter{if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function".into())}self.validate_expr(e,&bind)?}
                }
'''+s[b:]
a=s.index('                        if let Some(u) = &upsert {',s.index('let upsert_targets') if 'let upsert_targets' in s else s.index('let mut upsert_targets'))
b=s.index('                            if u.sets.is_empty() { continue }',a)
s=s[:a]+'''                        let mut selected=None;
                        for(u,target)in upsert.iter().zip(&upsert_targets){if let Some(i)=self.upsert_conflict(&t,&row,&conflicts,target.as_ref())?{selected=Some((u,i));break}}
                        if let Some((u,i))=selected {
'''+s[b:]
s=s.replace('''                            let i = conflicts[0];
                            let old = t.rows[i].clone();
                            let mut ctx = self.rowctx(&t, &old, None);
                            let excluded = self.rowctx(&t, &row, Some("excluded"));
                            ctx.fields.extend(excluded.fields);''','''                            let old = t.rows[i].clone();
                            let mut ctx = self.rowctx(&t, &old, alias.as_deref());
                            let mut excluded = self.rowctx(&t, &row, Some("excluded"));
                            for f in &mut excluded.fields{f.hidden=true}
                            ctx.fields.extend(excluded.fields);''',1)
a=s.index('                            let mut v = old.v.clone();',s.index('let mut selected=None;'))
b=s.index('                            let setcols =',a)
s=s[:a]+'''                            let mut v=old.v.clone();let mut requested=None;
                            for(n,e)in &u.sets{
                                let value=self.eval(e,&ctx,None,0)?;
                                if let Some(j)=t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)){v[j]=value}
                                else{requested=Some(value.clone());if let Some(j)=integer_pk(&t){v[j]=value}}
                            }
                            let r=self.prepare_row(&t,v,requested,Some(old.id)).map_err(|e|format!("!ABORT!{}",e))?;
'''+s[b:]
s=s.replace('''                            t.rows[i] = r.clone();
                            changed.push(r.clone());''','''                            t=self.db.tables[&k].clone();
                            let Some(i)=t.rows.iter().position(|row|row.id==old.id)else{continue};
                            if !self.conflicts(&t,&r,Some(i))?.is_empty(){return Err(format!("!ABORT!{}",self.unique_error(&t)))}
                            t.rows[i] = r.clone();
                            changed.push(r.clone());''',1)
# Forced ABORT takes precedence over the outer INSERT's OR conflict policy.
s=s.replace('''.trim_start_matches("!FAIL!").to_string())''','''.trim_start_matches("!FAIL!").trim_start_matches("!ABORT!").to_string())''',1)
s=s.replace('''                let rollback =
                    (mode == "ROLLBACK" && constraint) ||
                        e.starts_with("!ROLLBACK!");''','''                let forced_abort=e.starts_with("!ABORT!");
                let rollback = !forced_abort&&((mode == "ROLLBACK" && constraint) || e.starts_with("!ROLLBACK!"));''')
s=s.replace('''                let fail =
                    (mode == "FAIL" && constraint && !e.contains("FOREIGN KEY"))
                        || e.starts_with("!FAIL!");''','''                let fail = !forced_abort&&((mode == "FAIL" && constraint && !e.contains("FOREIGN KEY")) || e.starts_with("!FAIL!"));''')
s=s.replace('''            if let Some(u) = upsert {
                for (_, e) in &mut u.sets''','''            for u in upsert {
                for e in &mut u.target{strip_expr(e,schema)}
                if let Some(e)=&mut u.target_filter{strip_expr(e,schema)}
                for (_, e) in &mut u.sets''',1)
# Engine helpers resolve the actual uniqueness constraint and conflicting row.
at=s.index('    fn conflicts(')
s=s[:at]+'''    fn resolve_upsert_target(&self,t:&Table,u:&Upsert)->Res<Option<(Vec<E>,Option<E>)>>{
        if u.target.is_empty(){return Ok(None)}
        let ctx=self.rowctx(t,&Row{id:0,v:vec![V::Null;t.cols.len()]},None);
        for e in &u.target{self.validate_expr(e,&ctx)?}
        if let Some(e)=&u.target_filter{self.validate_expr(e,&ctx)?}
        let mut candidates:Vec<(Vec<E>,Option<E>)>=vec![];
        let mut cols=t.unique.clone();
        let pk=t.cols.iter().filter(|c|c.pk>0).map(|c|c.name.clone()).collect::<Vec<_>>();if !pk.is_empty(){cols.push(pk)}
        for c in &t.cols{if c.unique{cols.push(vec![c.name.clone()])}}
        if !t.without{cols.push(vec![integer_pk(t).map(|i|t.cols[i].name.clone()).unwrap_or("rowid".into())]);}
        for cols in cols{candidates.push((cols.into_iter().map(|n|E::Col(vec![n])).collect(),None))}
        for idx in self.db.indexes.values().filter(|i|i.unique&&i.table.eq_ignore_ascii_case(&t.name)){candidates.push((idx.expr.clone(),idx.filter.clone()))}
        for(expr,filter)in candidates{
            if expr.len()!=u.target.len(){continue}
            if let Some(f)=&filter{if !u.target_filter.as_ref().is_some_and(|t|same_expression(t,f)){continue}}
            let mut used=vec![false;expr.len()];let mut matches=true;
            for target in &u.target{
                if let Some(i)=expr.iter().enumerate().position(|(i,e)|!used[i]&&same_expression(order_expression(target),order_expression(e))&&explicit_coll(target).is_none_or(|c|c.eq_ignore_ascii_case(&self.metadata(e,&ctx).1))){used[i]=true}else{matches=false;break}
            }
            if matches{return Ok(Some((expr,filter)))}
        }
        Err("ON CONFLICT clause does not match any PRIMARY KEY or UNIQUE constraint".into())
    }
    fn upsert_conflict(&self,t:&Table,row:&Row,conflicts:&[usize],target:Option<&(Vec<E>,Option<E>)>)->Res<Option<usize>>{
        let Some((expr,filter))=target else{return Ok(conflicts.first().copied())};
        let new=self.rowctx(t,row,None);
        if let Some(f)=filter{if self.eval(f,&new,None,0)?.truth()!=Some(true){return Ok(None)}}
        let values=expr.iter().map(|e|self.eval(e,&new,None,0)).collect::<Res<Vec<_>>>()?;
        for &i in conflicts{
            let old=self.rowctx(t,&t.rows[i],None);
            if let Some(f)=filter{if self.eval(f,&old,None,0)?.truth()!=Some(true){continue}}
            let mut same=true;
            for (e,value)in expr.iter().zip(&values){let other=self.eval(e,&old,None,0)?;if value.null()||other.null()||cmp(value,&other,&self.metadata(e,&new).1)!=Ordering::Equal{same=false;break}}
            if same{return Ok(Some(i))}
        }
        Ok(None)
    }
'''+s[at:]
p.write_text(s)
