from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('''pub struct Db {
    #[serde(default)]
    pub generation''','''pub struct Db {
    // Connection-local checks participate in snapshots but never enter database files.
    #[serde(skip)]
    pub foreign_pending:std::collections::BTreeSet<(String,i64,usize)>,
    #[serde(default)]
    pub generation''',1)
s=s.replace('''    fn finish_transaction(&mut self) {
        self.txn.clear();''','''    fn finish_transaction(&mut self) {
        self.db.foreign_pending.clear();
        self.txn.clear();''')
start=s.index('    fn check_foreign(')
end=s.index('    fn returning(',start)
s=s[:start]+'''    fn track_foreign(&mut self,t:&Table,old:Option<&Row>,new:Option<&Row>,updated:&[String])->Res<()>{
        if !self.foreign_keys{return Ok(())}
        let name=key(&t.name);
        if let Some(old)=old{
            if new.is_none()||new.is_some_and(|r|r.id!=old.id){
                let pending=self.db.foreign_pending.iter().filter(|(n,id,_)|*n==name&&*id==old.id).cloned().collect::<Vec<_>>();
                for entry in pending{self.db.foreign_pending.remove(&entry);if let Some(new)=new{self.db.foreign_pending.insert((name.clone(),new.id,entry.2));}}
            }
        }
        if let Some(new)=new{
            for(i,f)in t.foreign.iter().enumerate(){
                let changed=old.is_none()||f.cols.iter().any(|n|{
                    let Some(c)=t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n))else{return true};
                    updated.iter().any(|u|u.eq_ignore_ascii_case(n))||old.is_some_and(|old|old.v[c]!=new.v[c])
                });
                if changed{self.db.foreign_pending.insert((name.clone(),new.id,i));}
            }
        }
        if let Some(old)=old{
            let mut pending=vec![];
            for child in self.db.tables.values(){
                for(i,f)in child.foreign.iter().enumerate(){
                    if !f.table.eq_ignore_ascii_case(&t.name){continue}
                    // Invalid external keys are ignored by DROP's implicit DELETE.
                    let Ok((_,ci,pi))=self.foreign_mapping(child,f)else{continue};
                    if new.is_some_and(|new|pi.iter().all(|&i|cmp(&old.v[i],&new.v[i],&t.cols[i].coll)==Ordering::Equal)){continue}
                    for row in &child.rows{
                        if ci.iter().zip(&pi).all(|(&c,&p)|!row.v[c].null()&&cmp(&row.v[c].apply(affinity(&t.cols[p].typ)),&old.v[p],&t.cols[p].coll)==Ordering::Equal){
                            pending.push((key(&child.name),row.id,i));
                        }
                    }
                }
            }
            self.db.foreign_pending.extend(pending);
        }
        Ok(())
    }
    fn check_foreign(&self,include_deferred:bool)->Res<()>{
        if !self.foreign_keys{return Ok(())}
        for(name,id,index)in &self.db.foreign_pending{
            let Some(t)=self.db.tables.get(name)else{continue};
            let Some(row)=t.rows.iter().find(|r|r.id==*id)else{continue};
            let Some(f)=t.foreign.get(*index)else{continue};
            if !include_deferred&&(f.deferred||self.pragmas.get("defer_foreign_keys").is_some_and(|v|v.i64()!=0)){continue}
            if f.cols.iter().any(|n|t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).is_some_and(|i|row.v[i].null())){continue}
            if !self.db.tables.contains_key(&key(&f.table)){return Err("FOREIGN KEY constraint failed".into())}
            let(parent,ci,pi)=self.foreign_mapping(t,f)?;
            if !parent.rows.iter().any(|p|ci.iter().zip(&pi).all(|(&c,&i)|cmp(&row.v[c].apply(affinity(&parent.cols[i].typ)),&p.v[i],&parent.cols[i].coll)==Ordering::Equal)){return Err("FOREIGN KEY constraint failed".into())}
        }
        Ok(())
    }
'''+s[end:]
# Tracking an insert happens once the row is installed, before its AFTER triggers.
needle='''                    self.fire(&t, "INSERT", "AFTER", None, Some(&row), &[])?;'''
assert needle in s;s=s.replace(needle,'''                    self.track_foreign(&t,None,Some(&row),&[])?;
                    self.fire(&t, "INSERT", "AFTER", None, Some(&row), &[])?;''',1)
s=s.replace('''self.cascade_update(&t, &old, &r, 0)''','''self.cascade_update(&t, &old, &r, &setcols, 0)''')
s=s.replace('''self.cascade_update(&t, &old, &row, 0)''','''self.cascade_update(&t, &old, &row, &setcols, 0)''')
s=s.replace('''fn cascade_update(&mut self,parent:&Table,old:&Row,new:&Row,depth:usize)->Res<()>{
        self.cascade_change(parent,old,Some(new),depth)
    }
    fn cascade_change(&mut self,parent:&Table,old:&Row,new:Option<&Row>,depth:usize)->Res<()>{
        if !self.foreign_keys{return Ok(())}''','''fn cascade_update(&mut self,parent:&Table,old:&Row,new:&Row,updated:&[String],depth:usize)->Res<()>{
        self.cascade_change(parent,old,Some(new),updated,depth)
    }
    fn cascade_change(&mut self,parent:&Table,old:&Row,new:Option<&Row>,updated:&[String],depth:usize)->Res<()>{
        if !self.foreign_keys{return Ok(())}
        self.track_foreign(parent,Some(old),new,updated)?;''')
s=s.replace('''self.cascade_change(&t,&before,None,depth+1)''','''self.cascade_change(&t,&before,None,&[],depth+1)''')
s=s.replace('''self.cascade_change(&t,&before,Some(&after),depth+1)''','''self.cascade_change(&t,&before,Some(&after),&f.cols,depth+1)''')
s=s.replace('''self.cascade_change(parent,old,None,depth)''','''self.cascade_change(parent,old,None,&[],depth)''')
needle='''                            let r = self.db.tables.remove(&k).is_some();'''
assert needle in s;s=s.replace(needle,'''                            let r = self.db.tables.remove(&k).is_some();
                            self.db.foreign_pending.retain(|(name,_,_)|name!=&k);''')
needle='''                self.db.tables.insert(key(&new), t);
            }
            Alter::Add'''
assert needle in s;s=s.replace(needle,'''                self.db.foreign_pending=self.db.foreign_pending.iter().map(|(name,id,f)|(if name==&k{key(&new)}else{name.clone()},*id,*f)).collect();
                self.db.tables.insert(key(&new), t);
            }
            Alter::Add''')
p.write_text(s)
