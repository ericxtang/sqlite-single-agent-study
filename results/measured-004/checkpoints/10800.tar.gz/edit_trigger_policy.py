from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('''    pub statement_nested:bool,
''','''    pub statement_nested:bool,
    pub conflict_policy:Option<String>,
''',1)
s=s.replace('''                statement_nested:false,
''','''                statement_nested:false,
                conflict_policy:None,
''',1)
s=s.replace('''    fn run(&mut self, s: Stmt, sql: &str) -> Res<ResultSet> {''','''    fn run(&mut self, mut s: Stmt, sql: &str) -> Res<ResultSet> {''')
needle='''        self.run_depth += 1;
        let result = self.run_inner(s, sql);
        self.run_depth -= 1;'''
new='''        let saved_policy=self.conflict_policy.clone();
        if let Stmt::Insert{mode,..}|Stmt::Update{mode,..}=&mut s{
            if let Some(policy)=&self.conflict_policy{*mode=policy.clone()}
            else if mode!="DEFAULT"{self.conflict_policy=Some(mode.clone())}
        }
        self.run_depth += 1;
        let result = self.run_inner(s, sql);
        self.run_depth -= 1;
        self.conflict_policy=saved_policy;'''
assert needle in s;s=s.replace(needle,new)
needle='''                let caller_ctx = self.trigger_ctx.clone();
                let db ='''
assert needle in s;s=s.replace(needle,'''                let caller_ctx = self.trigger_ctx.clone();
                let caller_policy=self.conflict_policy.clone();
                let db =''')
s=s.replace('''                let saved_nested=db.statement_nested;
                db.statement_nested=true;''','''                let saved_nested=db.statement_nested;
                let saved_policy=db.conflict_policy.clone();
                db.conflict_policy=caller_policy;
                db.statement_nested=true;''')
s=s.replace('''                db.statement_nested=saved_nested;
                db.trigger_ctx''','''                db.statement_nested=saved_nested;
                db.conflict_policy=saved_policy;
                db.trigger_ctx''')
# DO UPDATE conflict policy is ABORT, including its trigger programs.
i=s.index('    fn fire(')
s=s[:i]+'''    fn fire_abort(&mut self,table:&Table,event:&str,timing:&str,old:Option<&Row>,new:Option<&Row>,updated:&[String])->Res<bool>{
        let saved=self.conflict_policy.replace("ABORT".into());
        let result=self.fire(table,event,timing,old,new,updated);
        self.conflict_policy=saved;
        result.map_err(|e|if e.starts_with('!'){e}else{format!("!ABORT!{}",e)})
    }
'''+s[i:]
s=s.replace('''let proceed=self.fire(&t,"UPDATE","BEFORE",Some(&old),Some(&r),&setcols)?;''','''let proceed=self.fire_abort(&t,"UPDATE","BEFORE",Some(&old),Some(&r),&setcols)?;''')
# Only the UPSERT block uses r.
s=s.replace('''self.fire(&t, "UPDATE", "AFTER", Some(&old), Some(&r),
                                    &setcols)?;''','''self.fire_abort(&t, "UPDATE", "AFTER", Some(&old), Some(&r),
                                    &setcols)?;''')
# RAISE specifies an error action independent of the message text.
s=s.replace('''                    if self.trigger_ctx.is_none() {''','''                    if !self.in_trigger() {''')
s=s.replace('''                    return Err(if mode == "ROLLBACK" || mode == "FAIL" {
                                format!("!{}!{}",mode,msg)
                            } else { msg })''','''                    return Err(format!("!{}!{}",mode,msg))''')
i=s.index('    fn root_ctx(')
s=s[:i]+'''    fn in_trigger(&self)->bool{
        !self.active_triggers.is_empty()||self.trigger_ctx.as_ref().is_some_and(|ctx|ctx.fields.iter().any(|f|["old","new"].contains(&key(&f.table).as_str())))
    }
'''+s[i:]
needle='''                let aggregate = is_aggregate(&n, args.len());'''
assert needle in s;s=s.replace(needle,'''                if n=="raise"{
                    if !self.in_trigger(){return Err("RAISE() may only be used within a trigger-program".into())}
                    let mode=if let Some(E::Col(parts))=args.first(){key(&parts.join("."))}else{String::new()};
                    if !["ignore","abort","fail","rollback"].contains(&mode.as_str())||args.len()!=if mode=="ignore"{1}else{2}{return Err("invalid RAISE() arguments".into())}
                }
                let aggregate = is_aggregate(&n, args.len());''',1)
# Reject trigger timings that cannot fire on the object kind.
needle='''                self.db.triggers.insert(k, t);'''
assert needle in s;s=s.replace(needle,'''                let view=self.db.views.contains_key(&key(&t.table));
                if view&&t.timing!="INSTEAD OF"{return Err("cannot create BEFORE or AFTER trigger on view".into())}
                if !view&&t.timing=="INSTEAD OF"{return Err("cannot create INSTEAD OF trigger on table".into())}
                if t.name.to_ascii_lowercase().starts_with("sqlite_"){return Err("object name reserved for internal use".into())}
                self.db.triggers.insert(k, t);''',1)
p.write_text(s)
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('''                if self.eat("OF") {
                    loop {''','''                if self.eat("OF") {
                    if event!="UPDATE"{return Err("OF is only allowed after UPDATE".into())}
                    loop {''',1)
needle='''                    self.statement()?;
                    let end = self.ts[self.p - 1].end;'''
assert needle in s;s=s.replace(needle,'''                    let statement=self.statement()?;
                    match &statement{
                        Stmt::Insert{returning,default,..}=>{
                            if *default{return Err("DEFAULT VALUES is not allowed in triggers".into())}
                            if !returning.is_empty(){return Err("RETURNING is not allowed in triggers".into())}
                        }
                        Stmt::Update{returning,..}|Stmt::Delete{returning,..}=>{if !returning.is_empty(){return Err("RETURNING is not allowed in triggers".into())}}
                        Stmt::Query(_)=>{},
                        _=>return Err("statement is not allowed in trigger program".into())
                    }
                    let end = self.ts[self.p - 1].end;''',1)
p.write_text(s)
