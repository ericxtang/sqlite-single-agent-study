from pathlib import Path
p=Path('src/engine.rs')
s=p.read_text()
start=s.index('    fn check_foreign(')
end=s.index('    fn returning(',start)
s=s[:start]+'''    fn foreign_mapping<'a>(&'a self,child:&Table,f:&Foreign)->Res<(&'a Table,Vec<usize>,Vec<usize>)>{
        let parent=self.db.tables.get(&key(&f.table)).ok_or_else(||format!("no such table: {}.{}",self.namespace,f.table))?;
        let target=if f.target.is_empty(){let mut cols=parent.cols.iter().filter(|c|c.pk>0).collect::<Vec<_>>();cols.sort_by_key(|c|c.pk);cols.iter().map(|c|c.name.clone()).collect::<Vec<_>>()}else{f.target.clone()};
        if target.is_empty()||target.len()!=f.cols.len(){return Err("foreign key mismatch".into())}
        let ci=f.cols.iter().map(|n|child.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,_>>()?;
        let pi=target.iter().map(|n|parent.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,_>>()?;
        let mut candidates=parent.unique.clone();
        let pk=parent.cols.iter().filter(|c|c.pk>0).map(|c|c.name.clone()).collect::<Vec<_>>();if !pk.is_empty(){candidates.push(pk)}
        for c in &parent.cols{if c.unique{candidates.push(vec![c.name.clone()])}}
        for idx in self.db.indexes.values().filter(|i|i.unique&&i.table.eq_ignore_ascii_case(&parent.name)&&i.filter.is_none()){
            let cols=idx.expr.iter().map(|e|{
                let E::Col(n)=order_expression(e)else{return None};
                let c=parent.cols.iter().find(|c|n.last().is_some_and(|n|c.name.eq_ignore_ascii_case(n)))?;
                if explicit_coll(e).is_some_and(|name|!name.eq_ignore_ascii_case(&c.coll)){return None}
                Some(c.name.clone())
            }).collect::<Option<Vec<_>>>();
            if let Some(cols)=cols{candidates.push(cols)}
        }
        let mut wanted=target.iter().map(|n|key(n)).collect::<Vec<_>>();wanted.sort();
        if !candidates.into_iter().any(|cols|{let mut cols=cols.iter().map(|n|key(n)).collect::<Vec<_>>();cols.sort();cols==wanted}){return Err("foreign key mismatch".into())}
        Ok((parent,ci,pi))
    }
    fn validate_foreign_use(&self,t:&Table,event:&str,sets:&[String])->Res<()>{
        if !self.foreign_keys{return Ok(())}
        let changed=|name:&str|sets.iter().any(|n|n.eq_ignore_ascii_case(name)||integer_pk(t).is_some_and(|i|t.cols[i].name.eq_ignore_ascii_case(name)&&["rowid","oid","_rowid_"].contains(&key(n).as_str())&&!t.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n))));
        for f in &t.foreign{if event!="UPDATE"||f.cols.iter().any(|n|changed(n)){self.foreign_mapping(t,f)?;}}
        if event!="INSERT"{
            for child in self.db.tables.values(){for f in &child.foreign{
                if !f.table.eq_ignore_ascii_case(&t.name){continue}
                let target=if f.target.is_empty(){t.cols.iter().filter(|c|c.pk>0).map(|c|c.name.clone()).collect::<Vec<_>>()}else{f.target.clone()};
                if event=="DELETE"||target.iter().any(|n|changed(n)){self.foreign_mapping(child,f)?;}
            }}
        }
        Ok(())
    }
    fn check_foreign(&self,include_deferred:bool)->Res<()>{
        if !self.foreign_keys{return Ok(())}
        for t in self.db.tables.values(){
            if t.rows.is_empty(){continue}
            for f in &t.foreign{
                if !include_deferred&&(f.deferred||self.pragmas.get("defer_foreign_keys").is_some_and(|v|v.i64()!=0)){continue}
                let(parent,ci,pi)=self.foreign_mapping(t,f)?;
                for row in &t.rows{
                    if ci.iter().any(|&i|row.v[i].null()){continue}
                    if !parent.rows.iter().any(|p|ci.iter().zip(&pi).all(|(&c,&i)|cmp(&row.v[c].apply(affinity(&parent.cols[i].typ)),&p.v[i],&parent.cols[i].coll)==Ordering::Equal)){return Err("FOREIGN KEY constraint failed".into())}
                }
            }
        }
        Ok(())
    }
'''+s[end:]
needle='''        if view { return self.mutate_view(s) }
        match s {'''
assert needle in s
s=s.replace(needle,'''        if view { return self.mutate_view(s) }
        match &s{
            Stmt::Insert{table,upsert,..}=>{
                if let Some(t)=self.db.tables.get(&key(table)){self.validate_foreign_use(t,"INSERT",&[])?;for u in upsert{if !u.sets.is_empty(){self.validate_foreign_use(t,"UPDATE",&u.sets.iter().map(|(n,_)|n.clone()).collect::<Vec<_>>())?}}}
            }
            Stmt::Update{table,sets,..}=>{if let Some(t)=self.db.tables.get(&key(table)){self.validate_foreign_use(t,"UPDATE",&sets.iter().map(|(n,_)|n.clone()).collect::<Vec<_>>())?}}
            Stmt::Delete{table,..}=>{if let Some(t)=self.db.tables.get(&key(table)){self.validate_foreign_use(t,"DELETE",&[])?}}
            _=>{}
        }
        match s {''')
needle='''                for e in &t.checks {'''
assert needle in s
s=s.replace(needle,'''                for f in &t.foreign{
                    for name in &f.cols{if !t.cols.iter().any(|c|c.name.eq_ignore_ascii_case(name)){return Err(format!("unknown column {} in foreign key definition",name))}}
                    if !f.target.is_empty()&&f.target.len()!=f.cols.len(){return Err("number of columns in foreign key does not match referenced columns".into())}
                }
                for e in &t.checks {''',1)
# Check index suitability for foreign_key_check even when the child table is empty.
needle='''            for (fid, f) in t.foreign.iter().enumerate() {
                let ci ='''
assert needle in s
s=s.replace(needle,'''            for (fid, f) in t.foreign.iter().enumerate() {
                if self.db.tables.contains_key(&key(&f.table)){self.foreign_mapping(t,f)?;}
                let ci =''')
p.write_text(s)
p=Path('src/syntax.rs')
s=p.read_text()
s=s.replace('''                if event.eq_ignore_ascii_case("DELETE") {
                    f.delete = action
                } else { f.update = action }''','''                if !["CASCADE","RESTRICT","NO ACTION","SET NULL","SET DEFAULT"].contains(&action.as_str()){return Err("invalid foreign key action".into())}
                if event.eq_ignore_ascii_case("DELETE") { f.delete=action }
                else if event.eq_ignore_ascii_case("UPDATE"){f.update=action}
                else{return Err("invalid foreign key event".into())}''')
s=s.replace('''                    f.deferred = self.eat("DEFERRED");
                    self.eat("IMMEDIATE");''','''                    if self.eat("DEFERRED"){f.deferred=true}else{self.expect("IMMEDIATE")?}''')
s=s.replace('''                self.p += 2;
            } else { break }
        }
        Ok(f)''','''                self.p += 2;
                f.deferred=false;
                if self.eat("INITIALLY"){if !self.eat("DEFERRED"){self.expect("IMMEDIATE")?}}
            } else { break }
        }
        Ok(f)''')
p.write_text(s)
