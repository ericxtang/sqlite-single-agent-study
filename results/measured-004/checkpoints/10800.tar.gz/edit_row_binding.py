from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
i=s.index('    fn validate_expr(')
s=s[:i]+'''    fn validate_operand(&self,e:&E,c:&Ctx)->Res<usize>{
        match e{
            E::Tuple(es)=>{for e in es{self.validate_expr(e,c)?;}Ok(es.len())}
            E::Sub(q)=>{let mut bind=c.clone();bind.binding=true;Ok(self.query(q,&bind,1)?.columns.len())}
            _=>{self.validate_expr(e,c)?;Ok(1)}
        }
    }
    fn name_in_scope(c:&Ctx,n:&[String])->bool{
        Self::colindex(c,n).ok().flatten().is_some()||(n.len()==1&&c.aliases.contains_key(&key(&n[0])))||c.outer.as_ref().is_some_and(|c|Self::name_in_scope(c,n))
    }
'''+s[i:]
old='''            E::Bin(_, a, b) => {
                self.validate_expr(a, c)?;
                self.validate_expr(b, c)?
            }'''
new='''            E::Bin(op,a,b) if ["=","==","!=","<>","<",">","<=",">=","IS","IS NOT"].contains(&op.as_str())=>{
                if self.validate_operand(a,c)?!=self.validate_operand(b,c)?{return Err("row value size mismatch".into())}
            }
            E::Bin(_, a, b) => {
                self.validate_expr(a, c)?;
                self.validate_expr(b, c)?
            }'''
assert old in s;s=s.replace(old,new,1)
old='''            E::Between(a, b, d, _) => {
                self.validate_expr(a, c)?;
                self.validate_expr(b, c)?;
                self.validate_expr(d, c)?
            }
            E::In(e, list, q, _) => {
                self.validate_expr(e, c)?;
                for e in list { self.validate_expr(e, c)? }
                if let Some(q) = q {
                    let mut bind = c.clone();
                    bind.binding = true;
                    self.query(q, &bind, 1)?;
                }
            }
            E::Case(base, arms, end) => {
                if let Some(e) = base { self.validate_expr(e, c)? }
                for (a, b) in arms {
                    self.validate_expr(a, c)?;
                    self.validate_expr(b, c)?
                }
                if let Some(e) = end { self.validate_expr(e, c)? }
            }'''
new='''            E::Between(a,b,d,_)=>{
                let width=self.validate_operand(a,c)?;
                if self.validate_operand(b,c)?!=width||self.validate_operand(d,c)?!=width{return Err("row value size mismatch".into())}
            }
            E::In(e,list,q,_)=>{
                let width=self.validate_operand(e,c)?;
                for e in list{self.validate_expr(e,c)?;}
                if let Some(q)=q{
                    let mut bind=c.clone();bind.binding=true;
                    if self.query(q,&bind,1)?.columns.len()!=width{return Err("subquery column count mismatch".into())}
                }else if width>1&&!list.is_empty(){return Err("row value misused".into())}
            }
            E::Case(base,arms,end)=>{
                let width=base.as_ref().map(|e|self.validate_operand(e,c)).transpose()?.unwrap_or(1);
                for(a,b)in arms{
                    if self.validate_operand(a,c)?!=width{return Err("row value size mismatch".into())}
                    self.validate_expr(b,c)?;
                }
                if let Some(e)=end{self.validate_expr(e,c)?;}
            }'''
assert old in s;s=s.replace(old,new)
old='''            E::Sub(q) | E::Exists(q) => {
                let mut bind = c.clone();
                bind.binding = true;
                self.query(q, &bind, 1)?;
            }
            E::Tuple(es) => { for e in es { self.validate_expr(e, c)? } }'''
new='''            E::Sub(q)|E::Exists(q)=>{
                let mut bind=c.clone();bind.binding=true;
                let result=self.query(q,&bind,1)?;
                if matches!(e,E::Sub(_))&&result.columns.len()!=1{return Err("sub-select returns more than one column".into())}
            }
            E::Tuple(_)=>return Err("row value misused".into()),'''
assert old in s;s=s.replace(old,new)
s=s.replace('''                            if n.len() == 1 &&
                                    (n[0].eq_ignore_ascii_case("TRUE") ||''','''                            if n.len() == 1 &&!Self::name_in_scope(ctx,n)&&
                                    (n[0].eq_ignore_ascii_case("TRUE") ||''',1)
# Validate VALUES expressions before evaluating them, including unused branches.
needle='''                if base.binding {
                    for e in row { self.validate_expr(e, &base)?; }
                } else if q.exists_only'''
assert needle in s;s=s.replace(needle,'''                for e in row{self.validate_expr(e,&base)?;}
                if base.binding {
                } else if q.exists_only''',1)
p.write_text(s)
