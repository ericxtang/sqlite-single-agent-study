from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
start=s.index('    fn cascade_update(')
end=s.index('    fn foreign_violations(',start)
s=s[:start]+'''    fn cascade_update(&mut self,parent:&Table,old:&Row,new:&Row,depth:usize)->Res<()>{
        self.cascade_change(parent,old,Some(new),depth)
    }
    fn cascade_change(&mut self,parent:&Table,old:&Row,new:Option<&Row>,depth:usize)->Res<()>{
        if !self.foreign_keys{return Ok(())}
        if depth>40{return Err("too many levels of trigger recursion".into())}
        let references=self.db.tables.values().flat_map(|t|t.foreign.iter().filter(|f|f.table.eq_ignore_ascii_case(&parent.name)).map(|f|(key(&t.name),f.clone()))).collect::<Vec<_>>();
        for(name,f)in references{
            let action=if new.is_some(){&f.update}else{&f.delete};
            if action=="NO ACTION"{continue}
            let Some(child)=self.db.tables.get(&name).cloned()else{continue};
            // DML binding validates these mappings. DROP TABLE ignores schema mismatches.
            let Ok((_,ci,pi))=self.foreign_mapping(&child,&f)else{continue};
            if let Some(new)=new{if pi.iter().all(|&i|cmp(&old.v[i],&new.v[i],&parent.cols[i].coll)==Ordering::Equal){continue}}
            let affected=child.rows.iter().filter(|r|ci.iter().zip(&pi).all(|(&c,&p)|!r.v[c].null()&&cmp(&r.v[c].apply(affinity(&parent.cols[p].typ)),&old.v[p],&parent.cols[p].coll)==Ordering::Equal)).map(|r|r.id).collect::<Vec<_>>();
            if action=="RESTRICT"&&!affected.is_empty(){return Err("FOREIGN KEY constraint failed".into())}
            for id in affected{
                let Some(mut t)=self.db.tables.get(&name).cloned()else{continue};
                let Some(before)=t.rows.iter().find(|r|r.id==id).cloned()else{continue};
                if new.is_none()&&action=="CASCADE"{
                    let proceed=self.fire(&t,"DELETE","BEFORE",Some(&before),None,&[])?;
                    t=self.db.tables[&name].clone();
                    if !proceed{continue}
                    if !t.rows.iter().any(|r|r.id==id){continue}
                    t.rows.retain(|r|r.id!=id);
                    self.db.tables.insert(name.clone(),t.clone());
                    self.total+=1;
                    self.cascade_change(&t,&before,None,depth+1)?;
                    self.fire(&t,"DELETE","AFTER",Some(&before),None,&[])?;
                }else if ["CASCADE","SET NULL","SET DEFAULT"].contains(&action.as_str()){
                    let mut values=before.v.clone();
                    for(&c,&p)in ci.iter().zip(&pi){
                        values[c]=match action.as_str(){
                            "CASCADE"=>new.unwrap().v[p].clone(),
                            "SET DEFAULT"=>if let Some(e)=&t.cols[c].default{self.eval(e,&self.root_ctx(),None,0)?}else{V::Null},
                            _=>V::Null,
                        };
                    }
                    let after=self.build_row(&t,values,None,Some(before.id))?;
                    let proceed=self.fire(&t,"UPDATE","BEFORE",Some(&before),Some(&after),&f.cols)?;
                    t=self.db.tables[&name].clone();
                    if !proceed{continue}
                    let Some(i)=t.rows.iter().position(|r|r.id==before.id)else{continue};
                    self.validate_row(&t,&after)?;
                    if !self.conflicts(&t,&after,Some(i))?.is_empty(){return Err(self.unique_error(&t))}
                    t.rows[i]=after.clone();
                    self.db.tables.insert(name.clone(),t.clone());
                    self.total+=1;
                    self.cascade_change(&t,&before,Some(&after),depth+1)?;
                    self.fire(&t,"UPDATE","AFTER",Some(&before),Some(&after),&f.cols)?;
                }
            }
        }
        Ok(())
    }
'''+s[end:]
start=s.index('    fn cascade_delete(')
end=s.index('    fn pragma(',start)
s=s[:start]+'''    fn cascade_delete(&mut self,parent:&Table,deleted:&[Row],depth:usize)->Res<()>{
        for old in deleted{self.cascade_change(parent,old,None,depth)?;}
        Ok(())
    }
'''+s[end:]
p.write_text(s)
