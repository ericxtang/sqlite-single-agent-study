from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text().replace('SubCol(Box<Query>, usize),','SubCol(Box<Query>, usize, usize, usize),')
s=s.replace('''                    for (i, n) in names.into_iter().enumerate() {
                        sets.push((n, E::SubCol(q.clone(), i)))
                    }
                } else { return Err("row value required".into()) }''','''                    let width=names.len();let group=self.p;
                    for (i,n) in names.into_iter().enumerate(){sets.push((n,E::SubCol(q.clone(),i,width,group)))}
                } else if names.len()==1{sets.push((names[0].clone(),e))}
                else { return Err("row value required".into()) }''')
old='''        Ok(sets)
    }
    fn returning'''
new='''        let last=sets.iter().map(|(n,_)|n.to_ascii_lowercase()).collect::<Vec<_>>();
        Ok(sets.into_iter().enumerate().filter(|(i,(n,_))|!last[i+1..].contains(&n.to_ascii_lowercase())).map(|(_,s)|s).collect())
    }
    fn returning'''
assert old in s;s=s.replace(old,new)
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('E::SubCol(q, _)','E::SubCol(q, _, _, _)').replace('E::SubCol(_,_)','E::SubCol(_,_,_,_)')
s=s.replace('''            E::SubCol(q, i) => {
                let r = self.query(q, ctx, depth + 1)?;
                if *i >= r.columns.len() {''','''            E::SubCol(q, i, width, _) => {
                let r = self.query(q, ctx, depth + 1)?;
                if *width!=r.columns.len()||*i>=r.columns.len() {''')
i=s.index('    pub fn eval(')
s=s[:i]+'''    fn eval_list(&self,exprs:&[&E],ctx:&Ctx,group:Option<&[Vec<V>]>,depth:usize)->Res<Vec<V>>{
        let mut cached:BTreeMap<usize,Vec<V>>=BTreeMap::new();let mut values=vec![];
        for e in exprs{
            if let E::SubCol(q,i,width,id)=e{
                if !cached.contains_key(id){
                    let result=self.query(q,ctx,depth+1)?;
                    if result.columns.len()!=*width{return Err("subquery column count mismatch".into())}
                    cached.insert(*id,result.rows.into_iter().next().unwrap_or_else(||vec![V::Null;*width]));
                }
                values.push(cached[id][*i].clone())
            }else{values.push(self.eval(e,ctx,group,depth+1)?)}
        }
        Ok(values)
    }
'''+s[i:]
old='''                let mut row = vec![];
                for item in &items {
                    if q.exists_only && q.compound.is_empty() &&
                            q.offset.is_none() {
                        row.push(V::Null)
                    } else { row.push(self.eval(&item.e, &c, g, depth + 1)?) }
                }'''
new='''                let row=if q.exists_only&&q.compound.is_empty()&&q.offset.is_none(){vec![V::Null;items.len()]}
                    else{self.eval_list(&items.iter().map(|i|&i.e).collect::<Vec<_>>(),&c,g,depth+1)?};'''
assert old in s;s=s.replace(old,new)
# Static arity checks apply even without qualifying rows.
old='''            E::Sub(q) | E::SubCol(q, _, _, _) | E::Exists(q) => {
                let mut bind = c.clone();
                bind.binding = true;
                self.query(q, &bind, 1)?;
            }'''
new='''            E::SubCol(q,_,width,_)=>{
                let mut bind=c.clone();bind.binding=true;
                let result=self.query(q,&bind,1)?;
                if result.columns.len()!=*width{return Err("subquery column count mismatch".into())}
            }
            E::Sub(q) | E::Exists(q) => {
                let mut bind = c.clone();
                bind.binding = true;
                self.query(q, &bind, 1)?;
            }'''
assert old in s;s=s.replace(old,new)
# Pre-evaluate each assignment set using one value per subquery output row.
old='''                            for(n,e)in &u.sets{
                                let value=self.eval(e,&ctx,None,0)?;'''
new='''                            let assigned=self.eval_list(&u.sets.iter().map(|(_,e)|e).collect::<Vec<_>>(),&ctx,None,0)?;
                            for((n,_),value)in u.sets.iter().zip(assigned){'''
assert old in s;s=s.replace(old,new)
start=s.index('                    for (n, e) in &sets {',s.index('                let original = t.rows.clone();',s.index('            Stmt::Update { table, alias, from, sets')))
end=s.index('                        if let Some(j) =',start)
s=s[:start]+'''                    let assigned=if from.is_empty(){self.eval_list(&sets.iter().map(|(_,e)|e).collect::<Vec<_>>(),&ctx,None,0)?}
                        else{ctx.row[ctx.row.len()-sets.len()..].to_vec()};
                    for ((n,_),val) in sets.iter().zip(assigned){
'''+s[end:]
# Row positions may change when a BEFORE trigger mutates the table.
needle='''                    t = self.db.tables[&k].clone();
                    let conflicts = self.conflicts(&t, &row, Some(i))?;'''
assert needle in s;s=s.replace(needle,'''                    t = self.db.tables[&k].clone();
                    let Some(i)=t.rows.iter().position(|r|r.id==old.id)else{continue};
                    let conflicts = self.conflicts(&t, &row, Some(i))?;''')
# Remove the obsolete index binding earlier in this update loop.
s=s.replace('''                    let i =
                        match t.rows.iter().position(|r| r.id == old.id) {
                            Some(i) => i,
                            None => continue,
                        };''','''                    if !t.rows.iter().any(|r|r.id==old.id){continue}''')
old='''                    for (n, e) in &sets {
                        let i =
                            t.cols.iter().position(|c|
                                            c.name.eq_ignore_ascii_case(n)).ok_or("no such column in view")?;
                        row.v[i] = self.eval(e, &ctx, None, 0)?
                    }'''
new='''                    let assigned=self.eval_list(&sets.iter().map(|(_,e)|e).collect::<Vec<_>>(),&ctx,None,0)?;
                    for ((n,_),value) in sets.iter().zip(assigned){
                        let i=t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("no such column in view")?;
                        row.v[i]=value;
                    }'''
assert old in s;s=s.replace(old,new)
# Validate explicit collation names even on integer primary keys that need no index.
needle='''                let mut constraints=vec![];
                if integer_pk(&t).is_none(){'''
assert needle in s;s=s.replace(needle,'''                for spec in &keys{for e in &spec.expr{self.validate_expr(e,&ctx)?;}}
                let mut constraints=vec![];
                if integer_pk(&t).is_none(){''')
p.write_text(s)
