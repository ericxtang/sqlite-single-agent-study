from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
i=s.index('pub enum Stmt')
# Insert type before the derive immediately preceding Stmt.
i=s.rfind('#[derive',0,i)
s=s[:i]+'''#[derive(Clone,Debug)]
pub struct KeySpec{
    pub origin:String,
    pub expr:Vec<E>,
    pub desc:Vec<bool>,
    pub policy:String,
}
'''+s[i:]
s=s.replace('''        policies: Vec<(Vec<String>, String)>,
        checks: Vec<E>,''','''        policies: Vec<(Vec<String>, String)>,
        keys: Vec<KeySpec>,
        checks: Vec<E>,''',1)
i=s.index('    pub fn expr(')
s=s[:i]+'''    fn key_columns(&mut self)->Res<(Vec<String>,Vec<E>,Vec<bool>)>{
        self.expect("(")?;let mut names=vec![];let mut expr=vec![];let mut desc=vec![];
        loop{
            let n=self.ident()?;let mut e=E::Col(vec![n.clone()]);names.push(n);
            if self.eat("COLLATE"){e=E::Collate(Box::new(e),self.ident()?)}
            expr.push(e);desc.push(if self.eat("DESC"){true}else{self.eat("ASC");false});
            if !self.eat(","){break}
        }
        self.expect(")")?;Ok((names,expr,desc))
    }
'''+s[i:]
s=s.replace('''                let mut policies = vec![];
                let mut checks''','''                let mut policies = vec![];
                let mut keys=vec![];
                let mut checks''')
s=s.replace('''                                policies,
                                checks,''','''                                policies,
                                keys,
                                checks,''')
s=s.replace('''                            policies,
                            checks,''','''                            policies,
                            keys,
                            checks,''')
old='''                        pk = self.names()?;
                        let mode = self.conflict()?;
                        policies.push((pk.clone(), mode));'''
new='''                        if !pk.is_empty(){return Err("table has more than one primary key".into())}
                        let(names,expr,desc)=self.key_columns()?;pk=names;
                        let mode=self.conflict()?;
                        policies.push((pk.clone(),mode.clone()));
                        keys.push(KeySpec{origin:"pk".into(),expr,desc,policy:mode});'''
assert old in s;s=s.replace(old,new)
old='''                        let names = self.names()?;
                        uniq.push(names.clone());
                        let mode = self.conflict()?;
                        policies.push((names, mode));'''
new='''                        let(names,expr,desc)=self.key_columns()?;
                        uniq.push(names.clone());
                        let mode=self.conflict()?;
                        policies.push((names,mode.clone()));
                        keys.push(KeySpec{origin:"u".into(),expr,desc,policy:mode});'''
assert old in s;s=s.replace(old,new)
s=s.replace('''                for (i, n) in pk.iter().enumerate() {''','''                if !pk.is_empty()&&cols.iter().any(|c|c.pk>0){return Err("table has more than one primary key".into())}
                for (i, n) in pk.iter().enumerate() {''')
s=s.replace('''                c.pk = 1;
                c.pk_desc''','''                if c.pk>0{return Err("table has more than one primary key".into())}
                c.pk = 1;
                c.pk_desc''')
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('''    pub origin: String,
    pub name: String,''','''    pub origin: String,
    #[serde(default)]
    pub policy:String,
    pub name: String,''',1)
s=s.replace('''                policies,
                checks,''','''                policies,
                keys,
                checks,''',1)
start=s.index('                let mut constraints = vec![];',s.index('Stmt::CreateTable {',s.index('fn run_inner')))
end=s.index('                self.db.tables.insert(k, t);',start)
s=s[:start]+'''                let mut constraints=vec![];
                if integer_pk(&t).is_none(){
                    if let Some(pk)=keys.iter().find(|k|k.origin=="pk"){constraints.push(pk.clone())}
                    else if let Some(c)=t.cols.iter().find(|c|c.pk>0){constraints.push(KeySpec{origin:"pk".into(),expr:vec![E::Col(vec![c.name.clone()])],desc:vec![c.pk_desc],policy:c.policies.get("pk").cloned().unwrap_or("ABORT".into())})}
                }
                for c in &t.cols{if c.unique{constraints.push(KeySpec{origin:"u".into(),expr:vec![E::Col(vec![c.name.clone()])],desc:vec![false],policy:c.policies.get("uq").cloned().unwrap_or("ABORT".into())})}}
                constraints.extend(keys.into_iter().filter(|k|k.origin=="u"));
                for (i,spec) in constraints.into_iter().enumerate(){
                    for e in &spec.expr{self.validate_expr(e,&ctx)?;}
                    let name=format!("sqlite_autoindex_{}_{}",t.name,i+1);
                    self.db.indexes.insert(key(&name),Index{
                        temporary:false,origin:spec.origin,policy:spec.policy,name,table:t.name.clone(),unique:true,
                        desc:spec.desc,expr:spec.expr,filter:None,sql:String::new()
                    });
                }
'''+s[end:]
s=s.replace('''                        origin: "c".into(),
                        name,''','''                        origin: "c".into(),
                        policy:"ABORT".into(),
                        name,''')
# Only indexes and implicit rowid uniqueness should enforce their respective collations.
start=s.index('        let mut constraints = t.unique.clone();',s.index('    fn conflicts('))
end=s.index('        let ctx =',start)
s=s[:start]+s[end:]
start=s.index('            for cols in &constraints {',s.index('    fn conflicts('))
end=s.index('            for idx in',start)
s=s[:start]+s[end:]
start=s.index('        let mut cols=t.unique.clone();',s.index('    fn resolve_upsert_target'))
end=s.index('        for idx in',start)
s=s[:start]+'''        let mut cols=vec![];
        if let Some(i)=integer_pk(t){cols.push(vec![t.cols[i].name.clone()])}
        if !t.without{for name in ["rowid","oid","_rowid_"]{if !t.cols.iter().any(|c|c.name.eq_ignore_ascii_case(name)){cols.push(vec![name.into()])}}}
        for cols in cols{candidates.push((cols.into_iter().map(|n|E::Col(vec![n])).collect(),None))}
'''+s[end:]
start=s.index('        let mut candidates=parent.unique.clone();',s.index('    fn foreign_mapping'))
end=s.index('        for idx in',start)
s=s[:start]+'''        let mut candidates=vec![];
        if let Some(i)=integer_pk(parent){candidates.push(vec![parent.cols[i].name.clone()])}
'''+s[end:]
start=s.index('        let mut policies = t.policies.clone();',s.index('    fn unique_policy'))
end=s.index('        "ABORT".into()',start)
s=s[:start]+'''        if !t.without&&conflicts.iter().any(|&i|t.rows[i].id==row.id){
            if let Some(i)=integer_pk(t){
                let c=&t.cols[i];
                if let Some(p)=c.policies.get("pk"){return p.clone()}
                if let Some((_,p))=t.policies.iter().find(|(ns,_)|ns.len()==1&&ns[0].eq_ignore_ascii_case(&c.name)){return p.clone()}
            }
            return "ABORT".into()
        }
        for idx in self.db.indexes.values().filter(|i|i.unique&&i.table.eq_ignore_ascii_case(&t.name)){
            if self.upsert_conflict(t,row,conflicts,Some(&(idx.expr.clone(),idx.filter.clone()))).ok().flatten().is_some(){
                if !idx.policy.is_empty(){return idx.policy.clone()}
                // Old snapshots predate explicit index conflict policies.
                let cols=idx.expr.iter().filter_map(|e|if let E::Col(n)=order_expression(e){n.last().cloned()}else{None}).collect::<Vec<_>>();
                if let Some((_,p))=t.policies.iter().find(|(ns,_)|ns.len()==cols.len()&&ns.iter().zip(&cols).all(|(a,b)|a.eq_ignore_ascii_case(b))){return p.clone()}
                if cols.len()==1{if let Some(c)=t.cols.iter().find(|c|c.name.eq_ignore_ascii_case(&cols[0])){if let Some(p)=c.policies.get(if idx.origin=="pk"{"pk"}else{"uq"}){return p.clone()}}}
                return "ABORT".into()
            }
        }
'''+s[end:]
p.write_text(s)
