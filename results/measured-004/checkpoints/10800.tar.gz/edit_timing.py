from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
s=s.replace('''    pub run_depth: usize,
''','''    pub run_depth: usize,
    pub statement_nested:bool,
''',1)
s=s.replace('''                run_depth: 0,
''','''                run_depth: 0,
                statement_nested:false,
''',1)
# Defer immediate FK checks until the complete outer statement, including triggers.
needle='''        let mut out = self.run(stmt, sql);
        if implicit && out.is_ok() {'''
assert needle in s
s=s.replace(needle,'''        let mut out = self.run(stmt, sql);
        if write&&!self.statement_nested&&out.is_ok(){
            if let Err(e)=self.check_foreign(false).and_then(|_|{for db in self.attached.values(){db.check_foreign(false)?}Ok(())}){out=Err(e)}
        }
        if implicit && out.is_ok() {''')
needle='''                let saved_ctx = db.trigger_ctx.clone();
                db.trigger_ctx = caller_ctx;'''
assert needle in s;s=s.replace(needle,'''                let saved_ctx = db.trigger_ctx.clone();
                let saved_nested=db.statement_nested;
                db.statement_nested=true;
                db.trigger_ctx = caller_ctx;''')
s=s.replace('''                db.fallback = None;
                db.trigger_ctx = saved_ctx;''','''                db.fallback = None;
                db.statement_nested=saved_nested;
                db.trigger_ctx = saved_ctx;''')
# Remove final inner-DML FK checks; retain the special DROP check.
s=s.replace('''                self.check_foreign(self.txn.is_empty())?;
                self.returning''','''                self.returning''')
# Split row construction and local validation.
s=s.replace('''    fn prepare_row(&self, t: &Table, mut v: Vec<V>, requested: Option<V>,
        oldid: Option<i64>) -> Res<Row> {''','''    fn prepare_row(&self,t:&Table,v:Vec<V>,requested:Option<V>,oldid:Option<i64>)->Res<Row>{
        let row=self.build_row(t,v,requested,oldid)?;self.validate_row(t,&row)?;Ok(row)
    }
    fn finish_row(&self,t:&Table,mut row:Row,mode:&str)->Res<Row>{
        let mut replaced=false;
        for(i,c)in t.cols.iter().enumerate(){
            if c.notnull&&row.v[i].null()&&(mode=="REPLACE"||(mode=="DEFAULT"&&c.policies.get("nn").is_some_and(|p|p=="REPLACE"))){
                if let Some(e)=&c.default{row.v[i]=self.eval(e,&self.root_ctx(),None,0)?;replaced=true}
            }
        }
        if replaced{row=self.build_row(t,row.v,None,Some(row.id))?}
        self.validate_row(t,&row)?;Ok(row)
    }
    fn build_row(&self, t: &Table, mut v: Vec<V>, requested: Option<V>,
        oldid: Option<i64>) -> Res<Row> {''')
needle='''        for (i, c) in t.cols.iter().enumerate() {
            if row.v[i].null() &&'''
assert needle in s;s=s.replace(needle,'''        Ok(row)
    }
    fn validate_row(&self,t:&Table,row:&Row)->Res<()>{
        for (i, c) in t.cols.iter().enumerate() {
            if row.v[i].null() &&''',1)
start=s.index('    fn validate_row')
end=s.index('    fn resolve_upsert_target',start)
part=s[start:end].replace('        Ok(row)','        Ok(())')
s=s[:start]+part+s[end:]
# INSERT BEFORE trigger receives input before NOT NULL REPLACE/default validation.
start=s.index('                    for (i, c) in t.cols.iter().enumerate() {',s.index('                for input in inputs {',s.index('            Stmt::Insert { table, alias')))
end=s.index('                    let row =',start)
s=s[:start]+s[end:]
s=s.replace('''match self.prepare_row(&t, v, id, None)''','''match self.build_row(&t, v, id, None)''',1)
start=s.index('                    if t.cols.iter().any(|c| c.auto) {',s.index('                for input in inputs {',s.index('            Stmt::Insert { table, alias')))
end=s.index('                    let conflicts = self.conflicts(&t, &row, None)?;',start)
s=s[:start]+'''                    self.db.tables.insert(k.clone(),t.clone());
                    let proceed=self.fire(&t,"INSERT","BEFORE",None,Some(&row),&[])?;
                    t=self.db.tables[&k].clone();
                    if !proceed{continue}
                    let row=match self.finish_row(&t,row,&mode){Ok(row)=>row,Err(e)=>{
                        let policy=self.error_policy(&t,&e,&mode);if policy=="IGNORE"{continue}return Err(policy_error(&policy,e))
                    }};
                    if t.cols.iter().any(|c|c.auto){t.seq=t.seq.max(row.id);self.set_sequence(&t.name,t.seq);}
'''+s[end:]
# UPSERT DO UPDATE follows BEFORE -> local constraints -> unique constraints.
s=s.replace('''let r=self.prepare_row(&t,v,requested,Some(old.id))''','''let r=self.build_row(&t,v,requested,Some(old.id))''')
old='''                            if !self.fire(&t, "UPDATE", "BEFORE", Some(&old), Some(&r),
                                            &setcols)? {
                                continue
                            }
                            t=self.db.tables[&k].clone();
                            let Some(i)=t.rows.iter().position(|row|row.id==old.id)else{continue};'''
new='''                            let proceed=self.fire(&t,"UPDATE","BEFORE",Some(&old),Some(&r),&setcols)?;
                            t=self.db.tables[&k].clone();
                            if !proceed{continue}
                            let Some(i)=t.rows.iter().position(|row|row.id==old.id)else{continue};
                            self.validate_row(&t,&r).map_err(|e|format!("!ABORT!{}",e))?;'''
assert old in s;s=s.replace(old,new)
s=s.replace('''match self.prepare_row(&t, v, id, Some(old.id))''','''match self.build_row(&t, v, id, Some(old.id))''',1)
old='''                    if !self.fire(&t, "UPDATE", "BEFORE", Some(&old),
                                    Some(&row), &setcols)? {
                        continue
                    }
                    t = self.db.tables[&k].clone();
                    let Some(i)=t.rows.iter().position(|r|r.id==old.id)else{continue};'''
new='''                    let proceed=self.fire(&t,"UPDATE","BEFORE",Some(&old),Some(&row),&setcols)?;
                    t=self.db.tables[&k].clone();
                    if !proceed{continue}
                    let Some(i)=t.rows.iter().position(|r|r.id==old.id)else{continue};
                    let row=match self.finish_row(&t,row,&mode){Ok(row)=>row,Err(e)=>{
                        let policy=self.error_policy(&t,&e,&mode);if policy=="IGNORE"{continue}return Err(policy_error(&policy,e))
                    }};'''
assert old in s;s=s.replace(old,new)
old='''                    if !self.fire(&t, "DELETE", "BEFORE", Some(&row), None,
                                    &[])? {
                        continue
                    }
                    t = self.db.tables[&k].clone();'''
new='''                    let proceed=self.fire(&t,"DELETE","BEFORE",Some(&row),None,&[])?;
                    t=self.db.tables[&k].clone();
                    if !proceed{continue}'''
assert old in s;s=s.replace(old,new)
p.write_text(s)
