from pathlib import Path
p=Path('src/engine.rs');s=p.read_text()
a=s.index('            "index_info" | "index_xinfo" => {');b=s.index('            "foreign_key_list" => {',a)
s=s[:a]+'''            "index_info" | "index_xinfo" => {
                result.columns=vec!["seqno".into(),"cid".into(),"name".into()];
                let extended=n=="index_xinfo";
                if extended{result.columns.extend(["desc","coll","key"].iter().map(|s|s.to_string()));}
                let relation=self.db.indexes.get(&key(&text)).and_then(|i|self.db.tables.get(&key(&i.table)).map(|t|(t,Some(i))))
                    .or_else(||self.db.tables.get(&key(&text)).filter(|t|t.without).map(|t|(t,None)));
                if let Some((t,index))=relation{
                    for(seq,(cid,coll,desc,is_key))in self.index_columns(t,index)?.into_iter().enumerate(){
                        if !extended&&!is_key{continue}
                        let mut row=vec![V::Int(seq as i64),V::Int(cid),if cid>=0{V::Text(t.cols[cid as usize].name.clone())}else{V::Null}];
                        if extended{row.extend([V::Int(desc as i64),V::Text(coll),V::Int(is_key as i64)]);}
                        result.rows.push(row);
                    }
                }
            }
'''+s[b:]
pos=s.index('    fn index_records(')
s=s[:pos]+'''    fn index_columns(&self,t:&Table,index:Option<&Index>)->Res<Vec<(i64,String,bool,bool)>>{
        let pk=self.db.indexes.values().find(|idx|idx.table.eq_ignore_ascii_case(&t.name)&&idx.origin=="pk");
        let index=index.or(pk);
        let Some(index)=index else{return Ok(vec![])};
        let primary=t.without&&index.origin=="pk";
        let ctx=self.rowctx(t,&Row{id:0,v:vec![V::Null;t.cols.len()]},None);
        let term=|e:&E,desc:bool,keycol:bool|{
            let cid=column_name(e).and_then(|n|t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n))).map(|i|i as i64).unwrap_or(-2);
            (cid,self.metadata(e,&ctx).1,desc,keycol)
        };
        let mut cols:Vec<(i64,String,bool,bool)>=vec![];
        for(i,e)in index.expr.iter().enumerate(){
            let c=term(e,index.desc.get(i).copied().unwrap_or(false),true);
            if primary&&cols.iter().any(|a|a.0==c.0&&a.1.eq_ignore_ascii_case(&c.1)){continue}
            cols.push(c);
        }
        if primary{
            for(i,c)in t.cols.iter().enumerate(){
                if cols.iter().any(|a|a.0==i as i64)||(c.generated.is_some()&&!c.stored){continue}
                cols.push((i as i64,c.coll.clone(),false,false));
            }
        }else if t.without{
            if let Some(pk)=pk{
                for(i,e)in pk.expr.iter().enumerate(){
                    let c=term(e,pk.desc.get(i).copied().unwrap_or(false),false);
                    if !cols.iter().any(|a|a.0==c.0&&a.1.eq_ignore_ascii_case(&c.1)){cols.push(c);}
                }
            }
        }else{cols.push((-1,"BINARY".into(),false,false));}
        Ok(cols)
    }
'''+s[pos:]
# WITHOUT ROWID primary keys live in the table's record tree, not a separate schema entry.
s=s.replace('''                    for i in
                        self.db.indexes.values().filter(|t| t.temporary == temp) {
                        rows.push''','''                    for i in
                        self.db.indexes.values().filter(|t| t.temporary == temp) {
                        if i.origin=="pk"&&self.db.tables.get(&key(&i.table)).is_some_and(|t|t.without){continue}
                        rows.push''',1)
# Use declared primary-key expression collations/directions when scanning WITHOUT ROWID rows.
a=s.index('        if t.without {',s.index('    fn table_data'));b=s.index('        } else { rows.sort_by_key(|r| r.id) }',a)
s=s[:a]+'''        if t.without {
            let pks=self.index_columns(t,None).unwrap_or_default().into_iter().filter(|c|c.3).collect::<Vec<_>>();
            rows.sort_by(|a,b|{
                for(cid,coll,desc,_)in &pks{if *cid<0{continue}let ord=cmp(&a.v[*cid as usize],&b.v[*cid as usize],coll);if ord!=Ordering::Equal{return if *desc{ord.reverse()}else{ord}}}
                Ordering::Equal
            });
'''+s[b:]
p.write_text(s)
p=Path('src/syntax.rs');s=p.read_text()
a=s.index('            if self.eat("TABLE") {',s.index('    fn statement_inner'))
b=s.index('            if self.eat("INDEX") {',a)
part=s[a:b]
needle='''checks.push(self.expr()?);
                        self.expect(")")?;'''
assert needle in part
part=part.replace(needle,needle+'\n                        self.conflict()?;',1)
s=s[:a]+part+s[b:];p.write_text(s)
