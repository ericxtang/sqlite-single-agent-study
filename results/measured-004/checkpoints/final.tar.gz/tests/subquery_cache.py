exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
req('open',path=':memory:')
sql('CREATE TABLE t(id INTEGER PRIMARY KEY,n)')
sql('INSERT INTO t VALUES(1,0),(2,0),(3,0),(4,0)')
rows=vals('SELECT (SELECT hex(randomblob(16))) AS a,(SELECT hex(randomblob(16))) AS b FROM t')
assert len({r[0] for r in rows})==len({r[1] for r in rows})==1,rows
assert rows[0][0]!=rows[0][1],rows
# Separate statements never share a cached value.
again=vals('SELECT (SELECT hex(randomblob(16))) FROM t')
assert again[0][0]!=rows[0][0]
eq('SELECT id,(SELECT count(*) FROM t b WHERE b.id<t.id) FROM t ORDER BY id',[[1,0],[2,1],[3,2],[4,3]])
eq('SELECT id,(SELECT (SELECT t.id)) FROM t ORDER BY id',[[1,1],[2,2],[3,3],[4,4]])
eq('SELECT id,(SELECT "id") FROM t ORDER BY id',[[1,1],[2,2],[3,3],[4,4]])
eq('SELECT id,EXISTS(SELECT 1 FROM t b WHERE b.id<t.id) FROM t ORDER BY id',[[1,0],[2,1],[3,1],[4,1]])
# Uncorrelated results freeze when first needed, even if the statement changes their table.
sql('UPDATE t SET n=(SELECT count(*) FROM t WHERE n>0)+1')
eq('SELECT n FROM t',[[1],[1],[1],[1]])
sql('CREATE TABLE seen(id)')
sql('CREATE TRIGGER log AFTER UPDATE ON t BEGIN INSERT INTO seen VALUES(new.id+1); END')
sql('UPDATE t SET n=id IN (SELECT id FROM seen)')
eq('SELECT n FROM t',[[0],[0],[0],[0]])
sql('DELETE FROM seen')
sql('UPDATE t SET n=EXISTS(SELECT id FROM seen)')
eq('SELECT n FROM t',[[0],[0],[0],[0]])
sql('DROP TRIGGER log')
# Each trigger invocation has its own statement scope.
sql('CREATE TABLE logs(n)')
sql('CREATE TRIGGER per_row AFTER UPDATE ON t BEGIN INSERT INTO logs VALUES((SELECT count(*) FROM logs)); END')
sql('UPDATE t SET n=0')
eq('SELECT n FROM logs',[[0],[1],[2],[3]])
sql('DROP TRIGGER per_row')
# Row-valued assignments share the row subquery and its result across outer rows.
sql('CREATE TABLE pairs(a,b)')
sql('INSERT INTO pairs VALUES(0,0),(0,0)')
sql('UPDATE pairs SET (a,b)=(SELECT hex(randomblob(16)),hex(randomblob(16)))')
pairs=vals('SELECT a,b FROM pairs')
assert pairs[0]==pairs[1] and pairs[0][0]!=pairs[0][1],pairs
# Views keep separate evaluation sites when instantiated more than once.
sql('CREATE VIEW v AS SELECT (SELECT hex(randomblob(16))) AS n FROM t')
v=vals('SELECT n FROM v')
assert len({r[0] for r in v})==1,v
joined=vals('SELECT a.n,b.n FROM v a,v b')
assert len({r[0] for r in joined})==len({r[1] for r in joined})==1,joined
assert joined[0][0]!=joined[0][1],joined
eq('SELECT CASE WHEN 0 THEN (SELECT abs(-9223372036854775808)) ELSE 1 END FROM t',[[1]]*4)
# Attached view evaluation must use the current statement's cache.
sql("ATTACH ':memory:' AS aux")
sql('CREATE TABLE aux.t(n)')
sql('INSERT INTO aux.t VALUES(1),(2)')
sql('CREATE VIEW aux.v AS SELECT (SELECT hex(randomblob(16))) AS n FROM t')
a=vals('SELECT n FROM aux.v');b=vals('SELECT n FROM aux.v')
assert a[0]==a[1] and b[0]==b[1] and a[0]!=b[0],(a,b)
# Stored query identifiers are recreated when a database is reopened.
path='/work/subquery-cache.db'
try:os.unlink(path)
except FileNotFoundError:pass
req('open',path=path)
sql('CREATE TABLE t(n)');sql('INSERT INTO t VALUES(1),(2)')
sql('CREATE VIEW v AS SELECT (SELECT hex(randomblob(16))) AS n FROM t')
req('close');req('open',path=path)
r=vals('SELECT n,(SELECT hex(randomblob(16))) FROM v')
assert r[0]==r[1] and r[0][0]!=r[0][1],r
req('close');p.terminate();p.wait();os.unlink(path)
print('Statement-local subqueries, correlation, IN/EXISTS, assignments, triggers, and views passed')
