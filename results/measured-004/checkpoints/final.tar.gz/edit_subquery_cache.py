from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('pub struct Query {\n','''pub struct Query {
    #[serde(skip,default="next_query_id")]
    pub cache_id:u64,
''',1)
pos=s.index('#[derive(Clone,Debug,Default,Serialize,Deserialize)]\npub struct Query')
s=s[:pos]+'''pub fn next_query_id()->u64{
    static NEXT:std::sync::atomic::AtomicU64=std::sync::atomic::AtomicU64::new(1);
    NEXT.fetch_add(1,std::sync::atomic::Ordering::Relaxed)
}
'''+s[pos:]
s=s.replace('''        let q = self.query_inner()?;
        if self.tracking''','''        let mut q = self.query_inner()?;
        q.cache_id=next_query_id();
        if self.tracking''',1)
# IN table is represented as a synthesized query and still needs independent identity.
s=s.replace('''Some(Box::new(Query {
                                        items:''','''Some(Box::new(Query {
                                        cache_id:next_query_id(),
                                        items:''',1)
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
pos=s.index('#[derive(Clone)]\npub struct Engine')
s=s[:pos]+'''#[derive(Clone)]
pub struct SubqueryCacheEntry{
    pub result:Option<ResultSet>,
    // Keep CTE allocations alive so pointer identities cannot be reused within a statement.
    pub _ctes:Vec<Arc<Data>>,
}
pub type SubqueryCache=Arc<std::sync::Mutex<BTreeMap<(u64,u64,Vec<(String,usize)>),SubqueryCacheEntry>>>;
'''+s[pos:]
s=s.replace('pub struct Engine {\n','pub struct Engine {\n    pub subquery_cache:SubqueryCache,\n',1)
s=s.replace('pub struct Ctx {\n','''pub struct Ctx {
    pub cache_scope:u64,
    pub reference_probes:Vec<Arc<std::sync::atomic::AtomicBool>>,
''',1)
s=s.replace('''            Self {
                namespace:''','''            Self {
                subquery_cache:Default::default(),
                namespace:''',1)
# One evaluation context per statement, including each invocation of a trigger program.
s=s.replace('''        self.run_depth += 1;
        let result = self.run_inner(s, sql);
        self.run_depth -= 1;''','''        self.run_depth += 1;
        let saved_cache=std::mem::take(&mut self.subquery_cache);
        let result = self.run_inner(s, sql);
        self.subquery_cache=saved_cache;
        self.run_depth -= 1;''',1)
# Mark only successful resolution against a scope being probed.
a=s.index('    pub fn eval(');b=s.index('    fn row_values(',a)
part=s[a:b]
part=part.replace('''if let Some(i) = Self::colindex(c, &names)? {
                        return''','''if let Some(i) = Self::colindex(c, &names)? {
                        mark_outer_reference(c);
                        return''',1)
part=part.replace('''if let Some(e) = c.aliases.get(&key(n)) {
                        return''','''if let Some(e) = c.aliases.get(&key(n)) {
                        mark_outer_reference(c);
                        return''',1)
part=part.replace('''if let Some(i) = Self::colindex(ctx, n)? {
                    Ok''','''if let Some(i) = Self::colindex(ctx, n)? {
                    mark_outer_reference(ctx);
                    Ok''',1)
part=part.replace('''ctx.aliases.contains_key(&key(&n[0])) {
                    let e''','''ctx.aliases.contains_key(&key(&n[0])) {
                    mark_outer_reference(ctx);
                    let e''',1)
part=part.replace('self.query(q, ctx, depth + 1)?','self.eval_subquery(q, ctx, depth + 1)?')
part=part.replace('self.query(&q, ctx, depth + 1)?','self.eval_subquery(&q, ctx, depth + 1)?')
s=s[:a]+part+s[b:]
a=s.index('    fn row_values(');b=s.index('    fn row_compare(',a)
s=s[:a]+s[a:b].replace('self.query(q, c, d + 1)?','self.eval_subquery(q, c, d + 1)?')+s[b:]
a=s.index('    fn eval_list(');b=s.index('    pub fn eval(',a)
s=s[:a]+s[a:b].replace('self.query(q, ctx, depth + 1)?','self.eval_subquery(q, ctx, depth + 1)?')+s[b:]
# Local query scopes have no probe; their outer environment retains the markers.
s=s.replace('''            Ctx {
                binding: outer.binding,
                outer:''','''            Ctx {
                cache_scope:outer.cache_scope,
                binding: outer.binding,
                outer:''',1)
# Separate instances of a stored view keep distinct subquery evaluation sites.
s=s.replace('''Ctx { binding: ctx.binding, ..Default::default() };
                    let r =''','''Ctx { cache_scope:next_query_id(),binding: ctx.binding, ..Default::default() };
                    let r =''',1)
# Read-only routing to attachments shares the active statement cache.
a=s.index('    fn source(');b=s.index('    fn requested_index_rows(',a)
part=s[a:b].replace('''                    if db.txn.is_empty() { db.refresh()? }''','''                    db.subquery_cache=self.subquery_cache.clone();
                    if db.txn.is_empty() { db.refresh()? }''',1)
s=s[:a]+part+s[b:]
pos=s.index('    fn eval_list(')
s=s[:pos]+'''    fn eval_subquery(&self,q:&Query,ctx:&Ctx,depth:usize)->Res<ResultSet>{
        if ctx.binding||q.cache_id==0{return self.query(q,ctx,depth)}
        let ctes=ctx.ctes.iter().map(|(name,data)|(name.clone(),Arc::as_ptr(data) as usize)).collect::<Vec<_>>();
        let cache_key=(q.cache_id,ctx.cache_scope,ctes);
        let cached={self.subquery_cache.lock().map_err(|_|"subquery cache is unavailable")?.get(&cache_key).cloned()};
        if let Some(entry)=cached{
            return if let Some(result)=entry.result{Ok(result)}else{self.query(q,ctx,depth)}
        }
        let probe=Arc::new(std::sync::atomic::AtomicBool::new(false));
        let mut bind=ctx.clone();bind.binding=true;
        fn mark_scope(c:&mut Ctx,probe:&Arc<std::sync::atomic::AtomicBool>){
            c.reference_probes.push(probe.clone());
            if let Some(outer)=&mut c.outer{mark_scope(outer,probe)}
        }
        mark_scope(&mut bind,&probe);
        self.query(q,&bind,depth)?;
        let correlated=probe.load(std::sync::atomic::Ordering::Relaxed);
        if correlated{
            self.subquery_cache.lock().map_err(|_|"subquery cache is unavailable")?.insert(cache_key,SubqueryCacheEntry{result:None,_ctes:ctx.ctes.values().cloned().collect()});
            return self.query(q,ctx,depth)
        }
        let result=self.query(q,ctx,depth)?;
        self.subquery_cache.lock().map_err(|_|"subquery cache is unavailable")?.insert(cache_key,SubqueryCacheEntry{result:Some(result.clone()),_ctes:ctx.ctes.values().cloned().collect()});
        Ok(result)
    }
'''+s[pos:]
pos=s.index('fn key(s:')
s=s[:pos]+'''fn mark_outer_reference(ctx:&Ctx){
    for probe in &ctx.reference_probes{probe.store(true,std::sync::atomic::Ordering::Relaxed);}
}
'''+s[pos:]
p.write_text(s)
