from pathlib import Path
p=Path('src/syntax.rs');s=p.read_text()
s=s.replace('''    pub cache_id:u64,
''','''    pub cache_id:u64,
    #[serde(skip)]
    pub first_row:bool,
''',1)
p.write_text(s)
p=Path('src/engine.rs');s=p.read_text()
pos=s.index('    fn eval_subquery(')
s=s[:pos]+'''    fn scalar_subquery(&self,q:&Query,ctx:&Ctx,depth:usize)->Res<ResultSet>{
        let mut q=q.clone();q.first_row=true;self.eval_subquery(&q,ctx,depth)
    }
'''+s[pos:]
# Scalar and row-value sites use one row; IN and EXISTS retain their own semantics.
a=s.index('    fn eval_list(');b=s.index('    pub fn eval(',a)
s=s[:a]+s[a:b].replace('self.eval_subquery(q, ctx, depth + 1)?','self.scalar_subquery(q, ctx, depth + 1)?')+s[b:]
a=s.index('            E::SubCol(q, i, width, _) =>',s.index('    pub fn eval'));b=s.index('            E::OrderedCall',a)
s=s[:a]+s[a:b].replace('self.eval_subquery(q, ctx, depth + 1)?','self.scalar_subquery(q, ctx, depth + 1)?')+s[b:]
a=s.index('            E::Sub(q) => {',s.index('    pub fn eval'));b=s.index('            E::Exists(q)',a)
s=s[:a]+s[a:b].replace('self.eval_subquery(q, ctx, depth + 1)?','self.scalar_subquery(q, ctx, depth + 1)?')+s[b:]
a=s.index('    fn row_values(');b=s.index('    fn row_compare',a)
s=s[:a]+s[a:b].replace('self.eval_subquery(q, c, d + 1)?','self.scalar_subquery(q, c, d + 1)?')+s[b:]
a=s.index('    pub fn query(&self, q: &Query');b=s.index('        if let Some(m) = &q.materialized',a)
s=s[:a]+'''    pub fn query(&self, q: &Query, outer: &Ctx, depth: usize)->Res<ResultSet>{
        if depth>80{return Err("query recursion limit exceeded".into())}
        for e in q.limit.iter().chain(q.offset.iter()){
            if has_agg(e)||has_window(e){return Err("misuse of aggregate or window function in LIMIT".into())}
            self.validate_expr(e,&Ctx{binding:true,..outer.clone()})?;
        }
        let mut limit=usize::MAX;let mut offset=0usize;
        if !outer.binding&&(q.limit.is_some()||q.offset.is_some()||q.first_row||q.exists_only){
            let mut bind=outer.clone();bind.binding=true;
            let mut prototype=self.query(q,&bind,depth+1)?;
            // The wrapper exposes WITH entries referenced by the limits, without evaluating other CTEs.
            let limits=Query{ctes:q.ctes.clone(),recursive:q.recursive,
                values:vec![vec![q.limit.clone().unwrap_or(E::Val(V::Int(-1))),q.offset.clone().unwrap_or(E::Val(V::Int(0)))]],..Default::default()};
            let values=self.query(&limits,outer,depth+1)?.rows.into_iter().next().unwrap();
            let n=limit_int(&values[0])?;limit=if n<0{usize::MAX}else{n as usize};
            offset=limit_int(&values[1])?.max(0) as usize;
            if q.first_row||q.exists_only{limit=limit.min(1)}
            if limit==0{prototype.rows.clear();return Ok(prototype)}
        }
        let mut early_sliced=false;
'''+s[b:]
# VALUES bind every row, but a scalar use only evaluates the requested first row.
a=s.index('        if !q.values.is_empty()',s.index('    pub fn query'));b=s.index('            result =',a)
part=s[a:b]
part=part.replace('''            for row in &q.values {''','''            let slice_values=q.compound.is_empty()&&q.order.is_empty();
            let end=offset.saturating_add(limit);
            if slice_values&&!base.binding{early_sliced=true;}
            for (position,row) in q.values.iter().enumerate() {''',1)
part=part.replace('''                if base.binding
                    {} else if''','''                if base.binding||(slice_values&&(position<offset||position>=end))
                    {} else if''',1)
part=part.replace('''q.exists_only && q.compound.is_empty() &&
                        q.offset.is_none()''','''q.exists_only && q.compound.is_empty()''',1)
s=s[:a]+part+s[b:]
# Stream filters and projections for plain unordered queries.
a=s.index('            let mut filtered = vec![];',s.index('    pub fn query'))
b=s.index('            let mut groups:',a)
part=s[a:b]
part=part.replace('''            let mut filtered = vec![];''','''            let can_slice=!aggregated&&!q.distinct&&q.compound.is_empty()&&q.order.is_empty()&&!items.iter().any(|i|has_window(&i.e));
            let mut accepted=0usize;
            if can_slice{early_sliced=true}
            let mut filtered = vec![];''',1)
part=part.replace('''            for row in data.rows {''','''            for row in data.rows {
                if can_slice&&filtered.len()>=limit{break}''',1)
part=part.replace('''                filtered.push(row)''','''                if can_slice&&accepted<offset{accepted+=1;continue}
                filtered.push(row)''',1)
s=s[:a]+part+s[b:]
# EXISTS may skip output expressions with OFFSET when DISTINCT does not require them.
s=s.replace('''if q.exists_only && q.compound.is_empty() &&
                            q.offset.is_none()''','''if q.exists_only && q.compound.is_empty() &&
                            (!q.distinct||q.offset.is_none())''',1)
a=s.index('        let off =',s.index('        let order_branches',s.index('    pub fn query'))) if False else s.index('        let off =',s.index('        let mut order_branches',s.index('    pub fn query')))
b=s.index('        Ok(result)',a)
s=s[:a]+'''        result.rows=result.rows.into_iter().skip(if early_sliced{0}else{offset}).take(limit).collect();
'''+s[b:]
p.write_text(s)
