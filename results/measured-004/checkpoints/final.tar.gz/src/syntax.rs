use crate::value::V;
use serde::{Serialize, Deserialize};
pub type Res<T> = Result<T, String>;
#[derive(Clone,Debug)]
pub struct Tok {
    pub s: String,
    pub k: u8,
    pub start: usize,
    pub end: usize,
}
pub fn lex(sql: &str) -> Res<Vec<Tok>> {
    let mut out = vec![];
    let b = sql.as_bytes();
    let mut i = 0;
    while i < b.len() {
        if b[i].is_ascii_whitespace() { i += 1; continue }
        if b[i] == b'-' && b.get(i + 1) == Some(&b'-') {
            while i < b.len() && b[i] != b'\n' { i += 1 }
            continue
        }
        if b[i] == b'/' && b.get(i + 1) == Some(&b'*') {
            i += 2;
            while i + 1 < b.len() && !(b[i] == b'*' && b[i + 1] == b'/') {
                i += 1
            }
            i = (i + 2).min(b.len());
            continue
        }
        let start = i;
        let mut k = 0;
        let s;
        if [b'\'', b'"', b'`', b'['].contains(&b[i]) {
            let q = b[i];
            let end = if q == b'[' { b']' } else { q };
            k = if q == b'\'' { 1 } else if q == b'"' { 4 } else { 2 };
            i += 1;
            let mut bytes = vec![];
            loop {
                if i >= b.len() {
                    return Err("unrecognized token: unterminated string".into())
                }
                if b[i] == end {
                    if q != b'[' && b.get(i + 1) == Some(&end) {
                        bytes.push(end);
                        i += 2
                    } else { i += 1; break }
                } else { bytes.push(b[i]); i += 1 }
            }
            s = String::from_utf8_lossy(&bytes).into_owned()
        } else if [b'?', b':', b'@', b'$'].contains(&b[i]) {
            k = 5;
            let prefix = b[i];
            i += 1;
            if prefix == b'?' {
                while i < b.len() && b[i].is_ascii_digit() { i += 1; }
            } else {
                let begin = i;
                while i < b.len() &&
                        (b[i].is_ascii_alphanumeric() || b[i] == b'_' ||
                                    b[i] == b'$' || b[i] >= 128) {
                    i += 1;
                }
                if i == begin {
                    return Err("unrecognized parameter token".into())
                }
                if prefix == b'$' {
                    while b.get(i) == Some(&b':') && b.get(i + 1) == Some(&b':')
                        {
                        i += 2;
                        while i < b.len() &&
                                (b[i].is_ascii_alphanumeric() || b[i] == b'_' ||
                                            b[i] == b'$' || b[i] >= 128) {
                            i += 1;
                        }
                    }
                    if b.get(i) == Some(&b'(') {
                        i += 1;
                        while i < b.len() && b[i] != b')' &&
                                !b[i].is_ascii_whitespace() {
                            i += 1;
                        }
                        if b.get(i) != Some(&b')') {
                            return Err("unrecognized parameter token".into())
                        }
                        i += 1;
                    }
                }
            }
            s = sql[start..i].into();
        } else if b[i].is_ascii_digit() ||
                (b[i] == b'.' &&
                        b.get(i + 1).map_or(false, |x| x.is_ascii_digit())) {
            k = 3;
            i += 1;
            while i < b.len() &&
                    (b[i].is_ascii_alphanumeric() || b[i] == b'.' ||
                                b[i] == b'_' ||
                            ((b[i] == b'+' || b[i] == b'-') &&
                                    (b[i - 1] == b'e' || b[i - 1] == b'E'))) {
                i += 1
            }
            s = sql[start..i].into()
        } else if b[i].is_ascii_alphabetic() || b[i] == b'_' || b[i] >= 128 {
            i += 1;
            while i < b.len() &&
                    (b[i].is_ascii_alphanumeric() || b[i] == b'_' ||
                                b[i] == b'$' || b[i] >= 128) {
                i += 1
            }
            s = sql[start..i].into()
        } else {
            i += 1;
            if i < b.len() && b[i].is_ascii() &&
                    ["<=", ">=", "!=", "==", "<>", "||", "<<", ">>",
                                "->"].contains(&&sql[start..i + 1]) {
                i += 1;
                if &sql[start..i] == "->" && b.get(i) == Some(&b'>') {
                    i += 1
                }
            }
            s = sql[start..i].into()
        }
        out.push(Tok { s, k, start, end: i });
    }
    Ok(out)
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum E {
    Param(usize),
    Bound(V, char, String, bool),
    Quoted(String),
    Ident(String),
    OrderedCall(Box<E>, Vec<Order>),
    SubCol(Box<Query>, usize, usize, usize),
    Window(Box<E>, WinSpec),
    Val(V),
    Col(Vec<String>),
    Star(Option<String>),
    Unary(String, Box<E>),
    Bin(String, Box<E>, Box<E>),
    Call(String, Vec<E>, bool, Option<Box<E>>),
    Cast(Box<E>, String),
    Collate(Box<E>, String),
    Between(Box<E>, Box<E>, Box<E>, bool),
    In(Box<E>, Vec<E>, Option<Box<Query>>, bool),
    Case(Option<Box<E>>, Vec<(E, E)>, Option<Box<E>>),
    Sub(Box<Query>),
    Exists(Box<Query>),
    Tuple(Vec<E>),
    Like(Box<E>, Box<E>, Option<Box<E>>, bool, bool),
}
#[derive(Clone,Debug,Default,Serialize,Deserialize)]
pub struct WinSpec {
    #[serde(default)]
    pub reference_only: bool,
    pub base: Option<String>,
    pub partition: Vec<E>,
    pub order: Vec<Order>,
    pub frame: Option<String>,
    pub start: Option<Bound>,
    pub end: Option<Bound>,
    pub exclude: String,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Bound { Unbounded(bool), Current, Offset(Box<E>, bool), }
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Item {
    pub e: E,
    pub name: String,
    pub alias: Option<String>,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Order {
    pub e: E,
    pub desc: bool,
    pub nulls: Option<bool>,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Source {
    Join(Vec<Join>),
    Function(String, Vec<E>),
    Table(String),
    Query(Box<Query>),
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Join {
    #[serde(default)]
    pub indexed:Option<String>,
    pub source: Source,
    pub alias: Option<String>,
    pub kind: String,
    pub on: Option<E>,
    pub using: Vec<String>,
    pub natural: bool,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Materialized {
    pub columns: Vec<String>,
    pub rows: Vec<Vec<V>>,
    pub affinities: Vec<(char, String)>,
}
pub fn next_query_id()->u64{
    static NEXT:std::sync::atomic::AtomicU64=std::sync::atomic::AtomicU64::new(1);
    NEXT.fetch_add(1,std::sync::atomic::Ordering::Relaxed)
}
#[derive(Clone,Debug,Default,Serialize,Deserialize)]
pub struct Query {
    #[serde(skip,default="next_query_id")]
    pub cache_id:u64,
    #[serde(skip)]
    pub first_row:bool,
    #[serde(default)]
    pub exists_only: bool,
    pub materialized: Option<Materialized>,
    pub windows: Vec<(String, WinSpec)>,
    pub ctes: Vec<(String, Vec<String>, Query)>,
    pub recursive: bool,
    pub items: Vec<Item>,
    pub from: Vec<Join>,
    pub filter: Option<E>,
    pub group: Vec<E>,
    pub having: Option<E>,
    pub distinct: bool,
    pub values: Vec<Vec<E>>,
    pub compound: Vec<(String, Query)>,
    pub order: Vec<Order>,
    pub limit: Option<E>,
    pub offset: Option<E>,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Column {
    #[serde(default)]
    pub policies: std::collections::BTreeMap<String, String>,
    pub name: String,
    pub typ: String,
    pub notnull: bool,
    pub pk: usize,
    pub unique: bool,
    pub default: Option<E>,
    pub default_sql: Option<String>,
    pub coll: String,
    pub auto: bool,
    pub pk_desc: bool,
    pub generated: Option<E>,
    #[serde(default)]
    pub stored: bool,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Foreign {
    pub cols: Vec<String>,
    pub table: String,
    pub target: Vec<String>,
    pub delete: String,
    pub update: String,
    pub deferred: bool,
}
#[derive(Clone,Debug)]
pub struct KeySpec {
    pub origin: String,
    pub expr: Vec<E>,
    pub desc: Vec<bool>,
    pub policy: String,
}
#[derive(Clone,Debug)]
pub enum Stmt {
    Attach(E, String),
    Vacuum(Option<String>, Option<E>),
    Analyze(Option<String>),
    Reindex(Option<String>),
    Detach(String),
    Temp(Box<Stmt>),
    With(Query, Box<Stmt>),
    Explain(Box<Stmt>, bool),
    CreateTrigger(Trigger, bool),
    Query(Query),
    CreateTable {
        name: String,
        ifnot: bool,
        cols: Vec<Column>,
        unique: Vec<Vec<String>>,
        policies: Vec<(Vec<String>, String)>,
        keys: Vec<KeySpec>,
        checks: Vec<E>,
        foreign: Vec<Foreign>,
        without: bool,
        strict: bool,
        asq: Option<Query>,
    },
    CreateIndex {
        name: String,
        table: String,
        unique: bool,
        ifnot: bool,
        expr: Vec<E>,
        desc: Vec<bool>,
        filter: Option<E>,
    },
    CreateView {
        name: String,
        cols: Vec<String>,
        q: Query,
        ifnot: bool,
    },
    Drop(String, String, bool),
    Insert {
        table: String,
        alias: Option<String>,
        cols: Vec<String>,
        q: Option<Query>,
        default: bool,
        mode: String,
        returning: Vec<Item>,
        upsert: Vec<Upsert>,
    },
    Update {
        indexed:Option<String>,
        table: String,
        alias: Option<String>,
        from: Vec<Join>,
        sets: Vec<(String, E)>,
        filter: Option<E>,
        mode: String,
        returning: Vec<Item>,
    },
    Delete {
        indexed:Option<String>,
        table: String,
        alias: Option<String>,
        filter: Option<E>,
        returning: Vec<Item>,
    },
    Begin,
    Commit,
    Rollback(Option<String>),
    Savepoint(String),
    Release(String),
    Pragma(String, Option<E>),
    Alter(String, Alter),
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Trigger {
    #[serde(default)]
    pub temporary: bool,
    pub name: String,
    pub table: String,
    pub timing: String,
    pub event: String,
    pub columns: Vec<String>,
    pub when: Option<E>,
    pub body: Vec<String>,
    pub sql: String,
}
#[derive(Clone,Debug)]
pub enum Alter {
    Rename(String),
    RenameCol(String, String),
    Add(Column, Vec<E>, Vec<Foreign>, String),
    NotNull(String, bool, String),
    Drop(String),
}
#[derive(Clone,Debug)]
pub struct Upsert {
    pub target: Vec<E>,
    pub target_filter: Option<E>,
    pub sets: Vec<(String, E)>,
    pub filter: Option<E>,
}
#[derive(Clone,Debug)]
pub struct RenameScope {
    pub start: usize,
    pub end: usize,
    pub query: Query,
}
pub struct Parser<'a> {
    pub parameters: std::collections::BTreeMap<String, usize>,
    pub max_parameter: usize,
    pub tracking: bool,
    pub table_sites: Vec<usize>,
    pub column_sites: Vec<Vec<usize>>,
    pub declarations: Vec<usize>,
    pub foreign_sites: Vec<(String, usize)>,
    pub scopes: Vec<RenameScope>,
    pub ts: Vec<Tok>,
    pub p: usize,
    pub sql: &'a str,
}
impl<'a> Parser<'a> {
    pub fn new(sql: &'a str) -> Res<Self> {
        Ok(Self {
                ts: lex(sql)?,
                p: 0,
                sql,
                parameters: Default::default(),
                max_parameter: 0,
                tracking: false,
                table_sites: vec![],
                column_sites: vec![],
                declarations: vec![],
                foreign_sites: vec![],
                scopes: vec![],
            })
    }
    pub fn at(&self, s: &str) -> bool {
        self.ts.get(self.p).map_or(false,
            |t| t.k == 0 && t.s.eq_ignore_ascii_case(s))
    }
    pub fn eat(&mut self, s: &str) -> bool {
        if self.at(s) { self.p += 1; true } else { false }
    }
    pub fn expect(&mut self, s: &str) -> Res<()> {
        if self.eat(s) {
            Ok(())
        } else { Err(format!("near \"{}\": expected {}",self.peek(),s)) }
    }
    pub fn peek(&self) -> &str {
        self.ts.get(self.p).map_or("end of input", |t| &t.s)
    }
    pub fn ident(&mut self) -> Res<String> {
        let t = self.ts.get(self.p).ok_or("incomplete input")?.clone();
        if t.k == 3 || t.k == 5 ||
                ["(", ")", ",", ";", "=", "*"].contains(&t.s.as_str()) {
            return Err(format!("near \"{}\": syntax error",t.s))
        }
        self.p += 1;
        Ok(t.s)
    }
    pub fn name(&mut self) -> Res<String> {
        let a = self.ident()?;
        if self.eat(".") {
            let b = self.ident()?;
            Ok(format!("{}.{}",a,b))
        } else { Ok(a) }
    }
    fn table_name(&mut self) -> Res<String> {
        let name = self.name()?;
        if self.tracking { self.table_sites.push(self.p - 1); }
        Ok(name)
    }
    fn column_ident(&mut self) -> Res<String> {
        let name = self.ident()?;
        if self.tracking { self.declarations.push(self.p - 1); }
        Ok(name)
    }
    fn column_names(&mut self) -> Res<Vec<String>> {
        let start = self.p;
        let names = self.names()?;
        if self.tracking {
            let mut p = start + 1;
            while p < self.p - 1 {
                self.declarations.push(p);
                p += 1;
                while p < self.p - 1 && !self.ts[p].s.eq(",") { p += 1; }
                p += 1;
            }
        }
        Ok(names)
    }
    fn record_scope(&mut self, start: usize, q: Query) {
        if self.tracking {
            self.scopes.push(RenameScope { start, end: self.p, query: q });
        }
    }
    fn names(&mut self) -> Res<Vec<String>> {
        self.expect("(")?;
        let mut v = vec![];
        loop {
            v.push(self.ident()?);
            if self.eat("COLLATE") { self.ident()?; }
            self.eat("ASC");
            self.eat("DESC");
            if !self.eat(",") { break }
        }
        self.expect(")")?;
        Ok(v)
    }
    fn key_columns(&mut self) -> Res<(Vec<String>, Vec<E>, Vec<bool>)> {
        self.expect("(")?;
        let mut names = vec![];
        let mut expr = vec![];
        let mut desc = vec![];
        loop {
            let n = self.column_ident()?;
            let mut e = E::Col(vec![n.clone()]);
            names.push(n);
            if self.eat("COLLATE") {
                e = E::Collate(Box::new(e), self.ident()?)
            }
            expr.push(e);
            desc.push(if self.eat("DESC") {
                    true
                } else { self.eat("ASC"); false });
            if !self.eat(",") { break }
        }
        self.expect(")")?;
        Ok((names, expr, desc))
    }
    pub fn expr(&mut self) -> Res<E> { self.bp(0) }
    fn bp(&mut self, min: u8) -> Res<E> {
        let mut left =
            if self.eat("-") {
                if self.peek().replace('_', "") == "9223372036854775808" {
                    self.p += 1;
                    E::Val(V::Int(i64::MIN))
                } else { E::Unary("-".into(), Box::new(self.bp(90)?)) }
            } else if self.eat("+") {
                E::Unary("+".into(), Box::new(self.bp(90)?))
            } else if self.eat("~") {
                E::Unary("~".into(), Box::new(self.bp(90)?))
            } else if self.eat("NOT") {
                E::Unary("NOT".into(), Box::new(self.bp(25)?))
            } else if self.eat("(") {
                if self.at("SELECT") || self.at("WITH") || self.at("VALUES") {
                    let q = self.query()?;
                    self.expect(")")?;
                    E::Sub(Box::new(q))
                } else {
                    let e = self.expr()?;
                    if self.eat(",") {
                        let mut v = vec![e];
                        loop { v.push(self.expr()?); if !self.eat(",") { break } }
                        self.expect(")")?;
                        E::Tuple(v)
                    } else { self.expect(")")?; e }
                }
            } else if self.eat("CASE") {
                let base =
                    if !self.at("WHEN") {
                        Some(Box::new(self.expr()?))
                    } else { None };
                let mut arms = vec![];
                while self.eat("WHEN") {
                    let a = self.expr()?;
                    self.expect("THEN")?;
                    arms.push((a, self.expr()?))
                }
                let end =
                    if self.eat("ELSE") {
                        Some(Box::new(self.expr()?))
                    } else { None };
                self.expect("END")?;
                E::Case(base, arms, end)
            } else if self.eat("CAST") {
                self.expect("(")?;
                let e = self.expr()?;
                self.expect("AS")?;
                let mut t = String::new();
                let mut depth = 0;
                while self.p < self.ts.len() {
                    if self.at(")") && depth == 0 { break }
                    if self.at("(") { depth += 1 }
                    if self.at(")") { depth -= 1 }
                    if !t.is_empty() { t.push(' ') }
                    t.push_str(self.peek());
                    self.p += 1;
                }
                self.expect(")")?;
                E::Cast(Box::new(e), t)
            } else if self.eat("EXISTS") {
                self.expect("(")?;
                let q = self.query()?;
                self.expect(")")?;
                E::Exists(Box::new(q))
            } else if self.eat("*") {
                E::Star(None)
            } else {
                let t =
                    self.ts.get(self.p).ok_or("incomplete input")?.clone();
                self.p += 1;
                match t.k {
                    1 => E::Val(V::Text(t.s)),
                    5 => {
                        let index =
                            if t.s.starts_with('?') && t.s.len() > 1 {
                                t.s[1..].parse::<usize>().map_err(|_|
                                            "variable number out of range")?
                            } else if t.s != "?" && self.parameters.contains_key(&t.s) {
                                self.parameters[&t.s]
                            } else { self.max_parameter + 1 };
                        if index == 0 || index > 32766 {
                            return Err("variable number must be between ?1 and ?32766".into())
                        }
                        self.max_parameter = self.max_parameter.max(index);
                        if t.s != "?" { self.parameters.insert(t.s, index); }
                        E::Param(index)
                    }
                    3 => {
                        let s = t.s.replace('_', "");
                        let v =
                            if s.starts_with("0x") || s.starts_with("0X") {
                                V::Int(u64::from_str_radix(&s[2..],
                                                    16).map_err(|_| "hex literal too big")? as i64)
                            } else if let Ok(n) = s.parse::<i64>() {
                                V::Int(n)
                            } else {
                                V::Real(s.parse().map_err(|_| "invalid numeric literal")?)
                            };
                        E::Val(v)
                    }
                    _ => {
                        if t.k == 0 && t.s.eq_ignore_ascii_case("NULL") {
                            E::Val(V::Null)
                        } else if t.k == 0 && t.s.eq_ignore_ascii_case("X") &&
                                self.ts.get(self.p).map_or(false, |x| x.k == 1) {
                            let s = self.ident()?;
                            if s.len() % 2 != 0 {
                                return Err("unrecognized blob literal".into())
                            }
                            let mut b = vec![];
                            for i in (0..s.len()).step_by(2) {
                                b.push(u8::from_str_radix(&s[i..i + 2],
                                                16).map_err(|_| "invalid blob literal")?)
                            }
                            E::Val(V::Blob(b))
                        } else if self.eat("(") {
                            let mut args = vec![];
                            let mut orders = vec![];
                            let distinct = self.eat("DISTINCT");
                            if !self.eat(")") {
                                loop {
                                    args.push(self.expr()?);
                                    if !self.eat(",") { break }
                                }
                                if self.eat("ORDER") {
                                    self.expect("BY")?;
                                    orders = self.orders()?
                                }
                                self.expect(")")?;
                            }
                            let filter =
                                if self.eat("FILTER") {
                                    self.expect("(")?;
                                    self.expect("WHERE")?;
                                    let e = self.expr()?;
                                    self.expect(")")?;
                                    Some(Box::new(e))
                                } else { None };
                            let call = E::Call(t.s, args, distinct, filter);
                            let call =
                                if orders.is_empty() {
                                    call
                                } else { E::OrderedCall(Box::new(call), orders) };
                            if self.eat("OVER") {
                                let w =
                                    if self.at("(") {
                                        self.window()?
                                    } else {
                                        WinSpec {
                                            reference_only: true,
                                            base: Some(self.ident()?),
                                            ..Default::default()
                                        }
                                    };
                                E::Window(Box::new(call), w)
                            } else { call }
                        } else {
                            let mut sites = vec![self.p-1];
                            let mut n = vec![t.s];
                            while self.eat(".") {
                                if self.eat("*") {
                                    sites.push(self.p - 1);
                                    if self.tracking { self.column_sites.push(sites); }
                                    return Ok(E::Star(Some(n.join("."))))
                                }
                                n.push(self.ident()?);
                                sites.push(self.p - 1)
                            }
                            if self.tracking { self.column_sites.push(sites); }
                            if n.len() == 1 && t.k == 4 {
                                E::Quoted(n[0].clone())
                            } else if n.len() == 1 && t.k == 2 {
                                E::Ident(n[0].clone())
                            } else { E::Col(n) }
                        }
                    }
                }
            };
        loop {
            if self.at("COLLATE") && 85 >= min {
                self.p += 1;
                left = E::Collate(Box::new(left), self.ident()?);
                continue
            }
            let op = self.peek().to_ascii_uppercase();
            let neg =
                op == "NOT" &&
                    self.ts.get(self.p +
                                1).map_or(false,
                        |t|
                            ["IN", "LIKE", "GLOB",
                                        "BETWEEN"].contains(&t.s.to_ascii_uppercase().as_str()));
            let op2 =
                if neg {
                    self.ts[self.p + 1].s.to_ascii_uppercase()
                } else { op.clone() };
            let prec =
                match op2.as_str() {
                    "OR" => 10,
                    "AND" => 20,
                    "IS" | "=" | "==" | "!=" | "<>" | "IN" | "LIKE" | "GLOB" |
                        "BETWEEN" | "ISNULL" | "NOTNULL" => 30,
                    "<" | ">" | "<=" | ">=" => 40,
                    "&" | "|" | "<<" | ">>" => 50,
                    "+" | "-" => 60,
                    "*" | "/" | "%" => 70,
                    "||" | "->" | "->>" => 80,
                    _ => 0,
                };
            if prec == 0 || prec < min {
                if self.at("NOT") &&
                            self.ts.get(self.p +
                                        1).map_or(false, |t| t.s.eq_ignore_ascii_case("NULL")) &&
                        30 >= min {
                    self.p += 2;
                    left = E::Unary("NOTNULL".into(), Box::new(left));
                    continue
                }
                break
            }
            self.p += if neg { 2 } else { 1 };
            match op2.as_str() {
                "ISNULL" | "NOTNULL" => left = E::Unary(op2, Box::new(left)),
                "IS" => {
                    let not = self.eat("NOT");
                    let distinct = self.eat("DISTINCT");
                    if distinct { self.expect("FROM")? }
                    let op = if not ^ distinct { "IS NOT" } else { "IS" };
                    left =
                        E::Bin(op.into(), Box::new(left),
                            Box::new(self.bp(prec + 1)?))
                }
                "BETWEEN" => {
                    let a = self.bp(prec + 1)?;
                    self.expect("AND")?;
                    let b = self.bp(prec + 1)?;
                    left =
                        E::Between(Box::new(left), Box::new(a), Box::new(b), neg)
                }
                "IN" => {
                    let mut vals = vec![];
                    let mut q = None;
                    if self.eat("(") {
                        if self.at("SELECT") || self.at("WITH") || self.at("VALUES")
                            {
                            q = Some(Box::new(self.query()?));
                            self.expect(")")?
                        } else if !self.eat(")") {
                            loop {
                                vals.push(self.expr()?);
                                if !self.eat(",") { break }
                            }
                            self.expect(")")?
                        }
                    } else {
                        let name = self.table_name()?;
                        q =
                            Some(Box::new(Query {
                                        cache_id:next_query_id(),
                                        items: vec![Item{e:E::Star(None),name:"*".into(),alias:None}],
                                        from: vec![Join{indexed:None,source:Source::Table(name),alias:None,kind:"INNER".into(),on:None,using:vec![],natural:false}],
                                        ..Default::default()
                                    }))
                    }
                    left = E::In(Box::new(left), vals, q, neg)
                }
                "LIKE" | "GLOB" => {
                    let r = self.bp(prec + 1)?;
                    let esc =
                        if self.eat("ESCAPE") {
                            Some(Box::new(self.bp(prec + 1)?))
                        } else { None };
                    left =
                        E::Like(Box::new(left), Box::new(r), esc, op2 == "GLOB",
                            neg)
                }
                _ =>
                    left =
                        E::Bin(op2, Box::new(left), Box::new(self.bp(prec + 1)?)),
            }
        }
        Ok(left)
    }
    fn list_expr(&mut self) -> Res<Vec<E>> {
        let mut r = vec![self.expr()?];
        while self.eat(",") { r.push(self.expr()?) }
        Ok(r)
    }
    fn alias(&mut self) -> Res<Option<String>> {
        if self.eat("AS") { return Ok(Some(self.ident()?)) }
        if let Some(t) = self.ts.get(self.p) {
            let reserved =
                ["FROM", "WHERE", "GROUP", "HAVING", "ORDER", "LIMIT",
                        "OFFSET", "UNION", "INTERSECT", "EXCEPT", "JOIN", "LEFT",
                        "RIGHT", "FULL", "INNER", "CROSS", "NATURAL", "ON", "USING",
                        "RETURNING", "SET", "WINDOW", "DO", "END", "WHEN", "ELSE",
                        "THEN", "ASC", "DESC", "NULLS", "INDEXED", "NOT", "OVER",
                        "PARTITION", "ROWS", "RANGE", "GROUPS", "EXCLUDE",
                        "PRECEDING", "FOLLOWING", "BEGIN"];
            if (t.k == 1 || t.k == 2 || t.k == 4 ||
                            t.s.chars().next().map_or(false,
                                |c| c.is_alphabetic() || c == '_')) &&
                    !reserved.contains(&t.s.to_ascii_uppercase().as_str()) {
                return Ok(Some(self.ident()?))
            }
        }
        Ok(None)
    }
    fn items(&mut self) -> Res<Vec<Item>> {
        let mut out = vec![];
        loop {
            let start =
                self.ts.get(self.p).map_or(self.sql.len(), |t| t.start);
            let e = self.expr()?;
            let end = self.ts[self.p - 1].end;
            let alias = self.alias()?;
            let name =
                alias.clone().unwrap_or_else(||
                        match &e {
                            E::Col(v) => v.last().unwrap().clone(),
                            E::Quoted(n) | E::Ident(n) => n.clone(),
                            _ => self.sql[start..end].trim().to_string(),
                        });
            out.push(Item { e, name, alias });
            if !self.eat(",") { break }
        }
        Ok(out)
    }
    pub fn query(&mut self) -> Res<Query> {
        let start = self.p;
        let mut q = self.query_inner()?;
        q.cache_id=next_query_id();
        if self.tracking { self.record_scope(start, q.clone()); }
        Ok(q)
    }
    fn query_inner(&mut self) -> Res<Query> {
        let mut q = Query::default();
        if self.eat("WITH") {
            q.recursive = self.eat("RECURSIVE");
            loop {
                let name = self.ident()?;
                let cols = if self.at("(") { self.names()? } else { vec![] };
                self.expect("AS")?;
                self.eat("NOT");
                self.eat("MATERIALIZED");
                self.expect("(")?;
                let c = self.query()?;
                self.expect(")")?;
                q.ctes.push((name, cols, c));
                if !self.eat(",") { break }
            }
        }
        self.core(&mut q)?;
        while self.at("UNION") || self.at("INTERSECT") || self.at("EXCEPT") {
            let mut op = self.ident()?.to_ascii_uppercase();
            if self.eat("ALL") { op.push_str(" ALL") }
            let mut r = Query::default();
            self.core(&mut r)?;
            q.compound.push((op, r))
        }
        if self.eat("ORDER") { self.expect("BY")?; q.order = self.orders()? }
        if self.eat("LIMIT") {
            q.limit = Some(self.expr()?);
            if self.eat("OFFSET") {
                q.offset = Some(self.expr()?)
            } else if self.eat(",") {
                q.offset = q.limit.take();
                q.limit = Some(self.expr()?)
            }
        }
        Ok(q)
    }
    fn orders(&mut self) -> Res<Vec<Order>> {
        let mut v = vec![];
        loop {
            let e = self.expr()?;
            let desc = self.eat("DESC");
            self.eat("ASC");
            let nulls =
                if self.eat("NULLS") {
                    if self.eat("FIRST") {
                        Some(false)
                    } else { self.expect("LAST")?; Some(true) }
                } else { None };
            v.push(Order { e, desc, nulls });
            if !self.eat(",") { break }
        }
        Ok(v)
    }
    fn core(&mut self, q: &mut Query) -> Res<()> {
        let start = self.p;
        self.core_inner(q)?;
        if self.tracking { self.record_scope(start, q.clone()); }
        Ok(())
    }
    fn core_inner(&mut self, q: &mut Query) -> Res<()> {
        if self.eat("VALUES") {
            loop {
                self.expect("(")?;
                let row = self.list_expr()?;
                self.expect(")")?;
                q.values.push(row);
                if !self.eat(",") { break }
            }
            return Ok(())
        }
        self.expect("SELECT")?;
        q.distinct = self.eat("DISTINCT");
        self.eat("ALL");
        q.items = self.items()?;
        if self.eat("FROM") { q.from = self.sources()? }
        if self.eat("WHERE") { q.filter = Some(self.expr()?) }
        if self.eat("GROUP") {
            self.expect("BY")?;
            q.group = self.list_expr()?
        }
        if self.eat("HAVING") { q.having = Some(self.expr()?) }
        if self.eat("WINDOW") {
            loop {
                let n = self.ident()?;
                self.expect("AS")?;
                q.windows.push((n, self.window()?));
                if !self.eat(",") { break }
            }
        }
        Ok(())
    }
    fn sources(&mut self) -> Res<Vec<Join>> {
        let mut from = vec![];
        let mut kind = "INNER".to_string();
        let mut natural = false;
        loop {
            let source =
                if self.eat("(") {
                    let source =
                        if self.at("SELECT") || self.at("WITH") || self.at("VALUES")
                            {
                            Source::Query(Box::new(self.query()?))
                        } else { Source::Join(self.sources()?) };
                    self.expect(")")?;
                    source
                } else {
                    let n = self.table_name()?;
                    if self.eat("(") {
                        if self.tracking { self.table_sites.pop(); }
                        let args =
                            if self.eat(")") {
                                vec![]
                            } else {
                                let args = self.list_expr()?;
                                self.expect(")")?;
                                args
                            };
                        Source::Function(n, args)
                    } else { Source::Table(n) }
                };
            let alias = self.alias()?;
            let indexed=self.index_clause()?;
            if indexed.is_some()&&!matches!(source,Source::Table(_)){return Err("INDEXED BY requires a table".into())}
            let on = if self.eat("ON") { Some(self.expr()?) } else { None };
            let using =
                if self.eat("USING") { self.column_names()? } else { vec![] };
            if on.is_some() && !using.is_empty() {
                return Err("a join cannot have both ON and USING clauses".into())
            }
            if natural && (on.is_some() || !using.is_empty()) {
                return Err("a NATURAL join may not have ON or USING clauses".into())
            }
            from.push(Join {
                    indexed,
                    source,
                    alias,
                    kind: kind.clone(),
                    on,
                    using,
                    natural,
                });
            kind = "INNER".into();
            natural = false;
            if self.eat(",") { continue }
            natural = self.eat("NATURAL");
            if self.at("LEFT") || self.at("RIGHT") || self.at("FULL") ||
                        self.at("INNER") || self.at("CROSS") {
                kind = self.ident()?.to_ascii_uppercase();
                self.eat("OUTER");
            }
            if self.eat("JOIN") { continue }
            break
        }
        Ok(from)
    }
    fn bound(&mut self) -> Res<Bound> {
        if self.eat("UNBOUNDED") {
            let following = self.eat("FOLLOWING");
            if !following { self.expect("PRECEDING")? }
            Ok(Bound::Unbounded(following))
        } else if self.eat("CURRENT") {
            self.expect("ROW")?;
            Ok(Bound::Current)
        } else {
            let e = self.expr()?;
            let following = self.eat("FOLLOWING");
            if !following { self.expect("PRECEDING")? }
            Ok(Bound::Offset(Box::new(e), following))
        }
    }
    fn index_clause(&mut self)->Res<Option<String>>{
        if self.eat("INDEXED"){self.expect("BY")?;Ok(Some(self.ident()?))}
        else if self.eat("NOT"){self.expect("INDEXED")?;Ok(Some(String::new()))}else{Ok(None)}
    }
    fn window(&mut self) -> Res<WinSpec> {
        self.expect("(")?;
        let mut w = WinSpec::default();
        if !self.at(")") && !self.at("PARTITION") && !self.at("ORDER") &&
                        !self.at("ROWS") && !self.at("RANGE") && !self.at("GROUPS")
            {
            w.base = Some(self.ident()?)
        }
        if self.eat("PARTITION") {
            self.expect("BY")?;
            w.partition = self.list_expr()?
        }
        if self.eat("ORDER") { self.expect("BY")?; w.order = self.orders()? }
        if self.at("ROWS") || self.at("RANGE") || self.at("GROUPS") {
            w.frame = Some(self.ident()?.to_ascii_uppercase());
            if self.eat("BETWEEN") {
                w.start = Some(self.bound()?);
                self.expect("AND")?;
                w.end = Some(self.bound()?)
            } else {
                w.start = Some(self.bound()?);
                w.end = Some(Bound::Current)
            }
        }
        if self.eat("EXCLUDE") {
            w.exclude = self.ident()?.to_ascii_uppercase();
            if w.exclude == "CURRENT" {
                self.expect("ROW")?
            } else if w.exclude == "NO" { self.expect("OTHERS")? }
        }
        self.expect(")")?;
        Ok(w)
    }
    fn conflict(&mut self) -> Res<String> {
        if self.eat("ON") {
            self.expect("CONFLICT")?;
            let m = self.ident()?.to_ascii_uppercase();
            if !["ABORT", "FAIL", "ROLLBACK", "IGNORE",
                                "REPLACE"].contains(&m.as_str()) {
                return Err("invalid conflict resolution algorithm".into())
            }
            Ok(m)
        } else { Ok("ABORT".into()) }
    }
    fn foreign(&mut self, cols: Vec<String>) -> Res<Foreign> {
        let table = self.table_name()?;
        let start = self.p;
        let target = if self.at("(") { self.names()? } else { vec![] };
        if self.tracking && !target.is_empty() {
            let mut p = start + 1;
            while p < self.p - 1 {
                self.foreign_sites.push((table.clone(), p));
                p += 1;
                while p < self.p - 1 && self.ts[p].s != "," { p += 1; }
                p += 1;
            }
        }
        let mut f =
            Foreign {
                cols,
                table,
                target,
                delete: "NO ACTION".into(),
                update: "NO ACTION".into(),
                deferred: false,
            };
        loop {
            if self.eat("ON") {
                let event = self.ident()?;
                let mut action = self.ident()?.to_ascii_uppercase();
                if action == "SET" || action == "NO" {
                    action.push(' ');
                    action.push_str(&self.ident()?.to_ascii_uppercase())
                }
                if !["CASCADE", "RESTRICT", "NO ACTION", "SET NULL",
                                    "SET DEFAULT"].contains(&action.as_str()) {
                    return Err("invalid foreign key action".into())
                }
                if event.eq_ignore_ascii_case("DELETE") {
                    f.delete = action
                } else if event.eq_ignore_ascii_case("UPDATE") {
                    f.update = action
                } else { return Err("invalid foreign key event".into()) }
            } else if self.eat("MATCH") {
                self.ident()?;
            } else if self.eat("DEFERRABLE") {
                f.deferred = false;
                if self.eat("INITIALLY") {
                    if self.eat("DEFERRED") {
                        f.deferred = true
                    } else { self.expect("IMMEDIATE")? }
                }
            } else if self.at("NOT") &&
                    self.ts.get(self.p +
                                1).map_or(false, |t| t.s.eq_ignore_ascii_case("DEFERRABLE"))
                {
                self.p += 2;
                f.deferred = false;
                if self.eat("INITIALLY") {
                    if !self.eat("DEFERRED") { self.expect("IMMEDIATE")? }
                }
            } else { break }
        }
        Ok(f)
    }
    fn column(&mut self, checks: &mut Vec<E>, foreign: &mut Vec<Foreign>)
        -> Res<Column> {
        let name = self.column_ident()?;
        let mut typ = String::new();
        let mut depth = 0;
        while self.p < self.ts.len() {
            let s = self.peek().to_ascii_uppercase();
            if depth == 0 &&
                    [",", ")", "PRIMARY", "NOT", "NULL", "UNIQUE", "CHECK",
                                "DEFAULT", "COLLATE", "REFERENCES", "CONSTRAINT",
                                "GENERATED", "AS"].contains(&s.as_str()) {
                break
            }
            if s == "(" { depth += 1 }
            if s == ")" { depth -= 1 }
            if !typ.is_empty() && s != "(" && s != ")" && s != "," {
                typ.push(' ')
            }
            typ.push_str(self.peek());
            self.p += 1;
        }
        let mut c =
            Column {
                policies: Default::default(),
                name,
                typ,
                notnull: false,
                pk: 0,
                unique: false,
                default: None,
                default_sql: None,
                coll: "BINARY".into(),
                auto: false,
                pk_desc: false,
                generated: None,
                stored: false,
            };
        loop {
            if self.eat("CONSTRAINT") {
                self.ident()?;
            } else if self.eat("PRIMARY") {
                self.expect("KEY")?;
                if c.pk > 0 {
                    return Err("table has more than one primary key".into())
                }
                c.pk = 1;
                c.pk_desc = self.eat("DESC");
                self.eat("ASC");
                let m = self.conflict()?;
                c.policies.insert("pk".into(), m);
                c.auto = self.eat("AUTOINCREMENT");
            } else if self.eat("NOT") {
                self.expect("NULL")?;
                c.notnull = true;
                let m = self.conflict()?;
                c.policies.insert("nn".into(), m);
            } else if self.eat("NULL") {
                self.conflict()?;
            } else if self.eat("UNIQUE") {
                c.unique = true;
                let m = self.conflict()?;
                c.policies.insert("uq".into(), m);
            } else if self.eat("CHECK") {
                self.expect("(")?;
                checks.push(self.expr()?);
                self.expect(")")?;
            } else if self.eat("DEFAULT") {
                let start =
                    self.ts.get(self.p).ok_or("incomplete input")?.start;
                let e =
                    if self.eat("(") {
                        let e = self.expr()?;
                        self.expect(")")?;
                        e
                    } else { self.bp(90)? };
                let end = self.ts[self.p - 1].end;
                c.default = Some(e);
                c.default_sql = Some(self.sql[start..end].into());
            } else if self.eat("COLLATE") {
                c.coll = self.ident()?;
            } else if self.eat("REFERENCES") {
                foreign.push(self.foreign(vec![c.name.clone()])?);
            } else if self.eat("GENERATED") || self.at("AS") {
                self.eat("ALWAYS");
                self.expect("AS")?;
                self.expect("(")?;
                c.generated = Some(self.expr()?);
                self.expect(")")?;
                c.stored = self.eat("STORED");
                self.eat("VIRTUAL");
            } else { break }
        }
        Ok(c)
    }
    fn sets(&mut self) -> Res<Vec<(String, E)>> {
        let mut sets = vec![];
        loop {
            if self.at("(") {
                let names = self.column_names()?;
                self.expect("=")?;
                let e = self.expr()?;
                if let E::Tuple(es) = e {
                    if names.len() != es.len() {
                        return Err("assignment arity mismatch".into())
                    }
                    sets.extend(names.into_iter().zip(es))
                } else if let E::Sub(q) = e {
                    let width = names.len();
                    let group = self.p;
                    for (i, n) in names.into_iter().enumerate() {
                        sets.push((n, E::SubCol(q.clone(), i, width, group)))
                    }
                } else if names.len() == 1 {
                    sets.push((names[0].clone(), e))
                } else { return Err("row value required".into()) }
            } else {
                let n = self.column_ident()?;
                self.expect("=")?;
                sets.push((n, self.expr()?))
            }
            if !self.eat(",") { break }
        }
        let last =
            sets.iter().map(|(n, _)|
                        n.to_ascii_lowercase()).collect::<Vec<_>>();
        Ok(sets.into_iter().enumerate().filter(|(i, (n, _))|
                            !last[i +
                                                1..].contains(&n.to_ascii_lowercase())).map(|(_, s)|
                        s).collect())
    }
    fn returning(&mut self) -> Res<Vec<Item>> {
        if self.eat("RETURNING") { self.items() } else { Ok(vec![]) }
    }
    pub fn statement(&mut self) -> Res<Stmt> {
        let start = self.p;
        let stmt = self.statement_inner()?;
        if matches!(&stmt,Stmt::CreateView{..}|Stmt::CreateTrigger(_,_)) &&
                self.ts[start..self.p].iter().any(|t| t.k == 5) {
            return Err("parameters are not allowed in views or triggers".into())
        }
        if self.tracking {
            let mut q = Query::default();
            let source =
                |table: &String, alias: Option<String>|
                    Join {
                        indexed:None,
                        source: Source::Table(table.clone()),
                        alias,
                        kind: "INNER".into(),
                        on: None,
                        using: vec![],
                        natural: false,
                    };
            match &stmt {
                Stmt::CreateTable { name, .. } =>
                    q.from.push(source(name, None)),
                Stmt::CreateIndex { table, .. } =>
                    q.from.push(source(table, None)),
                Stmt::CreateTrigger(t, _) => {
                    q.from.push(source(&t.table, Some("old".into())));
                    q.from.push(source(&t.table, Some("new".into())));
                }
                Stmt::Insert { table, alias, .. } | Stmt::Delete {
                    table, alias, .. } =>
                    q.from.push(source(table, alias.clone())),
                Stmt::Update { table, alias, from, .. } => {
                    q.from.push(source(table, alias.clone()));
                    q.from.extend(from.clone());
                }
                _ => {}
            }
            if !q.from.is_empty() { self.record_scope(start, q); }
        }
        Ok(stmt)
    }
    fn statement_inner(&mut self) -> Res<Stmt> {
        if self.eat("ATTACH") {
            self.eat("DATABASE");
            let path = self.expr()?;
            self.expect("AS")?;
            return Ok(Stmt::Attach(path, self.ident()?))
        }
        if self.eat("DETACH") {
            self.eat("DATABASE");
            return Ok(Stmt::Detach(self.ident()?))
        }
        if self.eat("EXPLAIN") {
            let plan =
                if self.eat("QUERY") {
                    self.expect("PLAN")?;
                    true
                } else { false };
            return Ok(Stmt::Explain(Box::new(self.statement()?), plan))
        }
        if self.at("WITH") {
            let save = self.p;
            let saved_parameters = self.parameters.clone();
            let saved_max = self.max_parameter;
            self.p += 1;
            let mut q = Query::default();
            q.recursive = self.eat("RECURSIVE");
            loop {
                let name = self.ident()?;
                let cols = if self.at("(") { self.names()? } else { vec![] };
                self.expect("AS")?;
                self.eat("NOT");
                self.eat("MATERIALIZED");
                self.expect("(")?;
                let c = self.query()?;
                self.expect(")")?;
                q.ctes.push((name, cols, c));
                if !self.eat(",") { break }
            }
            if self.at("SELECT") || self.at("VALUES") {
                self.p = save;
                self.parameters = saved_parameters;
                self.max_parameter = saved_max;
                return Ok(Stmt::Query(self.query()?))
            }
            return Ok(Stmt::With(q, Box::new(self.statement()?)))
        }
        if self.at("SELECT") || self.at("WITH") || self.at("VALUES") {
            return Ok(Stmt::Query(self.query()?))
        }
        if self.eat("CREATE") {
            self.eat("TEMP");
            self.eat("TEMPORARY");
            let unique = self.eat("UNIQUE");
            if self.eat("TRIGGER") {
                let ifnot =
                    if self.eat("IF") {
                        self.expect("NOT")?;
                        self.expect("EXISTS")?;
                        true
                    } else { false };
                let name = self.name()?;
                let timing =
                    if self.eat("AFTER") {
                            "AFTER"
                        } else if self.eat("INSTEAD") {
                            self.expect("OF")?;
                            "INSTEAD OF"
                        } else { self.eat("BEFORE"); "BEFORE" }.to_string();
                let event = self.ident()?.to_ascii_uppercase();
                if !["INSERT", "UPDATE", "DELETE"].contains(&event.as_str()) {
                    return Err("invalid trigger event".into())
                }
                let mut columns = vec![];
                if self.eat("OF") {
                    if event != "UPDATE" {
                        return Err("OF is only allowed after UPDATE".into())
                    }
                    loop {
                        columns.push(self.column_ident()?);
                        if !self.eat(",") { break }
                    }
                }
                self.expect("ON")?;
                let table = self.table_name()?;
                if self.eat("FOR") {
                    self.expect("EACH")?;
                    self.expect("ROW")?
                }
                let when =
                    if self.eat("WHEN") { Some(self.expr()?) } else { None };
                self.expect("BEGIN")?;
                let mut body = vec![];
                while !self.at("END") {
                    let start =
                        self.ts.get(self.p).ok_or("incomplete trigger")?.start;
                    let statement = self.statement()?;
                    match &statement {
                        Stmt::Insert { returning, default, .. } => {
                            if *default {
                                return Err("DEFAULT VALUES is not allowed in triggers".into())
                            }
                            if !returning.is_empty() {
                                return Err("RETURNING is not allowed in triggers".into())
                            }
                        }
                        Stmt::Update { returning,indexed, .. } | Stmt::Delete { returning,indexed,
                            .. } => {
                            if indexed.is_some(){return Err("INDEXED BY is not allowed on trigger DML".into())}
                            if !returning.is_empty() {
                                return Err("RETURNING is not allowed in triggers".into())
                            }
                        }
                        Stmt::Query(_) => {}
                        _ =>
                            return Err("statement is not allowed in trigger program".into()),
                    }
                    let end = self.ts[self.p - 1].end;
                    body.push(self.sql[start..end].into());
                    self.expect(";")?;
                }
                self.expect("END")?;
                return Ok(Stmt::CreateTrigger(Trigger {
                                temporary: false,
                                name,
                                table,
                                timing,
                                event,
                                columns,
                                when,
                                body,
                                sql: self.sql.trim().trim_end_matches(';').into(),
                            }, ifnot))
            }
            if self.eat("TABLE") {
                let ifnot =
                    if self.eat("IF") {
                        self.expect("NOT")?;
                        self.expect("EXISTS")?;
                        true
                    } else { false };
                let name = self.table_name()?;
                let mut cols = vec![];
                let mut uniq = vec![];
                let mut policies = vec![];
                let mut keys = vec![];
                let mut checks = vec![];
                let mut foreign = vec![];
                let mut pk = vec![];
                if self.eat("AS") {
                    return Ok(Stmt::CreateTable {
                                name,
                                ifnot,
                                cols,
                                unique: uniq,
                                policies,
                                keys,
                                checks,
                                foreign,
                                without: false,
                                strict: false,
                                asq: Some(self.query()?),
                            })
                }
                self.expect("(")?;
                loop {
                    if self.eat("CONSTRAINT") { self.ident()?; }
                    if self.eat("PRIMARY") {
                        self.expect("KEY")?;
                        if !pk.is_empty() {
                            return Err("table has more than one primary key".into())
                        }
                        let (names, expr, desc) = self.key_columns()?;
                        pk = names;
                        let mode = self.conflict()?;
                        policies.push((pk.clone(), mode.clone()));
                        keys.push(KeySpec {
                                origin: "pk".into(),
                                expr,
                                desc,
                                policy: mode,
                            });
                    } else if self.eat("UNIQUE") {
                        let (names, expr, desc) = self.key_columns()?;
                        uniq.push(names.clone());
                        let mode = self.conflict()?;
                        policies.push((names, mode.clone()));
                        keys.push(KeySpec {
                                origin: "u".into(),
                                expr,
                                desc,
                                policy: mode,
                            });
                    } else if self.eat("CHECK") {
                        self.expect("(")?;
                        checks.push(self.expr()?);
                        self.expect(")")?;
                        self.conflict()?;
                    } else if self.eat("FOREIGN") {
                        self.expect("KEY")?;
                        let n = self.column_names()?;
                        self.expect("REFERENCES")?;
                        foreign.push(self.foreign(n)?);
                    } else {
                        cols.push(self.column(&mut checks, &mut foreign)?)
                    }
                    if !self.eat(",") { break }
                }
                self.expect(")")?;
                if !pk.is_empty() && cols.iter().any(|c| c.pk > 0) {
                    return Err("table has more than one primary key".into())
                }
                for (i, n) in pk.iter().enumerate() {
                    let c =
                        cols.iter_mut().find(|c|
                                        c.name.eq_ignore_ascii_case(n)).ok_or_else(||
                                    format!("unknown column {} in primary key",n))?;
                    c.pk = i + 1;
                }
                let mut without = false;
                let mut strict = false;
                loop {
                    if self.eat("WITHOUT") {
                        self.expect("ROWID")?;
                        without = true
                    } else if self.eat("STRICT") {
                        strict = true
                    } else { break }
                    self.eat(",");
                }
                return Ok(Stmt::CreateTable {
                            name,
                            ifnot,
                            cols,
                            unique: uniq,
                            policies,
                            keys,
                            checks,
                            foreign,
                            without,
                            strict,
                            asq: None,
                        })
            }
            if self.eat("INDEX") {
                let ifnot =
                    if self.eat("IF") {
                        self.expect("NOT")?;
                        self.expect("EXISTS")?;
                        true
                    } else { false };
                let name = self.name()?;
                self.expect("ON")?;
                let table = self.table_name()?;
                self.expect("(")?;
                let mut expr = vec![];
                let mut desc = vec![];
                loop {
                    expr.push(self.expr()?);
                    let descending = self.eat("DESC");
                    self.eat("ASC");
                    desc.push(descending);
                    if !self.eat(",") { break }
                }
                self.expect(")")?;
                let filter =
                    if self.eat("WHERE") { Some(self.expr()?) } else { None };
                return Ok(Stmt::CreateIndex {
                            name,
                            table,
                            unique,
                            ifnot,
                            expr,
                            desc,
                            filter,
                        })
            }
            if self.eat("VIEW") {
                let ifnot =
                    if self.eat("IF") {
                        self.expect("NOT")?;
                        self.expect("EXISTS")?;
                        true
                    } else { false };
                let name = self.name()?;
                let cols = if self.at("(") { self.names()? } else { vec![] };
                self.expect("AS")?;
                return Ok(Stmt::CreateView {
                            name,
                            cols,
                            q: self.query()?,
                            ifnot,
                        })
            }
            return Err("unsupported CREATE statement".into())
        }
        if self.eat("DROP") {
            let kind = self.ident()?.to_ascii_uppercase();
            let exists =
                if self.eat("IF") {
                    self.expect("EXISTS")?;
                    true
                } else { false };
            return Ok(Stmt::Drop(kind, self.name()?, exists))
        }
        if self.at("INSERT") || self.at("REPLACE") {
            let replace = self.eat("REPLACE");
            if !replace { self.expect("INSERT")? }
            let mode =
                if replace {
                    "REPLACE".into()
                } else if self.eat("OR") {
                    self.ident()?.to_ascii_uppercase()
                } else { "DEFAULT".into() };
            self.expect("INTO")?;
            let table = self.table_name()?;
            let alias =
                if self.eat("AS") { Some(self.ident()?) } else { None };
            let cols =
                if self.at("(") { self.column_names()? } else { vec![] };
            let default = self.eat("DEFAULT");
            let q =
                if default {
                    self.expect("VALUES")?;
                    None
                } else { Some(self.query()?) };
            let mut upsert = vec![];
            while self.eat("ON") {
                if default {
                    return Err("UPSERT is not allowed after DEFAULT VALUES".into())
                }
                if upsert.last().is_some_and(|u: &Upsert| u.target.is_empty())
                    {
                    return Err("only the final ON CONFLICT clause may omit its target".into())
                }
                self.expect("CONFLICT")?;
                let mut target = vec![];
                if self.eat("(") {
                    loop {
                        target.push(self.expr()?);
                        self.eat("ASC");
                        self.eat("DESC");
                        if !self.eat(",") { break }
                    }
                    self.expect(")")?;
                }
                let target_filter =
                    if self.eat("WHERE") {
                        if target.is_empty() {
                            return Err("conflict WHERE requires a target".into())
                        }
                        Some(self.expr()?)
                    } else { None };
                self.expect("DO")?;
                let (sets, filter) =
                    if self.eat("NOTHING") {
                        (vec![], None)
                    } else {
                        self.expect("UPDATE")?;
                        self.expect("SET")?;
                        let sets = self.sets()?;
                        let filter =
                            if self.eat("WHERE") { Some(self.expr()?) } else { None };
                        (sets, filter)
                    };
                upsert.push(Upsert { target, target_filter, sets, filter });
            }
            return Ok(Stmt::Insert {
                        table,
                        alias,
                        cols,
                        q,
                        default,
                        mode,
                        returning: self.returning()?,
                        upsert,
                    })
        }
        if self.eat("UPDATE") {
            let mode =
                if self.eat("OR") {
                    self.ident()?.to_ascii_uppercase()
                } else { "DEFAULT".into() };
            let table = self.table_name()?;
            let alias = self.alias()?;
            let indexed=self.index_clause()?;
            self.expect("SET")?;
            let sets = self.sets()?;
            let from =
                if self.eat("FROM") { self.sources()? } else { vec![] };
            let filter =
                if self.eat("WHERE") { Some(self.expr()?) } else { None };
            return Ok(Stmt::Update {
                        indexed,
                        table,
                        alias,
                        from,
                        sets,
                        filter,
                        mode,
                        returning: self.returning()?,
                    })
        }
        if self.eat("DELETE") {
            self.expect("FROM")?;
            let table = self.table_name()?;
            let alias = self.alias()?;
            let indexed=self.index_clause()?;
            let filter =
                if self.eat("WHERE") { Some(self.expr()?) } else { None };
            return Ok(Stmt::Delete {
                        indexed,
                        table,
                        alias,
                        filter,
                        returning: self.returning()?,
                    })
        }
        if self.eat("BEGIN") {
            self.eat("DEFERRED");
            self.eat("IMMEDIATE");
            self.eat("EXCLUSIVE");
            self.eat("TRANSACTION");
            return Ok(Stmt::Begin)
        }
        if self.eat("COMMIT") || self.eat("END") {
            self.eat("TRANSACTION");
            return Ok(Stmt::Commit)
        }
        if self.eat("ROLLBACK") {
            self.eat("TRANSACTION");
            let n =
                if self.eat("TO") {
                    self.eat("SAVEPOINT");
                    Some(self.ident()?)
                } else { None };
            return Ok(Stmt::Rollback(n))
        }
        if self.eat("SAVEPOINT") { return Ok(Stmt::Savepoint(self.ident()?)) }
        if self.eat("RELEASE") {
            self.eat("SAVEPOINT");
            return Ok(Stmt::Release(self.ident()?))
        }
        if self.eat("PRAGMA") {
            let n = self.name()?;
            let v =
                if self.eat("=") {
                    Some(self.expr()?)
                } else if self.eat("(") {
                    let e = self.expr()?;
                    self.expect(")")?;
                    Some(e)
                } else { None };
            return Ok(Stmt::Pragma(n, v))
        }
        if self.eat("ALTER") {
            self.expect("TABLE")?;
            let t = self.name()?;
            let a =
                if self.eat("RENAME") {
                    if self.eat("TO") {
                        Alter::Rename(self.ident()?)
                    } else {
                        self.eat("COLUMN");
                        let old = self.ident()?;
                        self.expect("TO")?;
                        Alter::RenameCol(old, self.ident()?)
                    }
                } else if self.eat("ADD") {
                    self.eat("COLUMN");
                    let start =
                        self.ts.get(self.p).ok_or("incomplete column definition")?.start;
                    let mut checks = vec![];
                    let mut foreign = vec![];
                    let c = self.column(&mut checks, &mut foreign)?;
                    let raw =
                        self.sql[start..self.ts[self.p - 1].end].to_string();
                    Alter::Add(c, checks, foreign, raw)
                } else if self.eat("ALTER") {
                    self.eat("COLUMN");
                    let column = self.ident()?;
                    let enable =
                        if self.eat("SET") {
                            true
                        } else { self.expect("DROP")?; false };
                    self.expect("NOT")?;
                    self.expect("NULL")?;
                    let policy =
                        if enable { self.conflict()? } else { "ABORT".into() };
                    Alter::NotNull(column, enable, policy)
                } else {
                    self.expect("DROP")?;
                    self.eat("COLUMN");
                    Alter::Drop(self.ident()?)
                };
            return Ok(Stmt::Alter(t, a))
        }
        if self.eat("VACUUM") {
            let schema =
                if self.p == self.ts.len() || self.at(";") || self.at("INTO")
                    {
                    None
                } else { Some(self.ident()?) };
            let into =
                if self.eat("INTO") { Some(self.expr()?) } else { None };
            return Ok(Stmt::Vacuum(schema, into))
        }
        if self.at("ANALYZE") || self.at("REINDEX") {
            let analyze = self.eat("ANALYZE");
            if !analyze { self.expect("REINDEX")?; }
            let target =
                if self.p == self.ts.len() || self.at(";") {
                    None
                } else { Some(self.name()?) };
            return Ok(if analyze {
                        Stmt::Analyze(target)
                    } else { Stmt::Reindex(target) })
        }
        Err(format!("near \"{}\": syntax error",self.peek()))
    }
    pub fn parse(sql: &'a str) -> Res<Stmt> {
        let mut p = Self::new(sql)?;
        let mut nesting = 0i64;
        let mut unary_run = 0;
        for t in &p.ts {
            if t.k == 0 && t.s == "(" {
                nesting += 1
            } else if t.k == 0 && t.s == ")" { nesting -= 1 }
            if t.k == 0 &&
                    ["-", "+", "~",
                                "NOT"].contains(&t.s.to_ascii_uppercase().as_str()) {
                unary_run += 1
            } else { unary_run = 0 }
            if nesting > 500 || unary_run > 500 {
                return Err("parser stack overflow".into())
            }
        }
        let mut s = p.statement()?;
        if p.ts.first().map_or(false, |t| t.s.eq_ignore_ascii_case("CREATE"))
                &&
                p.ts.get(1).map_or(false,
                    |t|
                        t.s.eq_ignore_ascii_case("TEMP") ||
                            t.s.eq_ignore_ascii_case("TEMPORARY")) {
            s = Stmt::Temp(Box::new(s))
        }
        p.eat(";");
        if p.p < p.ts.len() {
            return Err(format!("near \"{}\": syntax error",p.peek()))
        }
        Ok(s)
    }
}
