# sqlite-agent implementation state

Build: `cargo build --release --offline --bin sqlite-agent` (currently warning-free).
Test: `python3 tests/<suite>.py`; ten independent suites currently pass. Tests invoke only our Rust executable and documentation-derived expectations, never a reference engine/parser.

## Architecture
- `syntax.rs`: SQL tokenizer, Pratt expressions, SELECT/DDL/DML/transaction parser and serializable AST.
- `value.rs`: NULL/integer/real/text/blob, affinity, comparison, casts and JSON cell encoding.
- `engine.rs`: relational evaluation, constraints, triggers, snapshots/savepoints, schema and file connection management.
- `funcs.rs`: scalar/math/date/JSON functions, JSON/series table functions and pattern matching.
- `main.rs`: persistent JSON-lines interface; stdout is responses only, stderr diagnostics.

## Integrated behavior
SELECT expressions, aliases, DISTINCT, ordering/limits, joins (including outer/natural/USING), groups, aggregates including FILTER/argument ORDER BY, correlated and scalar subqueries, row comparisons, ordinary/recursive CTEs, compounds. Window functions: ranking, offsets, ntile, value functions and aggregate windows; partitions/order/named windows, ROWS/GROUPS/RANGE frames and exclusions.

Tables/views/indexes/triggers; INSERT/UPDATE/DELETE, RETURNING, UPSERT, UPDATE FROM, WITH before DML. Rowid/integer-PK/autoincrement, affinity, NULL semantics, column collations, generated/strict/without-rowid tables, unique/check/not-null/FK constraints, constraint conflict policies, foreign-key delete/update actions and deferred validation. BEFORE/AFTER triggers, RAISE, INSTEAD OF view triggers. ALTER rename/add/drop with common dependent schema rewrites. Temporary objects excluded from persisted state. Schema and common PRAGMAs, autoindex metadata, EXPLAIN QUERY PLAN (scan-oriented). Plain EXPLAIN bytecode intentionally errors: there is no VDBE implementation.

BEGIN/COMMIT/ROLLBACK, nested savepoints, statement rollback and FAIL/ROLLBACK/IGNORE/REPLACE paths. Persistent snapshots sync to a unique temporary file then atomic rename. OS writer locks prevent concurrent writers; readers use committed files/snapshots. Stale transaction writes reject rather than lose updates. Uncommitted data survives only in process memory and rolls back on close/crash. All files confined to /work; symlink escape checks and lockfile symlink rejection. Real values serialize as strings so infinities survive reopen.

## Known limitations / next work
- Persistence is an internal JSON snapshot, **not SQLite binary file format**. No B-tree, physical index optimizer, native rollback journal, or WAL implementation. Isolation is closest to snapshot/WAL behavior; lock/PRAGMA modes are not full SQLite implementations.
- ATTACH/DETACH not yet supported; parser mostly discards schema qualifiers. Temp/main name shadowing incomplete. TEMP state works for unique object names.
- SQL edge semantics remain incomplete: comprehensive binding, aggregate DISTINCT collations, column lineage in all compound/CTE cases, some trigger/foreign-key corner cases, generated expression restrictions, exact schema SQL rewriting, table joins in parentheses, all ORDER BY resolution rules.
- Date/strftime modifiers incomplete; JSON uses serde maps (object key order/duplicate labels differs), JSONB/JSON5 and subtype propagation only partially supported. Window chaining/frame validation and grouped windows have edge cases.
- Index metadata is approximate (DESC and without-rowid auxiliary metadata), `integrity_check`/some pragmas are partial. Virtual extensions beyond JSON and series are absent.
- Source is dense because rustfmt is not installed; cargo fmt must not be fetched from the internet.

Next useful directions: improve foreign-key parent validity/drop semantics; safe iterative LIKE matching; more introspection correctness; transaction/constraint edge cases; more durable file-format work if time permits. Keep the integrated executable passing while extending it. Continue until controller stops the period.
