"""Build offline and run documentation-derived tests against our own engine."""
from pathlib import Path
import subprocess
import sys
root=Path('/work')
subprocess.run(['cargo','build','--release','--offline','--bin','sqlite-agent'],cwd=root,check=True)
for suite in sorted((root/'tests').glob('*.py')):
    if suite.name != 'run_all.py':
        subprocess.run([sys.executable,str(suite)],cwd=root,check=True)
print('All regression suites passed.')
