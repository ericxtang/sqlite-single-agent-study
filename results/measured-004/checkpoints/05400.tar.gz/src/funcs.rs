use crate::value::*;use crate::syntax::Res;use std::cmp::Ordering;use std::time::{
    SystemTime, UNIX_EPOCH,
};
use std::sync::atomic::{AtomicU64, Ordering as AO};
fn rng() -> u64 {
    static SEED: AtomicU64 = AtomicU64::new(0);
    let mut s = SEED.load(AO::Relaxed);
    if s == 0 {
        s =
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos()
                as u64
    }
    let mut x = s;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    SEED.store(x, AO::Relaxed);
    x
}
pub fn scalar(n: &str, a: &[V]) -> Res<V> {
    let first = a.first().cloned().unwrap_or(V::Null);
    let get = |i: usize| a.get(i).cloned().unwrap_or(V::Null);
    let min =
        match n {
            "random" | "pi" | "char" | "json_array" | "json_object" | "date" |
                "time" | "datetime" | "julianday" | "unixepoch" => 0,
            "replace" | "substr" | "substring" | "instr" | "nullif" | "pow" |
                "power" | "mod" | "atan2" | "like" | "glob" => 2,
            _ => 1,
        };
    if a.len() < min {
        return Err(format!("wrong number of arguments to function {}()",n))
    }
    match n {
        "typeof" => Ok(V::Text(first.kind().into())),
        "length" | "octet_length" =>
            Ok(if first.null() {
                    V::Null
                } else {
                    V::Int(match &first {
                                V::Blob(b) => b.len(),
                                _ => {
                                    let s = first.text();
                                    if n == "octet_length" {
                                        s.len()
                                    } else {
                                        s.split('\0').next().unwrap_or("").chars().count()
                                    }
                                }
                            } as i64)
                }),
        "lower" | "upper" =>
            Ok(if first.null() {
                    V::Null
                } else {
                    V::Text(if n == "lower" {
                            first.text().to_ascii_lowercase()
                        } else { first.text().to_ascii_uppercase() })
                }),
        "abs" =>
            Ok(match if matches!(first,V::Text(_)|V::Blob(_)) {
                        real(first.f64())
                    } else { first.numeric() } {
                    V::Null => V::Null,
                    V::Int(i) =>
                        V::Int(i.checked_abs().ok_or("integer overflow")?),
                    v => real(v.f64().abs()),
                }),
        "round" => {
            if a.iter().any(V::null) { return Ok(V::Null) }
            let digits = get(1).i64().clamp(0, 30) as i32;
            let scale = 10f64.powi(digits);
            Ok(real((first.f64() * scale).round() / scale))
        }
        "sign" => {
            let v = first.apply('N');
            Ok(match v {
                    V::Int(i) => V::Int(i.signum()),
                    V::Real(f) =>
                        V::Int(if f == 0.0 { 0 } else if f < 0.0 { -1 } else { 1 }),
                    _ => V::Null,
                })
        }
        "quote"|"unistr_quote"=>Ok(V::Text(sql_quote(&first,n=="unistr_quote"))),
        "unistr"=>{if first.null(){Ok(V::Null)}else{Ok(V::Text(unistr(&first.text())?))}},
        "hex" =>
            Ok(V::Text(hex(&match first {
                                V::Blob(b) => b,
                                _ => first.text().into_bytes(),
                            }))),
        "unhex" => {
            if first.null() { return Ok(V::Null) }
            let ignore = get(1).text();
            let s =
                first.text().chars().filter(|c|
                            c.is_ascii_hexdigit() ||
                                !ignore.contains(*c)).collect::<String>();
            if s.len() % 2 != 0 || !s.is_ascii() { return Ok(V::Null) }
            let mut out = vec![];
            for i in (0..s.len()).step_by(2) {
                if let Ok(b) = u8::from_str_radix(&s[i..i + 2], 16) {
                    out.push(b)
                } else { return Ok(V::Null) }
            }
            Ok(V::Blob(out))
        }
        "unicode" =>
            Ok(if first.null() {
                    V::Null
                } else {
                    first.text().chars().next().map(|c|
                                V::Int(c as i64)).unwrap_or(V::Null)
                }),
        "char" =>
            Ok(V::Text(a.iter().map(|x|
                                char::from_u32(x.i64() as
                                            u32).unwrap_or('\u{fffd}')).collect())),
        "trim" | "ltrim" | "rtrim" => {
            if a.iter().any(V::null) { return Ok(V::Null) }
            let s = first.text();
            let chars = if a.len() > 1 { get(1).text() } else { " ".into() };
            let f = |c| chars.contains(c);
            Ok(V::Text(match n {
                            "ltrim" => s.trim_start_matches(f),
                            "rtrim" => s.trim_end_matches(f),
                            _ => s.trim_matches(f),
                        }.into()))
        }
        "replace" => {
            if a.len() != 3 {
                return Err("wrong number of arguments to function replace()".into())
            }
            if a.iter().any(V::null) { return Ok(V::Null) }
            let x = first.text();
            let y = get(1).text();
            Ok(V::Text(if y.is_empty() {
                        x
                    } else { x.replace(&y, &get(2).text()) }))
        }
        "substr" | "substring" => {
            if a.iter().any(V::null) { return Ok(V::Null) }
            let blob = matches!(first,V::Blob(_));
            let units =
                match &first {
                    V::Blob(b) =>
                        b.iter().map(|x| *x as u32).collect::<Vec<_>>(),
                    _ => first.text().chars().map(|c| c as u32).collect(),
                };
            let len = units.len() as i64;
            let start = get(1).i64();
            let mut from =
                if start > 0 {
                    start - 1
                } else if start < 0 { len.saturating_add(start) } else { 0 };
            let count = if a.len() > 2 { get(2).i64() } else { i64::MAX / 2 };
            let mut count = count;
            if start == 0 && count > 0 { count -= 1 }
            if count < 0 {
                from = from.saturating_add(count);
                count = count.saturating_neg()
            }
            let to = from.saturating_add(count).clamp(0, len);
            from = from.clamp(0, len);
            let slice = &units[from as usize..to.max(from) as usize];
            Ok(if blob {
                    V::Blob(slice.iter().map(|c| *c as u8).collect())
                } else {
                    V::Text(slice.iter().filter_map(|c|
                                    char::from_u32(*c)).collect())
                })
        }
        "instr" => {
            let b = get(1);
            if first.null() || b.null() { return Ok(V::Null) }
            if let (V::Blob(a), V::Blob(b)) = (&first, &b) {
                let i =
                    if b.is_empty() {
                        Some(0)
                    } else { a.windows(b.len()).position(|w| w == b) };
                Ok(V::Int(i.map(|i| i as i64 + 1).unwrap_or(0)))
            } else {
                let s = first.text();
                Ok(V::Int(s.find(&b.text()).map(|i|
                                    s[..i].chars().count() as i64 + 1).unwrap_or(0)))
            }
        }
        "concat" =>
            Ok(V::Text(a.iter().filter(|v|
                                        !v.null()).map(V::text).collect::<Vec<_>>().join(""))),
        "concat_ws" =>
            Ok(if first.null() {
                    V::Null
                } else {
                    V::Text(a[1..].iter().filter(|v|
                                            !v.null()).map(V::text).collect::<Vec<_>>().join(&first.text()))
                }),
        "nullif" =>
            Ok(if cmp(&first, &get(1), "BINARY") == Ordering::Equal {
                    V::Null
                } else { first }),
        "min" | "max" => {
            if a.iter().any(V::null) { return Ok(V::Null) }
            let mut best = first;
            for v in &a[1..] {
                let c = cmp(v, &best, "BINARY");
                if if n == "min" {
                        c == Ordering::Less
                    } else { c == Ordering::Greater } {
                    best = v.clone()
                }
            }
            Ok(best)
        }
        "likely" | "unlikely" | "likelihood" => Ok(first),
        "random" => Ok(V::Int((rng() as i64).max(i64::MIN + 1))),
        "zeroblob" | "randomblob" => {
            let count =
                first.i64().max(if n == "randomblob" { 1 } else { 0 });
            if count > 100_000_000 {
                return Err("string or blob too big".into())
            }
            Ok(V::Blob((0..count).map(|_|
                                if n == "zeroblob" { 0 } else { rng() as u8 }).collect()))
        }
        "like" | "glob" => {
            if a.iter().any(V::null) { return Ok(V::Null) }
            let esc =
                if a.len() > 2 { get(2).text().chars().next() } else { None };
            Ok(V::Int(pattern(&first.text(), &get(1).text(), esc, n == "glob",
                            n == "glob") as i64))
        }
        "printf" | "format" => Ok(format_sql(a)),
        "sqlite_compileoption_used" => Ok(V::Int(0)),
        "sqlite_compileoption_get" => Ok(V::Null),
        "pi" => Ok(V::Real(std::f64::consts::PI)),
        "sqrt" | "sin" | "cos" | "tan" | "asin" | "acos" | "atan" | "sinh" |
            "cosh" | "tanh" | "asinh" | "acosh" | "atanh" | "exp" | "ln" |
            "log" | "log10" | "log2" | "ceil" | "ceiling" | "floor" | "trunc"
            | "degrees" | "radians" | "pow" | "power" | "mod" | "atan2" => {
            if a.iter().any(|v|
                        v.null() || matches!(v.apply('N'),V::Text(_)|V::Blob(_))) {
                return Ok(V::Null)
            }
            let x = first.f64();
            let y = get(1).f64();
            Ok(real(match n {
                        "sqrt" => x.sqrt(),
                        "sin" => x.sin(),
                        "cos" => x.cos(),
                        "tan" => x.tan(),
                        "asin" => x.asin(),
                        "acos" => x.acos(),
                        "atan" => x.atan(),
                        "sinh" => x.sinh(),
                        "cosh" => x.cosh(),
                        "tanh" => x.tanh(),
                        "asinh" => x.asinh(),
                        "acosh" => x.acosh(),
                        "atanh" => x.atanh(),
                        "exp" => x.exp(),
                        "ln" => x.ln(),
                        "log" => if a.len() == 2 { y.log(x) } else { x.log10() },
                        "log10" => x.log10(),
                        "log2" => x.log2(),
                        "ceil" | "ceiling" => x.ceil(),
                        "floor" => x.floor(),
                        "trunc" => x.trunc(),
                        "degrees" => x.to_degrees(),
                        "radians" => x.to_radians(),
                        "pow" | "power" => x.powf(y),
                        "mod" => x % y,
                        _ => x.atan2(y),
                    }))
        }
        "date" | "time" | "datetime" | "julianday" | "unixepoch" | "strftime"
            | "timediff" => date_func(n, a),
        n if n.starts_with("json") => json_func(n, a),
        _ => Err(format!("no such function: {}",n)),
    }
}
fn hex(b: &[u8]) -> String { b.iter().map(|v| format!("{:02X}",v)).collect() }
pub fn pattern(p: &str, s: &str, escape: Option<char>, glob: bool,
    sensitive: bool) -> bool {
    #[derive(Clone)]
    enum Part { Star, One, Lit(char), Class(Vec<(char, char)>, bool), }
    let chars =
        p.split('\0').next().unwrap_or("").chars().collect::<Vec<_>>();
    let mut parts = vec![];
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if Some(c) == escape {
            i += 1;
            if i >= chars.len() { return false }
            parts.push(Part::Lit(chars[i]));
        } else if c == if glob { '*' } else { '%' } {
            if !matches!(parts.last(),Some(Part::Star)) {
                parts.push(Part::Star)
            }
        } else if c == if glob { '?' } else { '_' } {
            parts.push(Part::One)
        } else if glob && c == '[' {
            i += 1;
            let neg = chars.get(i) == Some(&'^');
            if neg { i += 1 }
            let mut ranges = vec![];
            if chars.get(i) == Some(&']') { ranges.push((']', ']')); i += 1 }
            while i < chars.len() && chars[i] != ']' {
                if i + 2 < chars.len() && chars[i + 1] == '-' &&
                        chars[i + 2] != ']' {
                    ranges.push((chars[i], chars[i + 2]));
                    i += 3
                } else { ranges.push((chars[i], chars[i])); i += 1 }
            }
            if i >= chars.len() { return false }
            parts.push(Part::Class(ranges, neg));
        } else { parts.push(Part::Lit(c)) }
        i += 1
    }
    let mut prev = vec![false;parts.len()+1];
    prev[0] = true;
    for (i, p) in parts.iter().enumerate() {
        if matches!(p,Part::Star) { prev[i + 1] = prev[i] } else { break }
    }
    for c in s.split('\0').next().unwrap_or("").chars() {
        let mut next = vec![false;prev.len()];
        for (i, p) in parts.iter().enumerate() {
            next[i + 1] =
                match p {
                    Part::Star => next[i] || prev[i + 1],
                    Part::One => prev[i],
                    Part::Lit(v) =>
                        prev[i] &&
                            if sensitive {
                                *v == c
                            } else { v.eq_ignore_ascii_case(&c) },
                    Part::Class(ranges, neg) =>
                        prev[i] &&
                            (ranges.iter().any(|(a, b)| c >= *a && c <= *b) ^ *neg),
                }
        }
        prev = next
    }
    prev[parts.len()]
}
fn format_sql(a:&[V])->V{if a.is_empty()||a[0].null(){return V::Null}let f=a[0].text();let mut out=String::new();let mut it=f.chars().peekable();let mut arg=1;while let Some(c)=it.next(){if c!='%'{out.push(c);continue}if it.peek()==Some(&'%'){it.next();out.push('%');continue}let mut flags=String::new();while it.peek().map_or(false,|c|"-+ #!0,".contains(*c)){flags.push(it.next().unwrap())}let mut width=0usize;if it.peek()==Some(&'*'){it.next();let w=a.get(arg).map(V::i64).unwrap_or(0);arg+=1;if w<0{flags.push('-')}width=w.unsigned_abs().min(100000)as usize}else{while it.peek().map_or(false,|c|c.is_ascii_digit()){width=(width*10+it.next().unwrap().to_digit(10).unwrap()as usize).min(100000)}}let mut precision=None;if it.peek()==Some(&'.'){it.next();let p=if it.peek()==Some(&'*'){it.next();let p=a.get(arg).map(V::i64).unwrap_or(0).unsigned_abs().min(1000)as usize;arg+=1;p}else{let mut p=0;while it.peek().map_or(false,|c|c.is_ascii_digit()){p=(p*10+it.next().unwrap().to_digit(10).unwrap()as usize).min(1000)}p};precision=Some(p)}while it.peek()==Some(&'l'){it.next();}let spec=it.next().unwrap_or('s');if spec=='n'{continue}let v=a.get(arg).cloned().unwrap_or(V::Null);arg+=1;let int=matches!(spec,'d'|'i'|'u'|'x'|'X'|'o'|'p');let float=matches!(spec,'f'|'e'|'E'|'g'|'G');let numeric=int||float;let text=v.text();let stringval=if let Some(p)=precision{if flags.contains('!'){text.chars().take(p).collect::<String>()}else{String::from_utf8_lossy(&text.as_bytes()[..p.min(text.len())]).into_owned()}}else{text};let mut rendered=match spec{'d'|'i'=>v.i64().to_string(),'u'=>(v.i64()as u64).to_string(),'x'=>format!("{:x}",v.i64()),'X'|'p'=>format!("{:X}",v.i64()),'o'=>format!("{:o}",v.i64()),'g'|'G'=>format_general(v.f64(),precision.unwrap_or(6).min(if flags.contains('!'){26}else{16}),flags.contains('!'),spec=='G'),'f'=>{let p=precision.unwrap_or(6).min(30);let x=v.f64();if !x.is_finite(){format_general(x,6,false,false)}else{let scale=10f64.powi(p as i32);let rounded=if (x.abs()*scale).is_finite(){(x.abs()*scale).round()/scale}else{x.abs()};let negative=x.is_sign_negative()&&!(flags.contains('#')&&!flags.contains('+')&&rounded==0.0);format!("{}{:.*}",if negative{"-"}else{""},p,rounded)}},'e'|'E'=>{let x=v.f64();if !x.is_finite(){format_general(x,6,false,false)}else{let s=format!("{:.*e}",precision.unwrap_or(6).min(30),x);let(m,e)=s.split_once('e').unwrap();let e=e.parse::<i32>().unwrap_or(0);format!("{}{}{}{:02}",m,if spec=='E'{"E"}else{"e"},if e<0{"-"}else{"+"},e.abs())}},'q'=>if v.null(){"(NULL)".into()}else{let s=if flags.contains('#'){escape_controls(&stringval)}else{stringval.clone()};s.replace('\'',"''")},'Q'=>if v.null(){"NULL".into()}else{sql_quote(&V::Text(stringval.clone()),flags.contains('#'))},'w'=>stringval.replace('"',"\"\""),'c'=>v.text().chars().next().map(|c|std::iter::repeat(c).take(precision.unwrap_or(1).max(1)).collect()).unwrap_or_default(),_=>stringval};if int{if let Some(p)=precision{let sign=rendered.starts_with('-');let digits=rendered.len()-sign as usize;if p>digits{rendered.insert_str(sign as usize,&"0".repeat(p-digits));}}if flags.contains('#')&&v.i64()!=0{match spec{'x'=>rendered="0x".to_string()+&rendered,'X'=>rendered="0X".to_string()+&rendered,'o'=>{if !rendered.starts_with('0'){rendered.insert(0,'0')}},_=>{}}}}if float&&flags.contains('0')&&v.f64().is_infinite(){rendered=if v.f64().is_sign_negative(){"-9.0e+999"}else{"9.0e+999"}.into()}if float&&(flags.contains('#')||flags.contains('!'))&&!rendered.contains('.')&&!rendered.contains("Inf"){let pos=rendered.find(['e','E']).unwrap_or(rendered.len());rendered.insert_str(pos,if flags.contains('!'){".0"}else{"."});}if numeric&&!rendered.starts_with('-')&&(float||spec=='d'||spec=='i'){if flags.contains('+'){rendered.insert(0,'+')}else if flags.contains(' '){rendered.insert(0,' ')}}if numeric&&flags.contains(','){let start=if rendered.starts_with(['-','+',' ']){1}else{0};let end=rendered.find(['.','e','E']).unwrap_or(rendered.len());if rendered[start..end].chars().all(|c|c.is_ascii_digit()){let mut pos=end.saturating_sub(3);while pos>start{rendered.insert(pos,',');if pos<3{break}pos-=3;}}}let len=if flags.contains('!')&&!numeric{rendered.chars().count()}else{rendered.len()};if width>len{let zeros=flags.contains('0')&&numeric&&!flags.contains('-');let padding=if zeros{"0"}else{" "}.repeat(width-len);if flags.contains('-'){rendered.push_str(&padding)}else if zeros&&rendered.starts_with(['-','+',' ']){rendered.insert_str(1,&padding)}else if zeros&&(rendered.starts_with("0x")||rendered.starts_with("0X")){rendered.insert_str(2,&padding)}else{rendered=padding+&rendered}}out.push_str(&rendered)}V::Text(out)}
pub fn to_json(v: &V) -> serde_json::Value {
    match v {
        V::Null => serde_json::Value::Null,
        V::Int(i) => serde_json::json!(i),
        V::Real(f) => serde_json::json!(f),
        V::Text(s) => serde_json::Value::String(s.clone()),
        V::Blob(_) => serde_json::Value::Null,
    }
}
fn from_json(v: &serde_json::Value) -> V {
    match v {
        serde_json::Value::Null => V::Null,
        serde_json::Value::Bool(b) => V::Int(*b as i64),
        serde_json::Value::Number(n) =>
            if let Some(i) = n.as_i64() {
                V::Int(i)
            } else {
                real(n.as_f64().unwrap_or_else(||
                            n.to_string().parse::<f64>().unwrap_or(0.0)))
            },
        serde_json::Value::String(s) => V::Text(s.clone()),
        _ => V::Text(v.to_string()),
    }
}
fn json_path<'a>(v: &'a serde_json::Value, p: &str)
    -> Res<Option<&'a serde_json::Value>> {
    if !p.starts_with('$') { return Err(format!("bad JSON path: {}",p)) }
    let mut v = v;
    let mut rest = &p[1..];
    while !rest.is_empty() {
        if rest.starts_with('.') {
            rest = &rest[1..];
            let key;
            if rest.starts_with('"') {
                rest = &rest[1..];
                let end = rest.find('"').ok_or("bad JSON path")?;
                key = &rest[..end];
                rest = &rest[end + 1..]
            } else {
                let end = rest.find(['.', '[']).unwrap_or(rest.len());
                key = &rest[..end];
                rest = &rest[end..]
            }
            v = match v.get(key) { Some(x) => x, None => return Ok(None), }
        } else if rest.starts_with('[') {
            let end = rest.find(']').ok_or("bad JSON path")?;
            let raw = &rest[1..end];
            let len = v.as_array().map_or(0, |a| a.len());
            let i =
                if let Some(n) = raw.strip_prefix("#-") {
                    len as i64 - n.parse::<i64>().map_err(|_| "bad JSON path")?
                } else { raw.parse::<i64>().map_err(|_| "bad JSON path")? };
            v =
                match if i < 0 { None } else { v.get(i as usize) } {
                    Some(x) => x,
                    None => return Ok(None),
                };
            rest = &rest[end + 1..]
        } else { return Err("bad JSON path".into()) }
    }
    Ok(Some(v))
}
pub fn json_extract_op(x: &V, y: &V, json: bool) -> Res<V> {
    if x.null() || y.null() { return Ok(V::Null) }
    let (v, _) = parse_json(&x.text())?;
    let raw = y.text();
    let path =
        if raw.starts_with('$') {
            raw
        } else if let V::Int(i) = y {
            if *i < 0 { format!("$[#{}]",i) } else { format!("$[{}]",i) }
        } else { format!("$.{}",raw) };
    Ok(match json_path(&v, &path)? {
            None => V::Null,
            Some(v) =>
                if json { V::Text(v.to_string()) } else { from_json(v) },
        })
}
fn json_func(n: &str, a: &[V]) -> Res<V> {
    if n == "json_array" {
        if a.iter().any(|v| matches!(v,V::Blob(_))) {
            return Err("JSON cannot hold BLOB values".into())
        }
        return Ok(V::Text(serde_json::Value::Array(a.iter().map(to_json).collect()).to_string()))
    }
    if n == "json_object" {
        if a.len() % 2 != 0 {
            return Err("json_object() requires an even number of arguments".into())
        }
        let mut m = serde_json::Map::new();
        for pair in a.chunks(2) {
            if !matches!(pair[0],V::Text(_)) {
                return Err("json_object() labels must be TEXT".into())
            }
            m.insert(pair[0].text(), to_json(&pair[1]));
        }
        return Ok(V::Text(serde_json::Value::Object(m).to_string()))
    }
    if n == "json_quote" { return Ok(V::Text(to_json(&a[0]).to_string())) }
    if a.is_empty() || a[0].null() { return Ok(V::Null) }
    if n == "json_valid" {
        if a.get(1).map_or(false, V::null) { return Ok(V::Null) }
        let flags = a.get(1).map(V::i64).unwrap_or(1);
        if !(1..=15).contains(&flags) {
            return Err("FLAGS parameter to json_valid() must be between 1 and 15".into())
        }
        let strict =
            serde_json::from_str::<serde_json::Value>(&a[0].text()).is_ok();
        let extended = parse_json(&a[0].text()).is_ok();
        return Ok(V::Int(((flags & 1 != 0 && strict) ||
                                (flags & 2 != 0 && extended)) as i64))
    }
    let (v, normalized) =
        match parse_json(&a[0].text()) {
            Ok(v) => v,
            Err(_) => {
                return if n == "json_error_position" {
                        Ok(V::Int(1))
                    } else { Err("malformed JSON".into()) }
            }
        };
    match n {
        "json" => Ok(V::Text(normalized)),
        "json_valid" => Ok(V::Int(1)),
        "json_error_position" => Ok(V::Int(0)),
        "json_extract" => {
            if a.len() < 2 { return Ok(V::Null) }
            let mut out = vec![];
            for p in &a[1..] {
                if p.null() {
                    out.push(serde_json::Value::Null)
                } else {
                    out.push(json_path(&v,
                                        &p.text())?.cloned().unwrap_or(serde_json::Value::Null))
                }
            }
            if out.len() == 1 {
                Ok(from_json(&out[0]))
            } else { Ok(V::Text(serde_json::Value::Array(out).to_string())) }
        }
        "json_type" | "json_array_length" => {
            let v =
                if a.len() > 1 {
                    if a[1].null() { return Ok(V::Null) }
                    match json_path(&v, &a[1].text())? {
                        Some(v) => v,
                        None => return Ok(V::Null),
                    }
                } else { &v };
            if n == "json_array_length" {
                return Ok(V::Int(v.as_array().map_or(0, |a| a.len()) as i64))
            }
            Ok(V::Text(match v {
                            serde_json::Value::Null => "null",
                            serde_json::Value::Bool(true) => "true",
                            serde_json::Value::Bool(false) => "false",
                            serde_json::Value::String(_) => "text",
                            serde_json::Value::Array(_) => "array",
                            serde_json::Value::Object(_) => "object",
                            serde_json::Value::Number(n) =>
                                if n.to_string().contains(['.', 'e', 'E']) {
                                    "real"
                                } else { "integer" },
                        }.into()))
        }
        "json_pretty" =>
            Ok(V::Text(serde_json::to_string_pretty(&v).unwrap_or_default())),
        _ => Err(format!("no such function: {}",n)),
    }
}
fn civil_days(y: i64, m: i64, d: i64) -> i64 {
    let y = y - if m <= 2 { 1 } else { 0 };
    let era = y.div_euclid(400);
    let yoe = y - era * 400;
    let mp = m + if m > 2 { -3 } else { 9 };
    let doy = (153 * mp + 2) / 5 + d - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe - 719468
}
fn from_days(z: i64) -> (i64, i64, i64) {
    let z = z + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = mp + if mp < 10 { 3 } else { -9 };
    (y + if m <= 2 { 1 } else { 0 }, m, d)
}
fn now() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs_f64()
}
pub fn date_current(n: &str) -> Res<V> {
    date_func(match n.to_ascii_uppercase().as_str() {
            "CURRENT_DATE" => "date",
            "CURRENT_TIME" => "time",
            _ => "datetime",
        }, &[])
}
fn parse_date(v: &V) -> Option<f64> {
    if v.null() { return None }
    if matches!(v,V::Int(_)|V::Real(_)) {
        return Some((v.f64() - 2440587.5) * 86400.0)
    }
    let s = v.text();
    let s = s.trim();
    if s.eq_ignore_ascii_case("now") { return Some(now()) }
    if let Ok(n) = s.parse::<f64>() { return Some((n - 2440587.5) * 86400.0) }
    let mut rest = s;
    let mut secs;
    if s.len() >= 10 && s.as_bytes().get(4) == Some(&b'-') &&
            s.as_bytes().get(7) == Some(&b'-') {
        let y = s[..4].parse().ok()?;
        let m = s[5..7].parse().ok()?;
        let d = s[8..10].parse().ok()?;
        if !(1..=12).contains(&m) || !(1..=31).contains(&d) { return None }
        secs = civil_days(y, m, d) as f64 * 86400.0;
        rest = s[10..].trim_start_matches([' ', 'T']);
    } else { secs = civil_days(2000, 1, 1) as f64 * 86400.0 }
    if !rest.is_empty() {
        let h: f64 = rest.get(..2)?.parse().ok()?;
        if rest.as_bytes().get(2) != Some(&b':') { return None }
        let m: f64 = rest.get(3..5)?.parse().ok()?;
        rest = &rest[5..];
        let mut sec = 0.0;
        if rest.starts_with(':') {
            rest = &rest[1..];
            let end =
                rest.find(|c: char|
                            !c.is_ascii_digit() && c != '.').unwrap_or(rest.len());
            sec = rest[..end].parse().ok()?;
            rest = &rest[end..]
        }
        if h > 24.0 || m >= 60.0 || sec >= 60.0 { return None }
        secs += h * 3600.0 + m * 60.0 + sec;
        rest = rest.trim();
        if rest.starts_with('+') || rest.starts_with('-') {
            let sign = if rest.starts_with('+') { 1.0 } else { -1.0 };
            let hh: f64 = rest.get(1..3)?.parse().ok()?;
            let mm: f64 = rest.get(4..6)?.parse().ok()?;
            secs -= sign * (hh * 3600.0 + mm * 60.0)
        } else if !rest.is_empty() && rest != "Z" { return None }
    }
    Some(secs)
}
fn date_func(n: &str, a: &[V]) -> Res<V> {
    let (format, args) =
        if n == "strftime" {
            if a.is_empty() { return Ok(V::Null) }
            (Some(a[0].text()), &a[1..])
        } else { (None, a) };
    if n == "timediff" { return time_difference(args) }
    let subsec_first =
        args.first().map_or(false,
            |a|
                ["subsec",
                            "subsecond"].contains(&a.text().to_ascii_lowercase().as_str()));
    let mut t =
        if args.is_empty() || subsec_first {
            now()
        } else {
            match parse_date(&args[0]) {
                Some(t) => t,
                None => return Ok(V::Null),
            }
        };
    let mut subsec = subsec_first;
    let mut overflow_days = 0i64;
    for modifier in args.iter().skip(1) {
        let m = modifier.text().to_ascii_lowercase();
        if m == "unixepoch" {
            t = args[0].f64()
        } else if m == "auto" {
            let x = args[0].f64();
            if x < 0.0 || x > 5373484.499999 { t = x }
        } else if m == "subsec" || m == "subsecond" {
            subsec = true
        } else if m == "start of day" {
            t = t.div_euclid(86400.0) * 86400.0
        } else if m == "start of month" || m == "start of year" {
            let (y, mo, _) = from_days((t / 86400.0).floor() as i64);
            t =
                civil_days(y, if m == "start of year" { 1 } else { mo }, 1) as
                        f64 * 86400.0
        } else if let Some(w) = m.strip_prefix("weekday ") {
            let w = w.parse::<i64>().unwrap_or(-1);
            if !(0..=6).contains(&w) { return Ok(V::Null) }
            let curr = ((t / 86400.0).floor() as i64 + 4).rem_euclid(7);
            t += (w - curr).rem_euclid(7) as f64 * 86400.0
        } else if m == "floor" {
            t -= overflow_days as f64 * 86400.0;
            overflow_days = 0
        } else if m == "ceiling" {
            overflow_days = 0
        } else if ["utc", "localtime"].contains(&m.as_str())
            {} else if (m.starts_with('+') || m.starts_with('-')) &&
                        m.len() >= 11 && m.as_bytes().get(5) == Some(&b'-') &&
                m.as_bytes().get(8) == Some(&b'-') {
            let sign = if m.starts_with('-') { -1 } else { 1 };
            let yr = m[1..5].parse::<i64>().unwrap_or(0);
            let mo = m[6..8].parse::<i64>().unwrap_or(0);
            let dd = m[9..11].parse::<i64>().unwrap_or(0);
            let (y, month, day) = from_days((t / 86400.0).floor() as i64);
            let months = y * 12 + month - 1 + sign * (yr * 12 + mo);
            t =
                civil_days(months.div_euclid(12), months.rem_euclid(12) + 1,
                                    day) as f64 * 86400.0 + t.rem_euclid(86400.0) +
                    sign as f64 * dd as f64 * 86400.0;
            if m.len() > 11 {
                let clock = m[11..].trim().split(':').collect::<Vec<_>>();
                if clock.len() != 3 { return Ok(V::Null) }
                let seconds =
                    clock[0].parse::<f64>().unwrap_or(0.0) * 3600.0 +
                            clock[1].parse::<f64>().unwrap_or(0.0) * 60.0 +
                        clock[2].parse::<f64>().unwrap_or(0.0);
                t += sign as f64 * seconds
            }
        } else if (m.starts_with('+') || m.starts_with('-')) &&
                m.contains(':') {
            let sign = if m.starts_with('-') { -1.0 } else { 1.0 };
            let clock = m[1..].split(':').collect::<Vec<_>>();
            if clock.len() < 2 || clock.len() > 3 { return Ok(V::Null) }
            let seconds =
                clock[0].parse::<f64>().unwrap_or(0.0) * 3600.0 +
                        clock[1].parse::<f64>().unwrap_or(0.0) * 60.0 +
                    clock.get(2).and_then(|s|
                                s.parse::<f64>().ok()).unwrap_or(0.0);
            t += sign * seconds
        } else {
            let parts = m.split_whitespace().collect::<Vec<_>>();
            if parts.len() != 2 { return Ok(V::Null) }
            let x =
                match parts[0].parse::<f64>() {
                    Ok(x) => x,
                    Err(_) => return Ok(V::Null),
                };
            match parts[1].trim_end_matches('s') {
                "day" => t += x * 86400.0,
                "hour" => t += x * 3600.0,
                "minute" => t += x * 60.0,
                "second" => t += x,
                "month" | "year" => {
                    let days = (t / 86400.0).floor() as i64;
                    let (y, m, d) = from_days(days);
                    let month =
                        y * 12 + m - 1 +
                            if parts[1].starts_with("year") {
                                (x * 12.0) as i64
                            } else { x as i64 };
                    let ty = month.div_euclid(12);
                    let tm = month.rem_euclid(12) + 1;
                    let monthdays =
                        civil_days(ty + (tm == 12) as i64,
                                if tm == 12 { 1 } else { tm + 1 }, 1) -
                            civil_days(ty, tm, 1);
                    overflow_days = (d - monthdays).max(0);
                    t =
                        civil_days(ty, tm, d) as f64 * 86400.0 +
                            t.rem_euclid(86400.0)
                }
                _ => return Ok(V::Null),
            }
        }
    }
    let days = (t / 86400.0).floor() as i64;
    let (y, mo, d) = from_days(days);
    let daysec = t.rem_euclid(86400.0);
    let h = (daysec / 3600.0) as i64;
    let mi = (daysec / 60.0) as i64 % 60;
    let sec = daysec % 60.0;
    let date = format!("{:04}-{:02}-{:02}",y,mo,d);
    let time =
        if subsec {
            format!("{:02}:{:02}:{:06.3}",h,mi,sec)
        } else { format!("{:02}:{:02}:{:02}",h,mi,sec.floor()as i64) };
    match n {
        "date" => Ok(V::Text(date)),
        "time" => Ok(V::Text(time)),
        "datetime" => Ok(V::Text(format!("{} {}",date,time))),
        "julianday" => Ok(real(t / 86400.0 + 2440587.5)),
        "unixepoch" =>
            Ok(if subsec { real(t) } else { V::Int(t.floor() as i64) }),
        "strftime" => {
            let mut out = String::new();
            let fmt = format.unwrap();
            let mut it = fmt.chars();
            while let Some(c) = it.next() {
                if c != '%' { out.push(c); continue }
                let s =
                    match it.next() {
                        Some('%') => "%".into(),
                        Some('Y') => format!("{:04}",y),
                        Some('m') => format!("{:02}",mo),
                        Some('d') => format!("{:02}",d),
                        Some('e') => format!("{:2}",d),
                        Some('H') => format!("{:02}",h),
                        Some('M') => format!("{:02}",mi),
                        Some('S') => format!("{:02}",sec.floor()as i64),
                        Some('f') => format!("{:06.3}",sec),
                        Some('F') => date.clone(),
                        Some('T') => time.clone(),
                        Some('s') => (t.floor() as i64).to_string(),
                        Some('J') => (t / 86400.0 + 2440587.5).to_string(),
                        Some('w') => (days + 4).rem_euclid(7).to_string(),
                        Some('u') => ((days + 3).rem_euclid(7) + 1).to_string(),
                        Some('j') => format!("{:03}",days-civil_days(y,1,1)+1),
                        Some('k') => format!("{:2}",h),
                        Some('l') => format!("{:2}",(h+11)%12+1),
                        Some('W') =>
                            format!("{:02}",(days-civil_days(y,1,1)+7-(days+3).rem_euclid(7))/7),
                        Some('U') =>
                            format!("{:02}",(days-civil_days(y,1,1)+7-(days+4).rem_euclid(7))/7),
                        Some('V') => format!("{:02}",iso_week(days).1),
                        Some('G') => format!("{:04}",iso_week(days).0),
                        Some('g') =>
                            format!("{:02}",iso_week(days).0.rem_euclid(100)),
                        Some('R') => format!("{:02}:{:02}",h,mi),
                        Some('I') => format!("{:02}",(h+11)%12+1),
                        Some('p') => if h < 12 { "AM" } else { "PM" }.into(),
                        Some('P') => if h < 12 { "am" } else { "pm" }.into(),
                        _ => return Ok(V::Null),
                    };
                out.push_str(&s)
            }
            Ok(V::Text(out))
        }
        _ => Ok(V::Null),
    }
}
#[derive(Clone)]
enum PathPart { Key(String), Index(i64), Append, }
fn split_path(path: &str) -> Res<Vec<PathPart>> {
    if !path.starts_with('$') { return Err("bad JSON path".into()) }
    let mut s = &path[1..];
    let mut out = vec![];
    while !s.is_empty() {
        if s.starts_with('.') {
            s = &s[1..];
            let k;
            if s.starts_with('"') {
                s = &s[1..];
                let i = s.find('"').ok_or("bad JSON path")?;
                k = s[..i].to_string();
                s = &s[i + 1..]
            } else {
                let i = s.find(['.', '[']).unwrap_or(s.len());
                k = s[..i].to_string();
                s = &s[i..]
            }
            out.push(PathPart::Key(k))
        } else if s.starts_with('[') {
            let i = s.find(']').ok_or("bad JSON path")?;
            let raw = &s[1..i];
            out.push(if raw == "#" {
                    PathPart::Append
                } else if let Some(n) = raw.strip_prefix("#-") {
                    PathPart::Index(-n.parse::<i64>().map_err(|_|
                                        "bad JSON path")?)
                } else {
                    PathPart::Index(raw.parse().map_err(|_| "bad JSON path")?)
                });
            s = &s[i + 1..]
        } else { return Err("bad JSON path".into()) }
    }
    Ok(out)
}
fn modify_json(v: &mut serde_json::Value, path: &[PathPart],
    new: Option<serde_json::Value>, mode: &str) -> bool {
    use serde_json::Value as J;
    if path.is_empty() {
        if let Some(new) = new {
            if mode != "json_insert" { *v = new; return true }
        } else { *v = J::Null; return true }
        return false
    }
    let last = path.len() == 1;
    match &path[0] {
        PathPart::Key(k) => {
            if let J::Object(m) = v {
                if last {
                    if new.is_none() { return m.remove(k).is_some() }
                    let exists = m.contains_key(k);
                    if (exists && mode == "json_insert") ||
                            (!exists && mode == "json_replace") {
                        return false
                    }
                    m.insert(k.clone(), new.unwrap());
                    true
                } else {
                    if !m.contains_key(k) {
                        if mode == "json_replace" || new.is_none() { return false }
                        m.insert(k.clone(),
                            if matches!(path[1],PathPart::Key(_)) {
                                J::Object(serde_json::Map::new())
                            } else { J::Array(vec![]) });
                    }
                    modify_json(m.get_mut(k).unwrap(), &path[1..], new, mode)
                }
            } else { false }
        }
        part => {
            if let J::Array(a) = v {
                let i =
                    match part {
                        PathPart::Append => a.len() as i64,
                        PathPart::Index(i) =>
                            if *i < 0 { a.len() as i64 + i } else { *i },
                        _ => 0,
                    };
                if i < 0 || i > a.len() as i64 { return false }
                let i = i as usize;
                if last {
                    if let Some(new) = new {
                        if i == a.len() {
                            if mode == "json_replace" {
                                false
                            } else { a.push(new); true }
                        } else if mode == "json_insert" {
                            false
                        } else { a[i] = new; true }
                    } else if i < a.len() { a.remove(i); true } else { false }
                } else {
                    if i == a.len() {
                        if mode == "json_replace" || new.is_none() { return false }
                        a.push(if matches!(path[1],PathPart::Key(_)) {
                                J::Object(serde_json::Map::new())
                            } else { J::Array(vec![]) })
                    }
                    modify_json(&mut a[i], &path[1..], new, mode)
                }
            } else { false }
        }
    }
}
fn merge_patch(target: &mut serde_json::Value, patch: &serde_json::Value) {
    use serde_json::Value as J;
    if let J::Object(m) = patch {
        if !target.is_object() { *target = J::Object(serde_json::Map::new()) }
        let t = target.as_object_mut().unwrap();
        for (k, v) in m {
            if v.is_null() {
                t.remove(k);
            } else {
                let dest = t.entry(k).or_insert(J::Null);
                merge_patch(dest, v)
            }
        }
    } else { *target = patch.clone() }
}
pub fn json_typed_func(n: &str, a: &[V], typed: &[bool]) -> Res<V> {
    let val =
        |i: usize| -> Res<serde_json::Value>
            {
                if matches!(a[i],V::Blob(_)) {
                    return Err("JSON cannot hold BLOB values".into())
                }
                if typed.get(i) == Some(&true) {
                    if let Ok(v) = serde_json::from_str(&a[i].text()) {
                        return Ok(v)
                    }
                }
                Ok(to_json(&a[i]))
            };
    let raw =
        |i: usize| -> Res<String>
            {
                if let V::Real(f) = a[i] {
                    if f.is_infinite() {
                        return Ok(if f.is_sign_negative() {
                                        "-9e999"
                                    } else { "9e999" }.into())
                    }
                }
                if matches!(a[i],V::Blob(_)) {
                    return Err("JSON cannot hold BLOB values".into())
                }
                if typed.get(i) == Some(&true) &&
                        serde_json::from_str::<serde_json::Value>(&a[i].text()).is_ok()
                    {
                    Ok(minify_json(&a[i].text()))
                } else { Ok(to_json(&a[i]).to_string()) }
            };
    match n {
        "json_array" => {
            let mut v = vec![];
            for i in 0..a.len() { v.push(raw(i)?) }
            Ok(V::Text(format!("[{}]",v.join(","))))
        }
        "json_object" => {
            if a.len() % 2 != 0 {
                return Err("json_object() requires an even number of arguments".into())
            }
            let mut pairs = vec![];
            for i in (0..a.len()).step_by(2) {
                if !matches!(a[i],V::Text(_)) {
                    return Err("json_object() labels must be TEXT".into())
                }
                pairs.push(format!("{}:{}",to_json(&a[i]),raw(i+1)?));
            }
            Ok(V::Text(format!("{{{}}}",pairs.join(","))))
        }
        "json_quote" => {
            if a.len() != 1 { return Err("wrong number of arguments".into()) }
            Ok(V::Text(raw(0)?))
        }
        "json_set" | "json_insert" | "json_replace" | "json_remove" |
            "json_patch" => {
            if a.is_empty() || a[0].null() { return Ok(V::Null) }
            let (mut v, _) = parse_json(&a[0].text())?;
            if n == "json_patch" {
                if a.len() != 2 {
                    return Err("wrong number of arguments".into())
                }
                if a[1].null() { return Ok(V::Null) }
                let (p, _) = parse_json(&a[1].text())?;
                merge_patch(&mut v, &p)
            } else if n == "json_remove" {
                for p in &a[1..] {
                    if p.null() { return Ok(V::Null) }
                    let path = split_path(&p.text())?;
                    if path.is_empty() { return Ok(V::Null) }
                    modify_json(&mut v, &path, None, n);
                }
            } else {
                if a.len() % 2 != 1 {
                    return Err("json_set/insert/replace needs an odd number of arguments".into())
                }
                for i in (1..a.len()).step_by(2) {
                    if a[i].null() { continue }
                    let path = split_path(&a[i].text())?;
                    modify_json(&mut v, &path, Some(val(i + 1)?), n);
                }
            }
            Ok(V::Text(v.to_string()))
        }
        _ => json_func(n, a),
    }
}
pub fn table_function(n: &str, a: &[V]) -> Res<(Vec<String>, Vec<Vec<V>>)> {
    if n == "generate_series" {
        if a.is_empty() {
            return Err("first argument to generate_series is missing".into())
        }
        let start = a[0].i64();
        let end = a.get(1).map(V::i64).unwrap_or(4294967295);
        let mut step = a.get(2).map(V::i64).unwrap_or(1);
        if step == 0 { step = 1 }
        let mut x = start;
        let mut rows = vec![];
        while if step > 0 { x <= end } else { x >= end } {
            rows.push(vec![V::Int(x),V::Int(start),V::Int(end),V::Int(step)]);
            if rows.len() > 100000 {
                return Err("series result too large".into())
            }
            x = match x.checked_add(step) { Some(x) => x, None => break, };
        }
        return Ok((vec!["value".into(),"start".into(),"stop".into(),"step".into()],
                    rows))
    }
    if n != "json_each" && n != "json_tree" {
        return Err(format!("no such table: {}",n))
    }
    let cols =
        ["key", "value", "type", "atom", "id", "parent", "fullkey", "path",
                            "json", "root"].iter().map(|n| n.to_string()).collect();
    if a.is_empty() || a[0].null() { return Ok((cols, vec![])) }
    let text = a[0].text();
    let (json, _) = parse_json(&text)?;
    let root = a.get(1).map(V::text).unwrap_or("$".into());
    let v =
        match json_path(&json, &root)? {
            Some(v) => v,
            None => return Ok((cols, vec![])),
        };
    let mut rows = vec![];
    let mut id = 0i64;
    fn emit(v: &serde_json::Value, k: V, path: &str, parent: Option<i64>,
        full: &str, recurse: bool, rows: &mut Vec<Vec<V>>, id: &mut i64,
        text: &str, root: &str) {
        use serde_json::Value as J;
        let mine = *id;
        *id += 1;
        let typ =
            match v {
                J::Null => "null",
                J::Bool(true) => "true",
                J::Bool(false) => "false",
                J::String(_) => "text",
                J::Number(n) =>
                    if n.to_string().contains(['.', 'e', 'E']) {
                        "real"
                    } else { "integer" },
                J::Array(_) => "array",
                J::Object(_) => "object",
            };
        let atom =
            if v.is_array() || v.is_object() {
                V::Null
            } else { from_json(v) };
        rows.push(vec![k,from_json(v),V::Text(typ.into()),atom,V::Int(mine),parent.map(V::Int).unwrap_or(V::Null),V::Text(full.into()),V::Text(path.into()),V::Text(text.into()),V::Text(root.into())]);
        if recurse {
            match v {
                J::Array(a) => {
                    for (i, v) in a.iter().enumerate() {
                        emit(v, V::Int(i as i64), full, Some(mine),
                            &format!("{}[{}]",full,i), true, rows, id, text, root)
                    }
                }
                J::Object(m) => {
                    for (k, v) in m {
                        emit(v, V::Text(k.clone()), full, Some(mine),
                            &format!("{}.{}",full,k), true, rows, id, text, root)
                    }
                }
                _ => {}
            }
        }
    }
    if n == "json_tree" {
        emit(v, V::Null, &root, None, &root, true, &mut rows, &mut id, &text,
            &root)
    } else {
        match v {
            serde_json::Value::Array(a) => {
                for (i, v) in a.iter().enumerate() {
                    emit(v, V::Int(i as i64), &root, None,
                        &format!("{}[{}]",root,i), false, &mut rows, &mut id, &text,
                        &root)
                }
            }
            serde_json::Value::Object(m) => {
                for (k, v) in m {
                    emit(v, V::Text(k.clone()), &root, None,
                        &format!("{}.{}",root,k), false, &mut rows, &mut id, &text,
                        &root)
                }
            }
            _ =>
                emit(v, V::Null, &root, None, &root, false, &mut rows,
                    &mut id, &text, &root),
        }
    }
    Ok((cols, rows))
}
pub fn check_arity(n: &str, k: usize) -> Res<()> {
    let (min, max) =
        match n {
            "random" | "pi" | "changes" | "total_changes" |
                "last_insert_rowid" | "sqlite_version" | "sqlite_source_id" |
                "row_number" | "rank" | "dense_rank" | "percent_rank" |
                "cume_dist" => (0, 0),
            "abs" | "sign" | "typeof" | "length" | "octet_length" | "lower" |
                "upper" | "hex" | "unicode" | "quote" | "unistr" | "unistr_quote" |
                "zeroblob" | "randomblob" | "likely" | "unlikely" | "sqrt" |
                "sin" | "cos" | "tan" | "asin" | "acos" | "atan" | "sinh" |
                "cosh" | "tanh" | "asinh" | "acosh" | "atanh" | "exp" | "ln" |
                "log10" | "log2" | "ceil" | "ceiling" | "floor" | "trunc" |
                "degrees" | "radians" | "sqlite_compileoption_get" |
                "sqlite_compileoption_used" | "sum" | "avg" | "total" |
                "count" | "json_group_array" | "ntile" | "first_value" |
                "last_value" | "json" | "json_quote" | "json_error_position"
                => (1, 1),
            "replace" => (3, 3),
            "nullif" | "ifnull" | "instr" | "likelihood" | "pow" | "power" |
                "mod" | "atan2" | "glob" | "string_agg" | "json_group_object"
                | "nth_value" | "timediff" | "json_patch" => (2, 2),
            "round" | "trim" | "ltrim" | "rtrim" | "unhex" | "log" |
                "group_concat" | "json_type" | "json_array_length" |
                "json_valid" | "json_pretty" => (1, 2),
            "substr" | "substring" | "like" => (2, 3),
            "lag" | "lead" => (1, 3),
            "coalesce" => (2, usize::MAX),
            "iif" | "if" => (2, usize::MAX),
            "min" | "max" | "concat" | "concat_ws" | "format" | "printf" |
                "strftime" | "json_extract" | "json_set" | "json_insert" |
                "json_replace" | "json_remove" => (1, usize::MAX),
            "char" | "json_array" | "json_object" | "date" | "time" |
                "datetime" | "julianday" | "unixepoch" => (0, usize::MAX),
            "raise" => (1, 2),
            _ => return Err(format!("no such function: {}",n)),
        };
    if k < min || k > max {
        Err(format!("wrong number of arguments to function {}()",n))
    } else { Ok(()) }
}

fn minify_json(s: &str) -> String {
    let mut out = String::new();
    let mut string = false;
    let mut escaped = false;
    for c in s.chars() {
        if string {
            out.push(c);
            if escaped {
                escaped = false
            } else if c == '\\' {
                escaped = true
            } else if c == '"' { string = false }
        } else if c == '"' {
            string = true;
            out.push(c)
        } else if !c.is_whitespace() { out.push(c) }
    }
    out
}

fn iso_week(days: i64) -> (i64, i64) {
    let thursday = days + 3 - (days + 3).rem_euclid(7);
    let y = from_days(thursday).0;
    (y, (thursday - civil_days(y, 1, 1)) / 7 + 1)
}
fn time_difference(args: &[V]) -> Res<V> {
    if args.len() != 2 {
        return Err("wrong number of arguments to function timediff()".into())
    }
    let a =
        match parse_date(&args[0]) {
            Some(t) => t,
            None => return Ok(V::Null),
        };
    let b =
        match parse_date(&args[1]) {
            Some(t) => t,
            None => return Ok(V::Null),
        };
    let (hi, lo, sign) = if a >= b { (a, b, '+') } else { (b, a, '-') };
    let (y1, m1, _) = from_days((hi / 86400.0).floor() as i64);
    let (y0, m0, d0) = from_days((lo / 86400.0).floor() as i64);
    let mut months = (y1 - y0) * 12 + m1 - m0;
    let pivot =
        loop {
            let month = y0 * 12 + m0 - 1 + months;
            let pivot =
                civil_days(month.div_euclid(12), month.rem_euclid(12) + 1, d0)
                            as f64 * 86400.0 + lo.rem_euclid(86400.0);
            if pivot <= hi || months <= 0 { break pivot }
            months -= 1
        };
    let diff = hi - pivot;
    let days = (diff / 86400.0).floor() as i64;
    let rest = diff.rem_euclid(86400.0);
    Ok(V::Text(format!("{}{:04}-{:02}-{:02} {:02}:{:02}:{:06.3}",sign,months/12,months%12,days,(rest/3600.0)as
                i64,(rest/60.0)as i64%60,rest%60.0)))
}
fn parse_json(s: &str) -> Res<(serde_json::Value, String)> {
    if let Ok(v) = serde_json::from_str(s) { return Ok((v, minify_json(s))) }
    let normalized = normalize_json5(s)?;
    let v = serde_json::from_str(&normalized).map_err(|_| "malformed JSON")?;
    Ok((v, minify_json(&normalized)))
}
fn normalize_json5(s: &str) -> Res<String> {
    let chars = s.chars().collect::<Vec<_>>();
    let mut out = String::new();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if c.is_whitespace() || c == '\u{feff}' {
            out.push(' ');
            i += 1;
            continue
        }
        if c == '/' && chars.get(i + 1) == Some(&'/') {
            i += 2;
            while i < chars.len() && chars[i] != '\n' && chars[i] != '\r' {
                i += 1
            }
            out.push(' ');
            continue
        }
        if c == '/' && chars.get(i + 1) == Some(&'*') {
            i += 2;
            while i + 1 < chars.len() &&
                    !(chars[i] == '*' && chars[i + 1] == '/') {
                i += 1
            }
            if i + 1 >= chars.len() { return Err("malformed JSON".into()) }
            i += 2;
            out.push(' ');
            continue
        }
        if c == '\'' || c == '"' {
            let quote = c;
            i += 1;
            let mut value = String::new();
            let mut closed = false;
            while i < chars.len() {
                let c = chars[i];
                i += 1;
                if c == quote { closed = true; break }
                if c == '\\' {
                    let e = *chars.get(i).ok_or("malformed JSON")?;
                    i += 1;
                    match e {
                        '\n' => {}
                        '\r' => { if chars.get(i) == Some(&'\n') { i += 1 } }
                        'x' => {
                            let mut n = 0;
                            for _ in 0..2 {
                                n =
                                    n * 16 +
                                        chars.get(i).and_then(|c|
                                                        c.to_digit(16)).ok_or("malformed JSON")?;
                                i += 1
                            }
                            value.push_str(&format!("\\u{:04x}",n));
                        }
                        'u' => {
                            value.push_str("\\u");
                            for _ in 0..4 {
                                let c = *chars.get(i).ok_or("malformed JSON")?;
                                if !c.is_ascii_hexdigit() {
                                    return Err("malformed JSON".into())
                                }
                                value.push(c);
                                i += 1
                            }
                        }
                        'v' => value.push_str("\\u000b"),
                        '0' => {
                            if chars.get(i).map_or(false, |c| c.is_ascii_digit()) {
                                return Err("malformed JSON".into())
                            }
                            value.push_str("\\u0000")
                        }
                        'b' | 'f' | 'n' | 'r' | 't' => {
                            value.push('\\');
                            value.push(e)
                        }
                        '\\' => value.push_str("\\\\"),
                        '"' => value.push_str("\\\""),
                        '\'' => value.push('\''),
                        _ => {
                            if e == '\u{2028}' || e == '\u{2029}'
                                {} else { value.push(e) }
                        }
                    }
                } else if c == '\n' || c == '\r' {
                    return Err("malformed JSON".into())
                } else if c == '"' {
                    value.push_str("\\\"")
                } else if c < '\u{20}' {
                    value.push_str(&format!("\\u{:04x}",c as u32))
                } else { value.push(c) }
            }
            if !closed { return Err("malformed JSON".into()) }
            out.push('"');
            out.push_str(&value);
            out.push('"');
            out.push(' ');
            continue
        }
        if ['{', '[', ':', ','].contains(&c) { out.push(c); i += 1; continue }
        if c == '}' || c == ']' {
            while out.ends_with(' ') { out.pop(); }
            if out.ends_with(',') {
                out.pop();
                let prev = out.trim_end().chars().last();
                if matches!(prev,Some('[')|Some('{')|Some(',')) {
                    return Err("malformed JSON".into())
                }
            }
            out.push(c);
            i += 1;
            continue
        }
        let start = i;
        while i < chars.len() && !chars[i].is_whitespace() &&
                !['{', '}', '[', ']', ':', ',', '/'].contains(&chars[i]) {
            i += 1
        }
        if i == start { return Err("malformed JSON".into()) }
        let token = chars[start..i].iter().collect::<String>();
        let mut j = i;
        loop {
            while j < chars.len() && chars[j].is_whitespace() { j += 1 }
            if chars.get(j) == Some(&'/') && chars.get(j + 1) == Some(&'*') {
                j += 2;
                while j + 1 < chars.len() &&
                        !(chars[j] == '*' && chars[j + 1] == '/') {
                    j += 1
                }
                j = (j + 2).min(chars.len());
            } else if chars.get(j) == Some(&'/') &&
                    chars.get(j + 1) == Some(&'/') {
                while j < chars.len() && chars[j] != '\n' { j += 1 }
            } else { break }
        }
        if chars.get(j) == Some(&':') {
            let first = token.chars().next().ok_or("malformed JSON")?;
            if !(first.is_ascii_alphabetic() || first == '_' || first == '$'
                                || first > '\u{7f}') ||
                    !token.chars().all(|c|
                                c.is_ascii_alphanumeric() || c == '_' || c == '$' ||
                                    c > '\u{7f}') {
                return Err("malformed JSON".into())
            }
            out.push_str(&serde_json::to_string(&token).map_err(|_|
                                "malformed JSON")?);
        } else {
            let lower = token.to_ascii_lowercase();
            let bare = lower.trim_start_matches(['+', '-']);
            if bare == "infinity" || bare == "inf" {
                if lower.starts_with('-') { out.push('-') }
                out.push_str("9e999")
            } else if ["nan", "qnan", "snan"].contains(&bare) {
                out.push_str("null")
            } else if ["true", "false", "null"].contains(&token.as_str()) {
                out.push_str(&token)
            } else {
                let sign = if token.starts_with('-') { "-" } else { "" };
                let number = token.trim_start_matches(['+', '-']);
                if number.starts_with("0x") || number.starts_with("0X") {
                    let n =
                        u128::from_str_radix(&number[2..],
                                    16).map_err(|_| "malformed JSON")?;
                    out.push_str(sign);
                    out.push_str(&n.to_string())
                } else {
                    let mut number =
                        token.strip_prefix('+').unwrap_or(&token).to_string();
                    if number.starts_with('.') {
                        number.insert(0, '0')
                    } else if number.starts_with("-.") { number.insert(1, '0') }
                    if number.ends_with('.') { number.push('0') }
                    if let Some(p) = number.find(['e', 'E']) {
                        if p > 0 && number.as_bytes()[p - 1] == b'.' {
                            number.insert(p, '0')
                        }
                    }
                    out.push_str(&number)
                }
            }
        }
        out.push(' ');
    }
    Ok(out)
}
fn unistr(s: &str) -> Res<String> {
    let c = s.chars().collect::<Vec<_>>();
    let mut i = 0;
    let mut out = String::new();
    while i < c.len() {
        let ch = c[i];
        i += 1;
        if ch != '\\' { out.push(ch); continue }
        let next = *c.get(i).ok_or("invalid Unicode escape")?;
        if next == '\\' { out.push('\\'); i += 1; continue }
        let len = match next { 'u' => {i += 1; 4}, 'U' => {i += 1; 8}, '+' => {i += 1; 6}, _ => 4 };
        let mut value = 0u32;
        for _ in 0..len {
            let d = c.get(i).and_then(|c| c.to_digit(16)).ok_or("invalid Unicode escape")?;
            value = value.checked_mul(16).and_then(|v| v.checked_add(d)).ok_or("invalid Unicode escape")?;
            i += 1;
        }
        out.push(char::from_u32(value).ok_or("invalid Unicode codepoint")?);
    }
    Ok(out)
}
fn escape_controls(s: &str) -> String {
    let mut out = String::new();
    for c in s.split('\0').next().unwrap_or("").chars() {
        if c == '\\' { out.push_str("\\\\") }
        else if c > '\0' && c < '\u{20}' { out.push_str(&format!("\\u{:04x}", c as u32)) }
        else { out.push(c) }
    }
    out
}
fn sql_quote(v: &V, unicode: bool) -> String {
    match v {
        V::Null => "NULL".into(),
        V::Blob(b) => format!("X'{}'", hex(b)),
        V::Text(s) => {
            let s = s.split('\0').next().unwrap_or("");
            let controls = unicode && s.chars().any(|c| c > '\0' && c < '\u{20}');
            let escaped = if controls { escape_controls(s) } else { s.into() };
            let quoted = format!("'{}'", escaped.replace('\'', "''"));
            if controls { format!("unistr({})", quoted) } else { quoted }
        },
        _ => v.text()
    }
}
