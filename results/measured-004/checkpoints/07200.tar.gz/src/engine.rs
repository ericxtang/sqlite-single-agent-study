use std::sync::Arc;use crate::syntax::*;use crate::value::*;use serde::{
    Serialize, Deserialize,
};
use std::collections::BTreeMap;
use std::cmp::Ordering;
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Row {
    pub id: i64,
    pub v: Vec<V>,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Table {
    #[serde(default)]
    pub temporary: bool,
    pub name: String,
    pub cols: Vec<Column>,
    pub unique: Vec<Vec<String>>,
    #[serde(default)]
    pub policies: Vec<(Vec<String>, String)>,
    pub checks: Vec<E>,
    pub foreign: Vec<Foreign>,
    pub without: bool,
    pub strict: bool,
    pub rows: Vec<Row>,
    pub seq: i64,
    pub sql: String,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Index {
    #[serde(default)]
    pub temporary: bool,
    #[serde(default="index_origin")]
    pub origin: String,
    pub name: String,
    pub table: String,
    pub unique: bool,
    pub expr: Vec<E>,
    #[serde(default)]
    pub desc: Vec<bool>,
    pub filter: Option<E>,
    pub sql: String,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct View {
    #[serde(default)]
    pub temporary: bool,
    pub name: String,
    pub cols: Vec<String>,
    pub q: Query,
    pub sql: String,
}
#[derive(Clone,Debug,Default,Serialize,Deserialize)]
pub struct Db {
    #[serde(default)] pub generation:u64,
    #[serde(default)]
    pub sequence_created: bool,
    #[serde(default)]
    pub sequences: Vec<Row>,
    #[serde(default)]
    pub triggers: BTreeMap<String, Trigger>,
    pub tables: BTreeMap<String, Table>,
    pub indexes: BTreeMap<String, Index>,
    pub views: BTreeMap<String, View>,
    pub user_version: i64,
    pub application_id: i64,
    pub schema_version: i64,
}
#[derive(Clone,Debug)]
pub struct Field {
    pub table: String,
    pub name: String,
    pub aff: char,
    pub coll: String,
    pub hidden: bool,
    pub using: bool,
}
#[derive(Clone,Debug,Default)]
pub struct Data {
    pub fields: Vec<Field>,
    pub rows: Vec<Vec<V>>,
}
#[derive(Clone,Debug,Default)]
pub struct ResultSet {
    pub items: Vec<Item>,
    pub coll_sources: Vec<bool>,
    pub affinities: Vec<(char, String)>,
    pub columns: Vec<String>,
    pub rows: Vec<Vec<V>>,
}
impl ResultSet {
    pub fn json(&self) -> serde_json::Value {
        serde_json::json!({"ok":true,"columns":self.columns,"rows":self.rows.iter().map(|r|r.iter().map(V::json).collect::<Vec<_>>()).collect::<Vec<_>>()})
    }
}
#[derive(Clone)]
pub struct Engine {
    pub snapshot_active: bool,
    pub attach_order: Vec<String>,
    pub attached: BTreeMap<String, Engine>,
    pub writer_lock: Option<std::sync::Arc<std::fs::File>>,
    pub trigger_ctx: Option<Ctx>,
    pub active_triggers: Vec<String>,
    pub db: Db,
    pub path: Option<std::path::PathBuf>,
    pub txn: Vec<(String, Db)>,
    pub changes: i64,
    pub total: i64,
    pub last: i64,
    pub foreign_keys: bool,
    pub pragmas: BTreeMap<String, V>,
}
#[derive(Clone,Default)]
pub struct WinCtx {
    pub rows: Arc<Vec<Vec<V>>>,
    pub groups: Arc<Vec<Vec<Vec<V>>>>,
    pub index: usize,
    pub named: Arc<BTreeMap<String, WinSpec>>,
}
#[derive(Clone,Default)]
pub struct Ctx {
    pub aliases: BTreeMap<String, E>,
    pub alias_group: Option<Vec<Vec<V>>>,
    pub binding: bool,
    pub win: Option<WinCtx>,
    pub fields: Vec<Field>,
    pub row: Vec<V>,
    pub outer: Option<Box<Ctx>>,
    pub ctes: BTreeMap<String, Arc<Data>>,
}
fn key(s: &str) -> String { s.to_ascii_lowercase() }
fn field(table: &str, name: &str, aff: char, coll: &str, hidden: bool)
    -> Field {
    Field {
        table: table.into(),
        name: name.into(),
        aff,
        coll: coll.into(),
        hidden,
        using: false,
    }
}
impl Engine {
    pub fn open(path: &str) -> Res<Self> {
        let path =
            if path == ":memory:" || path.is_empty() {
                None
            } else {
                let p = std::path::Path::new(path);
                let p =
                    if p.is_absolute() {
                        p.to_path_buf()
                    } else { std::path::Path::new("/work").join(p) };
                let mut clean = std::path::PathBuf::new();
                for part in p.components() {
                    match part {
                        std::path::Component::ParentDir => { clean.pop(); }
                        std::path::Component::CurDir => {}
                        _ => clean.push(part.as_os_str()),
                    }
                }
                if !clean.starts_with("/work") {
                    return Err("database path must be inside /work".into())
                }
                if let Some(parent) = clean.parent() {
                    let parent =
                        parent.canonicalize().map_err(|e| e.to_string())?;
                    if !parent.starts_with("/work") {
                        return Err("database path must be inside /work".into())
                    }
                }
                if clean.exists() {
                    let actual =
                        clean.canonicalize().map_err(|e| e.to_string())?;
                    if !actual.starts_with("/work") {
                        return Err("database path must be inside /work".into())
                    }
                }
                if clean.exists(){clean=clean.canonicalize().map_err(|e|e.to_string())?}
                else{let file=clean.file_name().ok_or("invalid database path")?.to_owned();clean=clean.parent().ok_or("invalid database path")?.canonicalize().map_err(|e|e.to_string())?.join(file)}
                Some(clean)
            };
        let db =
            if let Some(p) = &path {
                if p.exists() {
                    let b = std::fs::read(p).map_err(|e| e.to_string())?;
                    if b.is_empty() {
                        Db::default()
                    } else {
                        serde_json::from_slice(&b).map_err(|_|
                                    "file is not a database")?
                    }
                } else { Db::default() }
            } else { Db::default() };
        let mut e =
            Self {
                snapshot_active: false,
                attach_order: vec![],
                attached: BTreeMap::new(),
                writer_lock: None,
                trigger_ctx: None,
                active_triggers: vec![],
                db,
                path,
                txn: vec![],
                changes: 0,
                total: 0,
                last: 0,
                foreign_keys: false,
                pragmas: BTreeMap::new(),
            };
        if e.path.as_ref().map_or(false,
                |p|
                    !p.exists() || p.metadata().map_or(false, |m| m.len() == 0))
            {
            e.acquire_writer()?;
            if e.path.as_ref().is_some_and(|p|p.exists()&&p.metadata().is_ok_and(|m|m.len()>0)){e.refresh()?}else{e.persist()?}
            e.writer_lock=None;
        }
        Ok(e)
    }
    pub fn persist(&mut self)->Res<()>{
        if let Some(path)=&self.path{
            let mut db=persistent_db(&self.db);db.generation=db.generation.wrapping_add(1);
            let bytes=serde_json::to_vec(&db).map_err(|e|e.to_string())?;
            let mut prepared=vec![crate::storage::Prepared::new(path,&bytes)?];
            crate::storage::install_all(&mut prepared)?;
            self.db.generation=db.generation;
        }
        Ok(())
    }
    fn persist_transaction(&mut self)->Res<()>{
        let mut prepared=vec![];let mut generations=vec![];
        for (name,db) in std::iter::once((None,&*self)).chain(self.attached.iter().map(|(n,db)|(Some(n.clone()),db))){
            if db.writer_lock.is_none(){continue}
            if let Some(path)=&db.path{let mut value=persistent_db(&db.db);value.generation=value.generation.wrapping_add(1);
                let bytes=serde_json::to_vec(&value).map_err(|e|e.to_string())?;
                prepared.push(crate::storage::Prepared::new(path,&bytes)?);generations.push((name,value.generation));
            }
        }
        crate::storage::install_all(&mut prepared)?;
        for(name,generation)in generations{if let Some(name)=name{self.attached.get_mut(&name).unwrap().db.generation=generation}else{self.db.generation=generation}}
        Ok(())
    }
    fn finish_transaction(&mut self){
        self.txn.clear();self.writer_lock=None;self.snapshot_active=false;self.pragmas.insert("defer_foreign_keys".into(),V::Int(0));
        for db in self.attached.values_mut(){db.finish_transaction()}
    }
    fn writes_main(&self,s:&Stmt)->bool{
        if let Stmt::With(_,s)=s{return self.writes_main(s)}
        if let Some(target)=statement_target(s){
            if target.contains('.'){return false}
            if matches!(s,Stmt::Insert{..}|Stmt::Update{..}|Stmt::Delete{..}|Stmt::Drop(_,_,_)|Stmt::Alter(_,_))&&!self.db.tables.contains_key(&key(target))&&!self.db.views.contains_key(&key(target))&&!self.db.indexes.contains_key(&key(target))&&!self.db.triggers.contains_key(&key(target)){
                if self.attached.values().any(|db|db.db.tables.contains_key(&key(target))||db.db.views.contains_key(&key(target))||db.db.indexes.contains_key(&key(target))||db.db.triggers.contains_key(&key(target))){return false}
            }
        }
        statement_writes(s)
    }
    pub fn execute(&mut self, sql: &str) -> Res<ResultSet> {
        let _date_clock=crate::funcs::statement_clock();
        if lex(sql)?.is_empty() { return Ok(ResultSet::default()) }
        let stmt = Parser::parse(sql)?;
        self.execute_stmt(stmt, sql)
    }
    fn execute_stmt(&mut self, stmt: Stmt, sql: &str) -> Res<ResultSet> {
        let write = statement_writes(&stmt);
        let main_write=self.writes_main(&stmt);
        if write &&
                self.pragmas.get("query_only").map_or(false, |v| v.i64() != 0)
            {
            return Err("attempt to write a readonly database".into())
        }
        let dml = dml_kind(&stmt);
        let immediate =
            matches!(stmt,Stmt::Begin) &&
                lex(sql)?.iter().any(|t|
                        t.s.eq_ignore_ascii_case("IMMEDIATE") ||
                            t.s.eq_ignore_ascii_case("EXCLUSIVE"));
        let old_lock = self.writer_lock.is_some();
        if statement_touches(&stmt) { self.start_snapshot()?; }
        if main_write || immediate { self.acquire_writer()?; }
        if self.txn.is_empty() {
            if let Err(e) = self.refresh() {
                if !old_lock { self.writer_lock = None }
                return Err(e)
            }
        }
        let before = self.db.clone();
        let attached_before = self.attached.clone();
        let order_before = self.attach_order.clone();
        let changes = self.changes;
        let total = self.total;
        let last = self.last;
        let mode =
            match &stmt {
                Stmt::Insert { mode, .. } | Stmt::Update { mode, .. } =>
                    mode.clone(),
                _ => "ABORT".into(),
            };
        let out = self.run(stmt, sql);
        match out {
            Ok(mut r) => {
                if r.columns.is_empty() &&
                        self.pragmas.get("count_changes").map_or(false,
                            |v| v.i64() != 0) {
                    if let Some(kind) = dml {
                        r.columns.push(kind.into());
                        r.rows.push(vec![V::Int(self.changes)])
                    }
                }
                if self.txn.is_empty() {
                    if main_write && self.writer_lock.is_some() {
                        if let Err(e) = self.persist() {
                            self.db = before;
                            self.changes=changes;self.total=total;self.last=last;
                            self.attached=attached_before;self.attach_order=order_before;
                            self.writer_lock = None;
                            return Err(e)
                        }
                    }
                    self.writer_lock = None;
                    self.snapshot_active = false;
                }
                Ok(r)
            }
            Err(e) => {
                let constraint =
                    e.contains("constraint failed") ||
                            e.starts_with("!ROLLBACK!") || e.starts_with("!FAIL!");
                let rollback =
                    (mode == "ROLLBACK" && constraint) ||
                        e.starts_with("!ROLLBACK!");
                let fail =
                    (mode == "FAIL" && constraint && !e.contains("FOREIGN KEY"))
                        || e.starts_with("!FAIL!");
                if rollback && !self.txn.is_empty() {
                    self.db = self.txn[0].1.clone();
                    self.txn.clear();self.pragmas.insert("defer_foreign_keys".into(),V::Int(0));
                } else if !fail { self.db = before; }
                if !fail {
                    self.attached = attached_before;
                    self.attach_order = order_before;
                    if rollback {
                        for db in self.attached.values_mut() {
                            if !db.txn.is_empty() { let _ = db.execute("ROLLBACK"); }
                        }
                    }
                    self.changes = changes;
                    self.total = total;
                    self.last = last;
                }
                if self.txn.is_empty() {
                    if fail && self.writer_lock.is_some() { self.persist()?; }
                    self.writer_lock = None;
                    self.snapshot_active = false;
                } else if !old_lock && !write { self.writer_lock = None; }
                Err(e.trim_start_matches("!ROLLBACK!").trim_start_matches("!FAIL!").to_string())
            }
        }
    }
    fn start_snapshot(&mut self) -> Res<()> {
        if !self.txn.is_empty() && !self.snapshot_active {
            self.refresh()?;
            for (_, snapshot) in &mut self.txn {
                *snapshot = self.db.clone();
            }
            self.snapshot_active = true;
        }
        for db in self.attached.values_mut() { db.start_snapshot()?; }
        Ok(())
    }
    fn disk_db(&self) -> Res<Option<Db>> {
        if let Some(p) = &self.path {
            let b = std::fs::read(p).map_err(|e| e.to_string())?;
            if b.is_empty() { return Ok(Some(Db::default())) }
            Ok(Some(serde_json::from_slice(&b).map_err(|_|
                                "file is not a database")?))
        } else { Ok(None) }
    }
    fn refresh(&mut self) -> Res<()> {
        if let Some(mut db) = self.disk_db()? {
            for (k, t) in self.db.tables.iter().filter(|(_, t)| t.temporary) {
                db.tables.insert(k.clone(), t.clone());
            }
            for (k, t) in self.db.indexes.iter().filter(|(_, t)| t.temporary)
                {
                db.indexes.insert(k.clone(), t.clone());
            }
            for (k, t) in self.db.views.iter().filter(|(_, t)| t.temporary) {
                db.views.insert(k.clone(), t.clone());
            }
            for (k, t) in self.db.triggers.iter().filter(|(_, t)| t.temporary)
                {
                db.triggers.insert(k.clone(), t.clone());
            }
            self.db = db
        }
        Ok(())
    }
    fn acquire_writer(&mut self) -> Res<()> {
        if self.writer_lock.is_some() || self.path.is_none() { return Ok(()) }
        let p = self.path.as_ref().unwrap();
        let lockpath =
            p.with_file_name(format!("{}.agent-lock",p.file_name().unwrap().to_string_lossy()));
        if lockpath.symlink_metadata().map_or(false,
                |m| m.file_type().is_symlink()) {
            return Err("invalid database lock file".into())
        }
        let file =
            std::fs::OpenOptions::new().read(true).write(true).create(true).open(lockpath).map_err(|e|
                        e.to_string())?;
        let timeout=std::time::Duration::from_millis(self.pragmas.get("busy_timeout").map(V::i64).unwrap_or(0).clamp(0,i32::MAX as i64)as u64);
        let start=std::time::Instant::now();
        loop{match file.try_lock(){Ok(())=>break,Err(std::fs::TryLockError::WouldBlock)=>{let elapsed=start.elapsed();if elapsed>=timeout{return Err("database is locked".into())}std::thread::sleep(std::time::Duration::from_millis(5).min(timeout-elapsed));},Err(std::fs::TryLockError::Error(e))=>return Err(e.to_string())}}
        if !self.txn.is_empty() {
            if let Some(disk) = self.disk_db()? {
                let current =
                    serde_json::to_vec(&disk).map_err(|e| e.to_string())?;
                let snapshot =
                    serde_json::to_vec(&persistent_db(&self.txn[0].1)).map_err(|e|
                                e.to_string())?;
                if current != snapshot {
                    return Err("database is locked: transaction snapshot is stale".into())
                }
            }
        }
        self.writer_lock = Some(std::sync::Arc::new(file));
        Ok(())
    }
    fn colindex(ctx: &Ctx, n: &[String]) -> Res<Option<usize>> {
        let name = n.last().unwrap();
        let qual =
            if n.len() > 2 {
                Some(format!("{}.{}",n[n.len()-3],n[n.len()-2]))
            } else if n.len() > 1 {
                Some(n[n.len() - 2].clone())
            } else { None };
        let mut found = None;
        for (i, f) in ctx.fields.iter().enumerate() {
            if f.name.eq_ignore_ascii_case(name) &&
                    qual.as_ref().map_or(true, |q| table_qualifies(&f.table, q))
                {
                if found.is_some() && !f.hidden {
                    return Err(format!("ambiguous column name: {}",n.join(".")))
                }
                if found.is_none() { found = Some(i) }
            }
        }
        Ok(found)
    }
    fn metadata(&self, e: &E, ctx: &Ctx) -> (char, String) {
        match e {
            E::Bound(_, a, c, _) => (*a, c.clone()),
            E::Quoted(n) => self.metadata(&E::Col(vec![n.clone()]), ctx),
            E::Col(n) => {
                if let Ok(Some(i)) = Self::colindex(ctx, n) {
                    let f = &ctx.fields[i];
                    (f.aff, f.coll.clone())
                } else if n.len() == 1 &&
                        ctx.aliases.contains_key(&key(&n[0])) {
                    self.metadata(&ctx.aliases[&key(&n[0])],
                        &Ctx { aliases: BTreeMap::new(), ..ctx.clone() })
                } else if let Some(o) = &ctx.outer {
                    self.metadata(e, o)
                } else { ('B', "BINARY".into()) }
            }
            E::Cast(e, t) => (affinity(t), self.metadata(e, ctx).1),
            E::Unary(op, e) if op == "+" => ('B', self.metadata(e, ctx).1),
            E::Collate(x, c) => (self.metadata(x, ctx).0, c.clone()),
            _ => ('B', "BINARY".into()),
        }
    }
    fn collation_source(&self, e: &E, ctx: &Ctx) -> bool {
        match e {
            E::Bound(_, _, _, b) => *b,
            E::Col(n) => {
                Self::colindex(ctx, n).ok().flatten().is_some() ||
                        ctx.outer.as_ref().map_or(false,
                            |o| self.collation_source(e, o)) ||
                    n.len() == 1 &&
                        ctx.aliases.get(&key(&n[0])).map_or(false,
                            |e|
                                self.collation_source(e,
                                    &Ctx { aliases: BTreeMap::new(), ..ctx.clone() }))
            }
            E::Quoted(n) =>
                self.collation_source(&E::Col(vec![n.clone()]), ctx),
            E::Cast(e, _) => self.collation_source(e, ctx),
            E::Unary(op, e) if op == "+" => self.collation_source(e, ctx),
            _ => false,
        }
    }
    fn is_row_expr(&self, e: &E, ctx: &Ctx) -> Res<bool> {
        match e {
            E::Tuple(_) => Ok(true),
            E::Sub(q) => {
                let mut bind = ctx.clone();
                bind.binding = true;
                Ok(self.query(q, &bind, 1)?.columns.len() > 1)
            }
            _ => Ok(false),
        }
    }
    fn freeze_expr(&self, e: &E, ctx: &Ctx, g: Option<&[Vec<V>]>,
        depth: usize) -> Res<E> {
        if self.is_row_expr(e, ctx)? {
            let values = self.row_values(e, ctx, g, depth + 1)?;
            let mut out = vec![];
            for (e, v) in values {
                let (a, c) = self.metadata(&e, ctx);
                let bound = E::Bound(v, a, c, self.collation_source(&e, ctx));
                out.push(if let Some(c) = explicit_coll(&e) {
                        E::Collate(Box::new(bound), c.into())
                    } else { bound })
            }
            Ok(E::Tuple(out))
        } else {
            let v = self.eval(e, ctx, g, depth + 1)?;
            let (a, c) = self.metadata(e, ctx);
            let bound = E::Bound(v, a, c, self.collation_source(e, ctx));
            Ok(if let Some(c) = explicit_coll(e) {
                    E::Collate(Box::new(bound), c.into())
                } else { bound })
        }
    }
    fn compare(&self, a: &E, b: &E, av: &V, bv: &V, ctx: &Ctx) -> Ordering {
        let (aa, ac) = self.metadata(a, ctx);
        let (ba, bc) = self.metadata(b, ctx);
        let mut x = av.clone();
        let mut y = bv.clone();
        if "INR".contains(aa) && !"INR".contains(ba) {
            y = y.apply('N')
        } else if "INR".contains(ba) && !"INR".contains(aa) {
            x = x.apply('N')
        } else if aa == 'T' && ba == 'B' {
            y = y.apply('T')
        } else if ba == 'T' && aa == 'B' { x = x.apply('T') }
        let coll =
            explicit_coll(a).or_else(||
                        explicit_coll(b)).unwrap_or_else(||
                    if self.collation_source(a, ctx) {
                        &ac
                    } else if self.collation_source(b, ctx) {
                        &bc
                    } else { &ac });
        cmp(&x, &y, coll)
    }
    pub fn eval(&self, e: &E, ctx: &Ctx, group: Option<&[Vec<V>]>,
        depth: usize) -> Res<V> {
        if depth > 100 {
            return Err("expression or query is too complex".into())
        }
        let ev = |x: &E| self.eval(x, ctx, group, depth + 1);
        match e {
            E::Bound(v, _, _, _) => Ok(v.clone()),
            E::Quoted(n) => {
                let col = E::Col(vec![n.clone()]);
                match self.eval(&col, ctx, group, depth + 1) {
                    Ok(v) => Ok(v),
                    Err(e) if e.starts_with("no such column") =>
                        Ok(V::Text(n.clone())),
                    Err(e) => Err(e),
                }
            }
            E::SubCol(q, i) => {
                let r = self.query(q, ctx, depth + 1)?;
                if *i >= r.columns.len() {
                    return Err("subquery column count mismatch".into())
                }
                Ok(r.rows.first().map(|r| r[*i].clone()).unwrap_or(V::Null))
            }
            E::OrderedCall(call, orders) => {
                let rows = group.ok_or("misuse of aggregate function")?;
                let mut decorated = vec![];
                for row in rows {
                    let mut c = ctx.clone();
                    c.row = row.clone();
                    let keys =
                        orders.iter().map(|o|
                                        self.eval(&o.e, &c, None,
                                            depth + 1)).collect::<Res<Vec<_>>>()?;
                    decorated.push((row.clone(), keys))
                }
                decorated.sort_by(|a, b|
                        {
                            for (i, o) in orders.iter().enumerate() {
                                let mut c =
                                    cmp(&a.1[i], &b.1[i], &self.metadata(&o.e, ctx).1);
                                if o.desc { c = c.reverse() }
                                if c != Ordering::Equal { return c }
                            }
                            Ordering::Equal
                        });
                let rows =
                    decorated.into_iter().map(|x| x.0).collect::<Vec<_>>();
                self.eval(call, ctx, Some(&rows), depth + 1)
            }
            E::Window(call, w) => self.window_eval(call, w, ctx, depth + 1),
            E::Val(v) => Ok(v.clone()),
            E::Col(n) => {
                if let Some(i) = Self::colindex(ctx, n)? {
                    Ok(ctx.row.get(i).cloned().unwrap_or(V::Null))
                } else if n.len() == 1 &&
                        ctx.aliases.contains_key(&key(&n[0])) {
                    let e = &ctx.aliases[&key(&n[0])];
                    let c = Ctx { aliases: BTreeMap::new(), ..ctx.clone() };
                    self.eval(e, &c, ctx.alias_group.as_deref().or(group),
                        depth + 1)
                } else if let Some(o) = &ctx.outer {
                    self.eval(e, o, group, depth + 1)
                } else if n.len() == 1 && n[0].eq_ignore_ascii_case("TRUE") {
                    Ok(V::Int(1))
                } else if n.len() == 1 && n[0].eq_ignore_ascii_case("FALSE") {
                    Ok(V::Int(0))
                } else if n.len() == 1 &&
                        ["CURRENT_DATE", "CURRENT_TIME",
                                    "CURRENT_TIMESTAMP"].contains(&n[0].to_ascii_uppercase().as_str())
                    {
                    crate::funcs::date_current(&n[0])
                } else { Err(format!("no such column: {}",n.join("."))) }
            }
            E::Star(_) => Err("misuse of *".into()),
            E::Cast(e, t) => Ok(ev(e)?.cast(t)),
            E::Collate(e, _) => ev(e),
            E::Unary(op, e) => {
                let v = ev(e)?;
                Ok(match op.as_str() {
                        "ISNULL" => V::Int(v.null() as i64),
                        "NOTNULL" => V::Int(!v.null() as i64),
                        "NOT" => boolean(v.truth().map(|b| !b)),
                        "+" => v,
                        "-" =>
                            match v.numeric() {
                                V::Null => V::Null,
                                V::Int(i) =>
                                    i.checked_neg().map(V::Int).unwrap_or(V::Real(-(i as f64))),
                                v => real(-v.f64()),
                            },
                        "~" => if v.null() { V::Null } else { V::Int(!v.i64()) },
                        _ => V::Null,
                    })
            }
            E::Bin(op, a, b) => {
                if self.is_row_expr(a, ctx)? || self.is_row_expr(b, ctx)? {
                    return self.row_compare(op, a, b, ctx, group, depth + 1)
                }
                let x = ev(a)?;
                let y = ev(b)?;
                if op == "AND" {
                    return Ok(boolean(match (x.truth(), y.truth()) {
                                    (Some(false), _) | (_, Some(false)) => Some(false),
                                    (Some(true), Some(true)) => Some(true),
                                    _ => None,
                                }))
                }
                if op == "OR" {
                    return Ok(boolean(match (x.truth(), y.truth()) {
                                    (Some(true), _) | (_, Some(true)) => Some(true),
                                    (Some(false), Some(false)) => Some(false),
                                    _ => None,
                                }))
                }
                if ["=", "==", "!=", "<>", "<", ">", "<=", ">=", "IS",
                                "IS NOT"].contains(&op.as_str()) {
                    let is = op.starts_with("IS");
                    if x.null() || y.null() {
                        return Ok(if is {
                                    V::Int(((x.null() && y.null()) ^ (op == "IS NOT")) as i64)
                                } else { V::Null })
                    }
                    if is {
                        if let E::Col(n) = b.as_ref() {
                            if n.len() == 1 &&
                                    (n[0].eq_ignore_ascii_case("TRUE") ||
                                            n[0].eq_ignore_ascii_case("FALSE")) {
                                return Ok(V::Int(((x.truth() ==
                                                                Some(n[0].eq_ignore_ascii_case("TRUE"))) ^ (op == "IS NOT"))
                                                as i64))
                            }
                        }
                    }
                    let c = self.compare(a, b, &x, &y, ctx);
                    return Ok(V::Int(match op.as_str() {
                                        "=" | "==" | "IS" => c == Ordering::Equal,
                                        "!=" | "<>" | "IS NOT" => c != Ordering::Equal,
                                        "<" => c == Ordering::Less,
                                        ">" => c == Ordering::Greater,
                                        "<=" => c != Ordering::Greater,
                                        _ => c != Ordering::Less,
                                    } as i64))
                }
                if x.null() || y.null() { return Ok(V::Null) }
                if op == "||" { return Ok(V::Text(x.text() + &y.text())) }
                if op == "->" || op == "->>" {
                    return crate::funcs::json_extract_op(&x, &y, op == "->")
                }
                let xn = x.numeric();
                let yn = y.numeric();
                let int =
                    if let (V::Int(i), V::Int(j)) = (&xn, &yn) {
                        Some((*i, *j))
                    } else { None };
                Ok(match op.as_str() {
                        "+" =>
                            int.and_then(|(i, j)|
                                            i.checked_add(j)).map(V::Int).unwrap_or_else(||
                                    real(xn.f64() + yn.f64())),
                        "-" =>
                            int.and_then(|(i, j)|
                                            i.checked_sub(j)).map(V::Int).unwrap_or_else(||
                                    real(xn.f64() - yn.f64())),
                        "*" =>
                            int.and_then(|(i, j)|
                                            i.checked_mul(j)).map(V::Int).unwrap_or_else(||
                                    real(xn.f64() * yn.f64())),
                        "/" =>
                            if yn.f64() == 0.0 {
                                V::Null
                            } else {
                                int.and_then(|(i, j)|
                                                i.checked_div(j)).map(V::Int).unwrap_or_else(||
                                        real(xn.f64() / yn.f64()))
                            },
                        "%" => {
                            let j = yn.i64();
                            if j == 0 {
                                V::Null
                            } else {
                                let n = xn.i64().checked_rem(j).unwrap_or(0);
                                if int.is_some() { V::Int(n) } else { V::Real(n as f64) }
                            }
                        }
                        "&" => V::Int(xn.i64() & yn.i64()),
                        "|" => V::Int(xn.i64() | yn.i64()),
                        "<<" | ">>" => {
                            let shift = yn.i64();
                            let left = (op == "<<") ^ (shift < 0);
                            let n = xn.i64();
                            let k = shift.unsigned_abs();
                            V::Int(if k >= 64 {
                                    if !left && n < 0 { -1 } else { 0 }
                                } else if left { n.wrapping_shl(k as u32) } else { n >> k })
                        }
                        _ => return Err(format!("unsupported operator {}",op)),
                    })
            }
            E::Between(e, a, b, not) => {
                let bound =
                    Box::new(self.freeze_expr(e, ctx, group, depth + 1)?);
                let lo = E::Bin(">=".into(), bound.clone(), a.clone());
                let hi = E::Bin("<=".into(), bound, b.clone());
                let v =
                    self.eval(&E::Bin("AND".into(), Box::new(lo), Box::new(hi)),
                            ctx, group, depth + 1)?;
                Ok(if *not { boolean(v.truth().map(|b| !b)) } else { v })
            }
            E::In(e, list, q, not) => {
                if self.is_row_expr(e, ctx)? {
                    let left = self.freeze_expr(e, ctx, group, depth + 1)?;
                    let mut rhs = vec![];
                    if let Some(q) = q {
                        let r = self.query(q, ctx, depth + 1)?;
                        for row in r.rows {
                            rhs.push(E::Tuple(row.into_iter().enumerate().map(|(i, v)|
                                                {
                                                    let (a, c) =
                                                        r.affinities.get(i).cloned().unwrap_or(('B',
                                                                "BINARY".into()));
                                                    E::Bound(v, a, c, true)
                                                }).collect()))
                        }
                    } else { rhs = list.clone() }
                    let mut unknown = false;
                    for b in rhs {
                        let v =
                            self.row_compare("=", &left, &b, ctx, group, depth + 1)?;
                        if v.truth() == Some(true) {
                            return Ok(V::Int(!not as i64))
                        }
                        unknown |= v.null()
                    }
                    return Ok(if unknown {
                                V::Null
                            } else { V::Int(*not as i64) })
                }
                let x = ev(e)?;
                let mut hasnull = false;
                let mut hit = false;
                let mut count = 0;
                if let Some(q) = q {
                    let d = self.query(q, ctx, depth + 1)?;
                    if d.columns.len() != 1 {
                        return Err("sub-select returns more than one column".into())
                    }
                    let (aff, coll) =
                        d.affinities.first().cloned().unwrap_or(('B',
                                "BINARY".into()));
                    for row in d.rows {
                        count += 1;
                        let y = &row[0];
                        if y.null() || x.null() {
                            hasnull = true
                        } else if self.compare(e,
                                    &E::Collate(Box::new(E::Cast(Box::new(E::Val(y.clone())),
                                                    affinity_name(aff).into())), coll.clone()), &x, y, ctx) ==
                                Ordering::Equal {
                            hit = true
                        }
                    }
                } else {
                    for b in list {
                        count += 1;
                        let y = ev(b)?;
                        if y.null() || x.null() {
                            hasnull = true
                        } else if self.compare(e, &E::Val(y.clone()), &x, &y, ctx)
                                == Ordering::Equal {
                            hit = true
                        }
                    }
                }
                Ok(if hit {
                        V::Int(!not as i64)
                    } else if hasnull && count > 0 {
                        V::Null
                    } else { V::Int(*not as i64) })
            }
            E::Case(base, arms, end) => {
                if let Some(base) = base {
                    if self.is_row_expr(base, ctx)? {
                        let value = self.freeze_expr(base, ctx, group, depth + 1)?;
                        for (a, b) in arms {
                            if self.row_compare("=", &value, a, ctx, group,
                                                depth + 1)?.truth() == Some(true) {
                                return ev(b)
                            }
                        }
                        return if let Some(e) = end { ev(e) } else { Ok(V::Null) }
                    }
                }
                let baseval = base.as_ref().map(|e| ev(e)).transpose()?;
                for (a, b) in arms {
                    let av = ev(a)?;
                    if if let Some(v) = &baseval {
                            !v.null() && !av.null() &&
                                self.compare(base.as_ref().unwrap(), a, v, &av, ctx) ==
                                    Ordering::Equal
                        } else { av.truth() == Some(true) } {
                        return ev(b)
                    }
                }
                if let Some(e) = end { ev(e) } else { Ok(V::Null) }
            }
            E::Sub(q) => {
                let d = self.query(q, ctx, depth + 1)?;
                if d.columns.len() != 1 {
                    return Err("sub-select returns more than one column".into())
                }
                Ok(d.rows.first().and_then(|r|
                                    r.first()).cloned().unwrap_or(V::Null))
            }
            E::Exists(q) => {
                let mut q = (**q).clone();
                q.exists_only = true;
                q.order.clear();
                if q.limit.is_none() { q.limit = Some(E::Val(V::Int(1))) }
                Ok(V::Int((!self.query(&q, ctx, depth + 1)?.rows.is_empty())
                            as i64))
            }
            E::Tuple(_) => Err("row value misused".into()),
            E::Like(a, b, escape, glob, not) => {
                let a = ev(a)?;
                let b = ev(b)?;
                if a.null() || b.null() { return Ok(V::Null) }
                let esc =
                    if let Some(e) = escape {
                        let v = ev(e)?;
                        if v.null() { return Ok(V::Null) }
                        let s = v.text();
                        let c: Vec<char> = s.chars().collect();
                        if c.len() != 1 {
                            return Err("ESCAPE expression must be a single character".into())
                        }
                        Some(c[0])
                    } else { None };
                let sensitive =
                    *glob ||
                        self.pragmas.get("case_sensitive_like").map_or(false,
                            |v| v.i64() != 0);
                Ok(V::Int((crate::funcs::pattern(&b.text(), &a.text(), esc,
                                        *glob, sensitive) ^ *not) as i64))
            }
            E::Call(name, args, distinct, filter) => {
                let n = name.to_ascii_lowercase();
                crate::funcs::check_arity(&n, args.len())?;
                if args.iter().any(|e| matches!(e,E::Star(_))) &&
                        (n != "count" || *distinct) {
                    return Err("invalid use of * in function".into())
                }
                if *distinct && is_aggregate(&n, args.len()) &&
                        args.len() != 1 {
                    return Err("DISTINCT aggregates must have exactly one argument".into())
                }
                if filter.is_some() && !is_aggregate(&n, args.len()) {
                    return Err("FILTER may only be used with aggregate functions".into())
                }
                if n == "raise" {
                    if self.trigger_ctx.is_none() {
                        return Err("RAISE() may only be used within a trigger-program".into())
                    }
                    let mode =
                        match args.first() {
                            Some(E::Col(n)) => n[0].to_ascii_uppercase(),
                            _ => "ABORT".into(),
                        };
                    if mode == "IGNORE" { return Err("!IGNORE!".into()) }
                    let msg =
                        if args.len() > 1 {
                            ev(&args[1])?.text()
                        } else { "trigger constraint failed".into() };
                    return Err(if mode == "ROLLBACK" || mode == "FAIL" {
                                format!("!{}!{}",mode,msg)
                            } else { msg })
                }
                if is_aggregate(&n, args.len()) {
                    let rows =
                        group.ok_or_else(||
                                    format!("misuse of aggregate function {}()",name))?;
                    let mut values = vec![];
                    for row in rows {
                        let mut c = ctx.clone();
                        c.row = row.clone();
                        if let Some(f) = filter {
                            if self.eval(f, &c, None, depth + 1)?.truth() != Some(true)
                                {
                                continue
                            }
                        }
                        let mut a = vec![];
                        for e in args {
                            a.push(if matches!(e,E::Star(_)) {
                                    V::Int(1)
                                } else { self.eval(e, &c, None, depth + 1)? })
                        }
                        if !distinct ||
                                !values.iter().any(|v: &Vec<V>|
                                            v.iter().zip(&a).zip(args).all(|((a, b), e)|
                                                    cmp(a, b, &self.metadata(e, ctx).1) == Ordering::Equal)) {
                            values.push(a)
                        }
                    }
                    return self.aggregate(&n, &values, args, ctx)
                }
                if n == "coalesce" || n == "ifnull" {
                    if args.len() < 2 || (n == "ifnull" && args.len() != 2) {
                        return Err(format!("wrong number of arguments to function {}()",n))
                    }
                    for a in args {
                        let v = ev(a)?;
                        if !v.null() { return Ok(v) }
                    }
                    return Ok(V::Null)
                }
                if n == "iif" || n == "if" {
                    for pair in args.chunks(2) {
                        if pair.len() == 1 { return ev(&pair[0]) }
                        if ev(&pair[0])?.truth() == Some(true) {
                            return ev(&pair[1])
                        }
                    }
                    return Ok(V::Null)
                }
                let v = args.iter().map(ev).collect::<Res<Vec<_>>>()?;
                if n == "nullif" && v.len() == 2 {
                    let c = self.compare(&args[0], &args[1], &v[0], &v[1], ctx);
                    return Ok(if c == Ordering::Equal {
                                V::Null
                            } else { v[0].clone() })
                }
                if (n == "min" || n == "max") && v.len() > 1 {
                    if v.iter().any(V::null) { return Ok(V::Null) }
                    let coll =
                        args.iter().find_map(|e|
                                    {
                                        if let Some(c) = explicit_coll(e) {
                                            Some(c.to_string())
                                        } else if self.collation_source(e, ctx) {
                                            Some(self.metadata(e, ctx).1)
                                        } else { None }
                                    }).unwrap_or("BINARY".into());
                    let mut best = v[0].clone();
                    for val in &v[1..] {
                        if cmp(val, &best, &coll) ==
                                if n == "min" { Ordering::Less } else { Ordering::Greater }
                            {
                            best = val.clone()
                        }
                    }
                    return Ok(best)
                }
                if n.starts_with("json") {
                    let typed = args.iter().map(json_typed).collect::<Vec<_>>();
                    return crate::funcs::json_typed_func(&n, &v, &typed)
                }
                match n.as_str() {
                    "changes" => Ok(V::Int(self.changes)),
                    "total_changes" => Ok(V::Int(self.total)),
                    "last_insert_rowid" => Ok(V::Int(self.last)),
                    "sqlite_version" => Ok(V::Text("3.53.4".into())),
                    "sqlite_source_id" =>
                        Ok(V::Text("sqlite-agent independent implementation".into())),
                    _ => crate::funcs::scalar(&n, &v),
                }
            }
        }
    }
    fn row_values(&self, e: &E, c: &Ctx, g: Option<&[Vec<V>]>, d: usize)
        -> Res<Vec<(E, V)>> {
        match e {
            E::Tuple(es) =>
                es.iter().map(|e|
                            Ok((e.clone(), self.eval(e, c, g, d + 1)?))).collect(),
            E::Sub(q) => {
                let r = self.query(q, c, d + 1)?;
                let row =
                    r.rows.first().cloned().unwrap_or_else(||
                            vec![V::Null;r.columns.len()]);
                Ok(row.into_iter().enumerate().map(|(i, v)|
                                {
                                    let (a, c) =
                                        r.affinities.get(i).cloned().unwrap_or(('B',
                                                "BINARY".into()));
                                    (E::Bound(v.clone(), a, c, true), v)
                                }).collect())
            }
            _ => Ok(vec![(e.clone(),self.eval(e,c,g,d+1)?)]),
        }
    }
    fn row_compare(&self, op: &str, a: &E, b: &E, c: &Ctx,
        g: Option<&[Vec<V>]>, d: usize) -> Res<V> {
        let a = self.row_values(a, c, g, d + 1)?;
        let b = self.row_values(b, c, g, d + 1)?;
        if a.len() != b.len() { return Err("row value misused".into()) }
        let is = op == "IS" || op == "IS NOT";
        let equality = ["=", "==", "!=", "<>", "IS", "IS NOT"].contains(&op);
        let mut unknown = false;
        let mut ordering = Ordering::Equal;
        for ((ae, av), (be, bv)) in a.iter().zip(&b) {
            if av.null() || bv.null() {
                if is {
                    let ord = cmp(av, bv, "BINARY");
                    if ord != Ordering::Equal { ordering = ord; break }
                } else if equality {
                    unknown = true
                } else { return Ok(V::Null) }
            } else {
                let ord = self.compare(ae, be, av, bv, c);
                if ord != Ordering::Equal {
                    ordering = ord;
                    unknown = false;
                    break
                }
            }
        }
        if unknown { return Ok(V::Null) }
        Ok(V::Int(match op {
                        "=" | "==" | "IS" => ordering == Ordering::Equal,
                        "!=" | "<>" | "IS NOT" => ordering != Ordering::Equal,
                        "<" => ordering == Ordering::Less,
                        ">" => ordering == Ordering::Greater,
                        "<=" => ordering != Ordering::Greater,
                        ">=" => ordering != Ordering::Less,
                        _ => return Err("row value misused".into()),
                    } as i64))
    }
    fn window_eval(&self, call: &E, spec: &WinSpec, ctx: &Ctx, depth: usize)
        -> Res<V> {
        let env = ctx.win.as_ref().ok_or("misuse of window function")?;
        let spec = resolve_window(spec, &env.named, &mut vec![])?;
        self.validate_window_frame(&spec, ctx)?;
        let mut partition = vec![];
        let mut current_key = vec![];
        for e in &spec.partition {
            current_key.push(self.eval(e, ctx,
                        env.groups.get(env.index).map(|g| g.as_slice()),
                        depth + 1)?)
        }
        for (i, row) in env.rows.iter().enumerate() {
            let mut c = ctx.clone();
            c.win = None;
            c.row = row.clone();
            let g = env.groups.get(i).map(|x| x.as_slice());
            let mut pk = vec![];
            for e in &spec.partition {
                pk.push(self.eval(e, &c, g, depth + 1)?)
            }
            if !pk.iter().zip(&current_key).zip(&spec.partition).all(|((a, b),
                                e)| cmp(a, b, &self.metadata(e, ctx).1) == Ordering::Equal)
                {
                continue
            }
            let mut keys = vec![];
            for o in &spec.order {
                keys.push(self.eval(&o.e, &c, g, depth + 1)?)
            }
            partition.push((i, keys));
        }
        partition.sort_by(|a, b|
                {
                    for (i, o) in spec.order.iter().enumerate() {
                        let x = &a.1[i];
                        let y = &b.1[i];
                        let mut c = cmp(x, y, &self.metadata(&o.e, ctx).1);
                        if x.null() != y.null() {
                            if let Some(last) = o.nulls {
                                c =
                                    if x.null() ^ last {
                                        Ordering::Less
                                    } else { Ordering::Greater }
                            } else if o.desc { c = c.reverse() }
                        } else if o.desc { c = c.reverse() }
                        if c != Ordering::Equal { return c }
                    }
                    Ordering::Equal
                });
        let pos =
            partition.iter().position(|(i, _)|
                            *i == env.index).ok_or("window row not found")?;
        let peers =
            |a: usize, b: usize|
                partition[a].1.iter().zip(&partition[b].1).zip(&spec.order).all(|((a,
                            b), o)|
                        cmp(a, b, &self.metadata(&o.e, ctx).1) == Ordering::Equal);
        let mut ranks = vec![0usize;partition.len()];
        let mut dense = 0;
        for i in 0..partition.len() {
            if i > 0 && !peers(i, i - 1) { dense += 1 }
            ranks[i] = dense;
            if i == pos { break }
        }
        let rank_start =
            (0..=pos).rev().take_while(|&i|
                            peers(i, pos)).last().unwrap_or(pos);
        let rank_end =
            (pos..partition.len()).take_while(|&i|
                            peers(i, pos)).last().unwrap_or(pos);
        let n = partition.len();
        let (name, args, distinct, filter) =
            match call {
                E::Call(n, a, d, f) => (n.to_ascii_lowercase(), a, *d, f),
                _ => return Err("invalid window function".into()),
            };
        if distinct {
            return Err("DISTINCT is not supported for window functions".into())
        }
        if filter.is_some() && !is_aggregate(&name, args.len()) {
            return Err("FILTER clause may only be used with aggregate window functions".into())
        }
        let at =
            |e: &E, index: usize|
                {
                    let mut c = ctx.clone();
                    c.win = None;
                    c.row = env.rows[partition[index].0].clone();
                    self.eval(e, &c,
                        env.groups.get(partition[index].0).map(|g| g.as_slice()),
                        depth + 1)
                };
        match name.as_str() {
            "row_number" => return Ok(V::Int(pos as i64 + 1)),
            "rank" => return Ok(V::Int(rank_start as i64 + 1)),
            "dense_rank" => return Ok(V::Int(dense as i64 + 1)),
            "percent_rank" =>
                return Ok(V::Real(if n <= 1 {
                                0.0
                            } else { rank_start as f64 / (n - 1) as f64 })),
            "cume_dist" =>
                return Ok(V::Real((rank_end + 1) as f64 / n as f64)),
            "ntile" => {
                let buckets =
                    if let Some(e) = args.first() {
                        at(e, pos)?.i64()
                    } else { 0 };
                if buckets <= 0 {
                    return Err("argument of ntile must be a positive integer".into())
                }
                let buckets = buckets.min(n as i64) as usize;
                let size = n / buckets;
                let extra = n % buckets;
                let cutoff = (size + 1) * extra;
                return Ok(V::Int(if pos < cutoff {
                                    pos / (size + 1) + 1
                                } else { extra + (pos - cutoff) / size + 1 } as i64))
            }
            "lag" | "lead" => {
                if args.is_empty() {
                    return Err("wrong number of arguments to window function".into())
                }
                let offset =
                    if args.len() > 1 { at(&args[1], pos)?.i64() } else { 1 };
                let i =
                    (pos as
                                i64).saturating_add(if name == "lag" {
                            offset.saturating_neg()
                        } else { offset });
                return if i < 0 || i >= n as i64 {
                        if args.len() > 2 { at(&args[2], pos) } else { Ok(V::Null) }
                    } else { at(&args[0], i as usize) }
            }
            _ => {}
        }
        let frame = spec.frame.as_deref().unwrap_or("RANGE");
        let start = spec.start.as_ref().unwrap_or(&Bound::Unbounded(false));
        let end = spec.end.as_ref().unwrap_or(&Bound::Current);
        let category =
            |b: &Bound|
                match b {
                    Bound::Unbounded(false) => 0,
                    Bound::Offset(_, false) => 1,
                    Bound::Current => 2,
                    Bound::Offset(_, true) => 3,
                    Bound::Unbounded(true) => 4,
                };
        if matches!(start,Bound::Unbounded(true)) ||
                    matches!(end,Bound::Unbounded(false)) ||
                category(end) < category(start) {
            return Err("unsupported frame specification".into())
        }
        for bound in [start, end] {
            if let Bound::Offset(e, _) = bound {
                if !column_refs(e).is_empty() || has_subquery(e) || has_agg(e)
                        || has_window(e) {
                    return Err("frame offset must be constant".into())
                }
            }
        }
        let mut groupids = vec![];
        let mut gid = 0;
        for i in 0..n {
            if i > 0 && !peers(i, i - 1) { gid += 1 }
            groupids.push(gid)
        }
        let boundary =
            |bound: &Bound, is_end: bool| -> Res<i64>
                {
                    Ok(match bound {
                            Bound::Unbounded(f) => if *f { n as i64 - 1 } else { 0 },
                            Bound::Current =>
                                if frame == "ROWS" {
                                    pos as i64
                                } else if is_end {
                                    rank_end as i64
                                } else { rank_start as i64 },
                            Bound::Offset(e, following) => {
                                let offset = at(e, pos)?.apply('N');
                                if offset.null() || offset.f64() < 0.0 {
                                    return Err("frame offset must be a non-negative number".into())
                                }
                                if frame == "ROWS" {
                                    if offset.f64().fract() != 0.0 {
                                        return Err("frame offset must be a non-negative integer".into())
                                    }
                                    (pos as
                                                i64).saturating_add(if *following {
                                            offset.i64()
                                        } else { -offset.i64() })
                                } else if frame == "GROUPS" {
                                    let target =
                                        (groupids[pos] as
                                                    i64).saturating_add(if *following {
                                                offset.i64()
                                            } else { -offset.i64() });
                                    if is_end {
                                        groupids.iter().rposition(|g|
                                                        *g <= target).map(|i| i as i64).unwrap_or(-1)
                                    } else {
                                        groupids.iter().position(|g|
                                                        *g >= target).map(|i| i as i64).unwrap_or(n as i64)
                                    }
                                } else {
                                    if spec.order.len() != 1 {
                                        return Err("RANGE with offset requires one ORDER BY expression".into())
                                    }
                                    let cur = &partition[pos].1[0];
                                    if !matches!(cur,V::Int(_)|V::Real(_)) {
                                        if is_end { rank_end as i64 } else { rank_start as i64 }
                                    } else {
                                        let desc = spec.order[0].desc;
                                        let sign = if *following ^ desc { 1.0 } else { -1.0 };
                                        let target = cur.f64() + sign * offset.f64();
                                        if is_end {
                                            partition.iter().rposition(|(_, v)|
                                                            matches!(v[0],V::Int(_)|V::Real(_)) &&
                                                                if desc {
                                                                    v[0].f64() >= target
                                                                } else {
                                                                    v[0].f64() <= target
                                                                }).map(|i| i as i64).unwrap_or(-1)
                                        } else {
                                            partition.iter().position(|(_, v)|
                                                            matches!(v[0],V::Int(_)|V::Real(_)) &&
                                                                if desc {
                                                                    v[0].f64() <= target
                                                                } else {
                                                                    v[0].f64() >= target
                                                                }).map(|i| i as i64).unwrap_or(n as i64)
                                        }
                                    }
                                }
                            }
                        })
                };
        let lo = boundary(start, false)?.max(0);
        let hi = boundary(end, true)?.min(n as i64 - 1);
        let mut chosen = vec![];
        for i in lo..=hi {
            let i = i as usize;
            if spec.exclude == "CURRENT" && i == pos { continue }
            if spec.exclude == "GROUP" && peers(i, pos) { continue }
            if spec.exclude == "TIES" && i != pos && peers(i, pos) {
                continue
            }
            chosen.push(i)
        }
        if ["first_value", "last_value", "nth_value"].contains(&name.as_str())
            {
            if args.is_empty() {
                return Err("wrong number of arguments".into())
            }
            let index =
                match name.as_str() {
                    "first_value" => chosen.first(),
                    "last_value" => chosen.last(),
                    _ => {
                        if args.len() < 2 {
                            return Err("wrong number of arguments".into())
                        }
                        let n = at(&args[1], pos)?.i64();
                        if n < 1 {
                            return Err("second argument to nth_value must be a positive integer".into())
                        }
                        chosen.get(n as usize - 1)
                    }
                };
            return if let Some(&i) = index {
                    at(&args[0], i)
                } else { Ok(V::Null) }
        }
        if !is_aggregate(&name, args.len()) {
            return Err(format!("{}() may not be used as a window function",name))
        }
        let mut vals = vec![];
        for i in chosen {
            if let Some(f) = filter {
                if at(f, i)?.truth() != Some(true) { continue }
            }
            let mut row = vec![];
            for e in args {
                row.push(if matches!(e,E::Star(_)) {
                        V::Int(1)
                    } else { at(e, i)? })
            }
            vals.push(row)
        }
        self.aggregate(&name, &vals, args, ctx)
    }
    fn aggregate(&self, n: &str, rows: &[Vec<V>], args: &[E], ctx: &Ctx)
        -> Res<V> {
        let vals: Vec<&V> =
            rows.iter().filter_map(|r|
                            r.first()).filter(|v| !v.null()).collect();
        match n {
            "count" => Ok(V::Int(vals.len() as i64)),
            "sum" | "total" | "avg" => {
                let mut integer = 0i64;
                let mut sum = 0.0;
                let mut allint = true;
                let mut overflow = false;
                for v in &vals {
                    let input =
                        match v {
                            V::Text(s) => parse_number(s, true),
                            V::Blob(_) => V::Real(v.f64()),
                            _ => v.numeric(),
                        };
                    match input {
                        V::Int(i) => {
                            if let Some(s) = integer.checked_add(i) {
                                integer = s
                            } else {
                                overflow = true;
                                if n == "sum" && allint {
                                    return Err("integer overflow".into())
                                }
                            }
                            sum += i as f64
                        }
                        v => { allint = false; sum += v.f64() }
                    }
                }
                if n == "total" {
                    Ok(real(sum))
                } else if vals.is_empty() {
                    Ok(V::Null)
                } else if n == "avg" {
                    Ok(real(sum / vals.len() as f64))
                } else if allint {
                    if overflow {
                        Err("integer overflow".into())
                    } else { Ok(V::Int(integer)) }
                } else { Ok(real(sum)) }
            }
            "min" | "max" => {
                let coll =
                    args.first().map(|e|
                                self.metadata(e, ctx).1).unwrap_or_default();
                let mut best = V::Null;
                for v in vals {
                    if best.null() ||
                            if n == "min" {
                                cmp(v, &best, &coll) == Ordering::Less
                            } else { cmp(v, &best, &coll) == Ordering::Greater } {
                        best = v.clone()
                    }
                }
                Ok(best)
            }
            "group_concat" | "string_agg" => {
                let mut s = String::new();
                let mut first = true;
                for row in rows {
                    if let Some(v) = row.first() {
                        if v.null() { continue }
                        if !first {
                            s.push_str(&row.get(1).map(V::text).unwrap_or_else(||
                                            ",".into()))
                        }
                        s.push_str(&v.text());
                        first = false
                    }
                }
                Ok(if first { V::Null } else { V::Text(s) })
            }
            "json_group_array" => {
                let values =
                    rows.iter().map(|r| r[0].clone()).collect::<Vec<_>>();
                let typed =
                    vec![args.first().map_or(false,json_typed);values.len()];
                crate::funcs::json_typed_func("json_array", &values, &typed)
            }
            "json_group_object" => {
                let mut values = vec![];
                let mut typed = vec![];
                for row in rows {
                    if row.len() > 1 {
                        values.push(V::Text(row[0].text()));
                        values.push(row[1].clone());
                        typed.push(false);
                        typed.push(args.get(1).map_or(false, json_typed));
                    }
                }
                crate::funcs::json_typed_func("json_object", &values, &typed)
            }
            _ => Err(format!("no such function: {}",n)),
        }
    }
    fn table_data(&self, t: &Table, alias: &str) -> Data {
        let mut fields =
            t.cols.iter().map(|c|
                        field(alias, &c.name, affinity(&c.typ), &c.coll,
                            false)).collect::<Vec<_>>();
        let mut extra = vec![];
        if !t.without {
            for n in ["rowid", "_rowid_", "oid"] {
                if !t.cols.iter().any(|c| c.name.eq_ignore_ascii_case(n)) {
                    fields.push(field(alias, n, 'I', "BINARY", true));
                    extra.push(n)
                }
            }
        }
        let mut rows = t.rows.clone();
        if t.without {
            let mut pks =
                t.cols.iter().enumerate().filter(|(_, c)|
                            c.pk > 0).collect::<Vec<_>>();
            pks.sort_by_key(|(_, c)| c.pk);
            rows.sort_by(|a, b|
                    {
                        for (i, c) in &pks {
                            let ord = cmp(&a.v[*i], &b.v[*i], &c.coll);
                            if ord != Ordering::Equal {
                                return if c.pk_desc { ord.reverse() } else { ord }
                            }
                        }
                        Ordering::Equal
                    });
        } else { rows.sort_by_key(|r| r.id) }
        Data {
            fields,
            rows: rows.iter().map(|r|
                        {
                            let mut v = r.v.clone();
                            v.extend(extra.iter().map(|_| V::Int(r.id)));
                            v
                        }).collect(),
        }
    }
    fn source(&self, s: &Source, alias: &Option<String>, ctx: &Ctx,
        depth: usize) -> Res<Data> {
        match s {
            Source::Function(n, args) => {
                let args =
                    if ctx.binding {
                        for e in args { self.validate_expr(e, ctx)?; }
                        if n.eq_ignore_ascii_case("generate_series") {
                            vec![V::Int(0),V::Int(-1)]
                        } else { vec![V::Null;args.len()] }
                    } else {
                        args.iter().map(|e|
                                        self.eval(e, ctx, None,
                                            depth + 1)).collect::<Res<Vec<_>>>()?
                    };
                let alias = alias.as_deref().unwrap_or(n);
                let (cols, rows) =
                    if let Some(p) = key(n).strip_prefix("pragma_") {
                        let mut copy = self.clone();
                        let e = args.first().cloned().map(E::Val);
                        let r = copy.pragma(p, e.as_ref())?;
                        (r.columns, r.rows)
                    } else { crate::funcs::table_function(&key(n), &args)? };
                Ok(Data {
                        fields: cols.iter().enumerate().map(|(i, c)|
                                    field(alias, c, 'B', "BINARY",
                                        (n.starts_with("json_") && i >= 8) ||
                                            (n.eq_ignore_ascii_case("generate_series") &&
                                                    i > 0))).collect(),
                        rows,
                    })
            }
            Source::Join(joins) => {
                let mut data = self.join_sources(joins, ctx, depth + 1)?;
                if let Some(alias) = alias {
                    for f in &mut data.fields { f.table = alias.clone() }
                }
                Ok(data)
            }
            Source::Query(q) => {
                let r = self.query(q, ctx, depth + 1)?;
                Ok(Data {
                        fields: r.columns.iter().enumerate().map(|(i, n)|
                                    {
                                        let (a, c) =
                                            r.affinities.get(i).cloned().unwrap_or(('B',
                                                    "BINARY".into()));
                                        field(alias.as_deref().unwrap_or(""), n, a, &c, false)
                                    }).collect(),
                        rows: r.rows,
                    })
            }
            Source::Table(n) => {
                if let Some((schema, table)) = n.split_once('.') {
                    let db =
                        self.attached.get(&key(schema)).ok_or_else(||
                                    format!("unknown database {}",schema))?;
                    if db.txn.is_empty() {
                        let mut db = db.clone();
                        db.refresh()?;
                        let mut data =
                            db.source(&Source::Table(table.into()), alias, ctx,
                                    depth + 1)?;
                        if alias.is_none() {
                            for f in &mut data.fields {
                                f.table = format!("{}.{}",schema,f.table)
                            }
                        }
                        return Ok(data)
                    }
                    let mut data =
                        db.source(&Source::Table(table.into()), alias, ctx,
                                depth + 1)?;
                    if alias.is_none() {
                        for f in &mut data.fields {
                            f.table = format!("{}.{}",schema,f.table)
                        }
                    }
                    return Ok(data)
                }
                let a = alias.as_deref().unwrap_or(n);
                if let Some(d) = ctx.ctes.get(&key(n)) {
                    let mut d = (**d).clone();
                    for f in &mut d.fields { f.table = a.into() }
                    return Ok(d)
                }
                if let Some(t) = self.db.tables.get(&key(n)) {
                    return Ok(self.table_data(t, a))
                }
                if let Some(v) = self.db.views.get(&key(n)) {
                    let r = self.query(&v.q, ctx, depth + 1)?;
                    let cols =
                        if v.cols.is_empty() { r.columns } else { v.cols.clone() };
                    return Ok(Data {
                                fields: cols.iter().enumerate().map(|(i, n)|
                                            {
                                                let (aff, c) =
                                                    r.affinities.get(i).cloned().unwrap_or(('B',
                                                            "BINARY".into()));
                                                field(a, n, aff, &c, false)
                                            }).collect(),
                                rows: r.rows,
                            })
                }
                if ["sqlite_master", "sqlite_schema", "sqlite_temp_master",
                                "sqlite_temp_schema"].contains(&key(n).as_str()) {
                    let temp = key(n).contains("temp");
                    let names = ["type", "name", "tbl_name", "rootpage", "sql"];
                    let mut rows = vec![];
                    if self.db.sequence_created && !temp {
                        rows.push(vec![V::Text("table".into()),V::Text("sqlite_sequence".into()),V::Text("sqlite_sequence".into()),V::Int(3),V::Text("CREATE TABLE sqlite_sequence(name,seq)".into())]);
                    }
                    for t in
                        self.db.triggers.values().filter(|t| t.temporary == temp) {
                        rows.push(vec![V::Text("trigger".into()),V::Text(t.name.clone()),V::Text(t.table.clone()),V::Int(0),V::Text(t.sql.clone())])
                    }
                    for t in
                        self.db.tables.values().filter(|t| t.temporary == temp) {
                        rows.push(vec![V::Text("table".into()),V::Text(t.name.clone()),V::Text(t.name.clone()),V::Int(2),V::Text(t.sql.clone())])
                    }
                    for v in
                        self.db.views.values().filter(|t| t.temporary == temp) {
                        rows.push(vec![V::Text("view".into()),V::Text(v.name.clone()),V::Text(v.name.clone()),V::Int(0),V::Text(v.sql.clone())])
                    }
                    for i in
                        self.db.indexes.values().filter(|t| t.temporary == temp) {
                        rows.push(vec![V::Text("index".into()),V::Text(i.name.clone()),V::Text(i.table.clone()),V::Int(3),if
                                i.sql.is_empty(){V::Null}else{V::Text(i.sql.clone())}])
                    }
                    return Ok(Data {
                                fields: names.iter().map(|n|
                                            field(a, n, 'B', "BINARY", false)).collect(),
                                rows,
                            })
                }
                if n.eq_ignore_ascii_case("sqlite_sequence") &&
                        self.db.sequence_created {
                    return Ok(self.table_data(&self.sequence_table(), a))
                }
                for schema in &self.attach_order {
                    let db = &self.attached[schema];
                    if db.db.tables.contains_key(&key(n)) ||
                            db.db.views.contains_key(&key(n)) {
                        return self.source(&Source::Table(format!("{}.{}",schema,n)),
                                alias, ctx, depth + 1)
                    }
                }
                Err(format!("no such table: {}",n))
            }
        }
    }
    fn join_sources(&self, from: &[Join], ctx: &Ctx, depth: usize)
        -> Res<Data> {
        if depth > 80 { return Err("join nesting limit exceeded".into()) }
        let mut data = Data { fields: vec![], rows: vec![vec![]] };
        for j in from {
            if matches!(j.source,Source::Function(_, _)) {
                let nullctx =
                    Ctx {
                        fields: data.fields.clone(),
                        row: data.rows.first().cloned().unwrap_or_else(||
                                vec![V::Null;data.fields.len()]),
                        ..ctx.clone()
                    };
                let proto =
                    self.source(&j.source, &j.alias, &nullctx, depth + 1)?;
                let mut fields = data.fields.clone();
                fields.extend(proto.fields.clone());
                if let Some(e) = &j.on {
                    if has_agg(e) || has_window(e) {
                        return Err("misuse of aggregate or window function in ON".into())
                    }
                    let c =
                        Ctx {
                            fields: fields.clone(),
                            row: vec![V::Null;fields.len()],
                            ..ctx.clone()
                        };
                    self.validate_expr(e, &c)?
                }
                if ctx.binding {
                    let row = vec![V::Null;fields.len()];
                    let c =
                        Ctx {
                            fields: fields.clone(),
                            row: row.clone(),
                            ..ctx.clone()
                        };
                    if let Some(e) = &j.on { self.validate_expr(e, &c)?; }
                    data = Data { fields, rows: vec![row] };
                    continue
                }
                let mut rows = vec![];
                for left in &data.rows {
                    let c =
                        Ctx {
                            fields: data.fields.clone(),
                            row: left.clone(),
                            ..ctx.clone()
                        };
                    let right =
                        self.source(&j.source, &j.alias, &c, depth + 1)?;
                    let mut hit = false;
                    for r in right.rows {
                        let mut row = left.clone();
                        row.extend(r);
                        let cc =
                            Ctx {
                                fields: fields.clone(),
                                row: row.clone(),
                                ..ctx.clone()
                            };
                        let yes =
                            if let Some(e) = &j.on {
                                self.eval(e, &cc, None, depth + 1)?.truth() == Some(true)
                            } else { true };
                        if yes { rows.push(row); hit = true }
                    }
                    if !hit && j.kind == "LEFT" {
                        let mut row = left.clone();
                        row.extend(vec![V::Null;proto.fields.len()]);
                        rows.push(row)
                    }
                }
                data = Data { fields, rows };
                continue
            }
            let right = self.source(&j.source, &j.alias, ctx, depth + 1)?;
            let leftlen = data.fields.len();
            let mut using = j.using.clone();
            if j.natural {
                for f in &right.fields {
                    if !f.hidden &&
                            data.fields.iter().any(|x|
                                    !x.hidden && x.name.eq_ignore_ascii_case(&f.name)) {
                        using.push(f.name.clone())
                    }
                }
            }
            let mut pairs = vec![];
            for n in using {
                let a =
                    data.fields.iter().position(|f|
                                    !f.hidden &&
                                        f.name.eq_ignore_ascii_case(&n)).ok_or_else(||
                                format!("cannot join using column {}",n))?;
                let b =
                    right.fields.iter().position(|f|
                                    !f.hidden &&
                                        f.name.eq_ignore_ascii_case(&n)).ok_or_else(||
                                format!("cannot join using column {}",n))?;
                pairs.push((a, b));
            }
            let mut fields = data.fields.clone();
            fields.extend(right.fields.clone());
            for (_, b) in &pairs {
                fields[leftlen + b].hidden = true;
                fields[leftlen + b].using = true
            }
            if let Some(e) = &j.on {
                if has_agg(e) || has_window(e) {
                    return Err("misuse of aggregate or window function in ON".into())
                }
                let c =
                    Ctx {
                        fields: fields.clone(),
                        row: vec![V::Null;fields.len()],
                        ..ctx.clone()
                    };
                self.validate_expr(e, &c)?
            }
            if ctx.binding {
                let row = vec![V::Null;fields.len()];
                let c =
                    Ctx {
                        fields: fields.clone(),
                        row: row.clone(),
                        ..ctx.clone()
                    };
                if let Some(e) = &j.on { self.validate_expr(e, &c)?; }
                data = Data { fields, rows: vec![row] };
                continue
            }
            let mut rows = vec![];
            let mut rightmatched = vec![false;right.rows.len()];
            for l in &data.rows {
                let mut matched = false;
                for (i, r) in right.rows.iter().enumerate() {
                    let mut row = l.clone();
                    row.extend(r.clone());
                    let c =
                        Ctx {
                            fields: fields.clone(),
                            row: row.clone(),
                            ..ctx.clone()
                        };
                    let mut yes = true;
                    for (a, b) in &pairs {
                        if l[*a].null() || r[*b].null() ||
                                self.compare(&E::Bound(l[*a].clone(), data.fields[*a].aff,
                                                data.fields[*a].coll.clone(), true),
                                        &E::Bound(r[*b].clone(), right.fields[*b].aff,
                                                right.fields[*b].coll.clone(), true), &l[*a], &r[*b], &c) !=
                                    Ordering::Equal {
                            yes = false;
                            break
                        }
                    }
                    if yes {
                        if let Some(on) = &j.on {
                            yes =
                                self.eval(on, &c, None, depth + 1)?.truth() == Some(true)
                        }
                    }
                    if yes {
                        matched = true;
                        rightmatched[i] = true;
                        rows.push(row)
                    }
                }
                if !matched && (j.kind == "LEFT" || j.kind == "FULL") {
                    let mut row = l.clone();
                    row.extend(vec![V::Null;right.fields.len()]);
                    rows.push(row)
                }
            }
            if j.kind == "RIGHT" || j.kind == "FULL" {
                for (i, r) in right.rows.iter().enumerate() {
                    if !rightmatched[i] {
                        let mut row = vec![V::Null;leftlen];
                        row.extend(r.clone());
                        for (a, b) in &pairs { row[*a] = r[*b].clone() }
                        rows.push(row)
                    }
                }
            }
            data = Data { fields, rows };
        }
        Ok(data)
    }
    fn recursive_cte(&self, name: &str, columns: &[String], q: &Query,
        ctx: &Ctx, depth: usize) -> Res<ResultSet> {
        let first =
            q.compound.iter().position(|(_, b)|
                            query_table_references(b, name) >
                                0).ok_or_else(|| format!("circular reference: {}",name))?;
        let mut anchor = q.clone();
        anchor.compound.truncate(first);
        anchor.order.clear();
        anchor.limit = None;
        anchor.offset = None;
        if query_table_references(&anchor, name) > 0 {
            return Err(format!("circular reference: {}",name))
        }
        let op = &q.compound[first].0;
        if op != "UNION" && op != "UNION ALL" {
            return Err("recursive CTE requires UNION or UNION ALL".into())
        }
        let distinct = op == "UNION";
        let mut result = self.query(&anchor, ctx, depth + 1)?;
        let names =
            if columns.is_empty() {
                result.columns.clone()
            } else { columns.to_vec() };
        if names.len() != result.columns.len() {
            return Err("CTE column count mismatch".into())
        }
        let fields =
            names.iter().enumerate().map(|(i, n)|
                        {
                            let (a, c) =
                                result.affinities.get(i).cloned().unwrap_or(('B',
                                        "BINARY".into()));
                            field(name, n, a, &c, false)
                        }).collect::<Vec<_>>();
        let mut recursive_ctx = ctx.clone();
        recursive_ctx.ctes.insert(key(name),
            Arc::new(Data { fields, rows: vec![] }));
        let mut bind = recursive_ctx.clone();
        bind.binding = true;
        let mut branches = vec![result.items.clone()];
        for (branch_op, branch) in &q.compound[first..] {
            let direct =
                branch.from.iter().filter(|j|
                            matches!(&j.source,Source::Table(t) if
                                t.eq_ignore_ascii_case(name))).count();
            if branch_op != op || direct != 1 ||
                    query_table_references(branch, name) != 1 {
                return Err("invalid recursive reference or compound operator".into())
            }
            if !branch.group.is_empty() || branch.having.is_some() ||
                    branch.items.iter().any(|i|
                            has_agg(&i.e) || has_window(&i.e)) {
                return Err("recursive queries may not use aggregate or window functions".into())
            }
            let r = self.query(branch, &bind, depth + 1)?;
            if r.columns.len() != names.len() {
                return Err("recursive SELECT column count mismatch".into())
            }
            inherit_compound_collations(&mut result, &r);
            branches.push(r.items);
        }
        let order_indices = resolve_order(&q.order, &branches, true)?;
        if ctx.binding { result.rows.clear(); return Ok(result) }
        let limit =
            if let Some(e) = &q.limit {
                let n = limit_int(&self.eval(e, ctx, None, depth + 1)?)?;
                if n < 0 { usize::MAX } else { n as usize }
            } else { usize::MAX };
        let mut offset =
            if let Some(e) = &q.offset {
                limit_int(&self.eval(e, ctx, None, depth + 1)?)?.max(0) as
                    usize
            } else { 0 };
        let row_equal =
            |a: &[V], b: &[V]|
                a.len() == b.len() &&
                    a.iter().zip(b).enumerate().all(|(i, (a, b))|
                            cmp(a, b,
                                    result.affinities.get(i).map(|x|
                                                x.1.as_str()).unwrap_or("BINARY")) == Ordering::Equal);
        let mut seen: Vec<Vec<V>> = vec![];
        let mut queue = std::collections::VecDeque::new();
        for row in result.rows.drain(..) {
            if !distinct || !seen.iter().any(|r| row_equal(r, &row)) {
                if distinct { seen.push(row.clone()) }
                queue.push_back(row)
            }
        }
        let mut output = vec![];
        let mut steps = 0usize;
        while !queue.is_empty() && output.len() < limit {
            steps += 1;
            if steps > 1_000_000 || queue.len() > 1_000_000 {
                return Err("recursive query resource limit exceeded".into())
            }
            let index =
                if q.order.is_empty() {
                    0
                } else {
                    queue.iter().enumerate().min_by(|(_, a), (_, b)|
                                    {
                                        for (oi, o) in q.order.iter().enumerate() {
                                            let col = order_indices[oi].unwrap();
                                            let coll =
                                                explicit_coll(&o.e).unwrap_or_else(||
                                                        result.affinities.get(col).map(|x|
                                                                    x.1.as_str()).unwrap_or("BINARY"));
                                            let c = sort_compare(&a[col], &b[col], coll, o);
                                            if c != Ordering::Equal { return c }
                                        }
                                        Ordering::Equal
                                    }).map(|(i, _)| i).unwrap()
                };
            let row = queue.remove(index).unwrap();
            if offset > 0 { offset -= 1 } else { output.push(row.clone()) }
            if output.len() >= limit { break }
            Arc::make_mut(recursive_ctx.ctes.get_mut(&key(name)).unwrap()).rows
                = vec![row];
            for (_, branch) in &q.compound[first..] {
                for row in self.query(branch, &recursive_ctx, depth + 1)?.rows
                    {
                    if !distinct || !seen.iter().any(|r| row_equal(r, &row)) {
                        if distinct { seen.push(row.clone()) }
                        queue.push_back(row)
                    }
                }
            }
        }
        result.rows = output;
        Ok(result)
    }
    pub fn query(&self, q: &Query, outer: &Ctx, depth: usize)
        -> Res<ResultSet> {
        if !outer.binding {
            if let Some(e)=&q.limit{
                if column_refs(e).is_empty()&&!has_subquery(e)&&!nondeterministic(e)&&limit_int(&self.eval(e,outer,None,depth+1)?)?==0{
                    let mut bind=outer.clone();bind.binding=true;
                    let mut result=self.query(q,&bind,depth+1)?;result.rows.clear();return Ok(result)
                }
            }
        }
        if let Some(m) = &q.materialized {
            return Ok(ResultSet {
                        items: vec![],
                        coll_sources: vec![],
                        columns: m.columns.clone(),
                        rows: m.rows.clone(),
                        affinities: m.affinities.clone(),
                    })
        }
        if depth > 80 { return Err("query recursion limit exceeded".into()) }
        let mut base =
            Ctx {
                binding: outer.binding,
                outer: Some(Box::new(outer.clone())),
                ctes: outer.ctes.clone(),
                ..Default::default()
            };
        for ci in cte_order(q)? {
            let (n, cols, cq) = &q.ctes[ci];
            let r =
                if query_table_references(cq, n) > 0 {
                    self.recursive_cte(n, cols, cq, &base, depth + 1)?
                } else { self.query(cq, &base, depth + 1)? };
            let names =
                if cols.is_empty() {
                    r.columns
                } else {
                    if cols.len() != r.columns.len() {
                        return Err("CTE column count mismatch".into())
                    }
                    cols.clone()
                };
            base.ctes.insert(key(n),
                Arc::new(Data {
                        fields: names.iter().enumerate().map(|(i, s)|
                                    {
                                        let (a, c) =
                                            r.affinities.get(i).cloned().unwrap_or(('B',
                                                    "BINARY".into()));
                                        field(n, s, a, &c, false)
                                    }).collect(),
                        rows: r.rows,
                    }));
        }
        let mut result;
        let mut contexts: Vec<(Ctx, Option<Vec<Vec<V>>>)> = vec![];
        if !q.values.is_empty() {
            let cols = q.values[0].len();
            let mut rows = vec![];
            for row in &q.values {
                if row.len() != cols {
                    return Err("all VALUES must have the same number of terms".into())
                }
                if base.binding {
                    for e in row { self.validate_expr(e, &base)?; }
                } else if q.exists_only && q.compound.is_empty() &&
                        q.offset.is_none() {
                    for e in row { self.validate_expr(e, &base)?; }
                    rows.push(vec![V::Null;row.len()])
                } else {
                    rows.push(row.iter().map(|e|
                                        self.eval(e, &base, None, depth + 1)).collect::<Res<_>>()?)
                }
            }
            result =
                ResultSet {
                    items: q.values[0].iter().enumerate().map(|(i, e)|
                                Item {
                                    e: e.clone(),
                                    name: format!("column{}",i+1),
                                    alias: None,
                                }).collect(),
                    coll_sources: q.values[0].iter().map(|e|
                                explicit_coll(e).is_some() ||
                                    self.collation_source(e, &base)).collect(),
                    affinities: q.values[0].iter().map(|e|
                                self.metadata(e, &base)).collect(),
                    columns: (1..=cols).map(|i|
                                format!("column{}",i)).collect(),
                    rows,
                };
        } else {
            let data = self.join_sources(&q.from, &base, depth)?;
            base.fields = data.fields.clone();
            let mut items = vec![];
            for item in &q.items {
                if let E::Star(table) = &item.e {
                    let mut count = 0;
                    for f in &data.fields {
                        if (!f.hidden || (f.using && table.is_some())) &&
                                table.as_ref().map_or(true,
                                    |t| table_qualifies(&f.table, t)) {
                            items.push(Item {
                                    e: E::Col(if f.table.is_empty() {
                                            vec![f.name.clone()]
                                        } else { vec![f.table.clone(),f.name.clone()] }),
                                    name: f.name.clone(),
                                    alias: None,
                                });
                            count += 1
                        }
                    }
                    if count == 0 {
                        return Err("no tables specified or unknown table in *".into())
                    }
                } else { items.push(item.clone()) }
            }
            let mut bindctx =
                Ctx {
                    row: vec![V::Null;base.fields.len()],
                    win: Some(WinCtx {
                            rows: Arc::new(vec![]),
                            groups: Arc::new(vec![]),
                            index: 0,
                            named: Arc::new(q.windows.iter().map(|(n, w)|
                                            (key(n), w.clone())).collect()),
                        }),
                    ..base.clone()
                };
            for (_, w) in &q.windows {
                let w =
                    resolve_window(w, &bindctx.win.as_ref().unwrap().named,
                            &mut vec![])?;
                self.validate_window_frame(&w, &bindctx)?;
                for e in &w.partition { self.validate_expr(e, &bindctx)?; }
                for o in &w.order { self.validate_expr(&o.e, &bindctx)?; }
            }
            for item in &items { self.validate_expr(&item.e, &bindctx)?; }
            for item in &items {
                if let Some(alias) = &item.alias {
                    if !bindctx.fields.iter().any(|f|
                                    f.name.eq_ignore_ascii_case(alias)) {
                        let (a, coll) = self.metadata(&item.e, &base);
                        bindctx.fields.push(field("", alias, a, &coll, false));
                        bindctx.row.push(V::Null)
                    }
                }
            }
            if let Some(e) = &q.filter {
                if self.alias_has_kind(e, &items, &base, false) ||
                        self.alias_has_kind(e, &items, &base, true) {
                    return Err("misuse of aggregate or window function".into())
                }
                self.validate_expr(e, &bindctx)?;
            }
            for e in &q.group {
                let e = ordinal(e, &items)?;
                if self.alias_has_kind(e, &items, &base, false) ||
                        self.alias_has_kind(e, &items, &base, true) {
                    return Err("aggregate or window functions are not allowed in GROUP BY".into())
                }
                self.validate_expr(e, &bindctx)?;
            }
            if let Some(e) = &q.having {
                if self.alias_has_kind(e, &items, &base, true) {
                    return Err("misuse of window function".into())
                }
                self.validate_expr(e, &bindctx)?;
            }
            if q.compound.is_empty() {
                for o in &q.order {
                    let expr = ordinal(&o.e, &items)?;
                    self.validate_expr(expr, &bindctx)?;
                }
            }
            let aggregated =
                !q.group.is_empty() || items.iter().any(|i| has_agg(&i.e));
            if !aggregated && q.order.iter().any(|o| has_agg(&o.e)) {
                return Err("misuse of aggregate function in ORDER BY".into())
            }
            if q.having.is_some() && !aggregated {
                return Err("HAVING clause on a non-aggregate query".into())
            }
            if base.binding {
                let mut result =
                    ResultSet {
                        items: items.clone(),
                        coll_sources: items.iter().map(|i|
                                    explicit_coll(&i.e).is_some() ||
                                        self.collation_source(&i.e, &base)).collect(),
                        columns: items.iter().map(|i| i.name.clone()).collect(),
                        rows: vec![],
                        affinities: items.iter().map(|i|
                                    self.metadata(&i.e, &base)).collect(),
                    };
                let mut branches = vec![items.clone()];
                for (_, branch) in &q.compound {
                    let r = self.query(branch, &base, depth + 1)?;
                    if r.columns.len() != result.columns.len() {
                        return Err("compound column count mismatch".into())
                    }
                    inherit_compound_collations(&mut result, &r);
                    branches.push(r.items);
                }
                resolve_order(&q.order, &branches, !q.compound.is_empty())?;
                return Ok(result)
            }
            let mut filtered = vec![];
            for row in data.rows {
                let c = Ctx { row: row.clone(), ..base.clone() };
                if let Some(e) = &q.filter {
                    let c = self.alias_ctx(&items, &c, None, depth)?;
                    if self.eval(e, &c, None, depth + 1)?.truth() != Some(true)
                        {
                        continue
                    }
                }
                filtered.push(row)
            }
            let mut groups: Vec<Vec<Vec<V>>> = vec![];
            if aggregated {
                if q.group.is_empty() {
                    groups.push(filtered)
                } else {
                    let mut keys: Vec<Vec<V>> = vec![];
                    for row in filtered {
                        let c = Ctx { row: row.clone(), ..base.clone() };
                        let c = self.alias_ctx(&items, &c, None, depth)?;
                        let mut vals = vec![];
                        for e in &q.group {
                            let e = ordinal(e, &items)?;
                            vals.push(self.eval(e, &c, None, depth + 1)?)
                        }
                        if let Some(i) =
                                keys.iter().position(|x|
                                        x.iter().zip(&vals).zip(&q.group).all(|((a, b), e)|
                                                cmp(a, b,
                                                        &self.metadata(ordinal(e, &items).unwrap_or(e), &c).1) ==
                                                    Ordering::Equal)) {
                            groups[i].push(row)
                        } else { keys.push(vals); groups.push(vec![row]) }
                    }
                }
            } else { for row in filtered { groups.push(vec![row]) } }
            if let Some(e) = &q.having {
                let mut kept = vec![];
                for g in groups {
                    let c =
                        Ctx {
                            row: g.first().cloned().unwrap_or_else(||
                                    vec![V::Null;base.fields.len()]),
                            ..base.clone()
                        };
                    let group =
                        if aggregated { Some(g.as_slice()) } else { None };
                    let cc = self.alias_ctx(&items, &c, group, depth)?;
                    if self.eval(e, &cc, group, depth + 1)?.truth() ==
                            Some(true) {
                        kept.push(g)
                    }
                }
                groups = kept;
            }
            let winrows =
                Arc::new(groups.iter().map(|g|
                                g.first().cloned().unwrap_or_else(||
                                        vec![V::Null;base.fields.len()])).collect::<Vec<_>>());
            let wingroups =
                Arc::new(if aggregated { groups.clone() } else { vec![] });
            let mut rows = vec![];
            for (wi, group) in groups.into_iter().enumerate() {
                let mut representative =
                    group.first().cloned().unwrap_or_else(||
                            vec![V::Null;base.fields.len()]);
                if aggregated {
                    if let Some((name, arg)) =
                            items.iter().find_map(|item| find_minmax(&item.e)) {
                        let mut best = V::Null;
                        for row in &group {
                            let c = Ctx { row: row.clone(), ..base.clone() };
                            let v = self.eval(arg, &c, None, depth + 1)?;
                            if !v.null() &&
                                    (best.null() ||
                                            cmp(&v, &best, &self.metadata(arg, &c).1) ==
                                                if name.eq_ignore_ascii_case("min") {
                                                    Ordering::Less
                                                } else { Ordering::Greater }) {
                                best = v;
                                representative = row.clone()
                            }
                        }
                    }
                }
                let mut c =
                    Ctx {
                        row: representative,
                        win: Some(WinCtx {
                                rows: winrows.clone(),
                                groups: wingroups.clone(),
                                index: wi,
                                named: Arc::new(q.windows.iter().map(|(n, w)|
                                                (key(n), w.clone())).collect()),
                            }),
                        ..base.clone()
                    };
                let g =
                    if aggregated { Some(group.as_slice()) } else { None };
                let mut row = vec![];
                for item in &items {
                    if q.exists_only && q.compound.is_empty() &&
                            q.offset.is_none() {
                        row.push(V::Null)
                    } else { row.push(self.eval(&item.e, &c, g, depth + 1)?) }
                }

                if q.distinct &&
                        rows.iter().any(|r: &Vec<V>|
                                r.iter().zip(&row).zip(&items).all(|((a, b), item)|
                                        cmp(a, b, &self.metadata(&item.e, &c).1) ==
                                            Ordering::Equal)) {
                    continue
                }
                for (i, item) in items.iter().enumerate() {
                    if !c.fields.iter().any(|f|
                                    f.name.eq_ignore_ascii_case(&item.name)) {
                        let (a, coll) = self.metadata(&item.e, &base);
                        c.fields.push(field("", &item.name, a, &coll, false));
                        c.row.push(row[i].clone())
                    }
                }
                rows.push(row);
                contexts.push((c,
                        if aggregated { Some(group) } else { None }));
            }
            // Resolve expressions on an empty input too, so missing columns remain errors.
            if rows.is_empty() {
                let c =
                    Ctx {
                        row: vec![V::Null;base.fields.len()],
                        ..base.clone()
                    };
                for item in &items { self.validate_expr(&item.e, &c)?; }
            }
            result =
                ResultSet {
                    items: items.clone(),
                    coll_sources: items.iter().map(|i|
                                explicit_coll(&i.e).is_some() ||
                                    self.collation_source(&i.e, &base)).collect(),
                    affinities: items.iter().map(|i|
                                self.metadata(&i.e, &base)).collect(),
                    columns: items.iter().map(|i| i.name.clone()).collect(),
                    rows,
                };
        }
        let mut order_branches = vec![result.items.clone()];
        for (op, branch) in &q.compound {
            let r = self.query(branch, &base, depth + 1)?;
            if r.columns.len() != result.columns.len() {
                return Err("SELECTs to the left and right of compound operator do not have the same number of result columns".into())
            }
            order_branches.push(r.items.clone());
            inherit_compound_collations(&mut result, &r);
            let eq =
                |x: &[V], y: &[V]|
                    x.len() == y.len() &&
                        x.iter().zip(y).enumerate().all(|(i, (a, b))|
                                cmp(a, b,
                                        result.affinities.get(i).map(|(_, c)|
                                                    c.as_str()).unwrap_or("BINARY")) == Ordering::Equal);
            match op.as_str() {
                "UNION ALL" => result.rows.extend(r.rows),
                "UNION" => {
                    result.rows.extend(r.rows);
                    dedup_with(&mut result.rows, &eq)
                }
                "INTERSECT" => {
                    result.rows.retain(|x| r.rows.iter().any(|y| eq(x, y)));
                    dedup_with(&mut result.rows, &eq)
                }
                "EXCEPT" => {
                    result.rows.retain(|x| !r.rows.iter().any(|y| eq(x, y)));
                    dedup_with(&mut result.rows, &eq)
                }
                _ => {}
            }
            contexts.clear();
        }
        let order_indices =
            resolve_order(&q.order, &order_branches, !q.compound.is_empty())?;
        if base.binding { return Ok(result) }
        if !q.order.is_empty() {
            let mut sorted = vec![];
            for (i, row) in result.rows.iter().enumerate() {
                let c =
                    contexts.get(i).map(|x|
                                x.0.clone()).unwrap_or_else(||
                            Ctx {
                                fields: result.columns.iter().enumerate().map(|(i, n)|
                                            {
                                                let (a, c) =
                                                    result.affinities.get(i).cloned().unwrap_or(('B',
                                                            "BINARY".into()));
                                                field("", n, a, &c, false)
                                            }).collect(),
                                row: row.clone(),
                                ..base.clone()
                            });
                let g = contexts.get(i).and_then(|x| x.1.as_deref());
                let mut keys = vec![];
                for (oi, o) in q.order.iter().enumerate() {
                    let (v, coll) =
                        if let Some(index) = order_indices[oi] {
                            (row[index].clone(),
                                explicit_coll(&o.e).map(str::to_string).unwrap_or_else(||
                                        result.affinities.get(index).map(|x|
                                                    x.1.clone()).unwrap_or("BINARY".into())))
                        } else {
                            (self.eval(&o.e, &c, g, depth + 1)?,
                                self.metadata(&o.e, &c).1)
                        };
                    keys.push((v, coll));
                }
                sorted.push((row.clone(), keys));
            }
            sorted.sort_by(|a, b|
                    {
                        for (i, o) in q.order.iter().enumerate() {
                            let (x, coll) = &a.1[i];
                            let (y, _) = &b.1[i];
                            let mut c = cmp(x, y, coll);
                            if x.null() != y.null() {
                                if let Some(last) = o.nulls {
                                    c =
                                        if x.null() ^ last {
                                            Ordering::Less
                                        } else { Ordering::Greater }
                                } else if o.desc { c = c.reverse() }
                            } else if o.desc { c = c.reverse() }
                            if c != Ordering::Equal { return c }
                        }
                        Ordering::Equal
                    });
            result.rows = sorted.into_iter().map(|x| x.0).collect();
        }
        let off =
            if let Some(e) = &q.offset {
                let v = self.eval(e, &base, None, depth + 1)?;
                limit_int(&v)?.max(0) as usize
            } else { 0 };
        let lim =
            if let Some(e) = &q.limit {
                let v = self.eval(e, &base, None, depth + 1)?;
                let n = limit_int(&v)?;
                if n < 0 { usize::MAX } else { n as usize }
            } else { usize::MAX };
        result.rows = result.rows.into_iter().skip(off).take(lim).collect();
        Ok(result)
    }
    fn alias_ctx(&self, items: &[Item], ctx: &Ctx, g: Option<&[Vec<V>]>,
        _depth: usize) -> Res<Ctx> {
        let mut c = ctx.clone();
        c.alias_group = g.map(|g| g.to_vec());
        for item in items {
            if let Some(a) = &item.alias {
                if !c.fields.iter().any(|f| f.name.eq_ignore_ascii_case(a)) &&
                            (!has_agg(&item.e) || g.is_some()) && !has_window(&item.e) {
                    c.aliases.insert(key(a), item.e.clone());
                }
            }
        }
        Ok(c)
    }
    fn alias_has_kind(&self, e: &E, items: &[Item], ctx: &Ctx, window: bool)
        -> bool {
        if if window { has_window(e) } else { has_agg(e) } { return true }
        if let E::Col(n) = e {
            if n.len() == 1 && Self::colindex(ctx, n).ok().flatten().is_none()
                {
                if let Some(item) =
                        items.iter().find(|i|
                                i.alias.as_ref().is_some_and(|a|
                                        a.eq_ignore_ascii_case(&n[0]))) {
                    return if window {
                            has_window(&item.e)
                        } else { has_agg(&item.e) }
                }
            }
        }
        child_exprs(e).iter().any(|e|
                self.alias_has_kind(e, items, ctx, window))
    }
    fn validate_window_frame(&self, w: &WinSpec, c: &Ctx) -> Res<()> {
        let start = w.start.as_ref().unwrap_or(&Bound::Unbounded(false));
        let end = w.end.as_ref().unwrap_or(&Bound::Current);
        let category =
            |b: &Bound|
                match b {
                    Bound::Unbounded(false) => 0,
                    Bound::Offset(_, false) => 1,
                    Bound::Current => 2,
                    Bound::Offset(_, true) => 3,
                    Bound::Unbounded(true) => 4,
                };
        if matches!(start,Bound::Unbounded(true)) ||
                    matches!(end,Bound::Unbounded(false)) ||
                category(end) < category(start) {
            return Err("unsupported frame specification".into())
        }
        for b in [start, end] {
            if let Bound::Offset(e, _) = b {
                if !column_refs(e).is_empty() || has_subquery(e) || has_agg(e)
                            || has_window(e) || nondeterministic(e) {
                    return Err("frame offset must be constant".into())
                }
                self.validate_expr(e, c)?;
                let v = self.eval(e, c, None, 0)?.apply('N');
                if !matches!(v,V::Int(_)|V::Real(_)) || !v.f64().is_finite()
                        || v.f64() < 0.0 {
                    return Err("frame offset must be a non-negative number".into())
                }
                if w.frame.as_deref() != Some("RANGE") &&
                        v.f64().fract() != 0.0 {
                    return Err("frame offset must be a non-negative integer".into())
                }
                if w.frame.as_deref() == Some("RANGE") && w.order.len() != 1 {
                    return Err("RANGE with offset requires one ORDER BY expression".into())
                }
            }
        }
        Ok(())
    }
    fn validate_expr(&self, e: &E, c: &Ctx) -> Res<()> {
        match e {
            E::Col(_) => { self.eval(e, c, None, 0)?; }
            E::Quoted(_) | E::Val(_) | E::Bound(_, _, _, _) => {}
            E::Bin(_, a, b) => {
                self.validate_expr(a, c)?;
                self.validate_expr(b, c)?
            }
            E::Like(a, b, esc, _, _) => {
                self.validate_expr(a, c)?;
                self.validate_expr(b, c)?;
                if let Some(e) = esc { self.validate_expr(e, c)? }
            }
            E::Unary(_, a) | E::Cast(a, _) => self.validate_expr(a, c)?,
            E::Collate(a, name) => {
                if !["BINARY", "NOCASE",
                                    "RTRIM"].contains(&name.to_ascii_uppercase().as_str()) {
                    return Err(format!("no such collation sequence: {}",name))
                }
                self.validate_expr(a, c)?
            }
            E::Call(n, args, distinct, filter) => {
                let n = n.to_ascii_lowercase();
                crate::funcs::check_arity(&n, args.len())?;
                let aggregate = is_aggregate(&n, args.len());
                if is_window_builtin(&n) {
                    return Err(format!("misuse of window function {}()",n))
                }
                if args.iter().any(|e| matches!(e,E::Star(_))) &&
                        (n != "count" || *distinct) {
                    return Err("invalid use of * in function".into())
                }
                if *distinct && aggregate && args.len() != 1 {
                    return Err("DISTINCT aggregates must have exactly one argument".into())
                }
                if filter.is_some() && !aggregate {
                    return Err("FILTER may only be used with aggregate functions".into())
                }
                if aggregate &&
                        (args.iter().any(|e| has_agg(e) || has_window(e)) ||
                                filter.as_ref().is_some_and(|e|
                                        has_agg(e) || has_window(e))) {
                    return Err("misuse of nested aggregate or window function".into())
                }
                for (i, a) in args.iter().enumerate() {
                    if !(n == "raise" && i == 0) && !matches!(a,E::Star(_)) {
                        self.validate_expr(a, c)?
                    }
                }
                if let Some(e) = filter { self.validate_expr(e, c)? }
            }
            E::Window(call, w) => {
                let (name, args, distinct, filter) =
                    match call.as_ref() {
                        E::Call(n, a, d, f) => (key(n), a, *d, f),
                        _ =>
                            return Err("ORDER BY arguments are not supported for window functions".into()),
                    };
                crate::funcs::check_arity(&name, args.len())?;
                if !is_window_builtin(&name) &&
                        !is_aggregate(&name, args.len()) {
                    return Err(format!("{}() may not be used as a window function",name))
                }
                if distinct {
                    return Err("DISTINCT is not supported for window functions".into())
                }
                if filter.is_some() && !is_aggregate(&name, args.len()) {
                    return Err("FILTER may only be used with aggregate window functions".into())
                }
                for e in args {
                    if has_window(e) {
                        return Err("misuse of nested window function".into())
                    }
                    if matches!(e,E::Star(_)) {
                        if name != "count" { return Err("invalid use of *".into()) }
                    } else { self.validate_expr(e, c)? }
                }
                if let Some(e) = filter {
                    if has_window(e) {
                        return Err("misuse of window function in FILTER".into())
                    }
                    self.validate_expr(e, c)?
                }
                let named =
                    c.win.as_ref().ok_or("misuse of window function")?;
                let w = resolve_window(w, &named.named, &mut vec![])?;
                self.validate_window_frame(&w, c)?;
                for e in
                    w.partition.iter().chain(w.order.iter().map(|o| &o.e)) {
                    if has_window(e) {
                        return Err("misuse of nested window function".into())
                    }
                    self.validate_expr(e, c)?;
                }
            }
            E::OrderedCall(call, orders) => {
                if !matches!(call.as_ref(),E::Call(n,a,_,_) if
                            is_aggregate(&key(n),a.len())) {
                    return Err("ORDER BY may only be used with aggregate functions".into())
                }
                self.validate_expr(call, c)?;
                for o in orders {
                    if has_agg(&o.e) || has_window(&o.e) {
                        return Err("misuse of nested aggregate or window function".into())
                    }
                    self.validate_expr(&o.e, c)?;
                }
            }
            E::Between(a, b, d, _) => {
                self.validate_expr(a, c)?;
                self.validate_expr(b, c)?;
                self.validate_expr(d, c)?
            }
            E::In(e, list, q, _) => {
                self.validate_expr(e, c)?;
                for e in list { self.validate_expr(e, c)? }
                if let Some(q) = q {
                    let mut bind = c.clone();
                    bind.binding = true;
                    self.query(q, &bind, 1)?;
                }
            }
            E::Case(base, arms, end) => {
                if let Some(e) = base { self.validate_expr(e, c)? }
                for (a, b) in arms {
                    self.validate_expr(a, c)?;
                    self.validate_expr(b, c)?
                }
                if let Some(e) = end { self.validate_expr(e, c)? }
            }
            E::Sub(q) | E::SubCol(q, _) | E::Exists(q) => {
                let mut bind = c.clone();
                bind.binding = true;
                self.query(q, &bind, 1)?;
            }
            E::Tuple(es) => { for e in es { self.validate_expr(e, c)? } }
            E::Star(_) => {}
        }
        Ok(())
    }
    fn rowctx(&self, t: &Table, row: &Row, alias: Option<&str>) -> Ctx {
        let mut d = self.table_data(t, alias.unwrap_or(&t.name));
        let mut v = row.v.clone();
        while v.len() < d.fields.len() { v.push(V::Int(row.id)) }
        Ctx {
            fields: std::mem::take(&mut d.fields),
            row: v,
            outer: self.trigger_ctx.clone().map(Box::new),
            ctes: self.trigger_ctx.as_ref().map(|c|
                        c.ctes.clone()).unwrap_or_default(),
            ..Default::default()
        }
    }
    fn prepare_row(&self, t: &Table, mut v: Vec<V>, requested: Option<V>,
        oldid: Option<i64>) -> Res<Row> {
        let pk = integer_pk(t);
        let requested =
            if let Some(i) = pk {
                if !v[i].null() { Some(v[i].clone()) } else { requested }
            } else { requested };
        let id =
            if let Some(v) = requested.filter(|v| !v.null()) {
                let n = v.apply('N');
                if let V::Int(i) = n {
                    i
                } else { return Err("datatype mismatch".into()) }
            } else if let Some(i) = oldid {
                i
            } else {
                let max = t.rows.iter().map(|r| r.id).max().unwrap_or(0);
                let max =
                    if t.cols.iter().any(|c| c.auto) {
                        max.max(t.seq)
                    } else { max };
                if max == i64::MAX && !t.cols.iter().any(|c| c.auto) {
                    (1..=1000).find(|id|
                                    !t.rows.iter().any(|r|
                                                r.id == *id)).ok_or("database or disk is full")?
                } else {
                    max.checked_add(1).ok_or("database or disk is full")?
                }
            };
        if let Some(i) = pk { v[i] = V::Int(id) }
        for (i, c) in t.cols.iter().enumerate() {
            if !(t.strict && c.typ.eq_ignore_ascii_case("ANY")) {
                v[i] = v[i].apply(affinity(&c.typ))
            }
        }
        let mut row = Row { id, v };
        for _ in 0..t.cols.len().max(1) {
            for (i, c) in t.cols.iter().enumerate() {
                if let Some(e) = &c.generated {
                    let ctx = self.rowctx(t, &row, None);
                    row.v[i] =
                        self.eval(e, &ctx, None, 0)?.apply(affinity(&c.typ))
                }
            }
        }
        for (i, c) in t.cols.iter().enumerate() {
            if row.v[i].null() &&
                    (c.notnull || ((t.without || t.strict) && c.pk > 0)) {
                return Err(format!("NOT NULL constraint failed: {}.{}",t.name,c.name))
            }
            if t.strict && !row.v[i].null() {
                let valid =
                    match c.typ.to_ascii_uppercase().as_str() {
                        "INT" | "INTEGER" => matches!(row.v[i],V::Int(_)),
                        "REAL" => matches!(row.v[i],V::Real(_)|V::Int(_)),
                        "TEXT" => matches!(row.v[i],V::Text(_)),
                        "BLOB" => matches!(row.v[i],V::Blob(_)),
                        "ANY" => true,
                        _ => false,
                    };
                if !valid {
                    return Err(format!("cannot store {} value in {} column {}.{}",row.v[i].kind(),c.typ,t.name,c.name))
                }
            }
        }
        let ctx = self.rowctx(t, &row, None);
        for e in &t.checks {
            if !self.pragmas.get("ignore_check_constraints").map_or(false,
                            |v| v.i64() != 0) &&
                    self.eval(e, &ctx, None, 0)?.truth() == Some(false) {
                return Err(format!("CHECK constraint failed: {}",t.name))
            }
        }
        Ok(row)
    }
    fn conflicts(&self, t: &Table, row: &Row, skip: Option<usize>)
        -> Res<Vec<usize>> {
        let mut out = vec![];
        let mut constraints = t.unique.clone();
        let pk =
            t.cols.iter().filter(|c|
                            c.pk > 0).map(|c| c.name.clone()).collect::<Vec<_>>();
        if !pk.is_empty() { constraints.push(pk) }
        for c in &t.cols {
            if c.unique { constraints.push(vec![c.name.clone()]) }
        }
        let ctx = self.rowctx(t, row, None);
        for (i, r) in t.rows.iter().enumerate() {
            if Some(i) == skip { continue }
            let mut hit = !t.without && r.id == row.id;
            for cols in &constraints {
                let mut same = true;
                for n in cols {
                    let j =
                        t.cols.iter().position(|c|
                                        c.name.eq_ignore_ascii_case(n)).ok_or("no such column in constraint")?;
                    if row.v[j].null() || r.v[j].null() ||
                            cmp(&row.v[j], &r.v[j], &t.cols[j].coll) != Ordering::Equal
                        {
                        same = false;
                        break
                    }
                }
                hit |= same
            }
            for idx in
                self.db.indexes.values().filter(|idx|
                        idx.unique && idx.table.eq_ignore_ascii_case(&t.name)) {
                let old = self.rowctx(t, r, None);
                if let Some(f) = &idx.filter {
                    if self.eval(f, &ctx, None, 0)?.truth() != Some(true) ||
                            self.eval(f, &old, None, 0)?.truth() != Some(true) {
                        continue
                    }
                }
                let mut same = true;
                for e in &idx.expr {
                    let x = self.eval(e, &ctx, None, 0)?;
                    let y = self.eval(e, &old, None, 0)?;
                    if x.null() || y.null() ||
                            cmp(&x, &y, &self.metadata(e, &ctx).1) != Ordering::Equal {
                        same = false;
                        break
                    }
                }
                hit |= same
            }
            if hit { out.push(i) }
        }
        Ok(out)
    }
    fn error_policy(&self, t: &Table, error: &str, mode: &str) -> String {
        if !error.contains("constraint failed") { return "ABORT".into() }
        if mode != "DEFAULT" { return mode.into() }
        for c in &t.cols {
            if error ==
                    format!("NOT NULL constraint failed: {}.{}",t.name,c.name) {
                return c.policies.get("nn").cloned().unwrap_or("ABORT".into())
            }
        }
        "ABORT".into()
    }
    fn unique_policy(&self, t: &Table, row: &Row, conflicts: &[usize],
        mode: &str) -> String {
        if mode != "DEFAULT" { return mode.into() }
        let mut policies = t.policies.clone();
        for c in &t.cols {
            if c.unique {
                policies.push((vec![c.name.clone()],
                        c.policies.get("uq").cloned().unwrap_or("ABORT".into())))
            }
            if c.pk > 0 {
                policies.push((vec![c.name.clone()],
                        c.policies.get("pk").cloned().unwrap_or("ABORT".into())))
            }
        }
        for (cols, policy) in policies {
            if conflicts.iter().any(|&i|
                        cols.iter().all(|n|
                                t.cols.iter().position(|c|
                                            c.name.eq_ignore_ascii_case(n)).map_or(false,
                                    |j|
                                        !row.v[j].null() &&
                                            cmp(&row.v[j], &t.rows[i].v[j], &t.cols[j].coll) ==
                                                Ordering::Equal))) {
                return policy
            }
        }
        "ABORT".into()
    }
    fn unique_error(&self, t: &Table) -> String {
        let names =
            t.cols.iter().filter(|c|
                            c.pk > 0 ||
                                c.unique).map(|c|
                        format!("{}.{}",t.name,c.name)).collect::<Vec<_>>();
        format!("UNIQUE constraint failed: {}",if
            names.is_empty(){t.name.clone()}else{names.join(", ")})
    }
    fn check_foreign(&self, include_deferred: bool) -> Res<()> {
        if !self.foreign_keys { return Ok(()) }
        for t in self.db.tables.values() {
            if t.rows.is_empty() { continue }
            for f in &t.foreign {
                if !include_deferred &&
                        (f.deferred ||
                                self.pragmas.get("defer_foreign_keys").map_or(false,
                                    |v| v.i64() != 0)) {
                    continue
                }
                let parent =
                    self.db.tables.get(&key(&f.table)).ok_or_else(||
                                format!("no such table: main.{}",f.table))?;
                let target =
                    if f.target.is_empty() {
                        let mut cs =
                            parent.cols.iter().filter(|c| c.pk > 0).collect::<Vec<_>>();
                        cs.sort_by_key(|c| c.pk);
                        cs.iter().map(|c| c.name.clone()).collect::<Vec<_>>()
                    } else { f.target.clone() };
                if target.len() != f.cols.len() {
                    return Err("foreign key mismatch".into())
                }
                let mut candidates = parent.unique.clone();
                let mut pk =
                    parent.cols.iter().filter(|c| c.pk > 0).collect::<Vec<_>>();
                pk.sort_by_key(|c| c.pk);
                if !pk.is_empty() {
                    candidates.push(pk.iter().map(|c| c.name.clone()).collect())
                }
                for c in &parent.cols {
                    if c.unique { candidates.push(vec![c.name.clone()]) }
                }
                for idx in
                    self.db.indexes.values().filter(|i|
                            i.unique && i.table.eq_ignore_ascii_case(&parent.name) &&
                                i.filter.is_none()) {
                    let cols =
                        idx.expr.iter().filter_map(|e|
                                    if let E::Col(n) = e {
                                        n.last().cloned()
                                    } else { None }).collect::<Vec<_>>();
                    if cols.len() == idx.expr.len() { candidates.push(cols) }
                }
                if !candidates.iter().any(|c|
                                c.len() == target.len() &&
                                    c.iter().zip(&target).all(|(a, b)|
                                            a.eq_ignore_ascii_case(b))) {
                    return Err("foreign key mismatch".into())
                }
                let ci =
                    f.cols.iter().map(|n|
                                    t.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                            _>>()?;
                let pi =
                    target.iter().map(|n|
                                    parent.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                            _>>()?;
                for row in &t.rows {
                    if ci.iter().any(|&i| row.v[i].null()) { continue }
                    if !parent.rows.iter().any(|p|
                                    ci.iter().zip(&pi).all(|(&c, &i)|
                                            cmp(&row.v[c].apply(affinity(&parent.cols[i].typ)), &p.v[i],
                                                    &parent.cols[i].coll) == Ordering::Equal)) {
                        return Err("FOREIGN KEY constraint failed".into())
                    }
                }
            }
        }
        Ok(())
    }
    fn returning(&self, items: &[Item], t: &Table, rows: &[Row])
        -> Res<ResultSet> {
        if items.is_empty() { return Ok(ResultSet::default()) }
        let mut expanded = vec![];
        for item in items {
            if matches!(item.e,E::Star(_)) {
                for c in &t.cols {
                    expanded.push(Item {
                            e: E::Col(vec![c.name.clone()]),
                            name: c.name.clone(),
                            alias: None,
                        })
                }
            } else { expanded.push(item.clone()) }
        }
        let ctx =
            self.rowctx(t, &Row { id: 0, v: vec![V::Null;t.cols.len()] },
                None);
        for i in &expanded {
            if has_agg(&i.e) || has_window(&i.e) {
                return Err("misuse of aggregate or window function in RETURNING".into())
            }
            self.validate_expr(&i.e, &ctx)?;
        }
        let mut result =
            ResultSet {
                items: vec![],
                coll_sources: vec![],
                affinities: vec![],
                columns: expanded.iter().map(|i| i.name.clone()).collect(),
                rows: vec![],
            };
        for row in rows {
            let c = self.rowctx(t, row, None);
            result.rows.push(expanded.iter().map(|i|
                                self.eval(&i.e, &c, None, 0)).collect::<Res<_>>()?)
        }
        Ok(result)
    }
    fn run(&mut self, mut s: Stmt, sql: &str) -> Res<ResultSet> {
        if matches!(s,Stmt::Insert{..}|Stmt::Update{..}|Stmt::Delete{..}|Stmt::Drop(_,_,_)|Stmt::Alter(_,_))
            {
            if let Some(target) = statement_target(&s) {
                if !target.contains('.') &&
                                    !self.db.tables.contains_key(&key(target)) &&
                                !self.db.views.contains_key(&key(target)) &&
                            !self.db.indexes.contains_key(&key(target)) &&
                        !self.db.triggers.contains_key(&key(target)) {
                    let schema =
                        self.attach_order.iter().find(|name|
                                    {
                                        let db = &self.attached[*name].db;
                                        db.tables.contains_key(&key(target)) ||
                                                    db.views.contains_key(&key(target)) ||
                                                db.indexes.contains_key(&key(target)) ||
                                            db.triggers.contains_key(&key(target))
                                    }).cloned();
                    if let Some(schema) = schema {
                        qualify_target(&mut s, &schema)
                    }
                }
            }
        }
        if let Some(target) = statement_target(&s) {
            if let Some((schema, _)) = target.split_once('.') {
                let schema = schema.to_string();
                let mut routed = s.clone();
                self.materialize_inputs(&mut routed)?;
                strip_target(&mut routed, &schema);
                let db =
                    self.attached.get_mut(&key(&schema)).ok_or_else(||
                                format!("unknown database {}",schema))?;
                let before_total = db.total;
                let result =
                    db.execute_stmt(routed, &strip_schema(sql, &schema)?);
                self.total += db.total - before_total;
                if dml_kind(&s).is_some() {
                    self.changes = db.changes;
                    self.last = db.last;
                }
                return result;
            }
        }
        let seqmut =
            matches!(&s,Stmt::Insert{table,..}|Stmt::Update{table,..}|Stmt::Delete{table,..}
                if table.eq_ignore_ascii_case("sqlite_sequence"));
        if seqmut && !self.db.tables.contains_key("sqlite_sequence") {
            if !self.db.sequence_created {
                return Err("no such table: sqlite_sequence".into())
            }
            let t = self.sequence_table();
            self.db.tables.insert("sqlite_sequence".into(), t);
            let result = self.run(s, sql);
            if let Some(t) = self.db.tables.remove("sqlite_sequence") {
                self.db.sequences = t.rows;
            }
            return result;
        }
        let view =
            match &s {
                Stmt::Insert { table, .. } | Stmt::Update { table, .. } |
                    Stmt::Delete { table, .. } =>
                    self.db.views.contains_key(&key(table)) &&
                        !self.db.tables.contains_key(&key(table)),
                _ => false,
            };
        if view { return self.mutate_view(s) }
        match s {
            Stmt::Attach(path, name) => {
                let k = key(&name);
                if k == "main" || k == "temp" ||
                        self.attached.contains_key(&k) {
                    return Err(format!("database {} is already in use",name))
                }
                if self.attached.len() >= 10 {
                    return Err("too many attached databases".into())
                }
                let path =
                    self.eval(&path, &self.root_ctx(), None, 0)?.text();
                let mut db = Self::open(&path)?;
                db.foreign_keys = self.foreign_keys;
                db.pragmas = self.pragmas.clone();
                if !self.txn.is_empty(){db.txn=self.txn.iter().map(|(n,_)|(n.clone(),db.db.clone())).collect();}
                self.attach_order.push(k.clone());
                self.attached.insert(k, db);
                Ok(ResultSet::default())
            }
            Stmt::Detach(name) => {
                let k = key(&name);
                if k == "main" || k == "temp" {
                    return Err(format!("cannot detach database {}",name))
                }
                let db =
                    self.attached.get(&k).ok_or_else(||
                                format!("no such database: {}",name))?;
                if !db.txn.is_empty() {
                    return Err(format!("database {} is locked",name))
                }
                self.attached.remove(&k);
                self.attach_order.retain(|n| n != &k);
                Ok(ResultSet::default())
            }
            Stmt::Temp(stmt) => {
                let version = self.db.schema_version;
                let (kind, name) =
                    match stmt.as_ref() {
                        Stmt::CreateTable { name, .. } => ("table", name.clone()),
                        Stmt::CreateView { name, .. } => ("view", name.clone()),
                        Stmt::CreateIndex { name, .. } => ("index", name.clone()),
                        Stmt::CreateTrigger(t, _) => ("trigger", t.name.clone()),
                        _ => return Err("TEMP requires a schema object".into()),
                    };
                let r = self.run(*stmt, sql)?;
                let k = key(&name);
                match kind {
                    "table" => {
                        if let Some(t) = self.db.tables.get_mut(&k) {
                            t.temporary = true
                        }
                        for i in
                            self.db.indexes.values_mut().filter(|i|
                                    i.table.eq_ignore_ascii_case(&name)) {
                            i.temporary = true
                        }
                    }
                    "view" => {
                        if let Some(v) = self.db.views.get_mut(&k) {
                            v.temporary = true
                        }
                    }
                    "index" => {
                        if let Some(i) = self.db.indexes.get_mut(&k) {
                            i.temporary = true
                        }
                    }
                    _ => {
                        if let Some(t) = self.db.triggers.get_mut(&k) {
                            t.temporary = true
                        }
                    }
                }
                self.db.schema_version = version;
                Ok(r)
            }
            Stmt::With(mut q, stmt) => {
                let mut ctx = self.root_ctx();
                for (n, cols, _) in q.ctes.clone() {
                    q.items =
                        vec![Item{e:E::Star(None),name:"*".into(),alias:None}];
                    q.from =
                        vec![Join{source:Source::Table(n.clone()),alias:None,kind:"INNER".into(),on:None,using:vec![],natural:false}];
                    let r = self.query(&q, &ctx, 0)?;
                    let names = if cols.is_empty() { r.columns } else { cols };
                    ctx.ctes.insert(key(&n),
                        Arc::new(Data {
                                fields: names.iter().map(|s|
                                            field(&n, s, 'B', "BINARY", false)).collect(),
                                rows: r.rows,
                            }));
                }
                let saved = self.trigger_ctx.replace(ctx);
                let result = self.run(*stmt, sql);
                self.trigger_ctx = saved;
                result
            }
            Stmt::Explain(stmt, plan) => {
                if plan {
                    let mut rows = vec![];
                    if let Stmt::Query(q) = *stmt {
                        let mut bind=self.root_ctx();bind.binding=true;self.query(&q,&bind,0)?;
                        for (i, j) in q.from.iter().enumerate() {
                            let name =
                                match &j.source {
                                    Source::Table(n) | Source::Function(n, _) => n.clone(),
                                    Source::Query(_) => "SUBQUERY".into(),
                                    Source::Join(_) => "JOIN".into(),
                                };
                            rows.push(vec![V::Int(i as
                                    i64+2),V::Int(0),V::Int(0),V::Text(format!("SCAN {}",j.alias.as_ref().unwrap_or(&name)))])
                        }
                        if rows.is_empty() {
                            rows.push(vec![V::Int(1),V::Int(0),V::Int(0),V::Text("SCAN CONSTANT ROW".into())])
                        }
                    }
                    Ok(ResultSet {
                            items: vec![],
                            coll_sources: vec![],
                            affinities: vec![],
                            columns: ["id", "parent", "notused",
                                                "detail"].iter().map(|s| s.to_string()).collect(),
                            rows,
                        })
                } else {
                    Err("EXPLAIN bytecode is unavailable for this execution architecture".into())
                }
            }
            Stmt::CreateTrigger(t, ifnot) => {
                let k = key(&t.name);
                if self.db.triggers.contains_key(&k) {
                    if ifnot { return Ok(ResultSet::default()) }
                    return Err(format!("trigger {} already exists",t.name))
                }
                if !self.db.tables.contains_key(&key(&t.table)) &&
                        !self.db.views.contains_key(&key(&t.table)) {
                    return Err(format!("no such table: {}",t.table))
                }
                self.db.triggers.insert(k, t);
                self.db.schema_version += 1;
                Ok(ResultSet::default())
            }
            Stmt::Query(q) => self.query(&q, &self.root_ctx(), 0),
            Stmt::Begin => {
                if !self.txn.is_empty() {
                    return Err("cannot start a transaction within a transaction".into())
                }
                for db in self.attached.values_mut() { db.execute(sql)?; }
                self.txn.push((String::new(), self.db.clone()));
                self.snapshot_active =
                    lex(sql)?.iter().any(|t|
                            t.s.eq_ignore_ascii_case("IMMEDIATE") ||
                                t.s.eq_ignore_ascii_case("EXCLUSIVE"));
                Ok(ResultSet::default())
            }
            Stmt::Commit => {
                if self.txn.is_empty() {
                    return Err("cannot commit - no transaction is active".into())
                }
                self.check_foreign(true)?;
                for db in self.attached.values() { db.check_foreign(true)?; }
                self.persist_transaction()?;
                self.finish_transaction();
                Ok(ResultSet::default())
            }
            Stmt::Rollback(n) => {
                for db in self.attached.values_mut() {
                    if !db.txn.is_empty() { db.execute(sql)?; }
                }
                if let Some(n) = n {
                    let i =
                        self.txn.iter().rposition(|(s, _)|
                                        s.eq_ignore_ascii_case(&n)).ok_or_else(||
                                    format!("no such savepoint: {}",n))?;
                    self.db = self.txn[i].1.clone();
                    self.txn.truncate(i + 1)
                } else {
                    if self.txn.is_empty() {
                        return Err("cannot rollback - no transaction is active".into())
                    }
                    self.db = self.txn[0].1.clone();
                    self.finish_transaction()
                }
                Ok(ResultSet::default())
            }
            Stmt::Savepoint(n) => {
                for db in self.attached.values_mut() { db.execute(sql)?; }
                self.txn.push((n, self.db.clone()));
                Ok(ResultSet::default())
            }
            Stmt::Release(n) => {
                let i =
                    self.txn.iter().rposition(|(s, _)|
                                    s.eq_ignore_ascii_case(&n)).ok_or_else(||
                                format!("no such savepoint: {}",n))?;
                if i == 0 {
                    self.check_foreign(true)?;
                    for db in self.attached.values() {
                        db.check_foreign(true)?;
                    }
                }
                if i==0{self.persist_transaction()?;self.finish_transaction()}
                else{for db in self.attached.values_mut(){db.execute(sql)?;}self.txn.truncate(i)}
                Ok(ResultSet::default())
            }
            Stmt::CreateTable {
                name,
                ifnot,
                mut cols,
                unique,
                policies,
                checks,
                foreign,
                without,
                strict,
                asq } => {
                let k = key(&name);
                if self.db.tables.contains_key(&k) ||
                        self.db.views.contains_key(&k) {
                    if ifnot { return Ok(ResultSet::default()) }
                    return Err(format!("table {} already exists",name))
                }
                if k.starts_with("sqlite_") {
                    return Err("object name reserved for internal use".into())
                }
                if self.db.indexes.contains_key(&k) {
                    return Err(format!("there is already an index named {}",name))
                }
                let mut rows = vec![];
                if let Some(q) = asq {
                    let r = self.query(&q, &self.root_ctx(), 0)?;
                    for (i, n) in r.columns.into_iter().enumerate() {
                        let typ =
                            r.affinities.get(i).map(|(a, _)|
                                            match a {
                                                'I' => "INT",
                                                'T' => "TEXT",
                                                'R' => "REAL",
                                                'N' => "NUM",
                                                _ => "",
                                            }).unwrap_or("").to_string();
                        cols.push(Column {
                                policies: Default::default(),
                                name: n,
                                typ,
                                notnull: false,
                                pk: 0,
                                unique: false,
                                default: None,
                                default_sql: None,
                                coll: "BINARY".into(),
                                auto: false,
                                pk_desc: false,
                                generated: None,
                                stored: false,
                            })
                    }
                    rows =
                        r.rows.into_iter().enumerate().map(|(i, v)|
                                    Row { id: i as i64 + 1, v }).collect();
                }
                if cols.iter().filter(|c| c.pk == 1).count() > 1 {
                    return Err("table has more than one primary key".into())
                }
                if cols.iter().all(|c| c.generated.is_some()) {
                    return Err("must have at least one non-generated column".into())
                }
                for (i, c) in cols.iter().enumerate() {
                    if !["BINARY", "NOCASE",
                                        "RTRIM"].contains(&c.coll.to_ascii_uppercase().as_str()) {
                        return Err(format!("no such collation sequence: {}",c.coll))
                    }
                    if c.generated.is_some() &&
                            (c.pk > 0 || c.default.is_some()) {
                        return Err("generated columns cannot have a PRIMARY KEY or DEFAULT".into())
                    }
                    if cols[..i].iter().any(|x|
                                x.name.eq_ignore_ascii_case(&c.name)) {
                        return Err(format!("duplicate column name: {}",c.name))
                    }
                    if strict &&
                            !["INT", "INTEGER", "REAL", "TEXT", "BLOB",
                                            "ANY"].contains(&c.typ.to_ascii_uppercase().as_str()) {
                        return Err(format!("unknown datatype for {}.{}: {}",name,c.name,c.typ))
                    }
                    if c.auto &&
                            (c.typ.to_ascii_uppercase() != "INTEGER" || c.pk == 0 ||
                                        without || c.pk_desc) {
                        return Err("AUTOINCREMENT is only allowed on an INTEGER PRIMARY KEY".into())
                    }
                }
                if without && !cols.iter().any(|c| c.pk > 0) {
                    return Err(format!("PRIMARY KEY missing on table {}",name))
                }
                let t =
                    Table {
                        temporary: false,
                        name,
                        cols,
                        unique,
                        policies,
                        checks,
                        foreign,
                        without,
                        strict,
                        rows,
                        seq: 0,
                        sql: sql.trim().trim_end_matches(';').into(),
                    };
                if t.cols.iter().any(|c| c.auto) {
                    self.db.sequence_created = true;
                }
                let nullrow = Row { id: 0, v: vec![V::Null;t.cols.len()] };
                let ctx = self.rowctx(&t, &nullrow, None);
                for cols in &t.unique {
                    for n in cols {
                        if !t.cols.iter().any(|c| c.name.eq_ignore_ascii_case(n)) {
                            return Err(format!("no such column: {}",n))
                        }
                    }
                }
                for e in &t.checks {
                    if has_agg(e) || has_window(e) || has_subquery(e) {
                        return Err("subqueries and aggregates prohibited in CHECK constraints".into())
                    }
                    self.validate_expr(e, &ctx)?;
                }
                for c in &t.cols {
                    if let Some(e) = &c.default {
                        if has_subquery(e) || has_agg(e) || has_window(e) {
                            return Err("default value is not constant".into())
                        }
                        self.validate_expr(e, &self.root_ctx())?;
                    }
                    if let Some(e) = &c.generated {
                        if has_agg(e) || has_window(e) || has_subquery(e) ||
                                nondeterministic(e) {
                            return Err("invalid generated column expression".into())
                        }
                        self.validate_expr(e, &ctx)?;
                    }
                }
                for i in 0..t.cols.len() {
                    if generated_cycle(&t, i, &mut vec![]) {
                        return Err(format!("generated column loop on {}",t.cols[i].name))
                    }
                }
                let mut constraints = vec![];
                let mut pk =
                    t.cols.iter().filter(|c| c.pk > 0).collect::<Vec<_>>();
                pk.sort_by_key(|c| c.pk);
                if !pk.is_empty() && integer_pk(&t).is_none() {
                    constraints.push(("pk",
                            pk.iter().map(|c| c.name.clone()).collect::<Vec<_>>()))
                }
                for c in &t.cols {
                    if c.unique {
                        constraints.push(("u", vec![c.name.clone()]))
                    }
                }
                for cols in &t.unique {
                    constraints.push(("u", cols.clone()))
                }
                for (i, (origin, cols)) in constraints.into_iter().enumerate()
                    {
                    let name = format!("sqlite_autoindex_{}_{}",t.name,i+1);
                    let expr =
                        cols.iter().map(|n| E::Col(vec![n.clone()])).collect();
                    self.db.indexes.insert(key(&name),
                        Index {
                            temporary: false,
                            origin: origin.into(),
                            name,
                            table: t.name.clone(),
                            unique: true,
                            desc: vec![false;cols.len()],
                            expr,
                            filter: None,
                            sql: String::new(),
                        });
                }
                self.db.tables.insert(k, t);
                self.db.schema_version += 1;
                Ok(ResultSet::default())
            }
            Stmt::CreateIndex { name, table, unique, ifnot, expr, desc, filter
                } => {
                let k = key(&name);
                if k.starts_with("sqlite_") {
                    return Err("object name reserved for internal use".into())
                }
                if self.db.tables.contains_key(&k) ||
                        self.db.views.contains_key(&k) {
                    return Err(format!("there is already a table named {}",name))
                }
                if self.db.indexes.contains_key(&k) {
                    if ifnot { return Ok(ResultSet::default()) }
                    return Err(format!("index {} already exists",name))
                }
                let t =
                    self.db.tables.get(&key(&table)).ok_or_else(||
                                format!("no such table: {}",table))?;
                let c =
                    self.rowctx(t,
                        &Row { id: 0, v: vec![V::Null;t.cols.len()] }, None);
                for e in &expr {
                    if has_agg(e) || has_window(e) || has_subquery(e) ||
                            nondeterministic(e) {
                        return Err("invalid expression in index".into())
                    }
                    self.validate_expr(e, &c)?;
                }
                if let Some(e) = &filter { self.validate_expr(e, &c)?; }
                let mut seen: Vec<Vec<V>> = vec![];
                for row in &t.rows {
                    let c = self.rowctx(t, row, None);
                    if let Some(f) = &filter {
                        if self.eval(f, &c, None, 0)?.truth() != Some(true) {
                            continue
                        }
                    }
                    let v =
                        expr.iter().map(|e|
                                        self.eval(e, &c, None, 0)).collect::<Res<Vec<_>>>()?;
                    if unique && !v.iter().any(V::null) &&
                            seen.iter().any(|r|
                                    r.iter().zip(&v).zip(&expr).all(|((a, b), e)|
                                            cmp(a, b, &self.metadata(e, &c).1) == Ordering::Equal)) {
                        return Err(self.unique_error(t))
                    }
                    seen.push(v)
                }
                self.db.indexes.insert(k,
                    Index {
                        temporary: false,
                        origin: "c".into(),
                        name,
                        table,
                        unique,
                        expr,
                        desc,
                        filter,
                        sql: sql.trim().trim_end_matches(';').into(),
                    });
                self.db.schema_version += 1;
                Ok(ResultSet::default())
            }
            Stmt::CreateView { name, cols, q, ifnot } => {
                let k = key(&name);
                if self.db.views.contains_key(&k) ||
                        self.db.tables.contains_key(&k) {
                    if ifnot { return Ok(ResultSet::default()) }
                    return Err(format!("view {} already exists",name))
                }
                self.db.views.insert(k,
                    View {
                        temporary: false,
                        name,
                        cols,
                        q,
                        sql: sql.trim().trim_end_matches(';').into(),
                    });
                self.db.schema_version += 1;
                Ok(ResultSet::default())
            }
            Stmt::Drop(kind, name, exists) => {
                let k = key(&name);
                if kind == "TABLE" && k == "sqlite_sequence" {
                    return Err("table sqlite_sequence may not be dropped".into())
                }
                if kind == "INDEX" &&
                        self.db.indexes.get(&k).map_or(false, |i| i.origin != "c") {
                    return Err("index associated with UNIQUE or PRIMARY KEY constraint cannot be dropped".into())
                }
                let removed =
                    match kind.as_str() {
                        "TABLE" => {
                            if self.foreign_keys {
                                if let Some(t) = self.db.tables.get(&k).cloned() {
                                    let mut empty = t.clone();
                                    empty.rows.clear();
                                    self.db.tables.insert(k.clone(), empty);
                                    self.cascade_delete(&t, &t.rows, 0)?;
                                    self.check_foreign(self.txn.is_empty())?;
                                }
                            }
                            let r = self.db.tables.remove(&k).is_some();
                            self.db.sequences.retain(|r|
                                    r.v.first().map_or(true,
                                        |v| !v.text().eq_ignore_ascii_case(&name)));
                            self.db.indexes.retain(|_, i|
                                    !i.table.eq_ignore_ascii_case(&name));
                            self.db.triggers.retain(|_, i|
                                    !i.table.eq_ignore_ascii_case(&name));
                            r
                        }
                        "TRIGGER" => self.db.triggers.remove(&k).is_some(),
                        "INDEX" => self.db.indexes.remove(&k).is_some(),
                        "VIEW" => self.db.views.remove(&k).is_some(),
                        _ => false,
                    };
                if !removed && !exists {
                    return Err(format!("no such {}: {}",kind.to_ascii_lowercase(),name))
                }
                self.db.schema_version += 1;
                Ok(ResultSet::default())
            }
            Stmt::Insert { table, cols, q, default, mode, returning, upsert }
                => {
                let k = key(&table);
                let mut t =
                    self.db.tables.get(&k).cloned().ok_or_else(||
                                format!("no such table: {}",table))?;
                if t.cols.iter().any(|c| c.auto) {
                    t.seq =
                        self.db.sequences.iter().find(|r|
                                            r.v.first().map_or(false,
                                                |v|
                                                    v.text() ==
                                                        t.name)).and_then(|r| r.v.get(1)).map(V::i64).unwrap_or(0);
                }
                let target: Vec<String> =
                    if cols.is_empty() {
                        t.cols.iter().filter(|c|
                                        c.generated.is_none()).map(|c| c.name.clone()).collect()
                    } else { cols };
                let mut mapping = vec![];
                for n in &target {
                    if let Some(i) =
                            t.cols.iter().position(|c| c.name.eq_ignore_ascii_case(n)) {
                        if t.cols[i].generated.is_some() {
                            return Err(format!("cannot INSERT into generated column {}",n))
                        }
                        mapping.push(Some(i))
                    } else if !t.without &&
                            ["rowid", "oid", "_rowid_"].contains(&key(n).as_str()) {
                        mapping.push(None)
                    } else {
                        return Err(format!("table {} has no column named {}",table,n))
                    }
                }
                if let Some(u) = &upsert {
                    if !u.target.is_empty() {
                        let mut candidates = t.unique.clone();
                        let pk =
                            t.cols.iter().filter(|c|
                                            c.pk > 0).map(|c| c.name.clone()).collect::<Vec<_>>();
                        if !pk.is_empty() { candidates.push(pk) }
                        for c in &t.cols {
                            if c.unique { candidates.push(vec![c.name.clone()]) }
                        }
                        for idx in
                            self.db.indexes.values().filter(|i|
                                    i.unique && i.table.eq_ignore_ascii_case(&t.name)) {
                            let cols =
                                idx.expr.iter().filter_map(|e|
                                            if let E::Col(n) = e {
                                                n.last().cloned()
                                            } else { None }).collect::<Vec<_>>();
                            if cols.len() == idx.expr.len() { candidates.push(cols) }
                        }
                        if !candidates.iter().any(|c|
                                        c.len() == u.target.len() &&
                                            c.iter().all(|n|
                                                    u.target.iter().any(|t| t.eq_ignore_ascii_case(n)))) {
                            return Err("ON CONFLICT clause does not match any PRIMARY KEY or UNIQUE constraint".into())
                        }
                    }
                }
                let inputs =
                    if let Some(q) = q {
                        let r = self.query(&q, &self.root_ctx(), 0)?;
                        if r.columns.len() != target.len() {
                            return Err(format!("{} values for {} columns",r.columns.len(),target.len()))
                        }
                        r.rows
                    } else { vec![vec![]] };
                self.changes = 0;
                let mut changed = vec![];
                for input in inputs {
                    let mut v =
                        t.cols.iter().map(|c|
                                        if let Some(e) = &c.default {
                                            self.eval(e, &self.root_ctx(), None, 0)
                                        } else { Ok(V::Null) }).collect::<Res<Vec<_>>>()?;
                    let mut id = None;
                    if !default {
                        for (i, val) in input.into_iter().enumerate() {
                            if let Some(j) = mapping[i] {
                                v[j] = val
                            } else { id = Some(val) }
                        }
                    }
                    for (i, c) in t.cols.iter().enumerate() {
                        if (mode == "REPLACE" ||
                                            (mode == "DEFAULT" &&
                                                    c.policies.get("nn").map_or(false, |m| m == "REPLACE"))) &&
                                    c.notnull && v[i].null() {
                            if let Some(e) = &c.default {
                                v[i] = self.eval(e, &self.root_ctx(), None, 0)?
                            }
                        }
                    }
                    let row =
                        match self.prepare_row(&t, v, id, None) {
                            Ok(r) => r,
                            Err(e) => {
                                let m = self.error_policy(&t, &e, &mode);
                                if m == "IGNORE" { continue }
                                return Err(policy_error(&m, e))
                            }
                        };
                    if t.cols.iter().any(|c| c.auto) {
                        t.seq = t.seq.max(row.id);
                        self.set_sequence(&t.name, t.seq);
                    }
                    self.db.tables.insert(k.clone(), t.clone());
                    if !self.fire(&t, "INSERT", "BEFORE", None, Some(&row),
                                    &[])? {
                        continue
                    }
                    t = self.db.tables[&k].clone();
                    let conflicts = self.conflicts(&t, &row, None)?;
                    let policy =
                        self.unique_policy(&t, &row, &conflicts, &mode);
                    if !conflicts.is_empty() {
                        if let Some(u) = &upsert {
                            if !u.target.is_empty() {
                                let matches =
                                    conflicts.iter().any(|&i|
                                            u.target.iter().all(|n|
                                                    t.cols.iter().position(|c|
                                                                c.name.eq_ignore_ascii_case(n)).map_or(false,
                                                        |j|
                                                            !row.v[j].null() &&
                                                                cmp(&row.v[j], &t.rows[i].v[j], &t.cols[j].coll) ==
                                                                    Ordering::Equal)));
                                if !matches { return Err(self.unique_error(&t)) }
                            }
                            if u.sets.is_empty() { continue }
                            let i = conflicts[0];
                            let old = t.rows[i].clone();
                            let mut ctx = self.rowctx(&t, &old, None);
                            let excluded = self.rowctx(&t, &row, Some("excluded"));
                            ctx.fields.extend(excluded.fields);
                            ctx.row.extend(excluded.row);
                            if let Some(f) = &u.filter {
                                if self.eval(f, &ctx, None, 0)?.truth() != Some(true) {
                                    continue
                                }
                            }
                            let mut v = old.v.clone();
                            for (n, e) in &u.sets {
                                let j =
                                    t.cols.iter().position(|c|
                                                    c.name.eq_ignore_ascii_case(n)).ok_or_else(||
                                                format!("no such column: {}",n))?;
                                v[j] = self.eval(e, &ctx, None, 0)?
                            }
                            let r = self.prepare_row(&t, v, None, Some(old.id))?;
                            if !self.conflicts(&t, &r, Some(i))?.is_empty() {
                                return Err(self.unique_error(&t))
                            }
                            let setcols =
                                u.sets.iter().map(|(n, _)| n.clone()).collect::<Vec<_>>();
                            self.db.tables.insert(k.clone(), t.clone());
                            if !self.fire(&t, "UPDATE", "BEFORE", Some(&old), Some(&r),
                                            &setcols)? {
                                continue
                            }
                            t.rows[i] = r.clone();
                            changed.push(r.clone());
                            self.changes += 1;
                            self.db.tables.insert(k.clone(), t.clone());
                            self.cascade_update(&t, &old, &r, 0)?;
                            self.fire(&t, "UPDATE", "AFTER", Some(&old), Some(&r),
                                    &setcols)?;
                            t = self.db.tables[&k].clone();
                            continue
                        } else if policy == "IGNORE" {
                            continue
                        } else if policy == "REPLACE" {
                            let removed =
                                conflicts.iter().map(|&i|
                                            t.rows[i].clone()).collect::<Vec<_>>();
                            for i in conflicts.iter().rev() { t.rows.remove(*i); }
                            self.db.tables.insert(k.clone(), t.clone());
                            self.cascade_delete(&t, &removed, 0)?;
                            if self.pragmas.get("recursive_triggers").map_or(false,
                                    |v| v.i64() != 0) {
                                for old in &removed {
                                    self.fire(&t, "DELETE", "BEFORE", Some(old), None, &[])?;
                                    self.fire(&t, "DELETE", "AFTER", Some(old), None, &[])?;
                                }
                            }
                            t = self.db.tables[&k].clone();
                        } else {
                            return Err(policy_error(&policy, self.unique_error(&t)))
                        }
                    }
                    if !t.without { self.last = row.id }
                    t.seq = t.seq.max(row.id);
                    t.rows.push(row.clone());
                    changed.push(row.clone());
                    self.changes += 1;
                    self.db.tables.insert(k.clone(), t.clone());
                    self.fire(&t, "INSERT", "AFTER", None, Some(&row), &[])?;
                    t = self.db.tables[&k].clone();
                }
                self.changes = changed.len() as i64;
                self.total += self.changes;
                self.db.tables.insert(k, t.clone());
                self.check_foreign(self.txn.is_empty())?;
                self.returning(&returning, &t, &changed)
            }
            Stmt::Update { table, alias, from, sets, filter, mode, returning }
                => {
                let k = key(&table);
                let mut t =
                    self.db.tables.get(&k).cloned().ok_or_else(||
                                format!("no such table: {}",table))?;
                let nullctx =
                    self.rowctx(&t,
                        &Row { id: 0, v: vec![V::Null;t.cols.len()] },
                        alias.as_deref());
                for (n, e) in &sets {
                    let col =
                        t.cols.iter().find(|c| c.name.eq_ignore_ascii_case(n));
                    if col.is_none() &&
                            (t.without ||
                                    !["rowid", "oid", "_rowid_"].contains(&key(n).as_str())) {
                        return Err(format!("no such column: {}",n))
                    }
                    if col.map_or(false, |c| c.generated.is_some()) {
                        return Err("cannot UPDATE generated column".into())
                    }
                    if has_agg(e) || has_window(e) {
                        return Err("misuse of aggregate or window function".into())
                    }
                    if from.is_empty() { self.validate_expr(e, &nullctx)?; }
                }
                if from.is_empty() {
                    if let Some(e) = &filter {
                        if has_agg(e) || has_window(e) {
                            return Err("misuse of aggregate or window function".into())
                        }
                        self.validate_expr(e, &nullctx)?;
                    }
                } else {
                    let query =
                        Query {
                            items: sets.iter().map(|(n, e)|
                                        Item {
                                            e: e.clone(),
                                            name: n.clone(),
                                            alias: None,
                                        }).collect(),
                            from: from.clone(),
                            filter: filter.clone(),
                            limit: Some(E::Val(V::Int(0))),
                            ..Default::default()
                        };
                    let mut bind=nullctx.clone();bind.binding=true;self.query(&query,&bind,0)?;
                }
                let mut changed = vec![];
                self.changes = 0;
                let original = t.rows.clone();
                for old in original {
                    let i =
                        match t.rows.iter().position(|r| r.id == old.id) {
                            Some(i) => i,
                            None => continue,
                        };
                    let mut ctx = self.rowctx(&t, &old, alias.as_deref());
                    if !from.is_empty() {
                        let q =
                            Query {
                                items: sets.iter().map(|(n, e)|
                                            Item {
                                                e: e.clone(),
                                                name: n.clone(),
                                                alias: None,
                                            }).collect(),
                                from: from.clone(),
                                filter: filter.clone(),
                                limit: Some(E::Val(V::Int(1))),
                                ..Default::default()
                            };
                        let found = self.query(&q, &ctx, 0)?;
                        if found.rows.is_empty() { continue }
                        for (i, (n, _)) in sets.iter().enumerate() {
                            ctx.fields.push(field("__update_from", n, 'B', "BINARY",
                                    false));
                            ctx.row.push(found.rows[0][i].clone());
                        }
                    }
                    if from.is_empty() {
                        if let Some(f) = &filter {
                            if self.eval(f, &ctx, None, 0)?.truth() != Some(true) {
                                continue
                            }
                        }
                    }
                    let mut v = old.v.clone();
                    let mut id = None;
                    for (n, e) in &sets {
                        let val =
                            if from.is_empty() {
                                self.eval(e, &ctx, None, 0)?
                            } else {
                                self.eval(&E::Col(vec!["__update_from".into(),n.clone()]),
                                        &ctx, None, 0)?
                            };
                        if let Some(j) =
                                t.cols.iter().position(|c| c.name.eq_ignore_ascii_case(n)) {
                            if t.cols[j].generated.is_some() {
                                return Err("cannot UPDATE generated column".into())
                            }
                            v[j] = val
                        } else if !t.without &&
                                ["rowid", "oid", "_rowid_"].contains(&key(n).as_str()) {
                            id = Some(val.clone());
                            if let Some(j) = integer_pk(&t) { v[j] = val }
                        } else { return Err(format!("no such column: {}",n)) }
                    }
                    let row =
                        match self.prepare_row(&t, v, id, Some(old.id)) {
                            Ok(r) => r,
                            Err(e) => {
                                let m = self.error_policy(&t, &e, &mode);
                                if m == "IGNORE" { continue }
                                return Err(policy_error(&m, e))
                            }
                        };
                    let setcols =
                        sets.iter().map(|(n, _)| n.clone()).collect::<Vec<_>>();
                    self.db.tables.insert(k.clone(), t.clone());
                    if !self.fire(&t, "UPDATE", "BEFORE", Some(&old),
                                    Some(&row), &setcols)? {
                        continue
                    }
                    t = self.db.tables[&k].clone();
                    let conflicts = self.conflicts(&t, &row, Some(i))?;
                    let policy =
                        self.unique_policy(&t, &row, &conflicts, &mode);
                    if !conflicts.is_empty() {
                        if policy == "IGNORE" { continue }
                        if policy != "REPLACE" {
                            return Err(policy_error(&policy, self.unique_error(&t)))
                        }
                    }
                    let removed =
                        conflicts.iter().map(|&j|
                                    t.rows[j].clone()).collect::<Vec<_>>();
                    t.rows[i] = row.clone();
                    for j in conflicts.iter().rev() { t.rows.remove(*j); }
                    self.db.tables.insert(k.clone(), t.clone());
                    if !removed.is_empty() {
                        self.cascade_delete(&t, &removed, 0)?;
                        if self.pragmas.get("recursive_triggers").map_or(false,
                                |v| v.i64() != 0) {
                            for old in &removed {
                                self.fire(&t, "DELETE", "AFTER", Some(old), None, &[])?;
                            }
                        }
                        t = self.db.tables[&k].clone();
                    }
                    changed.push(row.clone());
                    self.changes += 1;
                    self.db.tables.insert(k.clone(), t.clone());
                    self.cascade_update(&t, &old, &row, 0)?;
                    self.fire(&t, "UPDATE", "AFTER", Some(&old), Some(&row),
                            &setcols)?;
                    t = self.db.tables[&k].clone();
                }
                self.changes = changed.len() as i64;
                self.total += self.changes;
                self.db.tables.insert(k, t.clone());
                self.check_foreign(self.txn.is_empty())?;
                self.returning(&returning, &t, &changed)
            }
            Stmt::Delete { table, alias, filter, returning } => {
                let k = key(&table);
                let mut t =
                    self.db.tables.get(&k).cloned().ok_or_else(||
                                format!("no such table: {}",table))?;
                let nullctx =
                    self.rowctx(&t,
                        &Row { id: 0, v: vec![V::Null;t.cols.len()] },
                        alias.as_deref());
                if let Some(e) = &filter {
                    if has_agg(e) || has_window(e) {
                        return Err("misuse of aggregate or window function".into())
                    }
                    self.validate_expr(e, &nullctx)?;
                }
                let original = t.rows.clone();
                let mut deleted = vec![];
                self.changes = 0;
                for row in original {
                    let ctx = self.rowctx(&t, &row, alias.as_deref());
                    if let Some(f) = &filter {
                        if self.eval(f, &ctx, None, 0)?.truth() != Some(true) {
                            continue
                        }
                    }
                    self.db.tables.insert(k.clone(), t.clone());
                    if !self.fire(&t, "DELETE", "BEFORE", Some(&row), None,
                                    &[])? {
                        continue
                    }
                    t = self.db.tables[&k].clone();
                    t.rows.retain(|r| r.id != row.id);
                    self.db.tables.insert(k.clone(), t.clone());
                    self.cascade_delete(&t, &[row.clone()], 0)?;
                    self.fire(&t, "DELETE", "AFTER", Some(&row), None, &[])?;
                    t = self.db.tables[&k].clone();
                    deleted.push(row);
                    self.changes += 1;
                }
                self.changes = deleted.len() as i64;
                self.total += self.changes;
                self.check_foreign(self.txn.is_empty())?;
                self.returning(&returning, &t, &deleted)
            }
            Stmt::Pragma(n, v) => self.pragma(&n, v.as_ref()),
            Stmt::Alter(n, a) => self.alter(&n, a),
            Stmt::Noop => Ok(ResultSet::default()),
        }
    }
    fn sequence_table(&self) -> Table {
        let cols =
            ["name",
                                "seq"].iter().map(|n|
                        Column {
                            policies: Default::default(),
                            name: n.to_string(),
                            typ: String::new(),
                            notnull: false,
                            pk: 0,
                            unique: false,
                            default: None,
                            default_sql: None,
                            coll: "BINARY".into(),
                            auto: false,
                            pk_desc: false,
                            generated: None,
                            stored: false,
                        }).collect();
        Table {
            temporary: false,
            name: "sqlite_sequence".into(),
            cols,
            unique: vec![],
            policies: vec![],
            checks: vec![],
            foreign: vec![],
            without: false,
            strict: false,
            rows: self.db.sequences.clone(),
            seq: 0,
            sql: "CREATE TABLE sqlite_sequence(name,seq)".into(),
        }
    }
    fn set_sequence(&mut self, name: &str, seq: i64) {
        if let Some(r) =
                self.db.sequences.iter_mut().find(|r|
                        r.v.first().map_or(false, |v| v.text() == name)) {
            r.v[1] = V::Int(seq)
        } else {
            let id =
                self.db.sequences.iter().map(|r|
                                    r.id).max().unwrap_or(0).saturating_add(1);
            self.db.sequences.push(Row {
                    id,
                    v: vec![V::Text(name.into()),V::Int(seq)],
                });
        }
    }
    fn materialize_inputs(&self, s: &mut Stmt) -> Res<()> {
        match s {
            Stmt::Insert { q: Some(q), .. } | Stmt::CreateTable {
                asq: Some(q), .. } => {
                let r = self.query(q, &self.root_ctx(), 0)?;
                *q =
                    Query {
                        materialized: Some(Materialized {
                                columns: r.columns,
                                rows: r.rows,
                                affinities: r.affinities,
                            }),
                        ..Default::default()
                    };
            }
            Stmt::Temp(s) => self.materialize_inputs(s)?,
            _ => {}
        }
        Ok(())
    }
    fn mutate_view(&mut self, s: Stmt) -> Res<ResultSet> {
        let (name, event) =
            match &s {
                Stmt::Insert { table, .. } => (table, "INSERT"),
                Stmt::Update { table, .. } => (table, "UPDATE"),
                Stmt::Delete { table, .. } => (table, "DELETE"),
                _ => unreachable!(),
            };
        let v = self.db.views[&key(name)].clone();
        if !self.db.triggers.values().any(|t|
                        t.table.eq_ignore_ascii_case(name) && t.event == event &&
                            t.timing == "INSTEAD OF") {
            return Err(format!("cannot modify {} because it is a view",name))
        }
        let result = self.query(&v.q, &self.root_ctx(), 0)?;
        let names = if v.cols.is_empty() { result.columns } else { v.cols };
        let cols =
            names.iter().map(|n|
                        Column {
                            policies: Default::default(),
                            name: n.clone(),
                            typ: String::new(),
                            notnull: false,
                            pk: 0,
                            unique: false,
                            default: None,
                            default_sql: None,
                            coll: "BINARY".into(),
                            auto: false,
                            pk_desc: false,
                            generated: None,
                            stored: false,
                        }).collect();
        let t =
            Table {
                temporary: v.temporary,
                name: v.name.clone(),
                cols,
                unique: vec![],
                policies: vec![],
                checks: vec![],
                foreign: vec![],
                without: false,
                strict: false,
                rows: result.rows.into_iter().enumerate().map(|(i, v)|
                            Row { id: i as i64 + 1, v }).collect(),
                seq: 0,
                sql: v.sql.clone(),
            };
        let mut output = vec![];
        let returning;
        match s {
            Stmt::Insert { cols, q, default, returning: r, .. } => {
                returning = r;
                let target = if cols.is_empty() { names } else { cols };
                let inputs =
                    if let Some(q) = q {
                        let result = self.query(&q, &self.root_ctx(), 0)?;
                        if result.columns.len() != target.len() {
                            return Err("view column count mismatch".into())
                        }
                        result.rows
                    } else { vec![vec![]] };
                for input in inputs {
                    let mut vals = vec![V::Null;t.cols.len()];
                    if !default {
                        for (n, val) in target.iter().zip(input) {
                            let i =
                                t.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("no such column in view")?;
                            vals[i] = val
                        }
                    }
                    let row = Row { id: -1, v: vals };
                    if self.fire(&t, "INSERT", "INSTEAD OF", None, Some(&row),
                                &[])? {
                        output.push(row)
                    }
                }
            }
            Stmt::Update { alias, sets, filter, returning: r, .. } => {
                returning = r;
                for old in &t.rows {
                    let ctx = self.rowctx(&t, old, alias.as_deref());
                    if let Some(e) = &filter {
                        if self.eval(e, &ctx, None, 0)?.truth() != Some(true) {
                            continue
                        }
                    }
                    let mut row = old.clone();
                    for (n, e) in &sets {
                        let i =
                            t.cols.iter().position(|c|
                                            c.name.eq_ignore_ascii_case(n)).ok_or("no such column in view")?;
                        row.v[i] = self.eval(e, &ctx, None, 0)?
                    }
                    let updated =
                        sets.iter().map(|(n, _)| n.clone()).collect::<Vec<_>>();
                    if self.fire(&t, "UPDATE", "INSTEAD OF", Some(old),
                                Some(&row), &updated)? {
                        output.push(row)
                    }
                }
            }
            Stmt::Delete { alias, filter, returning: r, .. } => {
                returning = r;
                for old in &t.rows {
                    let ctx = self.rowctx(&t, old, alias.as_deref());
                    if let Some(e) = &filter {
                        if self.eval(e, &ctx, None, 0)?.truth() != Some(true) {
                            continue
                        }
                    }
                    if self.fire(&t, "DELETE", "INSTEAD OF", Some(old), None,
                                &[])? {
                        output.push(old.clone())
                    }
                }
            }
            _ => unreachable!(),
        }
        self.changes = 0;
        self.returning(&returning, &t, &output)
    }
    fn root_ctx(&self) -> Ctx { self.trigger_ctx.clone().unwrap_or_default() }
    fn fire(&mut self, table: &Table, event: &str, timing: &str,
        old: Option<&Row>, new: Option<&Row>, updated: &[String])
        -> Res<bool> {
        let triggers =
            self.db.triggers.values().filter(|t|
                            t.table.eq_ignore_ascii_case(&table.name) &&
                                        t.event == event && t.timing == timing &&
                                (t.columns.is_empty() ||
                                        t.columns.iter().any(|c|
                                                updated.iter().any(|u|
                                                        u.eq_ignore_ascii_case(c))))).cloned().collect::<Vec<_>>();
        for t in triggers {
            if self.active_triggers.contains(&key(&t.name)) &&
                    !self.pragmas.get("recursive_triggers").map_or(false,
                            |v| v.i64() != 0) {
                continue
            }
            if self.active_triggers.len() > 40 {
                return Err("too many levels of trigger recursion".into())
            }
            let mut ctx = Ctx::default();
            if let Some(row) = old {
                let c = self.rowctx(table, row, Some("old"));
                ctx.fields.extend(c.fields);
                ctx.row.extend(c.row)
            }
            if let Some(row) = new {
                let c = self.rowctx(table, row, Some("new"));
                ctx.fields.extend(c.fields);
                ctx.row.extend(c.row)
            }
            if let Some(e) = &t.when {
                if self.eval(e, &ctx, None, 0)?.truth() != Some(true) {
                    continue
                }
            }
            let saved_ctx = self.trigger_ctx.replace(ctx);
            let changes = self.changes;
            let last = self.last;
            self.active_triggers.push(key(&t.name));
            let out =
                (|| -> Res<()>
                            {
                                for sql in &t.body {
                                    let s = Parser::parse(sql)?;
                                    self.run(s, sql)?;
                                }
                                Ok(())
                            })();
            self.trigger_ctx = saved_ctx;
            self.active_triggers.pop();
            self.changes = changes;
            self.last = last;
            match out {
                Err(e) if e == "!IGNORE!" => return Ok(false),
                Err(e) => return Err(e),
                _ => {}
            }
        }
        Ok(true)
    }
    fn cascade_update(&mut self, parent: &Table, old: &Row, new: &Row,
        depth: usize) -> Res<()> {
        if !self.foreign_keys { return Ok(()) }
        if depth > 40 {
            return Err("too many levels of trigger recursion".into())
        }
        let tables = self.db.tables.values().cloned().collect::<Vec<_>>();
        for mut t in tables {
            for f in t.foreign.clone() {
                if !f.table.eq_ignore_ascii_case(&parent.name) { continue }
                let target =
                    if f.target.is_empty() {
                        let mut cs =
                            parent.cols.iter().filter(|c| c.pk > 0).collect::<Vec<_>>();
                        cs.sort_by_key(|c| c.pk);
                        cs.iter().map(|c| c.name.clone()).collect()
                    } else { f.target };
                let ci =
                    f.cols.iter().map(|n|
                                    t.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                            _>>()?;
                let pi =
                    target.iter().map(|n|
                                    parent.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                            _>>()?;
                if pi.iter().all(|&i|
                            cmp(&old.v[i], &new.v[i], &parent.cols[i].coll) ==
                                Ordering::Equal) {
                    continue
                }
                let mut updates = vec![];
                for i in 0..t.rows.len() {
                    let r = &t.rows[i];
                    let hit =
                        ci.iter().zip(&pi).all(|(&c, &p)|
                                !r.v[c].null() &&
                                    cmp(&r.v[c].apply(affinity(&parent.cols[p].typ)), &old.v[p],
                                            &parent.cols[p].coll) == Ordering::Equal);
                    if !hit { continue }
                    let mut v = r.v.clone();
                    match f.update.as_str() {
                        "CASCADE" => {
                            for (&c, &p) in ci.iter().zip(&pi) {
                                v[c] = new.v[p].clone()
                            }
                        }
                        "SET NULL" | "SET DEFAULT" => {
                            for &c in &ci {
                                v[c] =
                                    if f.update == "SET DEFAULT" {
                                        if let Some(e) = &t.cols[c].default {
                                            self.eval(e, &self.root_ctx(), None, 0)?
                                        } else { V::Null }
                                    } else { V::Null }
                            }
                        }
                        "RESTRICT" =>
                            return Err("FOREIGN KEY constraint failed".into()),
                        _ => continue,
                    }
                    let updated = self.prepare_row(&t, v, None, Some(r.id))?;
                    if !self.conflicts(&t, &updated, Some(i))?.is_empty() {
                        return Err(self.unique_error(&t))
                    }
                    updates.push((r.clone(), updated.clone()));
                    t.rows[i] = updated;
                }
                self.db.tables.insert(key(&t.name), t.clone());
                self.total += updates.len() as i64;
                for (o, n) in updates {
                    self.cascade_update(&t, &o, &n, depth + 1)?;
                    self.fire(&t, "UPDATE", "AFTER", Some(&o), Some(&n),
                            &f.cols)?;
                }
            }
        }
        Ok(())
    }
    fn foreign_violations(&self, only: &str) -> Res<Vec<Vec<V>>> {
        let mut rows = vec![];
        for t in self.db.tables.values() {
            if !only.is_empty() && !t.name.eq_ignore_ascii_case(only) {
                continue
            }
            for (fid, f) in t.foreign.iter().enumerate() {
                let ci =
                    f.cols.iter().map(|n|
                                    t.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                            _>>()?;
                let parent = self.db.tables.get(&key(&f.table));
                let pi =
                    if let Some(p) = parent {
                        if f.target.is_empty() {
                            let mut v =
                                p.cols.iter().enumerate().filter(|(_, c)|
                                                c.pk > 0).map(|(i, c)| (c.pk, i)).collect::<Vec<_>>();
                            v.sort();
                            v.iter().map(|x| x.1).collect()
                        } else {
                            f.target.iter().map(|n|
                                            p.cols.iter().position(|c|
                                                        c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                                    _>>()?
                        }
                    } else { vec![] };
                for row in &t.rows {
                    if ci.iter().any(|&c| row.v[c].null()) { continue }
                    let found =
                        parent.map_or(false,
                            |p|
                                ci.len() == pi.len() &&
                                    p.rows.iter().any(|r|
                                            ci.iter().zip(&pi).all(|(&c, &i)|
                                                    cmp(&row.v[c].apply(affinity(&p.cols[i].typ)), &r.v[i],
                                                            &p.cols[i].coll) == Ordering::Equal)));
                    if !found {
                        rows.push(vec![V::Text(t.name.clone()),if
                                t.without{V::Null}else{V::Int(row.id)},V::Text(f.table.clone()),V::Int(fid
                                as i64)])
                    }
                }
            }
        }
        Ok(rows)
    }
    fn cascade_delete(&mut self, parent: &Table, deleted: &[Row],
        depth: usize) -> Res<()> {
        if !self.foreign_keys { return Ok(()) }
        if depth > 40 {
            return Err("too many levels of trigger recursion".into())
        }
        let tables = self.db.tables.values().cloned().collect::<Vec<_>>();
        for mut t in tables {
            for f in t.foreign.clone() {
                if !f.table.eq_ignore_ascii_case(&parent.name) { continue }
                let target =
                    if f.target.is_empty() {
                        let mut cols =
                            parent.cols.iter().filter(|c| c.pk > 0).collect::<Vec<_>>();
                        cols.sort_by_key(|c| c.pk);
                        cols.iter().map(|c| c.name.clone()).collect()
                    } else { f.target };
                let ci =
                    f.cols.iter().map(|n|
                                    t.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                            _>>()?;
                let pi =
                    target.iter().map(|n|
                                    parent.cols.iter().position(|c|
                                                c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch")).collect::<Result<Vec<_>,
                            _>>()?;
                let mut keep = vec![];
                let mut removed = vec![];
                let mut updated = vec![];
                for (i, r) in t.rows.iter().enumerate() {
                    let hit =
                        deleted.iter().any(|d|
                                ci.iter().zip(&pi).all(|(&c, &p)|
                                        !r.v[c].null() &&
                                            cmp(&r.v[c].apply(affinity(&parent.cols[p].typ)), &d.v[p],
                                                    &parent.cols[p].coll) == Ordering::Equal));
                    if !hit { keep.push(r.clone()); continue }
                    match f.delete.as_str() {
                        "CASCADE" => {
                            if self.fire(&t, "DELETE", "BEFORE", Some(r), None, &[])? {
                                removed.push(r.clone())
                            } else { keep.push(r.clone()) }
                        }
                        "SET NULL" | "SET DEFAULT" => {
                            let mut row = r.clone();
                            for &c in &ci {
                                row.v[c] =
                                    if f.delete == "SET DEFAULT" {
                                        if let Some(e) = &t.cols[c].default {
                                            self.eval(e, &self.root_ctx(), None, 0)?
                                        } else { V::Null }
                                    } else { V::Null }
                            }
                            let row = self.prepare_row(&t, row.v, None, Some(row.id))?;
                            if !self.conflicts(&t, &row, Some(i))?.is_empty() {
                                return Err(self.unique_error(&t))
                            }
                            if self.fire(&t, "UPDATE", "BEFORE", Some(r), Some(&row),
                                        &f.cols)? {
                                updated.push((r.clone(), row.clone()));
                                keep.push(row)
                            } else { keep.push(r.clone()) }
                        }
                        "RESTRICT" =>
                            return Err("FOREIGN KEY constraint failed".into()),
                        _ => keep.push(r.clone()),
                    }
                }
                t.rows = keep;
                self.db.tables.insert(key(&t.name), t.clone());
                self.total += (removed.len() + updated.len()) as i64;
                if !removed.is_empty() {
                    self.cascade_delete(&t, &removed, depth + 1)?;
                    for r in &removed {
                        self.fire(&t, "DELETE", "AFTER", Some(r), None, &[])?;
                    }
                }
                for (old, new) in updated {
                    self.cascade_update(&t, &old, &new, depth + 1)?;
                    self.fire(&t, "UPDATE", "AFTER", Some(&old), Some(&new),
                            &f.cols)?;
                }
                t = self.db.tables[&key(&t.name)].clone();
            }
        }
        Ok(())
    }
    fn pragma(&mut self, n: &str, e: Option<&E>) -> Res<ResultSet> {
        let n = key(n);
        let arg =
            e.map(|e|
                            match e {
                                E::Col(n) => Ok(V::Text(n.join("."))),
                                _ => self.eval(e, &self.root_ctx(), None, 0),
                            }).transpose()?;
        let text = arg.as_ref().map(V::text).unwrap_or_default();
        let on =
            if ["on", "true", "yes"].contains(&key(&text).as_str()) {
                1
            } else if ["off", "false", "no"].contains(&key(&text).as_str()) {
                0
            } else { arg.as_ref().map(V::i64).unwrap_or(0) };
        let mut result = ResultSet::default();
        match n.as_str() {
            "table_info" | "table_xinfo" => {
                result.columns =
                    ["cid", "name", "type", "notnull", "dflt_value",
                                        "pk"].iter().map(|s| s.to_string()).collect();
                if n == "table_xinfo" { result.columns.push("hidden".into()) }
                let virtual_sequence =
                    if text.eq_ignore_ascii_case("sqlite_sequence") &&
                            self.db.sequence_created {
                        Some(self.sequence_table())
                    } else { None };
                if let Some(t) =
                        self.db.tables.get(&key(&text)).or(virtual_sequence.as_ref())
                    {
                    for (i, c) in t.cols.iter().enumerate() {
                        if n == "table_info" && c.generated.is_some() { continue }
                        let mut row =
                            vec![V::Int(i as
                                i64),V::Text(c.name.clone()),V::Text(c.typ.to_ascii_uppercase()),V::Int((c.notnull||((t.strict||t.without)&&c.pk>0))as
                                i64),c.default_sql.as_ref().map(|s|V::Text(s.clone())).unwrap_or(V::Null),V::Int(c.pk
                                as i64)];
                        if n == "table_xinfo" {
                            row.push(V::Int(if c.generated.is_some() {
                                        if c.stored { 3 } else { 2 }
                                    } else { 0 }))
                        }
                        result.rows.push(row)
                    }
                } else if let Some(v) = self.db.views.get(&key(&text)) {
                    let r = self.query(&v.q, &self.root_ctx(), 0)?;
                    let names =
                        if v.cols.is_empty() { r.columns } else { v.cols.clone() };
                    for (i, colname) in names.into_iter().enumerate() {
                        let mut row =
                            vec![V::Int(i as
                                i64),V::Text(colname),V::Text(r.affinities.get(i).map(|(a,_)|if
                                *a=='B'{""}else{affinity_name(*a)}).unwrap_or("").into()),V::Int(0),V::Null,V::Int(0)];
                        if n == "table_xinfo" { row.push(V::Int(0)) }
                        result.rows.push(row)
                    }
                }
            }
            "table_list" => {
                result.columns =
                    ["schema", "name", "type", "ncol", "wr",
                                        "strict"].iter().map(|s| s.to_string()).collect();
                for t in self.db.tables.values() {
                    result.rows.push(vec![V::Text("main".into()),V::Text(t.name.clone()),V::Text("table".into()),V::Int(t.cols.len()as
                            i64),V::Int(t.without as i64),V::Int(t.strict as i64)])
                }
            }
            "index_list" => {
                result.columns =
                    ["seq", "name", "unique", "origin",
                                        "partial"].iter().map(|s| s.to_string()).collect();
                for (i, idx) in
                    self.db.indexes.values().filter(|i|
                                i.table.eq_ignore_ascii_case(&text)).enumerate() {
                    result.rows.push(vec![V::Int(i as
                            i64),V::Text(idx.name.clone()),V::Int(idx.unique as
                            i64),V::Text(idx.origin.clone()),V::Int(idx.filter.is_some()as
                            i64)])
                }
            }
            "index_info" | "index_xinfo" => {
                result.columns =
                    ["seqno", "cid",
                                        "name"].iter().map(|s| s.to_string()).collect();
                let extended = n == "index_xinfo";
                if extended {
                    result.columns.extend(["desc", "coll",
                                        "key"].iter().map(|s| s.to_string()))
                }
                if let Some(idx) = self.db.indexes.get(&key(&text)) {
                    if let Some(t) = self.db.tables.get(&key(&idx.table)) {
                        for (i, e) in idx.expr.iter().enumerate() {
                            let colname =
                                match e {
                                    E::Col(n) => n.last().cloned(),
                                    E::Collate(e, _) =>
                                        if let E::Col(n) = e.as_ref() {
                                            n.last().cloned()
                                        } else { None },
                                    _ => None,
                                };
                            let cid =
                                colname.as_ref().and_then(|n|
                                                t.cols.iter().position(|c|
                                                        c.name.eq_ignore_ascii_case(n))).map(|i|
                                            i as i64).unwrap_or(-2);
                            let mut row =
                                vec![V::Int(i as
                                    i64),V::Int(cid),colname.map(V::Text).unwrap_or(V::Null)];
                            if extended {
                                let coll =
                                    if let E::Collate(_, c) = e {
                                        c.clone()
                                    } else if cid >= 0 {
                                        t.cols[cid as usize].coll.clone()
                                    } else { "BINARY".into() };
                                row.extend(vec![V::Int(idx.desc.get(i).copied().unwrap_or(false)as
                                        i64),V::Text(coll),V::Int(1)]);
                            }
                            result.rows.push(row)
                        }
                        if extended && !t.without {
                            result.rows.push(vec![V::Int(idx.expr.len()as
                                    i64),V::Int(-1),V::Null,V::Int(0),V::Text("BINARY".into()),V::Int(0)])
                        }
                    }
                }
            }
            "foreign_key_list" => {
                result.columns =
                    ["id", "seq", "table", "from", "to", "on_update",
                                        "on_delete",
                                        "match"].iter().map(|s| s.to_string()).collect();
                if let Some(t) = self.db.tables.get(&key(&text)) {
                    for (i, f) in t.foreign.iter().enumerate() {
                        for (j, c) in f.cols.iter().enumerate() {
                            result.rows.push(vec![V::Int(i as
                                    i64),V::Int(j as
                                    i64),V::Text(f.table.clone()),V::Text(c.clone()),f.target.get(j).cloned().map(V::Text).unwrap_or(V::Null),V::Text(f.update.clone()),V::Text(f.delete.clone()),V::Text("NONE".into())])
                        }
                    }
                }
            }
            "foreign_key_check" => {
                result.columns =
                    ["table", "rowid", "parent",
                                        "fkid"].iter().map(|s| s.to_string()).collect();
                result.rows = self.foreign_violations(&text)?;
            }
            "integrity_check" | "quick_check" => {
                result.columns.push(n.clone());
                let max = if on > 0 { on.min(10000) as usize } else { 100 };
                for t in self.db.tables.values() {
                    if !text.is_empty() && on == 0 &&
                            !t.name.eq_ignore_ascii_case(&text) {
                        continue
                    }
                    for (i, row) in t.rows.iter().enumerate() {
                        if let Err(e) =
                                self.prepare_row(t, row.v.clone(), Some(V::Int(row.id)),
                                    Some(row.id)) {
                            result.rows.push(vec![V::Text(e)])
                        }
                        if n == "integrity_check" &&
                                !self.conflicts(t, row, Some(i))?.is_empty() {
                            result.rows.push(vec![V::Text(format!("non-unique entry in index on {}",t.name))])
                        }
                        if result.rows.len() >= max { break }
                    }
                    if result.rows.len() >= max { break }
                }
                if result.rows.is_empty() {
                    result.rows.push(vec![V::Text("ok".into())]);
                }
                result.rows.truncate(max);
            }
            "database_list" => {
                result.columns =
                    ["seq", "name",
                                        "file"].iter().map(|s| s.to_string()).collect();
                result.rows.push(vec![V::Int(0),V::Text("main".into()),V::Text(self.path.as_ref().map(|p|p.to_string_lossy().into_owned()).unwrap_or_default())]);
                for (i, name) in self.attach_order.iter().enumerate() {
                    let db = &self.attached[name];
                    result.rows.push(vec![V::Int(i as
                            i64+2),V::Text(name.clone()),V::Text(db.path.as_ref().map(|p|p.to_string_lossy().into_owned()).unwrap_or_default())]);
                }
            }
            "collation_list" => {
                result.columns = vec!["seq".into(),"name".into()];
                for (i, n) in ["RTRIM", "NOCASE", "BINARY"].iter().enumerate()
                    {
                    result.rows.push(vec![V::Int(i as
                            i64),V::Text(n.to_string())])
                }
            }
            "foreign_keys" => {
                if arg.is_some() {
                    if self.txn.is_empty() {
                        self.foreign_keys = on != 0;
                        for db in self.attached.values_mut() {
                            db.foreign_keys = on != 0
                        }
                    }
                } else {
                    result.columns.push(n);
                    result.rows.push(vec![V::Int(self.foreign_keys as i64)])
                }
            }
            "user_version" | "application_id" | "schema_version" => {
                let v =
                    match n.as_str() {
                        "user_version" => &mut self.db.user_version,
                        "application_id" => &mut self.db.application_id,
                        _ => &mut self.db.schema_version,
                    };
                if arg.is_some() {
                    *v = on as i32 as i64
                } else {
                    result.columns.push(n);
                    result.rows.push(vec![V::Int(*v)])
                }
            }
            "journal_mode" => {
                let v =
                    if let Some(v) = arg {
                        let v = V::Text(v.text().to_ascii_lowercase());
                        self.pragmas.insert(n.clone(), v.clone());
                        v
                    } else {
                        self.pragmas.get(&n).cloned().unwrap_or_else(||
                                V::Text(if self.path.is_none() {
                                            "memory"
                                        } else { "delete" }.into()))
                    };
                result.columns.push(n);
                result.rows.push(vec![v])
            }
            "encoding" => {
                if arg.is_none() {
                    result.columns.push(n);
                    result.rows.push(vec![V::Text("UTF-8".into())])
                }
            }
            "query_only" | "count_changes" | "ignore_check_constraints" |
                "legacy_alter_table" | "page_size" | "page_count" |
                "freelist_count" | "cache_size" | "synchronous" |
                "busy_timeout" | "temp_store" | "automatic_index" |
                "recursive_triggers" | "case_sensitive_like" |
                "defer_foreign_keys" | "read_uncommitted" | "locking_mode" =>
                {
                if let Some(v) = arg {
                    let value=if matches!(v,V::Text(_)){V::Int(on)}else{v};
                    self.pragmas.insert(n.clone(),value.clone());
                    if ["query_only","count_changes","ignore_check_constraints","recursive_triggers","case_sensitive_like","defer_foreign_keys","busy_timeout"].contains(&n.as_str()){
                        for db in self.attached.values_mut(){db.pragmas.insert(n.clone(),value.clone());}
                    }
                } else {
                    let v =
                        self.pragmas.get(&n).cloned().unwrap_or_else(||
                                V::Int(match n.as_str() {
                                        "page_size" => 4096,
                                        "page_count" => self.db.tables.len() as i64 + 1,
                                        "cache_size" => -2000,
                                        "synchronous" => 2,
                                        "automatic_index" => 1,
                                        _ => 0,
                                    }));
                    result.columns.push(n);
                    result.rows.push(vec![v]);
                }
            }
            _ => {}
        }
        Ok(result)
    }
    fn alter(&mut self, n: &str, a: Alter) -> Res<ResultSet> {
        let k = key(n);
        let mut t =
            self.db.tables.get(&k).cloned().ok_or_else(||
                        format!("no such table: {}",n))?;
        match a {
            Alter::Rename(new) => {
                if self.db.tables.contains_key(&key(&new)) {
                    return Err("there is already another table with this name".into())
                }
                self.db.tables.remove(&k);
                for r in &mut self.db.sequences {
                    if r.v[0].text() == t.name { r.v[0] = V::Text(new.clone()) }
                }
                t.sql = rewrite_identifier(&t.sql, n, &new)?;
                t.name = new.clone();
                for idx in self.db.indexes.values_mut() {
                    if idx.table.eq_ignore_ascii_case(n) {
                        idx.table = new.clone();
                        idx.sql = rewrite_identifier(&idx.sql, n, &new)?;
                    }
                }
                for child in self.db.tables.values_mut() {
                    for f in &mut child.foreign {
                        if f.table.eq_ignore_ascii_case(n) {
                            f.table = new.clone();
                            child.sql = rewrite_identifier(&child.sql, n, &new)?;
                        }
                    }
                }
                for view in self.db.views.values_mut() {
                    if query_uses(&view.q, n) {
                        view.sql = rewrite_identifier(&view.sql, n, &new)?;
                        if let Stmt::CreateView { q, .. } =
                                Parser::parse(&view.sql)? {
                            view.q = q
                        }
                    }
                }
                for trigger in self.db.triggers.values_mut() {
                    let changed =
                        trigger.table.eq_ignore_ascii_case(n) ||
                            trigger.body.iter().any(|s|
                                    lex(s).map_or(false,
                                        |ts| ts.iter().any(|t| t.s.eq_ignore_ascii_case(n))));
                    if changed {
                        trigger.sql = rewrite_identifier(&trigger.sql, n, &new)?;
                        if let Stmt::CreateTrigger(rebuilt, _) =
                                Parser::parse(&trigger.sql)? {
                            *trigger = rebuilt
                        }
                    }
                }
                self.db.tables.insert(key(&new), t);
            }
            Alter::Add(c) => {
                if t.cols.iter().any(|x| x.name.eq_ignore_ascii_case(&c.name))
                    {
                    return Err(format!("duplicate column name: {}",c.name))
                }
                if c.pk > 0 || c.unique {
                    return Err("Cannot add a PRIMARY KEY or UNIQUE column".into())
                }
                if c.stored {
                    return Err("cannot add a STORED column".into())
                }
                let v =
                    if let Some(e) = &c.default {
                        self.eval(e, &self.root_ctx(), None,
                                    0)?.apply(affinity(&c.typ))
                    } else { V::Null };
                if c.notnull && v.null() && !t.rows.is_empty() {
                    return Err("Cannot add a NOT NULL column with default value NULL".into())
                }
                for row in &mut t.rows { row.v.push(v.clone()) }
                let rendered = column_sql(&c);
                if let Some(pos) = t.sql.rfind(')') {
                    t.sql.insert_str(pos, &format!(", {}",rendered));
                }
                t.cols.push(c);
                for i in 0..t.rows.len() {
                    let old = t.rows[i].clone();
                    t.rows[i] =
                        self.prepare_row(&t, old.v, None, Some(old.id))?;
                }
                self.db.tables.insert(k, t);
            }
            Alter::Drop(n) => {
                let i =
                    t.cols.iter().position(|c|
                                    c.name.eq_ignore_ascii_case(&n)).ok_or_else(||
                                format!("no such column: {}",n))?;
                if t.cols.len() == 1 || t.cols[i].pk > 0 || t.cols[i].unique {
                    return Err("cannot drop constrained column".into())
                }
                if t.checks.iter().any(|e|
                                    column_refs(e).iter().any(|c| c.eq_ignore_ascii_case(&n)))
                            ||
                            t.cols.iter().filter_map(|c|
                                        c.generated.as_ref()).any(|e|
                                    column_refs(e).iter().any(|c| c.eq_ignore_ascii_case(&n)))
                        ||
                        self.db.indexes.values().filter(|x|
                                    x.table.eq_ignore_ascii_case(&t.name)).any(|idx|
                                idx.expr.iter().any(|e|
                                        column_refs(e).iter().any(|c| c.eq_ignore_ascii_case(&n))))
                    {
                    return Err("cannot drop column referenced by a constraint or index".into())
                }
                t.sql = drop_column_sql(&t.sql, &n)?;
                t.cols.remove(i);
                for row in &mut t.rows { row.v.remove(i); }
                self.db.tables.insert(k, t);
            }
            Alter::RenameCol(old, new) => {
                let i =
                    t.cols.iter().position(|c|
                                    c.name.eq_ignore_ascii_case(&old)).ok_or_else(||
                                format!("no such column: {}",old))?;
                if t.cols.iter().any(|c| c.name.eq_ignore_ascii_case(&new)) {
                    return Err(format!("duplicate column name: {}",new))
                }
                t.sql = rewrite_identifier(&t.sql, &old, &new)?;
                t.cols[i].name = new.clone();
                for idx in
                    self.db.indexes.values_mut().filter(|idx|
                            idx.table.eq_ignore_ascii_case(n)) {
                    for e in &mut idx.expr { rename_expr(e, &old, &new) }
                    if let Some(e) = &mut idx.filter {
                        rename_expr(e, &old, &new)
                    }
                    idx.sql = rewrite_identifier(&idx.sql, &old, &new)?;
                }
                for view in self.db.views.values_mut() {
                    if query_uses(&view.q, n) {
                        view.sql = rewrite_identifier(&view.sql, &old, &new)?;
                        if let Stmt::CreateView { q, .. } =
                                Parser::parse(&view.sql)? {
                            view.q = q
                        }
                    }
                }
                for trigger in
                    self.db.triggers.values_mut().filter(|tr|
                            tr.table.eq_ignore_ascii_case(n)) {
                    trigger.sql = rewrite_identifier(&trigger.sql, &old, &new)?;
                    if let Stmt::CreateTrigger(rebuilt, _) =
                            Parser::parse(&trigger.sql)? {
                        *trigger = rebuilt
                    }
                }
                for child in self.db.tables.values_mut() {
                    for f in &mut child.foreign {
                        if f.table.eq_ignore_ascii_case(n) {
                            for c in &mut f.target {
                                if c.eq_ignore_ascii_case(&old) { *c = new.clone() }
                            }
                        }
                    }
                }
                for cols in &mut t.unique {
                    for c in cols {
                        if c.eq_ignore_ascii_case(&old) { *c = new.clone() }
                    }
                }
                for e in &mut t.checks { rename_expr(e, &old, &new) }
                for c in &mut t.cols {
                    if let Some(e) = &mut c.generated {
                        rename_expr(e, &old, &new)
                    }
                }
                for f in &mut t.foreign {
                    for c in &mut f.cols {
                        if c.eq_ignore_ascii_case(&old) { *c = new.clone() }
                    }
                }
                self.db.tables.insert(k, t);
            }
        }
        self.db.schema_version += 1;
        Ok(ResultSet::default())
    }
}
fn integer_pk(t: &Table) -> Option<usize> {
    if t.without || t.cols.iter().filter(|c| c.pk > 0).count() != 1 {
        None
    } else {
        t.cols.iter().position(|c|
                c.pk == 1 && c.typ.eq_ignore_ascii_case("INTEGER") &&
                    !c.pk_desc)
    }
}
fn is_aggregate(n: &str, len: usize) -> bool {
    ["count", "sum", "total", "avg", "group_concat", "string_agg",
                    "json_group_array", "json_group_object"].contains(&n) ||
        (len == 1 && (n == "min" || n == "max"))
}
fn has_agg(e: &E) -> bool {
    match e {
        E::Call(n, a, _, _) =>
            is_aggregate(&key(n), a.len()) ||
                child_exprs(e).iter().any(|e| has_agg(e)),
        E::Window(call, w) => {
            let nested =
                match call.as_ref() {
                    E::Call(_, a, _, f) =>
                        a.iter().any(has_agg) ||
                            f.as_ref().is_some_and(|f| has_agg(f)),
                    _ => false,
                };
            nested || w.partition.iter().any(has_agg) ||
                w.order.iter().any(|o| has_agg(&o.e))
        }
        _ => child_exprs(e).iter().any(|e| has_agg(e)),
    }
}
fn is_window_builtin(n: &str) -> bool {
    ["row_number", "rank", "dense_rank", "percent_rank", "cume_dist", "ntile",
                "lag", "lead", "first_value", "last_value",
                "nth_value"].contains(&n)
}
fn resolve_window(w: &WinSpec, named: &BTreeMap<String, WinSpec>,
    stack: &mut Vec<String>) -> Res<WinSpec> {
    let mut out = w.clone();
    if let Some(name) = &w.base {
        let k = key(name);
        if stack.contains(&k) {
            return Err("circular window definition".into())
        }
        stack.push(k.clone());
        let base =
            named.get(&k).ok_or_else(|| format!("no such window: {}",name))?;
        let base = resolve_window(base, named, stack)?;
        stack.pop();
        if w.reference_only { return Ok(base) }
        if !out.partition.is_empty() {
            return Err("cannot override PARTITION clause of window".into())
        }
        if !out.order.is_empty() && !base.order.is_empty() {
            return Err("cannot override ORDER BY clause of window".into())
        }
        if base.frame.is_some() {
            return Err("cannot override frame specification of window".into())
        }
        out.partition = base.partition;
        if out.order.is_empty() { out.order = base.order }
        out.base = None;
    }
    Ok(out)
}

fn sort_compare(a: &V, b: &V, coll: &str, order: &Order) -> Ordering {
    let mut c = cmp(a, b, coll);
    if a.null() != b.null() {
        if let Some(last) = order.nulls {
            c =
                if a.null() ^ last {
                    Ordering::Less
                } else { Ordering::Greater }
        } else if order.desc { c = c.reverse() }
    } else if order.desc { c = c.reverse() }
    c
}
fn expression_table_references(e: &E, name: &str) -> usize {
    match e {
        E::Sub(q) | E::SubCol(q, _) | E::Exists(q) =>
            query_table_references(q, name),
        E::In(e, a, q, _) =>
            expression_table_references(e, name) +
                    a.iter().map(|e|
                                expression_table_references(e, name)).sum::<usize>() +
                q.as_ref().map_or(0, |q| query_table_references(q, name)),
        E::Window(e, w) =>
            expression_table_references(e, name) +
                    w.partition.iter().map(|e|
                                expression_table_references(e, name)).sum::<usize>() +
                w.order.iter().map(|o|
                            expression_table_references(&o.e, name)).sum::<usize>(),
        _ =>
            child_exprs(e).iter().map(|e|
                        expression_table_references(e, name)).sum(),
    }
}
fn query_table_references(q: &Query, name: &str) -> usize {
    if q.ctes.iter().any(|(n, _, _)| n.eq_ignore_ascii_case(name)) {
        return 0
    }
    let sources =
        q.from.iter().map(|j|
                    {
                        (match &j.source {
                                    Source::Table(n) =>
                                        usize::from(n.eq_ignore_ascii_case(name)),
                                    Source::Query(q) => query_table_references(q, name),
                                    Source::Join(joins) =>
                                        query_table_references(&Query {
                                                    from: joins.clone(),
                                                    ..Default::default()
                                                }, name),
                                    Source::Function(_, a) =>
                                        a.iter().map(|e|
                                                    expression_table_references(e, name)).sum(),
                                }) +
                            j.on.as_ref().map_or(0,
                                |e| expression_table_references(e, name))
                    }).sum::<usize>();
    sources +
                            q.items.iter().map(|i|
                                        expression_table_references(&i.e, name)).sum::<usize>() +
                        q.filter.as_ref().map_or(0,
                            |e| expression_table_references(e, name)) +
                    q.having.as_ref().map_or(0,
                        |e| expression_table_references(e, name)) +
                q.group.iter().chain(q.order.iter().map(|o|
                                                &o.e)).chain(q.limit.iter()).chain(q.offset.iter()).chain(q.values.iter().flatten()).map(|e|
                            expression_table_references(e, name)).sum::<usize>() +
            q.compound.iter().map(|(_, q)|
                        query_table_references(q, name)).sum::<usize>() +
        q.ctes.iter().map(|(_, _, q)|
                    query_table_references(q, name)).sum::<usize>()
}
fn cte_order(q: &Query) -> Res<Vec<usize>> {
    let mut names = std::collections::BTreeSet::new();
    for (n, _, _) in &q.ctes {
        if !names.insert(key(n)) {
            return Err(format!("duplicate WITH table name: {}",n))
        }
    }
    let mut body = q.clone();
    body.ctes.clear();
    let mut needed =
        q.ctes.iter().map(|(n, _, _)|
                    query_table_references(&body, n) > 0).collect::<Vec<_>>();
    let deps =
        q.ctes.iter().map(|(_, _, c)|
                    q.ctes.iter().map(|(n, _, _)|
                                query_table_references(c, n) >
                                    0).collect::<Vec<_>>()).collect::<Vec<_>>();
    loop {
        let mut changed = false;
        for i in 0..needed.len() {
            if needed[i] {
                for j in 0..needed.len() {
                    if deps[i][j] && !needed[j] {
                        needed[j] = true;
                        changed = true
                    }
                }
            }
        }
        if !changed { break }
    }
    let mut done = vec![false;needed.len()];
    let mut order = vec![];
    while done.iter().zip(&needed).any(|(d, n)| *n && !*d) {
        let i =
            (0..needed.len()).find(|&i|
                            needed[i] && !done[i] &&
                                (0..needed.len()).all(|j|
                                        i == j || !deps[i][j] ||
                                            done[j])).ok_or("circular reference in WITH clause")?;
        done[i] = true;
        order.push(i);
    }
    Ok(order)
}

fn order_position(e: &E) -> Option<i64> {
    match e {
        E::Val(V::Int(i)) => Some(*i),
        E::Collate(e, _) => order_position(e),
        E::Unary(op, e) if op == "+" => order_position(e),
        E::Unary(op, e) if op == "-" => order_position(e)?.checked_neg(),
        _ => None,
    }
}
fn order_expression(e: &E) -> &E {
    if let E::Collate(e, _) = e { order_expression(e) } else { e }
}
fn same_expression(a: &E, b: &E) -> bool {
    match (a, b) {
        (E::Col(a), E::Col(b)) =>
            a.last().zip(b.last()).is_some_and(|(a, b)|
                        a.eq_ignore_ascii_case(b)) &&
                (a.len() == 1 || b.len() == 1 ||
                        a.iter().zip(b).all(|(a, b)| a.eq_ignore_ascii_case(b))),
        (E::Call(a, aa, ad, af), E::Call(b, ba, bd, bf)) =>
            a.eq_ignore_ascii_case(b) && ad == bd && aa.len() == ba.len() &&
                    aa.iter().zip(ba).all(|(a, b)| same_expression(a, b)) &&
                match (af, bf) {
                    (None, None) => true,
                    (Some(a), Some(b)) => same_expression(a, b),
                    _ => false,
                },
        (E::Bin(a, al, ar), E::Bin(b, bl, br)) =>
            a == b && same_expression(al, bl) && same_expression(ar, br),
        (E::Unary(a, ae), E::Unary(b, be)) | (E::Cast(ae, a), E::Cast(be, b))
            | (E::Collate(ae, a), E::Collate(be, b)) =>
            a.eq_ignore_ascii_case(b) && same_expression(ae, be),
        _ => serde_json::to_value(a).ok() == serde_json::to_value(b).ok(),
    }
}
fn resolve_order(orders: &[Order], branches: &[Vec<Item>], compound: bool)
    -> Res<Vec<Option<usize>>> {
    let width = branches.first().map_or(0, Vec::len);
    orders.iter().map(|order|
                {
                    if let Some(c) = explicit_coll(&order.e) {
                        if !["BINARY", "NOCASE",
                                            "RTRIM"].contains(&c.to_ascii_uppercase().as_str()) {
                            return Err(format!("no such collation sequence: {}",c))
                        }
                    }
                    if let Some(n) = order_position(&order.e) {
                        if n < 1 || n as usize > width {
                            return Err("ORDER BY term out of range".into())
                        }
                        return Ok(Some(n as usize - 1))
                    }
                    let e = order_expression(&order.e);
                    for items in branches {
                        if let E::Col(n) = e {
                            if n.len() == 1 {
                                if let Some(i) =
                                        items.iter().position(|item|
                                                item.alias.as_ref().unwrap_or(&item.name).eq_ignore_ascii_case(&n[0]))
                                    {
                                    return Ok(Some(i))
                                }
                            }
                        }
                        if let Some(i) =
                                items.iter().position(|item|
                                        same_expression(e, order_expression(&item.e))) {
                            return Ok(Some(i))
                        }
                    }
                    if compound {
                        Err("ORDER BY term does not match any column in the result set".into())
                    } else { Ok(None) }
                }).collect()
}
fn inherit_compound_collations(left: &mut ResultSet, right: &ResultSet) {
    for i in 0..left.affinities.len() {
        if !left.coll_sources.get(i).copied().unwrap_or(false) &&
                right.coll_sources.get(i).copied().unwrap_or(false) {
            if let Some((_, coll)) = right.affinities.get(i) {
                left.affinities[i].1 = coll.clone();
                if let Some(src) = left.coll_sources.get_mut(i) {
                    *src = true
                }
            }
        }
    }
}

fn ordinal<'a>(e: &'a E, items: &'a [Item]) -> Res<&'a E> {
    if let Some(i) = order_position(e) {
        if i < 1 || i as usize > items.len() {
            Err("GROUP BY term out of range".into())
        } else { Ok(&items[i as usize - 1].e) }
    } else { Ok(e) }
}
fn limit_int(v: &V) -> Res<i64> {
    match v.apply('N') {
        V::Int(i) => Ok(i),
        _ => Err("datatype mismatch".into()),
    }
}
fn rename_expr(e: &mut E, old: &str, new: &str) {
    match e {
        E::Col(n) => {
            if n.last().map_or(false, |n| n.eq_ignore_ascii_case(old)) {
                *n.last_mut().unwrap() = new.into()
            }
        }
        E::Unary(_, a) | E::Cast(a, _) | E::Collate(a, _) =>
            rename_expr(a, old, new),
        E::Bin(_, a, b) => {
            rename_expr(a, old, new);
            rename_expr(b, old, new)
        }
        E::Call(_, a, _, _) => { for e in a { rename_expr(e, old, new) } }
        _ => {}
    }
}

fn find_minmax(e: &E) -> Option<(&str, &E)> {
    match e {
        E::Call(n, a, _, _) if
            a.len() == 1 &&
                (n.eq_ignore_ascii_case("min") ||
                        n.eq_ignore_ascii_case("max")) => Some((n, &a[0])),
        E::Bin(_, a, b) => find_minmax(a).or_else(|| find_minmax(b)),
        E::Unary(_, a) | E::Cast(a, _) | E::Collate(a, _) |
            E::OrderedCall(a, _) => find_minmax(a),
        _ => None,
    }
}
fn has_window(e: &E) -> bool {
    match e {
        E::Window(_, _) => true,
        E::Bin(_, a, b) => has_window(a) || has_window(b),
        E::Unary(_, a) | E::Cast(a, _) | E::Collate(a, _) => has_window(a),
        E::Call(_, args, _, _) => args.iter().any(has_window),
        _ => false,
    }
}

fn json_typed(e: &E) -> bool {
    match e {
        E::Call(n, _, _, _) =>
            n.starts_with("json") &&
                !["json_type", "json_valid", "json_array_length",
                                "json_error_position"].contains(&n.as_str()),
        E::Bin(n, _, _) => n == "->",
        _ => false,
    }
}

fn index_origin() -> String { "c".into() }

fn policy_error(mode: &str, e: String) -> String {
    if mode == "FAIL" || mode == "ROLLBACK" {
        format!("!{}!{}",mode,e)
    } else { e }
}

fn affinity_name(a: char) -> &'static str {
    match a {
        'I' => "INTEGER",
        'R' => "REAL",
        'N' => "NUMERIC",
        'T' => "TEXT",
        _ => "BLOB",
    }
}

fn child_exprs(e: &E) -> Vec<&E> {
    match e {
        E::Unary(_, a) | E::Cast(a, _) | E::Collate(a, _) => vec![a],
        E::OrderedCall(a, orders) => {
            let mut v = vec![a.as_ref()];
            v.extend(orders.iter().map(|o| &o.e));
            v
        }
        E::Bin(_, a, b) => vec![a,b],
        E::Call(_, a, _, f) => {
            let mut v = a.iter().collect::<Vec<_>>();
            if let Some(f) = f { v.push(f) }
            v
        }
        E::Tuple(a) => a.iter().collect(),
        E::Between(a, b, c, _) => vec![a,b,c],
        E::Like(a, b, esc, _, _) => {
            let mut v = vec![a.as_ref(),b.as_ref()];
            if let Some(e) = esc { v.push(e) }
            v
        }
        E::In(e, args, _, _) => {
            let mut v = vec![e.as_ref()];
            v.extend(args);
            v
        }
        E::Case(base, arms, end) => {
            let mut v = vec![];
            if let Some(e) = base { v.push(e.as_ref()) }
            for (a, b) in arms { v.push(a); v.push(b) }
            if let Some(e) = end { v.push(e.as_ref()) }
            v
        }
        _ => vec![],
    }
}
fn has_subquery(e: &E) -> bool {
    matches!(e,E::Sub(_)|E::SubCol(_,_)|E::Exists(_)|E::In(_,_,Some(_),_)) ||
        child_exprs(e).iter().any(|e| has_subquery(e))
}
fn nondeterministic(e: &E) -> bool {
    if let E::Call(n, _, _, _) = e {
        if ["random", "randomblob", "changes", "total_changes",
                        "last_insert_rowid"].contains(&n.to_ascii_lowercase().as_str())
            {
            return true
        }
    }
    child_exprs(e).iter().any(|e| nondeterministic(e))
}
fn column_refs(e: &E) -> Vec<String> {
    let mut v = vec![];
    if let E::Col(n) = e { v.push(n.last().unwrap().clone()) }
    if let E::Quoted(n) = e { v.push(n.clone()) }
    for e in child_exprs(e) { v.extend(column_refs(e)) }
    v
}
fn generated_cycle(t: &Table, i: usize, stack: &mut Vec<usize>) -> bool {
    if stack.contains(&i) { return true }
    if let Some(e) = &t.cols[i].generated {
        stack.push(i);
        for n in column_refs(e) {
            if let Some(j) =
                    t.cols.iter().position(|c| c.name.eq_ignore_ascii_case(&n))
                {
                if generated_cycle(t, j, stack) { return true }
            }
        }
        stack.pop();
    }
    false
}

fn statement_writes(s: &Stmt) -> bool {
    match s {
        Stmt::Temp(s) | Stmt::With(_, s) => statement_writes(s),
        Stmt::Attach(_, _) | Stmt::Detach(_) | Stmt::Query(_) |
            Stmt::Explain(_, _) | Stmt::Begin | Stmt::Commit |
            Stmt::Rollback(_) | Stmt::Savepoint(_) | Stmt::Release(_) =>
            false,
        Stmt::Pragma(n, arg) =>
            arg.is_some() &&
                ["user_version", "application_id",
                            "schema_version"].contains(&key(n).as_str()),
        Stmt::Noop => false,
        _ => true,
    }
}

fn persistent_db(db: &Db) -> Db {
    let mut d = db.clone();
    d.tables.retain(|_, t| !t.temporary);
    d.indexes.retain(|_, t| !t.temporary);
    d.views.retain(|_, t| !t.temporary);
    d.triggers.retain(|_, t| !t.temporary);
    d
}
fn quote_ident(s: &str) -> String { format!("\"{}\"",s.replace('"',"\"\"")) }
fn rewrite_identifier(sql: &str, old: &str, new: &str) -> Res<String> {
    let ts = lex(sql)?;
    let mut out = String::new();
    let mut pos = 0;
    for t in ts {
        if t.k != 1 && t.s.eq_ignore_ascii_case(old) {
            out.push_str(&sql[pos..t.start]);
            out.push_str(&quote_ident(new));
            pos = t.end
        }
    }
    out.push_str(&sql[pos..]);
    Ok(out)
}
fn query_uses(q: &Query, n: &str) -> bool {
    q.from.iter().any(|j|
                    match &j.source {
                        Source::Table(t) => t.eq_ignore_ascii_case(n),
                        Source::Query(q) => query_uses(q, n),
                        Source::Join(joins) =>
                            query_uses(&Query {
                                        from: joins.clone(),
                                        ..Default::default()
                                    }, n),
                        _ => false,
                    }) || q.compound.iter().any(|(_, q)| query_uses(q, n)) ||
        q.ctes.iter().any(|(_, _, q)| query_uses(q, n))
}
fn column_sql(c: &Column) -> String {
    let mut s = quote_ident(&c.name);
    if !c.typ.is_empty() { s.push(' '); s.push_str(&c.typ) }
    if c.notnull { s.push_str(" NOT NULL") }
    if let Some(d) = &c.default_sql { s.push_str(" DEFAULT "); s.push_str(d) }
    if c.coll != "BINARY" { s.push_str(" COLLATE "); s.push_str(&c.coll) }
    if let Some(e) = &c.generated {
        s.push_str(" AS (");
        s.push_str(&expr_sql(e));
        s.push_str(") VIRTUAL")
    }
    s
}
fn expr_sql(e: &E) -> String {
    match e {
        E::Val(V::Null) => "NULL".into(),
        E::Val(V::Text(s)) => format!("'{}'",s.replace('\'',"''")),
        E::Val(V::Blob(b)) =>
            format!("X'{}'",b.iter().map(|b|format!("{:02x}",b)).collect::<String>()),
        E::Val(v) => v.text(),
        E::Col(n) =>
            n.iter().map(|n| quote_ident(n)).collect::<Vec<_>>().join("."),
        E::Quoted(n) => quote_ident(n),
        E::Bin(op, a, b) => format!("({} {} {})",expr_sql(a),op,expr_sql(b)),
        E::Unary(op, a) => format!("{} ({})",op,expr_sql(a)),
        E::Call(n, args, d, _) =>
            format!("{}({}{})",n,if
                *d{"DISTINCT "}else{""},args.iter().map(expr_sql).collect::<Vec<_>>().join(", ")),
        E::Cast(e, t) => format!("CAST({} AS {})",expr_sql(e),t),
        E::Collate(e, c) => format!("{} COLLATE {}",expr_sql(e),c),
        E::Star(None) => "*".into(),
        _ => "NULL".into(),
    }
}
fn drop_column_sql(sql: &str, name: &str) -> Res<String> {
    let ts = lex(sql)?;
    let mut depth = 0;
    let mut start = 0;
    for (i, t) in ts.iter().enumerate() {
        if t.s == "(" {
            depth += 1;
            if depth == 1 { start = i + 1 }
        } else if t.s == ")" {
            if depth == 1 {
                if ts.get(start).map_or(false,
                        |t| t.s.eq_ignore_ascii_case(name)) {
                    let begin =
                        if start > 0 && ts[start - 1].s == "," {
                            ts[start - 1].start
                        } else { ts[start].start };
                    return Ok(format!("{}{}",&sql[..begin],&sql[t.start..]))
                }
            }
            depth -= 1
        } else if t.s == "," && depth == 1 {
            if ts.get(start).map_or(false, |t| t.s.eq_ignore_ascii_case(name))
                {
                return Ok(format!("{}{}",&sql[..ts[start].start],&sql[t.end..]))
            }
            start = i + 1
        }
    }
    Err("cannot rewrite table definition".into())
}

fn explicit_coll(e: &E) -> Option<&str> {
    if let E::Collate(_, c) = e { return Some(c) }
    for child in child_exprs(e) {
        if let Some(c) = explicit_coll(child) { return Some(c) }
    }
    None
}

fn dml_kind(s: &Stmt) -> Option<&'static str> {
    match s {
        Stmt::Insert { .. } => Some("rows inserted"),
        Stmt::Update { .. } => Some("rows updated"),
        Stmt::Delete { .. } => Some("rows deleted"),
        Stmt::With(_, s) => dml_kind(s),
        _ => None,
    }
}

fn statement_target(s: &Stmt) -> Option<&str> {
    match s {
        Stmt::Insert { table, .. } | Stmt::Update { table, .. } |
            Stmt::Delete { table, .. } => Some(table),
        Stmt::CreateTable { name, .. } | Stmt::CreateView { name, .. } =>
            Some(name),
        Stmt::CreateIndex { name, table, .. } =>
            if name.contains('.') { Some(name) } else { Some(table) },
        Stmt::CreateTrigger(t, _) =>
            if t.name.contains('.') { Some(&t.name) } else { Some(&t.table) },
        Stmt::Drop(_, n, _) | Stmt::Alter(n, _) | Stmt::Pragma(n, _) =>
            Some(n),
        Stmt::Temp(s) => statement_target(s),
        _ => None,
    }
}
fn strip_schema(sql: &str, schema: &str) -> Res<String> {
    let ts = lex(sql)?;
    let mut out = String::new();
    let mut pos = 0;
    for pair in ts.windows(2) {
        if pair[0].k != 1 && pair[0].s.eq_ignore_ascii_case(schema) &&
                pair[1].s == "." {
            out.push_str(&sql[pos..pair[0].start]);
            pos = pair[1].end
        }
    }
    out.push_str(&sql[pos..]);
    Ok(out)
}

fn strip_target(s: &mut Stmt, schema: &str) {
    let strip = |n: &mut String| strip_name(n, schema);
    match s {
        Stmt::Insert { table, q, returning, upsert, .. } => {
            strip(table);
            if let Some(q) = q { strip_query(q, schema) }
            for i in returning { strip_expr(&mut i.e, schema) }
            if let Some(u) = upsert {
                for (_, e) in &mut u.sets { strip_expr(e, schema) }
                if let Some(e) = &mut u.filter { strip_expr(e, schema) }
            }
        }
        Stmt::Update { table, sets, filter, from, returning, .. } => {
            strip(table);
            for (_, e) in sets { strip_expr(e, schema) }
            if let Some(e) = filter { strip_expr(e, schema) }
            strip_sources(from, schema);
            for i in returning { strip_expr(&mut i.e, schema) }
        }
        Stmt::Delete { table, filter, returning, .. } => {
            strip(table);
            if let Some(e) = filter { strip_expr(e, schema) }
            for i in returning { strip_expr(&mut i.e, schema) }
        }
        Stmt::CreateTable { name, foreign, asq, checks, cols, .. } => {
            strip(name);
            for f in foreign { strip(&mut f.table) }
            if let Some(q) = asq { strip_query(q, schema) }
            for e in checks { strip_expr(e, schema) }
            for c in cols {
                if let Some(e) = &mut c.default { strip_expr(e, schema) }
                if let Some(e) = &mut c.generated { strip_expr(e, schema) }
            }
        }
        Stmt::CreateView { name, q, .. } => {
            strip(name);
            strip_query(q, schema)
        }
        Stmt::CreateIndex { name, table, expr, filter, .. } => {
            strip(name);
            strip(table);
            for e in expr { strip_expr(e, schema) }
            if let Some(e) = filter { strip_expr(e, schema) }
        }
        Stmt::CreateTrigger(t, _) => {
            strip(&mut t.name);
            strip(&mut t.table);
            if let Some(e) = &mut t.when { strip_expr(e, schema) }
            t.sql = strip_schema(&t.sql, schema).unwrap_or(t.sql.clone());
            for b in &mut t.body {
                *b = strip_schema(b, schema).unwrap_or(b.clone());
            }
        }
        Stmt::Drop(_, n, _) | Stmt::Alter(n, _) | Stmt::Pragma(n, _) =>
            strip(n),
        Stmt::Temp(s) => strip_target(s, schema),
        Stmt::With(q, s) => {
            strip_query(q, schema);
            strip_target(s, schema)
        }
        _ => {}
    }
}
fn strip_name(n: &mut String, schema: &str) {
    if let Some((prefix, tail)) = n.split_once('.') {
        if prefix.eq_ignore_ascii_case(schema) { *n = tail.to_string() }
    }
}
fn strip_sources(from: &mut [Join], schema: &str) {
    for j in from {
        match &mut j.source {
            Source::Table(n) => strip_name(n, schema),
            Source::Function(n, args) => {
                strip_name(n, schema);
                for e in args { strip_expr(e, schema) }
            }
            Source::Query(q) => strip_query(q, schema),
            Source::Join(joins) => strip_sources(joins, schema),
        }
        if let Some(e) = &mut j.on { strip_expr(e, schema) }
    }
}
fn strip_window(w: &mut WinSpec, schema: &str) {
    for e in &mut w.partition { strip_expr(e, schema) }
    for o in &mut w.order { strip_expr(&mut o.e, schema) }
    for b in [&mut w.start, &mut w.end] {
        if let Some(Bound::Offset(e, _)) = b { strip_expr(e, schema) }
    }
}
fn strip_query(q: &mut Query, schema: &str) {
    strip_sources(&mut q.from, schema);
    for i in &mut q.items { strip_expr(&mut i.e, schema) }
    for e in [&mut q.filter, &mut q.having, &mut q.limit, &mut q.offset] {
        if let Some(e) = e { strip_expr(e, schema) }
    }
    for e in &mut q.group { strip_expr(e, schema) }
    for o in &mut q.order { strip_expr(&mut o.e, schema) }
    for (_, w) in &mut q.windows { strip_window(w, schema) }
    for (_, _, q) in &mut q.ctes { strip_query(q, schema) }
    for (_, q) in &mut q.compound { strip_query(q, schema) }
    for row in &mut q.values { for e in row { strip_expr(e, schema) } }
}
fn strip_expr(e: &mut E, schema: &str) {
    match e {
        E::Col(n) => {
            if n.len() >= 3 && n[0].eq_ignore_ascii_case(schema) {
                n.remove(0);
            } else if n.len() == 2 { strip_name(&mut n[0], schema) }
        }
        E::Star(Some(n)) => strip_name(n, schema),
        E::Sub(q) | E::SubCol(q, _) | E::Exists(q) => strip_query(q, schema),
        E::Unary(_, e) | E::Cast(e, _) | E::Collate(e, _) =>
            strip_expr(e, schema),
        E::Bin(_, a, b) => { strip_expr(a, schema); strip_expr(b, schema) }
        E::Call(_, args, _, filter) => {
            for e in args { strip_expr(e, schema) }
            if let Some(e) = filter { strip_expr(e, schema) }
        }
        E::Tuple(es) => { for e in es { strip_expr(e, schema) } }
        E::Between(a, b, c, _) => {
            strip_expr(a, schema);
            strip_expr(b, schema);
            strip_expr(c, schema)
        }
        E::In(e, args, q, _) => {
            strip_expr(e, schema);
            for e in args { strip_expr(e, schema) }
            if let Some(q) = q { strip_query(q, schema) }
        }
        E::Case(base, arms, end) => {
            if let Some(e) = base { strip_expr(e, schema) }
            for (a, b) in arms {
                strip_expr(a, schema);
                strip_expr(b, schema)
            }
            if let Some(e) = end { strip_expr(e, schema) }
        }
        E::Like(a, b, esc, _, _) => {
            strip_expr(a, schema);
            strip_expr(b, schema);
            if let Some(e) = esc { strip_expr(e, schema) }
        }
        E::Window(e, w) => { strip_expr(e, schema); strip_window(w, schema) }
        E::OrderedCall(e, o) => {
            strip_expr(e, schema);
            for o in o { strip_expr(&mut o.e, schema) }
        }
        _ => {}
    }
}

fn table_qualifies(table: &str, qual: &str) -> bool {
    if qual.contains('.') {
        if let Some(q) = qual.strip_prefix("main.") {
            table.eq_ignore_ascii_case(q)
        } else { table.eq_ignore_ascii_case(qual) }
    } else {
        table.rsplit('.').next().unwrap_or(table).eq_ignore_ascii_case(qual)
    }
}
fn qualify_target(s: &mut Stmt, schema: &str) {
    let n =
        match s {
            Stmt::Insert { table, .. } | Stmt::Update { table, .. } |
                Stmt::Delete { table, .. } => table,
            Stmt::Drop(_, n, _) | Stmt::Alter(n, _) => n,
            _ => return,
        };
    *n = format!("{}.{}",schema,n);
}

fn query_touches(q: &Query) -> bool {
    !q.from.is_empty() || q.items.iter().any(|i| has_subquery(&i.e)) ||
                    q.values.iter().flatten().any(has_subquery) ||
                q.ctes.iter().any(|(_, _, q)| query_touches(q)) ||
            q.compound.iter().any(|(_, q)| query_touches(q)) ||
        q.filter.as_ref().map_or(false, has_subquery)
}
fn statement_touches(s: &Stmt) -> bool {
    match s {
        Stmt::Query(q) => query_touches(q),
        Stmt::With(q, s) => query_touches(q) || statement_touches(s),
        Stmt::Temp(s) => statement_touches(s),
        Stmt::Begin | Stmt::Commit | Stmt::Rollback(_) | Stmt::Savepoint(_) |
            Stmt::Release(_) | Stmt::Attach(_, _) | Stmt::Detach(_) |
            Stmt::Noop | Stmt::Explain(_, _) => false,
        Stmt::Pragma(n, _) =>
            !["foreign_keys", "busy_timeout", "query_only", "count_changes",
                            "ignore_check_constraints", "recursive_triggers",
                            "case_sensitive_like"].contains(&n.as_str()),
        _ => true,
    }
}

fn dedup_with(rows: &mut Vec<Vec<V>>, eq: &impl Fn(&[V], &[V]) -> bool) {
    let mut out = vec![];
    for row in rows.drain(..) {
        if !out.iter().any(|r: &Vec<V>| eq(r, &row)) { out.push(row) }
    }
    *rows = out
}
