use crate::syntax::Res;
use std::fs::{File, OpenOptions};
use std::io::Write;
use std::path::{Path,PathBuf};
use std::sync::atomic::{AtomicU64,Ordering};
static NEXT_FILE:AtomicU64=AtomicU64::new(0);
fn unique_path(path:&Path,kind:&str)->PathBuf{
    let clock=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
    path.with_file_name(format!("{}.agent-{}-{}-{}-{}",path.file_name().unwrap().to_string_lossy(),kind,std::process::id(),clock,NEXT_FILE.fetch_add(1,Ordering::Relaxed)))
}
fn sync_directory(path:&Path)->Res<()>{
    if let Some(parent)=path.parent(){File::open(parent).and_then(|f|f.sync_all()).map_err(|e|e.to_string())?}
    Ok(())
}
// Staging every participant before installing any prevents partial commits on
// serialization, preparation, or permission failures. Backups allow recovery
// from an installation error within the running process.
pub struct Prepared {
    target:PathBuf,
    staged:PathBuf,
    backup:Option<PathBuf>,
    installed:bool,
    preserve_backup:bool,
}
impl Prepared{
    pub fn new(path:&Path,bytes:&[u8])->Res<Self>{
        if let Ok(metadata)=path.symlink_metadata(){if !metadata.file_type().is_file(){return Err("database target is not a regular file".into())}}
        let staged=unique_path(path,"tmp");
        let mut state=Self{target:path.to_path_buf(),staged,backup:None,installed:false,preserve_backup:false};
        let mut f=OpenOptions::new().write(true).create_new(true).open(&state.staged).map_err(|e|e.to_string())?;
        if let Ok(metadata)=path.metadata(){f.set_permissions(metadata.permissions()).map_err(|e|e.to_string())?}
        f.write_all(bytes).and_then(|_|f.sync_all()).map_err(|e|e.to_string())?;
        if path.exists(){let backup=unique_path(path,"backup");std::fs::hard_link(path,&backup).map_err(|e|e.to_string())?;state.backup=Some(backup);}
        sync_directory(path)?;
        Ok(state)
    }
    fn install(&mut self)->Res<()>{
        std::fs::rename(&self.staged,&self.target).map_err(|e|e.to_string())?;self.installed=true;
        sync_directory(&self.target)
    }
    fn restore(&mut self)->Res<()>{
        if self.installed{
            if let Some(backup)=&self.backup{std::fs::rename(backup,&self.target).map_err(|e|e.to_string())?}
            else{std::fs::remove_file(&self.target).map_err(|e|e.to_string())?}
            self.installed=false;sync_directory(&self.target)?;
        }
        Ok(())
    }
}
impl Drop for Prepared{
    fn drop(&mut self){let _=std::fs::remove_file(&self.staged);if !self.preserve_backup{if let Some(backup)=&self.backup{let _=std::fs::remove_file(backup);}}}
}
pub fn install_all(prepared:&mut [Prepared])->Res<()>{
    for i in 0..prepared.len(){if let Err(error)=prepared[i].install(){
        let mut recovery=None;
        for p in prepared[..=i].iter_mut().rev(){if let Err(e)=p.restore(){p.preserve_backup=true;recovery=Some(e)}}
        return Err(if let Some(e)=recovery{format!("{}; rollback of database files failed: {}",error,e)}else{error})
    }}
    Ok(())
}
