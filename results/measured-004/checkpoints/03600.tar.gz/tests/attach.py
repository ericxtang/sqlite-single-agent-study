exec(open('/work/tests/semantics.py').read().split("req('open',path=':memory:')")[0])
path='/work/attached-test.db'
for f in [path,path+'.agent-lock']:
 try:os.unlink(f)
 except FileNotFoundError:pass
req('open',path=':memory:')
sql(f"ATTACH DATABASE '{path}' AS aux")
sql('CREATE TABLE main.t(id INTEGER PRIMARY KEY,v)')
sql('CREATE TABLE aux.t(id INTEGER PRIMARY KEY,v)')
sql("INSERT INTO main.t VALUES(1,'main')");sql("INSERT INTO aux.t VALUES(1,'aux')")
eq('SELECT m.v,a.v FROM main.t AS m JOIN aux.t AS a USING(id)',[['main','aux']])
eq('SELECT last_insert_rowid(),changes(),total_changes()',[[1,1,2]])
eq("PRAGMA aux.table_info('t')",[[0,'id','INTEGER',0,None,1],[1,'v','',0,None,0]])
sql('BEGIN');sql("UPDATE t SET v='newmain'");sql("UPDATE aux.t SET v='newaux'");sql('ROLLBACK')
eq('SELECT m.v,a.v FROM main.t m,aux.t a',[['main','aux']])
sql('SAVEPOINT s');sql("INSERT INTO aux.t VALUES(2,'two')");sql('ROLLBACK TO s');sql('RELEASE s');eq('SELECT count(*) FROM aux.t',[[1]])
sql('BEGIN');sql("INSERT INTO aux.t VALUES(2,'two')");sql('COMMIT')
sql('DETACH aux');err('SELECT * FROM aux.t');sql(f"ATTACH '{path}' AS aux");eq('SELECT count(*) FROM aux.t',[[2]])
assert len(vals('PRAGMA database_list'))==2
req('close');p.terminate();os.unlink(path);os.unlink(path+'.agent-lock');print('attached database tests passed')
