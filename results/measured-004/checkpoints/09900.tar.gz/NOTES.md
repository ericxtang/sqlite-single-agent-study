# sqlite-agent implementation state

Build: cargo build --release --offline --bin sqlite-agent.
Test: python3 tests/run_all.py. All tests exercise our executable using documentation-derived expectations; no reference database/parser was used.
Continue making useful progress until the controller ends the work period.

## Architecture
- syntax.rs: handwritten tokenizer, Pratt expression parser, SELECT/DDL/DML/transaction parser, serializable AST.
- value.rs: NULL/integer/real/text/blob values, affinity, comparison, casting, typed JSON response encoding.
- engine.rs: relational execution and binding, schema/constraints/triggers, snapshots/savepoints, persistence and connection management.
- funcs.rs: scalar/math/date/JSON/JSON5 functions, JSON/series table functions, iterative pattern matching, formatting.
- json.rs: ordered JSON AST/parser preserving object order and duplicate labels.
- storage.rs: staged snapshots, multi-file commit journals/recovery, filesystem synchronization, bounded deep-schema decoding.
- main.rs: persistent JSON-lines interface; stdout contains only flushed protocol responses.
- CTE data and window input data use shared immutable Arc values; row context clones avoid copying entire input relations.

## Integrated behavior
SELECT aliases, DISTINCT, sorting/limits, ordinary/outer/natural/USING/parenthesized joins, aggregates (FILTER and argument ORDER BY), correlated/scalar/row subqueries, ordinary/recursive CTEs, compounds, windows. Compound ordering resolves aliases/expressions across branches and applies result collations. Lazy CASE/coalesce/iif branches bind without evaluating unused subqueries. BETWEEN freezes its left operand once.

Window ranking/offset/value/aggregate functions; named windows/chaining, partitions, ROWS/GROUPS/RANGE, exclusions, grouped aggregates within windows, static placement/frame checks. Recursive CTEs use a single-row work queue, FIFO or ORDER BY priority, LIMIT/OFFSET, UNION deduplication, multiple anchors/recursive terms; optional RECURSIVE keyword. Forward CTE dependencies work, unused SELECT CTEs are skipped. A one-million-step/queued-row resource limit prevents unlimited recursion.

Tables/views/indexes/triggers; INSERT/UPDATE/DELETE with RETURNING, UPSERT, UPDATE FROM, WITH DML; ALTER rename/add/drop common dependency rewrites. Rowid/integer-PK/autoincrement and writable sqlite_sequence; affinity, collations, generated/strict/without-rowid tables; UNIQUE/NOT NULL/CHECK/FK constraints and conflict policies. Foreign-key actions, deferred checks, BEFORE/AFTER/INSTEAD OF triggers, RAISE and trigger change accounting. Introspection pragmas, autoindex metadata, integrity/FK checks, scan-oriented EXPLAIN QUERY PLAN.

BEGIN/COMMIT/ROLLBACK, savepoints, statement rollback and FAIL/ROLLBACK/IGNORE/REPLACE behavior. BEGIN DEFERRED activates a snapshot on database access. OS writer locks, committed-file refresh, stale snapshot rejection. Synced unique temporary snapshot, atomic rename, parent directory sync, preserved file permissions, commit generations and busy_timeout. Multi-file commits stage every participant, then persist a shared commit decision and per-file journal pointers. Recovery finishes committed groups or restores groups whose durable decision is rollback. Opening or refreshing any affected database performs recovery. Uncommitted data is memory-only and discarded on close/crash. Path confinement to /work and symlink checks. ATTACH/DETACH, qualified reads/writes, joins, copied DML/CTAS, attached transactions/savepoints. Temporary objects use a separate in-memory schema with main/temp shadowing, explicit qualifiers, schema-local persistent views, temporary cross-schema views, and temporary triggers. Temporary state is excluded from persistence. Root write statements use implicit transactions across attached participants, preserving ABORT/FAIL/ROLLBACK behavior for cross-schema trigger writes.

Core/math/date/strftime functions, numeric interpretation/range checks, timezone conversion via the documented localtime_r/mktime OS service, millisecond precision, frozen statement clock, and directional timediff round trips. Fractional months/years use 30/365-day fractions as an implementation choice. Also unistr/unistr_quote and printf/format. SQL text conversion uses 15-digit real formatting; typed JSON responses preserve available real precision. JSON and JSON5 syntax/validation, constructors, paths/extraction/operators, mutation/merge-patch, aggregation, each/tree, pretty formatting. Ordered JSON values preserve duplicate labels; extraction/edits target the first matching label. JSON nesting limit 1000. LIKE/GLOB use iterative matching.

## Validation
Regression suites cover expressions/types, storage/reopen, transactions/concurrent writers/crash rollback, schema/constraints, triggers/cascades, views/temp, attached files, ALTER, aggregate/window binding, compound ordering/collation, row subqueries, CTE queues/dependencies, joins, JSON/JSON5/order, formatting/casts and autoincrement resets. A seeded 500-operation transaction model checks combined DML/snapshot behavior. A 12,000-row recursive query verifies iterative execution and guards the former context-copy performance issue. Multi-file recovery tests terminate subprocesses at seven commit/rollback/cleanup stages, then verify consistent file outcomes; another test reopens actual database snapshots after a partial installation. Deep schema reopen tests cover generated expressions beyond serde_json’s default document nesting limit.

## Known limitations / useful next directions
- Persistence is an internal JSON snapshot, **not native SQLite binary format**. No B-tree, physical index optimizer, native journal or WAL. Reported storage pragmas are approximations. Isolation resembles snapshot/WAL behavior. The custom multi-file recovery journal is tested, but native SQLite journal/WAL interoperability is absent. Independent reads of different attachments do not establish a single global read snapshot.
- Main/temp shadowing and common cross-schema reads/writes work. Some temporary trigger naming collisions and temporary ALTER rewrites remain incomplete. Attached writes use a parent snapshot for cross-schema reads; cross-schema writes originating inside an attached/temp schema trigger remain limited. Snapshot activation is shared across attachments.
- Comprehensive SQL binding still has gaps. Uncorrelated subqueries are not cached; EXISTS with compounds/offset may evaluate projection values. Some unusual alias/compound collation/aggregate/window corner cases remain. WITH DML materializes CTEs eagerly.
- JSONB is unavailable (binary details are not supplied). JSON subtype propagation is syntax-based and incomplete. JSON5 escaped identifiers and some malformed-input positions are incomplete. Table JSON ids are internal counters, not stable binary offsets.
- Date/time edge behavior (e.g. preserving an explicit 24:00 input without normalization and uncommon timezone transitions) still needs review.
- Plain EXPLAIN returns an unsupported error; there is no VDBE. Some pragmas/virtual extensions/physical index behaviors are absent.
- Rustfmt is unavailable. Source can be formatted offline using the installed compiler's parser printer: RUSTC_BOOTSTRAP=1 rustc -Zunpretty=normal --edition=2021 src/<file>.rs, capturing stdout into that file via Python after successful completion. This was used successfully, followed by a full build/test run.

Next: continue SQL binding/constraint/schema edge cases, performance of table/index operations, and durability review. Current integrated suite has 33 Python regression suites plus Rust subprocess crash/recovery tests. Keep the integrated executable usable.
