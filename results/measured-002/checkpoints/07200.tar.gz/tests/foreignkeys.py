import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('PRAGMA foreign_keys=ON')
sql('CREATE TABLE child(p REFERENCES parent(id))');sql('CREATE TABLE parent(id INTEGER PRIMARY KEY)')
sql('INSERT INTO child VALUES(1)',False);sql('INSERT INTO parent VALUES(1)');sql('INSERT INTO child VALUES(1)')
sql('DELETE FROM parent',False)
sql('CREATE TABLE selfref(id INTEGER PRIMARY KEY,p REFERENCES selfref(id) ON DELETE CASCADE ON UPDATE CASCADE)')
sql('INSERT INTO selfref VALUES(1,1)');sql('UPDATE selfref SET id=2');assert sql('SELECT * FROM selfref')==[['2','2']]
sql('INSERT INTO selfref VALUES(3,2),(4,3)');sql('DELETE FROM selfref WHERE id=2');assert sql('SELECT count(*) FROM selfref')==[['0']]
sql('CREATE TABLE cycle(id INTEGER PRIMARY KEY,p REFERENCES cycle(id) ON DELETE CASCADE)')
sql('INSERT INTO cycle VALUES(1,2),(2,1)');sql('DELETE FROM cycle WHERE id=1');assert sql('SELECT count(*) FROM cycle')==[['0']]
sql('CREATE TABLE nn(p NOT NULL REFERENCES parent(id) ON DELETE SET NULL)');sql('INSERT INTO nn VALUES(1)')
sql('DELETE FROM child');sql('DELETE FROM parent',False);assert sql('SELECT id FROM parent')==[['1']]
sql('DROP TABLE nn')
sql('CREATE TABLE cas(p REFERENCES parent(id) ON DELETE CASCADE ON UPDATE CASCADE)');sql('CREATE TABLE logs(e,p)')
sql("CREATE TRIGGER casu AFTER UPDATE ON cas BEGIN INSERT INTO logs VALUES('U',new.p); END")
sql("CREATE TRIGGER casd AFTER DELETE ON cas BEGIN INSERT INTO logs VALUES('D',old.p); END")
sql('INSERT INTO cas VALUES(1)');sql('UPDATE parent SET id=2');sql('DELETE FROM parent')
assert sql('SELECT * FROM logs')==[['U','2'],['D','2']]
sql('PRAGMA foreign_keys=OFF');sql('INSERT INTO child VALUES(99)');sql('PRAGMA foreign_keys=ON')
assert sql('SELECT p FROM child')==[['99']]
sql('CREATE TABLE unrelated(x)');sql('INSERT INTO unrelated VALUES(1)')
sql('INSERT INTO parent VALUES(3)');sql('INSERT INTO child VALUES(3)');sql('INSERT INTO child VALUES(4)',False)
sql('BEGIN');sql('INSERT INTO unrelated VALUES(2)');sql('COMMIT')
assert len(sql('PRAGMA foreign_key_check'))==1
sql('CREATE TABLE badparent(x)');sql('CREATE TABLE badchild(x REFERENCES badparent(x))');sql('INSERT INTO badparent VALUES(1)');sql('INSERT INTO badchild VALUES(1)',False)
# A new row cannot inherit the exemption for a historical violation with the same rowid/key.
sql('BEGIN');sql('DELETE FROM child WHERE p=99');sql('INSERT INTO child(rowid,p) VALUES(1,99)',False);sql('ROLLBACK')
assert sql('SELECT p FROM child WHERE p=99')==[['99']]
sql('CREATE TABLE hist(id INTEGER PRIMARY KEY,p REFERENCES parent(id) DEFERRABLE INITIALLY DEFERRED)')
sql('PRAGMA foreign_keys=OFF');sql('INSERT INTO hist VALUES(1,999)');sql('PRAGMA foreign_keys=ON')
sql('BEGIN');sql('DELETE FROM hist');sql('INSERT INTO hist VALUES(1,999)');sql('COMMIT',False);sql('ROLLBACK')
assert sql('SELECT * FROM hist')==[['1','999']]
sql('BEGIN');sql('UPDATE hist SET id=2');sql('COMMIT');assert sql('SELECT * FROM hist')==[['2','999']]
p.terminate();p.wait();print('PASS: foreign-key cycles, self updates, child constraints/triggers, historical violations, parent keys')
