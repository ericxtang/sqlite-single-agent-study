//! Find live CTE dependencies without crossing a nested WITH binding.
use crate::{ast::*, parser::Res};
use std::collections::{HashMap, HashSet};
type Names = HashSet<String>;

fn expression(e: &Expr, out: &mut Names) {
    match e {
        Expr::Sub(q) | Expr::Exists(q) => out.extend(query_names(q)),
        Expr::In(_, _, Some(q), _) => out.extend(query_names(q)),
        Expr::Func { order, over, .. } => {
            orders(order, out);
            if let Some(w) = over { window(w, out); }
        }
        _ => {}
    }
    for e in e.children() { expression(e, out); }
}
fn orders(list: &[Order], out: &mut Names) {
    for o in list { expression(&o.expr, out); }
}
fn window(w: &Window, out: &mut Names) {
    for e in &w.partition { expression(e, out); }
    orders(&w.order, out);
    if let Some((_, a, b)) = &w.frame {
        for bound in [a, b] {
            if let Bound::Pre(e) | Bound::Following(e) = bound { expression(e, out); }
        }
    }
}
fn joins(list: &[Join], out: &mut Names) {
    for j in list {
        match &j.source {
            Source::Table(n, _, args) => {
                out.insert(n.to_ascii_lowercase());
                for e in args { expression(e, out); }
            }
            Source::Query(q, _) => out.extend(query_names(q)),
            Source::Nested(js, _) => joins(js, out),
        }
        if let Some(e) = &j.on { expression(e, out); }
    }
}
fn body(q: &Query) -> Names {
    let mut out = Names::new();
    for c in &q.cores {
        joins(&c.from, &mut out);
        for i in &c.items { expression(&i.expr, &mut out); }
        for e in c.wh.iter().chain(&c.group).chain(c.having.iter()) { expression(e, &mut out); }
        for row in &c.values { for e in row { expression(e, &mut out); } }
        for (_, w) in &c.windows { window(w, &mut out); }
    }
    orders(&q.order, &mut out);
    for e in q.limit.iter().chain(q.offset.iter()) { expression(e, &mut out); }
    out
}
// Return both reachable local definitions and the names they need from outside.
fn resolve(cs: &[Cte], direct: Names) -> (Names, Names) {
    let defs = cs.iter().map(|c| (c.name.to_ascii_lowercase(), c)).collect::<HashMap<_, _>>();
    let mut pending = direct.into_iter().collect::<Vec<_>>();
    let mut live = Names::new();
    let mut external = Names::new();
    while let Some(name) = pending.pop() {
        if let Some(c) = defs.get(&name) {
            if live.insert(name) { pending.extend(query_names(&c.query)); }
        } else { external.insert(name); }
    }
    (live, external)
}
pub(crate) fn query_names(q: &Query) -> Names { resolve(&q.ctes, body(q)).1 }
fn selected(cs: &[Cte], direct: Names) -> Res<Vec<Cte>> {
    let mut seen = Names::new();
    for c in cs {
        if !seen.insert(c.name.to_ascii_lowercase()) {
            return Err(format!("duplicate WITH table name: {}", c.name));
        }
    }
    let (live, _) = resolve(cs, direct);
    Ok(cs.iter().filter(|c| live.contains(&c.name.to_ascii_lowercase())).cloned().collect())
}
pub(crate) fn for_query(q: &Query) -> Res<Vec<Cte>> { selected(&q.ctes, body(q)) }
pub(crate) fn for_statement(cs: &[Cte], stmt: &Stmt) -> Res<Vec<Cte>> {
    selected(cs, statement_names(stmt))
}
fn statement_names(stmt: &Stmt) -> Names {
    let mut out = Names::new();
    match stmt {
        Stmt::Select(q) | Stmt::CreateView { query: q, .. } => out.extend(query_names(q)),
        Stmt::Insert { query, upsert, ret, .. } => {
            if let Some(q) = query { out.extend(query_names(q)); }
            for u in upsert {
                for e in u.target.iter().chain(u.target_where.iter()).chain(u.wh.iter()) {
                    expression(e, &mut out);
                }
                for (_, e) in &u.set { expression(e, &mut out); }
            }
            for i in ret { expression(&i.expr, &mut out); }
        }
        Stmt::Update { set, wh, from, ret, order, limit, .. } => {
            for (_, e) in set { expression(e, &mut out); }
            for e in wh.iter().chain(limit.iter()) { expression(e, &mut out); }
            joins(from, &mut out);
            orders(order, &mut out);
            for i in ret { expression(&i.expr, &mut out); }
        }
        Stmt::Delete { wh, ret, order, limit, .. } => {
            for e in wh.iter().chain(limit.iter()) { expression(e, &mut out); }
            orders(order, &mut out);
            for i in ret { expression(&i.expr, &mut out); }
        }
        Stmt::With(cs, _, s) => return resolve(cs, statement_names(s)).1,
        Stmt::Explain(s, _) => return statement_names(s),
        Stmt::CreateTable(t) => { if let Some(q) = &t.query { out.extend(query_names(q)); } }
        _ => {}
    }
    out
}

/// A recursive table can occur once in the recursive SELECT's FROM clause,
/// including parenthesized joins, and nowhere in its subqueries or expressions.
pub(crate) fn recursive_split(c: &Cte) -> Res<Option<usize>> {
    let name = c.name.to_ascii_lowercase();
    if !query_names(&c.query).contains(&name) { return Ok(None); }
    fn hide_direct(js: &mut [Join], name: &str) -> usize {
        let mut count = 0;
        for j in js {
            match &mut j.source {
                Source::Table(n, _, _) if n.eq_ignore_ascii_case(name) => { n.clear(); count += 1; }
                Source::Nested(js, _) => count += hide_direct(js, name),
                _ => {}
            }
        }
        count
    }
    let mut probe = c.query.clone();
    let mut counts = vec![];
    for core in &mut probe.cores { counts.push(hide_direct(&mut core.from, &name)); }
    if query_names(&probe).contains(&name) {
        return Err(format!("recursive reference in a subquery or expression: {}", c.name));
    }
    let split = counts.iter().position(|n| *n != 0)
        .ok_or_else(|| format!("circular reference: {}", c.name))?;
    if split == 0 { return Err(format!("circular reference: {}", c.name)); }
    if counts[split..].iter().any(|n| *n != 1) {
        return Err("recursive table must appear exactly once in each recursive SELECT".into());
    }
    Ok(Some(split))
}
