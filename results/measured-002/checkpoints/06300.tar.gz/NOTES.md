# Work state and continuation notes

All shell operations, reads/writes, compilation and tests use `mcp__workspace__exec` at /work. Only /docs, our own code/tests, Rust std, serde and serde_json have been used. No database engine, SQL parser, external tests/source, network, other models, or agents. User explicitly wants continued independent useful progress until the controller stops the work period.

## Integrated implementation

- Rust project and JSON-lines process contract implemented; release binary path is `target/release/sqlite-agent`.
- Lexer/Pratt parser, typed values, affinities, casts, NULL/boolean semantics, collation, rowids, overflow promotion.
- SELECT/VALUES, joins (LEFT/RIGHT/FULL/USING/NATURAL), projection, WHERE/GROUP/HAVING/ORDER/LIMIT, DISTINCT and compounds, correlated subqueries, row values, ordinary/recursive CTEs.
- Window functions with ROWS/RANGE/GROUPS, EXCLUDE forms, filters, grouped-window evaluation and named-window chaining. Percentile/median aggregates and windows included.
- Schema-aware ALTER RENAME TABLE/COLUMN and DROP COLUMN dependency checking; SQL rendering covers subqueries, compounds, windows, trigger DML. Index determinism, unique creation collations, dynamic date/time determinism are checked.
- DDL/DML, constraints/conflict algorithms, UPSERT targets, RETURNING, strict/without-rowid/generated columns, foreign keys/cascades/deferred checks.
- BEFORE/AFTER/INSTEAD OF triggers, WHEN, UPDATE OF, OLD/NEW, RAISE, recursion controls, UPSERT hooks and view DML.
- ATTACH/DETACH with flat qualified schema names, cross-database queries, per-file persistence, qualified views/triggers, temporary-table shadowing.
- Recursive CTEs use a documented extraction queue, including ORDER BY priority, LIMIT/OFFSET, compound seeds/recursive terms, forward CTE dependencies, optional RECURSIVE keyword. Compound set comparisons honor collations and ORDER BY resolves result expressions/aliases across terms.
- sqlite_sequence is an actual table, including direct modifications and lifetime after last AUTOINCREMENT table is dropped.
- Functions for strings, numbers, dates, JSON/JSON5, JSON paths/table functions, Unicode escapes, introspection pragmas.
- SQLite 3 native database images: headers, varints/records, table and index leaf/interior B-trees, overflow chains, freelist, UTF8/UTF16 reading. Descending index keys retained. Complete new image + fsync + atomic rename for commits.
- Two-file OS flock coordination (reader and writer) among our own processes. Deferred/immediate/exclusive transactions, commit retry with readers, snapshot isolation in WAL mode, crash rollback (uncommitted changes remain private). Durable application-level super-journal manifests/backups provide crash atomicity across attached files; recovery happens on open/access. Symlink aliases canonicalize to common file/lock paths. Native WAL files are NOT generated or recovered; WAL header/mode and snapshot behavior use atomic images.

## Tests and build

`cargo build --offline --bin sqlite-agent` succeeds with no warnings. Required delivery build: `cargo build --release --offline --bin sqlite-agent` (run again after changes; release may lag debug).
`cargo test --offline`: varint/record boundary round trips.
Process tests:
- `tests/semantics.py`: 118 core/documented assertions, state and reopen.
- `tests/edgecases.py`: sequence edits, upsert targeting, empty-query errors, affinities, descending PKs, schema validation, JSON5 and percentile functions.
- `tests/windows.py`: explicit RANGE/GROUPS/ROWS, exclusions, grouped windows, chaining, offsets.
- `tests/triggers.py`: row and view triggers, counters, recursive behavior, RAISE, persistence.
- `tests/attach.py`: attached files, cross-schema joins, rollback, reattach under new names, stored views/triggers, temp shadowing, attached sequences/autoindexes.
- `tests/isolation.py`: two subprocesses, writer conflicts, commit retry, snapshots, killed writer.
- `tests/storage.py`: 512/4096/65536-byte images, large indexes and overflow blobs; independent Python structural decoder verifies every page belongs to a B-tree, overflow chain or freelist, and reopened SQL values agree.
- `tests/recovery.py`: inject pending/committed manifests with 0/1/2 replaced images and verify whole-transaction recovery.
- `tests/foreignkeys.py`: cyclic/self cascades, child constraints/triggers, historical violations, parent key checks.
- `tests/names.py`: star slots, quoted identifiers/defaults/generated cycles, tuple comparisons, nested aliases, zero-row validation, collation propagation.
- `tests/ctes.py`: queue priority, offsets, compound seeds, forward dependencies, compound result ordering/collations.
- `tests/robustness.py`: deep parser/expression/JSON errors and 300 deterministic mutations of our SQL snippets.
- `tests/alter.py`: rename/drop dependencies, views/trigger programs, foreign keys, automatic indices/sequences, quoted punctuation, reopened behavior.
- `tests/indexes.py`: expression/partial-index restrictions, existing-key collations, dynamic date/time determinism, reordered FK targets and collation matching.
All 14 process suites and cargo unit tests passed against the freshly rebuilt release binary after these changes. No warnings. Build failures must stop dependent tests (use &&), to avoid accidentally running an older binary. rustfmt component is not installed, and must not be fetched; code currently has dense formatting.

## Current limitations and next candidates

1. ALTER now binds and rewrites column/table references using schema_edit.rs; tests cover direct and nested views, row triggers, FKs, checks/generated expressions, indices and persistence. Remaining edge cases: view INSTEAD OF triggers (table lookup currently expects real table), nested source scopes/CTE aliases, compound output names and UPDATE FROM/UPSERT expressions inside trigger column rewrites. USING rename may produce an invalid join when only one side changes; post-validation should reject these. Source SQL rendering now complete for supported queries and trigger DML.
2. Attached schema edge cases: attached PRAGMA writes, attachment metadata during rollback, names containing literal dots conflated with qualification.
3. Foreign checks use a transaction-root/statement-root baseline to tolerate historical violations. Signature uses table/rowid/FK-index/values, so deleting/reinserting the identical invalid row may evade detection. Parent unique keys now compare declared collations and accept reordered target columns. Cascades now enforce child constraints and trigger hooks, self/cycles tested.
4. Trigger changes() context stack now passes tests for first/subsequent/nested DML. Keep validation appropriate if modifying DML.
5. Native WAL/rollback journals and locking interoperability with other implementations remain absent. Full-image commits use our own flock sidecars and durable manifests. Review rare I/O failures during committed-marker writes/recovery cleanup for consistency.
6. Query planner/EXPLAIN are basic placeholders, indices not used for acceleration. Virtual table extensions and JSONB unavailable (removed bogus JSONB aggregate registration). Complete printf/date edge behavior not implemented.
7. Remaining expression issues include scalar-subquery affinity/collation, nested CTE shadowing/subquery recursion restrictions, row-value validation on empty results, and aggregate overflow/precision. Empty-query clause/function/window/ordinal validation was strengthened.
8. Parser recursion and expression height limits are 128, JSON parser/path nesting 200, recursive CTE extraction limit 1,000,000; these are lower than some upstream compile-time defaults and documented in README. General corruption/fuzz handling merits continued work.
9. STRICT generated columns currently check type before computing generated values but need a check afterward as well; prioritize this fix. Disk Reader currently validates table trees but should also validate index B-trees and shared/freelist page ownership before accepting an image. busy_timeout is stored but has no waiting behavior yet.
10. `rustfmt` is unavailable and must not be fetched. Existing modules are dense; new functions use readable formatting. Temporary *_method.tmp files were removed after integration.

Keep the implementation integrated, derive new tests from /docs, and continue useful work rather than stopping after a component.
