import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=p.stdout.readline();assert r,p.poll();return json.loads(r)
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE a(x,y)');sql('CREATE TABLE b(x,y)')
sql('INSERT INTO a VALUES(1,10),(2,20)');sql('INSERT INTO b VALUES(1,30),(3,40)')
assert sql('SELECT * FROM a,b ORDER BY a.x,b.x')==[['1','10','1','30'],['1','10','3','40'],['2','20','1','30'],['2','20','3','40']]
assert sql('SELECT a.*,b.* FROM a JOIN b USING(x)')==[['1','10','1','30']]
assert sql('SELECT * FROM a JOIN b USING(x)')==[['1','10','30']]
assert sql('SELECT x,"x:1" FROM (SELECT a.x,b.x FROM a,b) ORDER BY 1,2')==[['1','1'],['1','3'],['2','1'],['2','3']]
assert sql('SELECT "x","missing" FROM a ORDER BY x')==[['1','missing'],['2','missing']]
sql('SELECT "x" FROM a,b',False)
assert sql('SELECT x+1 AS z FROM a WHERE z BETWEEN 2 AND 2')==[['2']]
assert sql('SELECT x+1 AS z FROM a WHERE abs(z)=3')==[['3']]
assert sql('SELECT x+1 AS z FROM a WHERE CASE z WHEN 2 THEN 1 ELSE 0 END')==[['2']]
assert sql('SELECT x+1 AS z FROM a WHERE z IN (2,9)')==[['2']]
assert sql('SELECT (1,NULL)=(2,NULL),(1,NULL)=(1,2),(1,NULL)<(2,0),(1,NULL)>(0,NULL)')==[['0',None,'1','1']]
assert sql('SELECT (1,2) BETWEEN (1,1) AND (1,3),(1,NULL) BETWEEN (0,1) AND (2,3)')==[['1','1']]
sql('CREATE TABLE quoted_cycle(a,b AS("c"+1),c AS("b"+1))',False)
sql('CREATE TABLE quoted_self(a,b AS("b"+1))',False)
sql('CREATE TABLE bad_default(a DEFAULT "text")',False)
sql('CREATE TABLE bad_param(a DEFAULT (?))',False)
sql('CREATE TABLE bad_param2(a DEFAULT (:missing))',False)
sql('CREATE TABLE good_default(a DEFAULT (length(\'abc\')),b DEFAULT CURRENT_DATE)')
sql('INSERT INTO good_default DEFAULT VALUES');assert sql('SELECT a,length(b) FROM good_default')==[['3','10']]
sql('ALTER TABLE a ADD COLUMN d DEFAULT CURRENT_TIME',False)
sql('ALTER TABLE a ADD COLUMN d DEFAULT (1+2)',False)
sql('ALTER TABLE a ADD COLUMN d NOT NULL',False)
sql('ALTER TABLE a ADD COLUMN d AS(x+y) NOT NULL');assert sql('SELECT d FROM a ORDER BY x')==[['11'],['22']]
sql('CREATE TABLE collated(x COLLATE NOCASE)');sql("INSERT INTO collated VALUES('a')")
assert sql('SELECT "x"=\'A\',CAST(x AS TEXT)=\'A\' FROM collated')==[['1','1']]
sql('CREATE TABLE binarycol(x COLLATE BINARY)');sql("INSERT INTO binarycol VALUES('a')")
assert len(sql("SELECT x FROM binarycol UNION SELECT 'A' COLLATE NOCASE"))==2
for q in ['SELECT x FROM b WHERE sum(x)>0','SELECT sum(sum(x)) FROM b','SELECT x FROM b GROUP BY count(*)','SELECT x FROM b ORDER BY 3','SELECT string_agg(x) FROM b','SELECT lower(x) FILTER(WHERE 1) FROM b']:
 sql(q,False)
sql('CREATE TABLE empty(x)')
for q in ['SELECT x FROM empty ORDER BY missing','SELECT x FROM empty GROUP BY missing','SELECT x FROM empty ORDER BY 0','SELECT x FROM empty GROUP BY 0','SELECT no_such_function(x) OVER() FROM empty','SELECT rank(1) OVER() FROM empty','SELECT sum(x) OVER missing FROM empty','SELECT sum(x) OVER(ROWS -1 PRECEDING) FROM empty','SELECT sum(x) OVER(RANGE 1 PRECEDING) FROM empty','SELECT x COLLATE missing FROM empty','SELECT * FROM empty e JOIN empty f ON missing=1']:
 sql(q,False)
assert sql('SELECT sum(x) BETWEEN 1 AND 10,count(*) IN(1,2) FROM a')==[['1','1']]
p.terminate();p.wait();print('PASS: projection, row values, aliases, quoted identifiers and schema defaults')
