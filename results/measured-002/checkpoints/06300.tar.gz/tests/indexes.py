import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE t(x TEXT,y INT)');sql("INSERT INTO t VALUES('a',1),('A',2)")
sql('CREATE UNIQUE INDEX bad ON t(x COLLATE NOCASE)',False)
sql('CREATE UNIQUE INDEX good ON t(x COLLATE BINARY)')
for q in ['CREATE INDEX rand ON t(random())','CREATE INDEX sub ON t((SELECT 1))','CREATE INDEX ver ON t(sqlite_version())','CREATE INDEX param ON t(x) WHERE y>?','CREATE INDEX bad_where ON t(x) WHERE unknown>1','CREATE INDEX rid ON t(rowid)','CREATE INDEX agg ON t(sum(y))']:
 sql(q,False)
sql('CREATE INDEX lowerx ON t(lower(x)) WHERE y>0')
sql('CREATE TABLE dates(x TEXT)');sql('CREATE INDEX dx ON dates(date(x))')
sql('BEGIN');sql("INSERT INTO dates VALUES('now')",False);sql("INSERT INTO dates VALUES('2026-09-19')");sql('COMMIT')
assert sql('SELECT date(x) FROM dates')==[['2026-09-19']]
sql('CREATE TABLE generated(x TEXT,y TEXT AS(date(x)))');sql("INSERT INTO generated(x) VALUES('now')",False)
sql("INSERT INTO generated(x) VALUES('2020-01-01')");assert sql('SELECT y FROM generated')==[['2020-01-01']]
sql('CREATE TABLE generated_now(x,y AS(datetime()))');sql('INSERT INTO generated_now(x) VALUES(1)',False)
assert sql('SELECT length(datetime())')==[['19']]
# FK target order may differ from the unique index, but declared collations must match.
sql('PRAGMA foreign_keys=ON');sql('CREATE TABLE parent(a,b,UNIQUE(a,b))');sql('CREATE TABLE child(x,y,FOREIGN KEY(x,y) REFERENCES parent(b,a))')
sql('INSERT INTO parent VALUES(1,2)');sql('INSERT INTO child VALUES(2,1)');sql('INSERT INTO child VALUES(1,2)',False)
sql('CREATE TABLE p2(a TEXT)');sql('CREATE UNIQUE INDEX p2idx ON p2(a COLLATE NOCASE)');sql('CREATE TABLE c2(a REFERENCES p2(a))')
sql("INSERT INTO p2 VALUES('a')");sql("INSERT INTO c2 VALUES('a')",False)
p.terminate();p.wait();print('PASS: index constraints/collations, deterministic schema expressions, foreign parent key matching')
