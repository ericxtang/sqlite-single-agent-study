import json,subprocess,os,struct
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=p.stdout.readline();assert r,p.poll();return json.loads(r)
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
path='/work/tests/corruption-source.db';bad='/work/tests/corruption-bad.db'
try:os.unlink(path)
except FileNotFoundError:pass
assert req({'op':'open','path':path})['ok'];sql('PRAGMA page_size=512')
sql('CREATE TABLE t(x INTEGER PRIMARY KEY,y TEXT CHECK(length(y)>0))');sql('CREATE INDEX yi ON t(y)')
sql("INSERT INTO t VALUES(1,'"+'x'*5000+"')")
root=int(sql("SELECT rootpage FROM sqlite_schema WHERE name='yi'")[0][0]);assert root>1
sql('CREATE TABLE free(a)');sql('DROP TABLE free')
req({'op':'close'});original=bytearray(open(path,'rb').read());ps=struct.unpack_from('>H',original,16)[0];assert ps==512
cases=[]
b=original.copy();b[(root-1)*ps]=0;cases.append(('index page type',b))
b=original.copy();struct.pack_into('>I',b,32,root);struct.pack_into('>I',b,36,1);cases.append(('freelist owns index root',b))
b=original.copy();struct.pack_into('>I',b,36,99999);cases.append(('freelist count',b))
b=original.copy();struct.pack_into('>H',b,(root-1)*ps+8,ps-1);cases.append(('invalid index cell offset',b))
b=original[:-1];cases.append(('truncated image',b))
for label,b in cases:
 with open(bad,'wb') as f:f.write(b)
 r=req({'op':'open','path':bad});assert not r['ok'],(label,r)
 assert req({'op':'open','path':':memory:'})['ok'];assert sql('SELECT 1')==[['1']]
assert req({'op':'open','path':path})['ok'];assert sql('PRAGMA integrity_check')==[['ok']]
sql('PRAGMA ignore_check_constraints=ON');sql("INSERT INTO t VALUES(2,'')")
assert sql('PRAGMA integrity_check(1)')==[['CHECK constraint failed in t']]
sql('DELETE FROM t WHERE x=2');assert sql('PRAGMA quick_check')==[['ok']]
sql('CREATE TABLE strict_gen(a TEXT,b INT AS(a)) STRICT');sql("INSERT INTO strict_gen(a) VALUES('bad')",False)
sql("INSERT INTO strict_gen(a) VALUES('123')");assert sql('SELECT b,typeof(b) FROM strict_gen')==[['123','integer']]
sql('CREATE TABLE strict_any(a TEXT,b ANY AS(a)) STRICT');sql("INSERT INTO strict_any(a) VALUES('00123')");assert sql('SELECT b,typeof(b) FROM strict_any')==[['00123','text']]
p.terminate();p.wait();print('PASS: index/freelist corruption detection, integrity checks and STRICT generated values')
