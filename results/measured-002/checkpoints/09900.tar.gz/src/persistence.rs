use crate::{db::{Connection,State},parser::Res,value::{Val,Aff,affinity},schema,storage};
impl Connection{
 pub(crate) fn encoding(&self)->u32{match self.pragmas.get("encoding").map(Val::text).unwrap_or_default().to_ascii_lowercase().as_str(){"utf-16le"=>2,"utf-16be"=>3,_=>1}}
 pub(crate) fn schema_created(&self)->bool{self.state.schema_version!=0||self.state.user_version!=0||self.state.application_id!=0||self.state.tables.values().any(|t|!t.name.contains('.')&&!t.temp)}
 pub(crate) fn set_encoding(&mut self,name:&str)->Res<()>{if self.schema_created(){return Ok(())}let enc=match name.to_ascii_lowercase().replace('-',"").as_str(){"utf8"=>1,"utf16le"=>2,"utf16be"=>3,"utf16"=>if cfg!(target_endian="little"){2}else{3},_=>return Err(format!("unsupported encoding: {}",name))};if self.attachments.values().any(|c|c.borrow().encoding()!=enc){return Err("attached databases must use the same text encoding as main database".into())}self.pragmas.insert("encoding".into(),Val::Text(storage::encoding_name(enc).into()));Ok(())}

 pub(crate) fn cast_value(&self,v:Val,typ:&str)->Val{if self.encoding()==1||v.null(){return v.cast(typ)}match (affinity(typ),v){(Aff::Blob|Aff::None,Val::Blob(b))=>Val::Blob(b),(Aff::Blob|Aff::None,v)=>Val::Blob(crate::storage::text_bytes(&v.text(),self.encoding())),(_,Val::Blob(b))=>{let units=b.chunks_exact(2).map(|p|if self.encoding()==2{u16::from_le_bytes([p[0],p[1]])}else{u16::from_be_bytes([p[0],p[1]])}).collect::<Vec<_>>();Val::Text(String::from_utf16_lossy(&units)).cast(typ)},(_,v)=>v.cast(typ)}}
 pub fn persist(&self)->Res<()>{
  let main=schema::main_state(&self.state);
  let main_changed=self.file_settings_dirty.get()||self.path.as_ref().map_or(false,|p|!p.exists())||!schema::same_data(&main,&self.main_disk_state.borrow());
  if main_changed&&self.read_only_file{return Err("attempt to write a readonly database".into())}
  let mut updates=vec![];
  for(db,cell)in &self.attachments{let c=cell.borrow();let exported=schema::export(&self.state,db,&c.state);if c.file_settings_dirty.get()||!schema::same_data(&exported,&c.state){if c.read_only_file{return Err("attempt to write a readonly attached database".into())}updates.push((db.clone(),exported));}}
  // Hold all necessary commit locks before producing or replacing any image.
  if main_changed{if let Some(l)=&self.locks{l.write()?;if !self.wal(){l.exclusive()?;}}}
  for(db,_)in &updates{let c=self.attachments[db].borrow();if let Some(l)=&c.locks{l.write()?;if !c.wal(){l.exclusive()?;}}}
  let mut images=vec![];let mut own_version=None;
  if main_changed{if let Some(p)=&self.path{let b=storage::encode(self)?;own_version=Some(u32::from_be_bytes(b[24..28].try_into().unwrap()));images.push((p.clone(),b));}}
  for(db,exported)in &updates{let c=self.attachments[db].borrow();if let Some(p)=&c.path{let mut encoder=Connection::open(":memory:")?;encoder.state=exported.clone();encoder.pragmas=c.pragmas.clone();encoder.path=Some(p.clone());images.push((p.clone(),storage::encode(&encoder)?));}}
  crate::journal::commit(&images)?;
  if main_changed{*self.main_disk_state.borrow_mut()=main;self.file_settings_dirty.set(false);self.own_commit_version.set(own_version);}
  for(db,state)in updates{let mut c=self.attachments[&db].borrow_mut();c.state=state;c.file_version=c.disk_version()?;*c.main_disk_state.borrow_mut()=c.state.clone();c.file_settings_dirty.set(false);}
  Ok(())
 }
 pub(crate) fn check_readonly_changes(&self,before:&State)->Res<()>{
  if self.read_only_file&&!schema::same_data(&schema::main_state(before),&schema::main_state(&self.state)){return Err("attempt to write a readonly database".into())}
  for(db,cell)in &self.attachments{let c=cell.borrow();if c.read_only_file&&before.schema_meta.contains_key(db)&&!schema::same_data(&schema::export(before,db,&c.state),&schema::export(&self.state,db,&c.state)){return Err("attempt to write a readonly attached database".into())}}
  Ok(())
 }
 pub(crate) fn attached_statistics(&self,db:&str)->Res<(i64,i64)>{
  let c=self.attachments.get(db).ok_or_else(||format!("unknown database {}",db))?.borrow();let exported=schema::export(&self.state,db,&c.state);if schema::same_data(&exported,&c.state){return c.page_statistics()}
  let mut encoder=Connection::open(":memory:")?;encoder.state=exported;encoder.pragmas=c.pragmas.clone();storage::statistics(&storage::encode(&encoder)?)
 }
 pub(crate) fn page_statistics(&self)->Res<(i64,i64)>{
  let dirty=!schema::same_data(&schema::main_state(&self.state),&self.main_disk_state.borrow());
  if !dirty{if let Some(p)=&self.path{let b=std::fs::read(p).map_err(|e|e.to_string())?;if b.len()>=100&&u32::from_be_bytes(b[24..28].try_into().unwrap())==self.file_version{return storage::statistics(&b)}}}
  storage::statistics(&storage::encode(self)?)
 }
}
