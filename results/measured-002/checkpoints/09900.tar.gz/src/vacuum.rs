use crate::{db::{Connection,State,safe_path,atomic_write},ast::Expr,query::{Rel,Ctes,Ctx},parser::Res,value::Val,schema};
fn compact(s:&mut State){let mut root=2;for t in s.tables.values_mut(){t.root=root;root+=1}for i in s.indexes.values_mut(){i.root=root;root+=1}s.schema_version=s.schema_version.wrapping_add(1);}
impl Connection{
 pub(crate) fn set_page_size(&mut self,size:i64){
  if !(512..=65536).contains(&size)||!(size as u64).is_power_of_two(){return}
  self.pending_page_size.set(Some(size));
  if self.state.schema_version==0&&self.state.user_version==0&&self.state.application_id==0&&self.state.tables.is_empty()&&!self.wal(){self.pragmas.insert("page_size".into(),Val::Int(size));self.pending_page_size.set(None);}
 }
 pub(crate) fn vacuum(&mut self,db:&str,into:&Option<Expr>,ctes:&Ctes)->Res<Rel>{
  if !self.tx.is_empty(){return Err("cannot VACUUM from within a transaction".into())}
  if db!="main"&&db!="temp"&&!self.attachments.contains_key(db){return Err(format!("unknown database {}",db))}
  if into.is_none(){self.writable()?;if (db=="main"&&self.read_only_file)||self.attachments.get(db).map_or(false,|c|c.borrow().read_only_file){return Err("attempt to write a readonly database".into())}}
  let mut encoder=Connection::open(":memory:")?;
  let (mut data,settings,pending,wal)=if db=="main"{(schema::main_state(&self.state),self.pragmas.clone(),self.pending_page_size.get(),self.wal())}else if let Some(cell)=self.attachments.get(db){let c=cell.borrow();(schema::export(&self.state,db,&c.state),c.pragmas.clone(),c.pending_page_size.get(),c.wal())}else{(schema::export(&self.state,db,&State::default()),encoder.pragmas.clone(),None,false)};
  compact(&mut data);encoder.state=data.clone();encoder.pragmas=settings.clone();if !wal{if let Some(size)=pending{encoder.pragmas.insert("page_size".into(),Val::Int(size));}}
  if let Some(e)=into{let value=self.eval(e,&Ctx::empty(ctes))?;if value.null(){return Err("invalid VACUUM INTO filename".into())}let path=safe_path(&value.text())?;if path.exists()&&std::fs::metadata(&path).map_err(|e|e.to_string())?.len()>0{return Err("output file already exists".into())}encoder.pragmas.insert("journal_mode".into(),Val::Text("delete".into()));atomic_write(&path,&crate::storage::encode(&encoder)?)?;return Ok(Rel::default())}
  if db=="main"{let mut temporary=self.state.clone();temporary.tables.retain(|n,_|n.contains('.'));temporary.indexes.retain(|n,_|n.contains('.'));temporary.views.retain(|n,_|n.contains('.'));temporary.triggers.retain(|n,_|n.contains('.'));data.tables.extend(temporary.tables);data.indexes.extend(temporary.indexes);data.views.extend(temporary.views);data.triggers.extend(temporary.triggers);data.schema_meta=temporary.schema_meta;self.state=data;self.pragmas=encoder.pragmas;self.file_settings_dirty.set(true);}else{schema::import(&mut self.state,&data,db);if let Some(cell)=self.attachments.get(db){let mut c=cell.borrow_mut();c.pragmas=encoder.pragmas;c.file_settings_dirty.set(true);}}
  if let Err(e)=self.persist(){if db=="main"{self.pragmas=settings;self.file_settings_dirty.set(false);}else if let Some(cell)=self.attachments.get(db){let mut c=cell.borrow_mut();c.pragmas=settings;c.file_settings_dirty.set(false);}return Err(e)}
  if !wal{if db=="main"{self.pending_page_size.set(None)}else if let Some(cell)=self.attachments.get(db){cell.borrow().pending_page_size.set(None)}}
  Ok(Rel::default())
 }
}
