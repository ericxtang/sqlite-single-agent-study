use serde::{Serialize,Deserialize};
use crate::value::Val;
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Expr {Slot(usize),DQuote(String),Lit(Val),Col(Vec<String>),Star(Option<String>),Unary(String,Box<Expr>),Binary(String,Box<Expr>,Box<Expr>),Collate(Box<Expr>,String),Between(Box<Expr>,Box<Expr>,Box<Expr>,bool),In(Box<Expr>,Vec<Expr>,Option<Box<Query>>,bool),Case(Option<Box<Expr>>,Vec<(Expr,Expr)>,Option<Box<Expr>>),Cast(Box<Expr>,String),Func{name:String,args:Vec<Expr>,distinct:bool,filter:Option<Box<Expr>>,order:Vec<Order>,over:Option<Window>},Sub(Box<Query>),Exists(Box<Query>),Tuple(Vec<Expr>)}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Window{pub name:Option<String>,pub partition:Vec<Expr>,pub order:Vec<Order>,pub frame:Option<(String,Bound,Bound)>,#[serde(default)]pub exclude:Option<String>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Bound{UnboundedPre,Pre(Box<Expr>),Current,Following(Box<Expr>),UnboundedFollowing}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Order{pub expr:Expr,pub desc:bool,pub nulls:Option<bool>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Item{pub expr:Expr,pub alias:Option<String>,pub label:String}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Cte{pub name:String,pub cols:Vec<String>,pub query:Query}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Query{pub ctes:Vec<Cte>,pub recursive:bool,pub cores:Vec<Core>,pub compounds:Vec<String>,pub order:Vec<Order>,pub limit:Option<Expr>,pub offset:Option<Expr>}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Core{pub distinct:bool,pub items:Vec<Item>,pub from:Vec<Join>,pub wh:Option<Expr>,pub group:Vec<Expr>,pub having:Option<Expr>,pub values:Vec<Vec<Expr>>,pub windows:Vec<(String,Window)>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Join{pub source:Source,pub kind:String,pub on:Option<Expr>,pub using:Vec<String>,pub natural:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Source{Table(String,Option<String>,Vec<Expr>),Query(Box<Query>,Option<String>),Nested(Vec<Join>,Option<String>)}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Column{pub name:String,pub typ:String,pub notnull:bool,pub nn_conflict:String,pub default:Option<Expr>,pub default_sql:Option<String>,#[serde(default)]pub default_parenthesized:bool,pub pk:usize,pub pk_desc:bool,pub auto:bool,pub coll:String,pub generated:Option<Expr>,pub stored:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Unique{pub cols:Vec<Expr>,pub conflict:String,pub primary:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Foreign{pub cols:Vec<String>,pub table:String,pub target:Vec<String>,pub on_delete:String,pub on_update:String,pub deferred:bool}
#[derive(Clone,Debug)]
pub struct TableDef{pub name:String,pub ifnot:bool,pub cols:Vec<Column>,pub unique:Vec<Unique>,pub checks:Vec<Expr>,pub foreign:Vec<Foreign>,pub without:bool,pub strict:bool,pub temp:bool,pub query:Option<Query>}
#[derive(Clone,Debug)]
pub struct Upsert{pub target:Vec<Expr>,pub target_where:Option<Expr>,pub set:Vec<(Vec<String>,Expr)>,pub wh:Option<Expr>}
#[derive(Clone,Debug)]
pub enum Stmt{Attach(Expr,String),Detach(String),CreateTrigger(TriggerDef),Select(Query),CreateTable(TableDef),CreateIndex{name:String,table:String,unique:bool,ifnot:bool,cols:Vec<Expr>,wh:Option<Expr>},CreateView{name:String,ifnot:bool,cols:Vec<String>,query:Query,temp:bool},Insert{table:String,alias:Option<String>,cols:Vec<String>,query:Option<Query>,default:bool,conflict:String,upsert:Vec<Upsert>,ret:Vec<Item>},Update{table:String,alias:Option<String>,set:Vec<(Vec<String>,Expr)>,wh:Option<Expr>,from:Vec<Join>,conflict:String,ret:Vec<Item>,order:Vec<Order>,limit:Option<Expr>},Delete{table:String,alias:Option<String>,wh:Option<Expr>,ret:Vec<Item>,order:Vec<Order>,limit:Option<Expr>},Drop{kind:String,name:String,ifexists:bool},Alter{table:String,action:Alter},Begin(String),Commit,Rollback(Option<String>),Savepoint(String),Release(String),Pragma{name:String,value:Option<Expr>},Vacuum(String,Option<Expr>),Noop,Explain(Box<Stmt>,bool),With(Vec<Cte>,bool,Box<Stmt>)}
#[derive(Clone,Debug)]
pub enum Alter{Rename(String),RenameColumn(String,String),Add(Column,Vec<Unique>,Vec<Expr>,Vec<Foreign>),Drop(String)}

#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct TriggerDef{pub name:String,pub table:String,pub timing:String,pub event:String,pub of:Vec<String>,pub when:Option<Expr>,pub body:Vec<String>,pub temp:bool,pub ifnot:bool,pub sql:String}
impl Expr{
 pub fn children(&self)->Vec<&Expr>{match self{Expr::Unary(_,e)|Expr::Collate(e,_)|Expr::Cast(e,_)=>vec![e],Expr::Binary(_,a,b)=>vec![a,b],Expr::Between(a,b,c,_)=>vec![a,b,c],Expr::In(a,es,_,_)=>{let mut v=vec![a.as_ref()];v.extend(es);v},Expr::Case(base,arms,el)=>{let mut v=vec![];if let Some(e)=base{v.push(e.as_ref())}for(a,b)in arms{v.push(a);v.push(b)}if let Some(e)=el{v.push(e.as_ref())}v},Expr::Func{args,filter,..}=>{let mut v=args.iter().collect::<Vec<_>>();if let Some(e)=filter{v.push(e.as_ref())}v},Expr::Tuple(es)=>es.iter().collect(),_=>vec![]}}
}

impl Expr {
 /// Rewrite children in this expression scope, preserving subquery scopes.
 pub fn map_children(&mut self,f:&mut impl FnMut(&Expr)->Expr){
  match self {
   Expr::Unary(_,e)|Expr::Collate(e,_)|Expr::Cast(e,_)=>**e=f(e),
   Expr::Binary(_,a,b)=>{**a=f(a);**b=f(b);},
   Expr::Between(a,b,c,_)=>{**a=f(a);**b=f(b);**c=f(c);},
   Expr::In(a,es,_,_)=>{**a=f(a);for e in es{*e=f(e);}},
   Expr::Case(base,arms,el)=>{if let Some(e)=base{**e=f(e)}for(a,b)in arms{*a=f(a);*b=f(b)}if let Some(e)=el{**e=f(e)}},
   Expr::Func{args,filter,order,over,..}=>{for e in args{*e=f(e)}if let Some(e)=filter{**e=f(e)}for o in order{o.expr=f(&o.expr)}if let Some(w)=over{for e in &mut w.partition{*e=f(e)}for o in &mut w.order{o.expr=f(&o.expr)}if let Some((_,a,b))=&mut w.frame{for bound in [a,b]{match bound{Bound::Pre(e)|Bound::Following(e)=>**e=f(e),_=>()}}}}},
   Expr::Tuple(es)=>for e in es{*e=f(e)},_=>()
  }
 }
}
