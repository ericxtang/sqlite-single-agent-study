# Implementation notes
All implementation and verification uses the offline workspace, with /docs as the sole SQL reference. No database engine/parser dependencies.
Architecture: hand-written lexer and Pratt expression parser; relational interpreter; typed values and affinity; schema/row state with statement rollback and transaction/savepoint snapshots. First persistence format is an atomic serialized state file; SQLite page format remains a compatibility target.
Priorities: integrated interface, expressions, DDL/DML, joins/grouping/subqueries, constraints, persistence/transactions, functions and pragmas, advanced SQL. Tests derive from documented rules, never a reference engine.
