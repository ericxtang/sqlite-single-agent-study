"""Row comparisons and binding on empty inputs, using documented scalar rules."""
import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE t(a TEXT COLLATE NOCASE,b INTEGER,c)');sql("INSERT INTO t VALUES('A',2,3)")
assert sql("SELECT (a,b)=('a','2'),(SELECT a,b FROM t)=('a','2'),('a','2')=(SELECT a,b FROM t) FROM t")==[['1','1','1']]
assert sql("SELECT (SELECT a,b FROM t) IN(SELECT 'a','2')")==[['1']]
assert sql("SELECT (a COLLATE BINARY,b)=('a','2'),(a,b)=('a' COLLATE BINARY,'2') FROM t")==[['0','0']]
assert sql("SELECT (SELECT '2')=b,b=(SELECT '2') FROM t")==[['1','1']]
assert sql('SELECT (SELECT 2) IS TRUE,(SELECT 0) IS FALSE,(SELECT NULL) IS NOT TRUE')==[['1','1','1']]
assert sql('SELECT (SELECT 1,NULL,4)=(1,NULL,3),(SELECT 1,NULL,3)=(1,2,3)')==[['0',None]]
assert sql('SELECT (SELECT 2,3) BETWEEN (1,9) AND (3,0)')==[['1']]
sql('CREATE TABLE empty(a,b)')
for q in ['SELECT (a,b) FROM empty','SELECT (a,b)=1 FROM empty','SELECT (a,b)=(1,2,3) FROM empty','SELECT (SELECT 1,2) FROM empty','SELECT (a,b) IN(SELECT 1) FROM empty','SELECT (a,b) IN(1,2) FROM empty','SELECT abs((a,b)) FROM empty','SELECT (SELECT nonexistent FROM t) FROM empty','SELECT EXISTS(SELECT nonexistent FROM t) FROM empty','SELECT (SELECT (1,2)) FROM empty','UPDATE empty SET(a,b)=(1,2,3)','UPDATE empty SET(a,b)=(SELECT 1)','UPDATE empty SET a=(SELECT 1,2)','VALUES()','SELECT ()','SELECT CASE 1 ELSE 2 END']:
 sql(q,False)
# Binding discovers invalid names without evaluating unused value expressions.
assert sql('SELECT (SELECT abs(-9223372036854775808)) FROM empty')==[]
assert sql('SELECT CASE WHEN 0 THEN (SELECT abs(-9223372036854775808)) ELSE 7 END')==[['7']]
assert sql('SELECT coalesce(8,(SELECT abs(-9223372036854775808)))')==[['8']]
assert sql('SELECT (SELECT 1/0) FROM empty')==[]
sql('UPDATE t SET(b,c)=(SELECT 5,6)');assert sql('SELECT b,c FROM t')==[['5','6']]
sql('UPDATE t SET(b,c)=(SELECT a,b FROM empty)');assert sql('SELECT b,c FROM t')==[[None,None]]
# EXISTS ignores unused output expressions, while nested sources still produce values.
assert sql('SELECT EXISTS(SELECT abs(-9223372036854775808)),EXISTS(SELECT min(abs(-9223372036854775808)) FROM empty)')==[['1','1']]
assert sql('SELECT EXISTS(SELECT DISTINCT abs(-9223372036854775808))')==[['1']]
assert sql('SELECT EXISTS(SELECT a FROM t ORDER BY abs(-9223372036854775808))')==[['1']]
assert sql('SELECT EXISTS(SELECT * FROM (SELECT 1 x) WHERE x=1)')==[['1']]
assert sql('SELECT EXISTS(SELECT 1 FROM empty),EXISTS(SELECT count(*) FROM empty),EXISTS(SELECT 1 LIMIT 0)')==[['0','1','0']]
assert sql('SELECT EXISTS(SELECT 1 UNION ALL SELECT 2 LIMIT 1 OFFSET 1)')==[['1']]
assert sql('SELECT EXISTS(SELECT DISTINCT 1 FROM (VALUES(1),(2)) LIMIT 1 OFFSET 1)')==[['0']]
assert sql("SELECT 'a' IN(VALUES('A' COLLATE NOCASE))")==[['1']]
sql('WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT nonexistent FROM n LIMIT 0) SELECT * FROM n',False)
p.terminate();p.wait();print('PASS: row/subquery affinity and collations, NULL comparisons, empty-input binding and lazy values')
