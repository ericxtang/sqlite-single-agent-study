use crate::{ast::*,db::Connection,query::{Ctx,Field},value::Val,parser::Res};
use std::cmp::Ordering;
impl Connection{
 pub(crate) fn row_components(&self,e:&Expr,ctx:&Ctx)->Res<(Vec<Val>,Vec<Field>,Vec<Option<String>>)>{
  if let Expr::Sub(q)=e{let r=self.query(q,ctx.ctes,Some(ctx))?;let n=r.fields.len();return Ok((r.rows.first().cloned().unwrap_or(vec![Val::Null;n]),r.fields,vec![None;n]))}
  let exprs=if let Expr::Tuple(es)=e{es.iter().collect::<Vec<_>>()}else{vec![e]};let mut values=vec![];let mut fields=vec![];let mut collates=vec![];
  for e in exprs{values.push(self.eval(e,ctx)?);let(aff,coll)=self.meta(e,ctx);fields.push(Field{name:String::new(),table:String::new(),aff,coll,has_collation:self.collation(e,ctx).is_some(),hidden:false,aliases:vec![]});collates.push(Self::explicit_coll(e));}Ok((values,fields,collates))
 }
 pub(crate) fn row_compare(&self,op:&str,a:&Expr,b:&Expr,ctx:&Ctx)->Res<Val>{
  let(x,xf,xc)=self.row_components(a,ctx)?;let(y,yf,yc)=self.row_components(b,ctx)?;if x.len()!=y.len(){return Err("row value misused".into())}
  let equality=["=","==","!=","<>","IS","IS NOT"].contains(&op);let identity=op=="IS"||op=="IS NOT";
  if x.len()==1&&identity{if let Expr::Col(n)=b{if n.len()==1&&(n[0].eq_ignore_ascii_case("TRUE")||n[0].eq_ignore_ascii_case("FALSE"))&&self.lookup(n,ctx)?.is_none(){return Ok(Val::boolean((x[0].truth()==Some(n[0].eq_ignore_ascii_case("TRUE")))^(op=="IS NOT")))}}}
  let mut unknown=false;let mut ordering=Ordering::Equal;
  for i in 0..x.len(){if (x[i].null()||y[i].null())&&!identity{if !equality{return Ok(Val::Null)}unknown=true;continue}
   ordering=if x.len()==1{self.comparison(a,b,x[i].clone(),y[i].clone(),ctx)}else{let mut left=Expr::Slot(0);let mut right=Expr::Slot(1);if let Some(c)=&xc[i]{left=Expr::Collate(Box::new(left),c.clone())}if let Some(c)=&yc[i]{right=Expr::Collate(Box::new(right),c.clone())}let fields=[xf[i].clone(),yf[i].clone()];let row=[x[i].clone(),y[i].clone()];let c=Ctx{fields:&fields,row:&row,..Ctx::empty(ctx.ctes)};self.comparison(&left,&right,x[i].clone(),y[i].clone(),&c)};
   if ordering!=Ordering::Equal{break}
  }
  if unknown&&ordering==Ordering::Equal{return Ok(Val::Null)}Ok(Val::boolean(match op{"="|"=="|"IS"=>ordering==Ordering::Equal,"!="|"<>"|"IS NOT"=>ordering!=Ordering::Equal,"<"=>ordering==Ordering::Less,">"=>ordering==Ordering::Greater,"<="=>ordering!=Ordering::Greater,">="=>ordering!=Ordering::Less,_=>false}))
 }
 pub(crate) fn validate_row_expr(&self,e:&Expr,ctx:&Ctx)->Res<usize>{match e{Expr::Tuple(es)=>{if es.len()<2{return Err("row value misused".into())}for e in es{self.validate_expr(e,ctx)?;}Ok(es.len())},Expr::Sub(q)=>Ok(self.query_fields(q,ctx)?.len()),_=>{self.validate_expr(e,ctx)?;Ok(1)}}}
}
