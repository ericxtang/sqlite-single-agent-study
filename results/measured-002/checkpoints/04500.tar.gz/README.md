# sqlite-agent

An independent Rust SQL database implementation based only on the supplied SQLite reference documentation. It uses no database engine or SQL parser dependency.

Build and run:

```
cargo build --release --offline --bin sqlite-agent
./target/release/sqlite-agent
```

The executable follows `IO_CONTRACT.md`: one JSON request and response per line, typed result cells, persistent connections, and errors that leave the process usable. Paths must stay under `/work`.

Implementation modules:

- `lex.rs`, `parser.rs`, `ast.rs`: SQL scanning, parsing, and syntax trees.
- `value.rs`, `query.rs`: dynamic values, affinities, SQL expressions, relational queries, aggregates, CTEs, and windows.
- `db.rs`, `schema.rs`: schemas, constraints, DML, triggers, attached databases, transactions, and savepoints.
- `storage.rs`: SQLite 3 headers, record encodings, B-trees, overflow chains, and freelists.
- `locking.rs`: advisory locks coordinating this implementation's processes.
- `func.rs`, `date.rs`, `jsonfunc.rs`: scalar functions, UTC date arithmetic, JSON/JSON5, and JSON table functions.

Tests use documentation-derived expectations and this implementation only:

```
cargo test --offline
python3 tests/semantics.py
python3 tests/edgecases.py
python3 tests/windows.py
python3 tests/triggers.py
python3 tests/attach.py
python3 tests/isolation.py
python3 tests/storage.py
```

Set `SQLITE_AGENT_BIN=/work/target/release/sqlite-agent` to run process tests against the release binary.

This is a substantial implementation in progress, not complete SQLite compatibility. Commits write full database images with fsync and atomic rename. WAL mode provides snapshot behavior through this mechanism; native WAL files and rollback journals are not implemented. OS locks coordinate this implementation, not other SQLite libraries. Atomic crash recovery across multiple attached files, virtual-table extensions, complete planner/opcode output, JSONB, and some schema/name-resolution details remain incomplete. See `NOTES.md` for the current work state.
