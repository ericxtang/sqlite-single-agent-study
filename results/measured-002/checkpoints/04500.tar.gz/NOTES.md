# Work state and continuation notes

All shell operations, reads/writes, compilation and tests use `mcp__workspace__exec` at /work. Only /docs, our own code/tests, Rust std, serde and serde_json have been used. No database engine, SQL parser, external tests/source, network, other models, or agents. User explicitly wants continued independent useful progress until the controller stops the work period.

## Integrated implementation

- Rust project and JSON-lines process contract implemented; release binary path is `target/release/sqlite-agent`.
- Lexer/Pratt parser, typed values, affinities, casts, NULL/boolean semantics, collation, rowids, overflow promotion.
- SELECT/VALUES, joins (LEFT/RIGHT/FULL/USING/NATURAL), projection, WHERE/GROUP/HAVING/ORDER/LIMIT, DISTINCT and compounds, correlated subqueries, row values, ordinary/recursive CTEs.
- Window functions with ROWS/RANGE/GROUPS, EXCLUDE forms, filters, grouped-window evaluation and named-window chaining. Percentile/median aggregates and windows included.
- DDL/DML, constraints/conflict algorithms, UPSERT targets, RETURNING, strict/without-rowid/generated columns, foreign keys/cascades/deferred checks.
- BEFORE/AFTER/INSTEAD OF triggers, WHEN, UPDATE OF, OLD/NEW, RAISE, recursion controls, UPSERT hooks and view DML.
- ATTACH/DETACH with flat qualified schema names, cross-database queries, per-file persistence, qualified views/triggers, temporary-table shadowing.
- sqlite_sequence is an actual table, including direct modifications and lifetime after last AUTOINCREMENT table is dropped.
- Functions for strings, numbers, dates, JSON/JSON5, JSON paths/table functions, Unicode escapes, introspection pragmas.
- SQLite 3 native database images: headers, varints/records, table and index leaf/interior B-trees, overflow chains, freelist, UTF8/UTF16 reading. Descending index keys retained. Complete new image + fsync + atomic rename for commits.
- Two-file OS flock coordination (reader and writer) among our own processes. Deferred/immediate/exclusive transactions, commit retry with readers, snapshot isolation in WAL mode, crash rollback (uncommitted changes remain private). Native WAL files are NOT generated or recovered; WAL header/mode and snapshot behavior use atomic images.

## Tests and build

`cargo build --offline --bin sqlite-agent` succeeds with no warnings. Required delivery build: `cargo build --release --offline --bin sqlite-agent` (run again after changes; release may lag debug).
`cargo test --offline`: varint/record boundary round trips.
Process tests:
- `tests/semantics.py`: 118 core/documented assertions, state and reopen.
- `tests/edgecases.py`: sequence edits, upsert targeting, empty-query errors, affinities, descending PKs, schema validation, JSON5 and percentile functions.
- `tests/windows.py`: explicit RANGE/GROUPS/ROWS, exclusions, grouped windows, chaining, offsets.
- `tests/triggers.py`: row and view triggers, counters, recursive behavior, RAISE, persistence.
- `tests/attach.py`: attached files, cross-schema joins, rollback, reattach under new names, stored views/triggers, temp shadowing, attached sequences/autoindexes.
- `tests/isolation.py`: two subprocesses, writer conflicts, commit retry, snapshots, killed writer.
- `tests/storage.py`: 512/4096/65536-byte images, large indexes and overflow blobs; independent Python structural decoder verifies every page belongs to a B-tree, overflow chain or freelist, and reopened SQL values agree.
All suites passed after attached database integration; latest small changes should be checked as appropriate. Build failures must stop dependent tests (use &&), to avoid accidentally running an older binary. rustfmt component is not installed, and must not be fetched; code currently has dense formatting.

## Current limitations and next candidates

1. Multi-file commits preflight locks, but crash atomicity across attached files is not yet implemented. A super-journal/commit manifest would be a useful next storage step. No native WAL/rollback-journal recovery and no interoperability with native SQLite locking.
2. Fix trigger `changes()` semantics: first trigger statement should see caller's value at statement start; DML currently resets/accumulates self.changes while processing rows.
3. Some attached schema details need more coverage: attachment state during rollback of ATTACH, attached PRAGMA writes, read-version refresh, schema-qualified renames and implicit object resolution. Names containing literal dots are conflated with schema qualification.
4. Foreign checks now allow creation before a parent exists and enabling foreign_keys over preexisting bad rows. DML still scans all foreign constraints, which can incorrectly reject unrelated operations with preexisting violations. Cascaded updates should enforce all child constraints and trigger hooks; self-referencing cascade recursion needs attention.
5. Row comparison / star projection recently improved: positional Expr::Slot avoids ambiguous expanded stars, subquery duplicate columns get :N suffixes. Add focused tests. Double-quoted expression fallback now supported (Expr::DQuote); generated dependencies/default restrictions should explicitly handle that variant.
6. SQL normalization after ALTER needs fuller view/trigger rewrites. Quoted/unquoted UPSERT targets are now compared via rendered expressions.
7. Query planner and EXPLAIN output are only basic placeholders, and indices are not used for query acceleration. Virtual-table modules (FTS/rtree/etc.), JSONB, and full printf/date edge behavior are absent/incomplete. JSONB aggregate names are listed in is_agg but currently delegate to unavailable JSONB scalar calls; remove or implement consistently.
8. Scalar-subquery expression affinity, aggregate overflow/precision edges, aliases in complex GROUP/HAVING/ORDER expressions, window validation on empty inputs, and CTE recursion ordering/limits have remaining edge cases.
9. Limits and corruption handling should be hardened against deeply nested SQL/JSON, pathological rows, circular foreign keys and malicious page files; query/view recursion already has a guard.

Keep the implementation integrated, derive new tests from /docs, and continue useful work rather than stopping after a component.
