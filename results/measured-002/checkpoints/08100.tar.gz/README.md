# sqlite-agent

An independent Rust SQL database implementation based only on the supplied SQLite reference documentation. It uses no database engine or SQL parser dependency.

Build and run:

```
cargo build --release --offline --bin sqlite-agent
./target/release/sqlite-agent
```

The executable follows `IO_CONTRACT.md`: one JSON request and response per line, typed result cells, persistent connections, and errors that leave the process usable. Paths must stay under `/work`.

Implementation modules:

- `lex.rs`, `parser.rs`, `ast.rs`: SQL scanning, parsing, and syntax trees.
- `value.rs`, `query.rs`: dynamic values, affinities, SQL expressions, relational queries, aggregates, CTEs, and windows.
- `db.rs`, `schema.rs`, `schema_edit.rs`: schemas, constraints, DML, triggers, attached databases, transactions, and savepoints.
- `storage.rs`: SQLite 3 headers, record encodings, B-trees, overflow chains, and freelists.
- `locking.rs`, `journal.rs`: advisory locks and durable commit manifests coordinating this implementation's processes and attached files.
- `func.rs`, `date.rs`, `jsonfunc.rs`: scalar functions, UTC date arithmetic, JSON/JSON5, and JSON table functions.

Tests use documentation-derived expectations and this implementation only:

```
cargo test --offline
python3 tests/semantics.py
python3 tests/edgecases.py
python3 tests/windows.py
python3 tests/triggers.py
python3 tests/attach.py
python3 tests/isolation.py
python3 tests/storage.py
python3 tests/recovery.py
python3 tests/foreignkeys.py
python3 tests/names.py
python3 tests/ctes.py
python3 tests/robustness.py
python3 tests/alter.py
python3 tests/indexes.py
python3 tests/corruption.py
python3 tests/busy.py
python3 tests/patterns.py
python3 tests/metadata.py
python3 tests/bulk.py
```

Set `SQLITE_AGENT_BIN=/work/target/release/sqlite-agent` to run process tests against the release binary.

This is a substantial implementation in progress, not complete SQLite compatibility. Commits write full database images with fsync and atomic rename. WAL mode provides snapshot behavior through this mechanism; native WAL files and rollback journals are not implemented. OS locks coordinate this implementation, not other SQLite libraries. Multi-file commits have application-level crash recovery through durable backup manifests. Virtual-table extensions, complete planner/opcode output, JSONB, and some schema/name-resolution details remain incomplete. Parser/expression nesting is limited to 128 and JSON nesting to 200 to keep errors recoverable. See `NOTES.md` for the current work state.
