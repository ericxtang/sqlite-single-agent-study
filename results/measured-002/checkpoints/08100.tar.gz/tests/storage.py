"""Exercise SQLite page format, overflow chains, and reopen without another engine."""
import json,subprocess,os,struct
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());assert r['ok'],(v,r);return r
def sql(s):return req({'op':'execute','sql':s})
def plain(s):return [[v.get('value') for v in r] for r in sql(s)['rows']]
for ps in (512,4096,65536):
 path=f'/work/tests/pages-{ps}.db'
 try:os.unlink(path)
 except FileNotFoundError:pass
 req({'op':'open','path':path})
 sql(f'PRAGMA page_size={ps}')
 sql('CREATE TABLE t(id INTEGER PRIMARY KEY AUTOINCREMENT,txt TEXT UNIQUE,b BLOB)')
 sql('CREATE TABLE wr(a TEXT,b INT,c TEXT,PRIMARY KEY(a,b)) WITHOUT ROWID')
 sql('CREATE INDEX wc ON wr(c)')
 sql('BEGIN')
 sql("WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<750) INSERT INTO t(txt,b) SELECT printf('value-%05d',x),zeroblob(x%29) FROM n")
 sql("INSERT INTO t(txt,b) VALUES('overflow',zeroblob(200000))")
 sql("WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<400) INSERT INTO wr SELECT printf('key-%05d',x),x,printf('%0100d',x) FROM n")
 sql('ALTER TABLE t ADD COLUMN more TEXT DEFAULT \'extra\'')
 sql('COMMIT')
 before=plain('SELECT count(*),sum(length(b)),sum(id),max(length(b)) FROM t')
 before_wr=plain('SELECT count(*),sum(b),sum(length(c)) FROM wr')
 req({'op':'close'});req({'op':'open','path':path})
 assert plain('SELECT count(*),sum(length(b)),sum(id),max(length(b)) FROM t')==before
 assert plain('SELECT count(*),sum(b),sum(length(c)) FROM wr')==before_wr
 assert plain('SELECT DISTINCT more FROM t')==[['extra']]
 sql("INSERT INTO t(txt) VALUES('next')")
 assert plain('SELECT last_insert_rowid()')==[['752']]
 data=open(path,'rb').read();assert data[:16]==b'SQLite format 3\0'
 assert len(data)%ps==0 and int.from_bytes(data[28:32],'big')==len(data)//ps
 assert data[21:24]==bytes([64,32,32]);assert int.from_bytes(data[44:48],'big')==4
 roots=[int(r[0]) for r in plain("SELECT rootpage FROM sqlite_schema WHERE rootpage>0")]
 # The automatically maintained sequence has its own root, discover all schema records below.
 seen=set()
 def u16(b,o):return int.from_bytes(b[o:o+2],'big')
 def u32(b,o):return int.from_bytes(b[o:o+4],'big')
 def vi(b,o):
  n=0
  for k in range(9):
   c=b[o];o+=1
   if k==8:return (n<<8)|c,o
   n=(n<<7)|(c&127)
   if c<128:return n,o
 def rec(b):
  h,o=vi(b,0);types=[]
  while o<h:t,o=vi(b,o);types.append(t)
  out=[];o=h
  for t in types:
   size=[0,1,2,3,4,6,8,8,0,0][t] if t<10 else (t-12)//2
   bs=b[o:o+size];o+=size
   if t==0:v=None
   elif t in (8,9):v=t-8
   elif t<7:v=int.from_bytes(bs,'big',signed=True)
   elif t==7:v=struct.unpack('>d',bs)[0]
   elif t%2:v=bs.decode()
   else:v=bs
   out.append(v)
  return out
 def page(n):
  assert 1<=n<=len(data)//ps,n
  assert n not in seen,('multiply referenced',n)
  seen.add(n);return data[(n-1)*ps:n*ps]
 def walk(n):
  b=page(n);h=100 if n==1 else 0;kind=b[h];assert kind in (2,5,10,13)
  hs=12 if kind in (2,5) else 8;count=u16(b,h+3);records=[]
  spans=[]
  for i in range(count):
   o=u16(b,h+hs+i*2);start=o;assert o>=h+hs+count*2
   if kind in (2,5):child=u32(b,o);o+=4;records.extend(walk(child))
   if kind==5:_,o=vi(b,o)
   else:
    size,o=vi(b,o)
    if kind==13:_,o=vi(b,o)
    x=ps-35 if kind==13 else (ps-12)*64//255-23
    m=(ps-12)*32//255-23
    local=size if size<=x else m+(size-m)%(ps-4)
    if local>x:local=m
    payload=b[o:o+local];o+=local
    if size>local:
     nxt=u32(b,o);o+=4
     while len(payload)<size:
      overflow=page(nxt);nxt=u32(overflow,0)
      payload+=overflow[4:4+min(ps-4,size-len(payload))]
     assert nxt==0
    assert len(payload)==size
    records.append(rec(payload))
   assert o<=ps;spans.append((start,o))
  spans.sort();assert all(a[1]<=b[0] for a,b in zip(spans,spans[1:]))
  if kind in (2,5):records.extend(walk(u32(b,h+8)))
  return records
 schema=walk(1)
 for typ,name,tbl,root,ddl in schema:
  if root:walk(root)
 free=u32(data,32);freecount=0
 while free:
  b=page(free);freecount+=1
  for i in range(u32(b,4)):page(u32(b,8+4*i));freecount+=1
  free=u32(b,0)
 assert freecount==u32(data,36)
 assert len(seen)==len(data)//ps,('orphan pages',ps,len(seen),len(data)//ps)
 print('PASS page format and reopen:',ps,len(data)//ps,'pages')
req({'op':'close'});p.terminate();p.wait()
