import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE t(x)');sql('INSERT INTO t VALUES(1)');sql('CREATE VIEW v AS SELECT x FROM t')
sql('CREATE TEMP TABLE t(x)');sql('INSERT INTO temp.t VALUES(2)')
assert sql('SELECT * FROM v')==[['1']]
sql('CREATE TEMP VIEW v AS SELECT x FROM t');assert sql('SELECT * FROM v')==[['2']]
assert sql('SELECT * FROM main.v')==[['1']]
sql('CREATE TRIGGER temp_vi INSTEAD OF INSERT ON temp.v BEGIN INSERT INTO main.t VALUES(new.x); END')
sql('INSERT INTO v VALUES(3)');assert sql('SELECT x FROM main.t ORDER BY x')==[['1'],['3']]
sql('DROP VIEW v');assert sql('SELECT * FROM v ORDER BY x')==[['1'],['3']]
# A temp table shadows a main view and a temp view shadows a main table.
sql('CREATE TEMP TABLE v(x)');sql('INSERT INTO v VALUES(9)');assert sql('SELECT * FROM v')==[['9']]
sql('DROP TABLE v');sql('CREATE TEMP VIEW shadow AS SELECT 4 x');sql('CREATE TABLE main.shadow(x)')
sql('INSERT INTO shadow VALUES(1)',False);sql('DROP TABLE shadow',False);assert sql('SELECT * FROM shadow')==[['4']]
sql('CREATE TABLE log(x)');sql('CREATE TEMP TABLE log(x)')
sql('CREATE TRIGGER mt AFTER INSERT ON main.t BEGIN INSERT INTO log VALUES(new.x); END')
sql('INSERT INTO main.t VALUES(5)');assert sql('SELECT * FROM main.log')==[['5']];assert sql('SELECT * FROM temp.log')==[]
sql('CREATE INDEX same ON main.t(x)');sql('CREATE INDEX same ON temp.t(x)')
assert sql('PRAGMA temp.index_list(t)')[0][1]=='temp.same'
sql('DROP INDEX same');assert sql('PRAGMA temp.index_list(t)')==[];assert len(sql('PRAGMA main.index_list(t)'))==1
before=sql('PRAGMA main.schema_version');temp_before=int(sql('PRAGMA temp.schema_version')[0][0]);sql('DROP TABLE t')
assert sql('PRAGMA main.schema_version')==before;assert int(sql('PRAGMA temp.schema_version')[0][0])==temp_before+1
# Search attached schemas by attachment order, regardless of alias sort order.
sql("ATTACH ':memory:' AS zfirst");sql("ATTACH ':memory:' AS asecond")
sql('CREATE TABLE zfirst.shared(x)');sql('CREATE TABLE asecond.shared(x)');sql('INSERT INTO zfirst.shared VALUES(10)');sql('INSERT INTO asecond.shared VALUES(20)')
assert sql('SELECT * FROM shared')==[['10']]
assert [r[1] for r in sql('PRAGMA database_list')][-2:]==['zfirst','asecond']
sql('CREATE VIEW zfirst.sharedview AS SELECT * FROM shared');assert sql('SELECT * FROM sharedview')==[['10']]
sql('DROP VIEW sharedview');sql('SELECT * FROM zfirst.sharedview',False)
# Explicit main qualification bypasses a CTE with the same name.
sql('CREATE TABLE q(x)');sql('INSERT INTO q VALUES(7)');assert sql('WITH q AS(SELECT 8 x) SELECT * FROM main.q')==[['7']]
# A TEMP parent cannot redirect a foreign key declared in main.
sql('PRAGMA foreign_keys=ON');sql('CREATE TABLE parent(x PRIMARY KEY)');sql('CREATE TABLE child(x REFERENCES parent(x))')
sql('CREATE TEMP TABLE parent(x PRIMARY KEY)');sql('INSERT INTO temp.parent VALUES(99)');sql('INSERT INTO child VALUES(99)',False)
p.terminate();p.wait();print('PASS: temp/main/attached shadowing, trigger/view bindings, lookup order and schema-local foreign keys')
