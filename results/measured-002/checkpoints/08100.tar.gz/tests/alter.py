import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
path='/work/tests/alter.db'
try:os.unlink(path)
except FileNotFoundError:pass
assert req({'op':'open','path':path})['ok']
sql('CREATE TABLE t(id INTEGER PRIMARY KEY,a INT,b INT,c AS(a+b),CHECK(a>0))')
sql('CREATE TABLE unrelated(a INT)');sql('INSERT INTO unrelated VALUES(50)')
sql('CREATE TABLE log(x INT)')
sql('CREATE INDEX ia ON t(CASE WHEN a>1 THEN a ELSE b END) WHERE a>0')
sql('CREATE VIEW v AS SELECT t.a,unrelated.a ua FROM t,unrelated')
sql('CREATE VIEW nested AS SELECT a FROM (SELECT a FROM t)')
sql('CREATE TRIGGER tr AFTER UPDATE OF a ON t WHEN new.a>old.a BEGIN INSERT INTO log VALUES(new.a); UPDATE log SET x=x+new.a WHERE x=old.a; END')
sql('CREATE TABLE child(x REFERENCES t(a))')
sql('INSERT INTO t(id,a,b) VALUES(1,2,3)')
sql('ALTER TABLE t RENAME COLUMN a TO amount')
assert sql('SELECT amount,b,c FROM t')==[['2','3','5']]
assert sql('SELECT amount,ua FROM v')==[['2','50']]
assert sql('SELECT amount FROM nested')==[['2']]
sql('UPDATE t SET amount=4');assert sql('SELECT x FROM log')==[['4']]
assert sql('SELECT c FROM t')==[['7']]
sql('INSERT INTO t(id,amount,b) VALUES(2,-1,1)',False)
assert sql('PRAGMA foreign_key_list(child)')[0][4]=='amount'
req({'op':'close'});assert req({'op':'open','path':path})['ok']
assert sql('SELECT amount,ua FROM v')==[['4','50']]
sql('UPDATE t SET amount=5');assert sql('SELECT x FROM log ORDER BY x')==[['5'],['9']]
sql('ALTER TABLE t DROP COLUMN amount',False)
sql('ALTER TABLE t DROP COLUMN b',False)
sql('CREATE TABLE dropper(a CHECK(a>0),b,c)');sql('INSERT INTO dropper VALUES(1,2,3)')
sql('ALTER TABLE dropper DROP COLUMN a');assert sql('SELECT * FROM dropper')==[['2','3']]
sql('ALTER TABLE dropper DROP COLUMN c');assert sql('SELECT * FROM dropper')==[['2']]
sql('ALTER TABLE dropper DROP COLUMN b',False)
sql('CREATE TABLE d(a,b,c)');sql('CREATE INDEX didx ON d(b) WHERE c>0')
sql('ALTER TABLE d DROP COLUMN b',False);sql('ALTER TABLE d DROP COLUMN c',False)
sql('DROP INDEX didx');sql('CREATE VIEW dv AS SELECT b FROM d');sql('ALTER TABLE d DROP COLUMN b',False)
sql('DROP VIEW dv');sql('CREATE TRIGGER dt AFTER INSERT ON d BEGIN INSERT INTO log VALUES(new.b); END');sql('ALTER TABLE d DROP COLUMN b',False)
sql('DROP TRIGGER dt');sql('ALTER TABLE d DROP COLUMN b')
sql('CREATE TABLE w(a INT,b,c,PRIMARY KEY(a DESC)) WITHOUT ROWID');sql('INSERT INTO w VALUES(1,2,3),(2,3,4)');sql('ALTER TABLE w RENAME COLUMN b TO value')
req({'op':'close'});assert req({'op':'open','path':path})['ok'];assert sql('SELECT a,value FROM w')==[['2','3'],['1','2']]
assert sql('SELECT * FROM dropper')==[['2']]
sql('CREATE TABLE base(id INTEGER PRIMARY KEY AUTOINCREMENT,base UNIQUE,n)')
sql('CREATE TABLE ref(x REFERENCES base(base))')
sql('CREATE VIEW base_view AS SELECT base.*,base.base AS named FROM base')
sql('CREATE VIEW alias_view AS SELECT base.n FROM base AS base')
sql("CREATE TRIGGER base_tr AFTER INSERT ON base BEGIN INSERT INTO log VALUES(new.n); UPDATE base SET n=n+1 WHERE id=new.id; END")
sql("INSERT INTO base(base,n) VALUES('first',10)")
sql('ALTER TABLE base RENAME TO renamed')
assert sql('SELECT base,n,named FROM base_view')==[['first','11','first']]
assert sql('SELECT n FROM alias_view')==[['11']]
assert sql('PRAGMA foreign_key_list(ref)')[0][2]=='renamed'
assert sql("SELECT name FROM sqlite_sequence WHERE name='renamed'")==[['renamed']]
assert sql("SELECT name FROM sqlite_schema WHERE type='index' AND tbl_name='renamed'")==[['sqlite_autoindex_renamed_1']]
sql("INSERT INTO renamed(base,n) VALUES('second',20)");assert sql('SELECT n FROM renamed ORDER BY id')==[['11'],['21']]
req({'op':'close'});assert req({'op':'open','path':path})['ok']
assert sql('SELECT base,n FROM base_view ORDER BY id')==[['first','11'],['second','21']]
sql("INSERT INTO renamed(base,n) VALUES('third',30)");assert sql('SELECT n FROM renamed ORDER BY id')==[['11'],['21'],['31']]
sql("CREATE TABLE punctuation(a TEXT DEFAULT '(',b CHECK(b<>','),c DEFAULT ')')")
sql('ALTER TABLE punctuation DROP COLUMN a');sql('INSERT INTO punctuation(b) VALUES(2)');assert sql('SELECT * FROM punctuation')==[['2',')']]
sql('CREATE TABLE viewbase(a,b)')
sql('CREATE VIEW implicit_names AS SELECT a,b FROM viewbase')
sql('CREATE VIEW fixed_names(a,b) AS SELECT a,b FROM viewbase')
sql('CREATE TRIGGER vi INSTEAD OF INSERT ON implicit_names WHEN new.a>0 BEGIN INSERT INTO viewbase(a,b) VALUES(new.a,new.b); END')
sql('CREATE TRIGGER vu INSTEAD OF UPDATE OF a ON fixed_names BEGIN UPDATE viewbase SET a=new.a WHERE a=old.a; END')
sql('ALTER TABLE viewbase RENAME COLUMN a TO amount')
sql('INSERT INTO implicit_names(amount,b) VALUES(1,10)');sql('UPDATE fixed_names SET a=2')
assert sql('SELECT amount,b FROM viewbase')==[['2','10']]
sql('CREATE TABLE unaffected(a,b)');sql('ALTER TABLE unaffected RENAME COLUMN a TO value');sql('ALTER TABLE unaffected DROP COLUMN b')
sql('ALTER TABLE viewbase DROP COLUMN amount',False)
req({'op':'close'});assert req({'op':'open','path':path})['ok']
sql('INSERT INTO implicit_names(amount,b) VALUES(3,30)');assert sql('SELECT a FROM fixed_names ORDER BY a')==[['2'],['3']]
p.terminate();p.wait();print('PASS: column rename/drop dependencies, triggers, views, constraints and persistence')
