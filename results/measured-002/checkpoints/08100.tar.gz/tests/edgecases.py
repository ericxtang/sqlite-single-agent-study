import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE s(id INTEGER PRIMARY KEY AUTOINCREMENT,x UNIQUE)')
assert sql('SELECT * FROM sqlite_sequence')==[]
sql("INSERT INTO s(x) VALUES('a')");sql("INSERT OR IGNORE INTO s(x) VALUES('a')");sql("INSERT INTO s(x) VALUES('b')")
assert sql('SELECT id FROM s ORDER BY id')==[['1'],['3']]
assert sql('SELECT seq FROM sqlite_sequence')==[['3']]
sql('UPDATE sqlite_sequence SET seq=50 WHERE name=\'s\'');sql("INSERT INTO s(x) VALUES('c')")
assert sql('SELECT last_insert_rowid()')==[['51']]
sql('DELETE FROM s');sql('DELETE FROM sqlite_sequence');sql("INSERT INTO s(x) VALUES('d')");assert sql('SELECT last_insert_rowid()')==[['1']]
sql('ALTER TABLE s RENAME TO ss');assert sql('SELECT name FROM sqlite_sequence')==[['ss']]
sql('DROP TABLE ss');assert sql('SELECT * FROM sqlite_sequence')==[];sql('DROP TABLE sqlite_sequence',False)
sql('CREATE TABLE u(a INT UNIQUE,b INT UNIQUE,c)');sql("INSERT INTO u VALUES(1,10,'a'),(2,20,'b')")
sql("INSERT INTO u VALUES(3,20,'x') ON CONFLICT(a) DO NOTHING",False)
sql("INSERT INTO u VALUES(3,20,'x') ON CONFLICT(a) DO NOTHING ON CONFLICT(b) DO UPDATE SET c=excluded.c")
assert sql('SELECT a,b,c FROM u ORDER BY a')==[['1','10','a'],['2','20','x']]
sql('INSERT INTO u VALUES(3,30,0) ON CONFLICT(c) DO NOTHING',False)
sql('CREATE TABLE partial(a,b,c)');sql('CREATE UNIQUE INDEX px ON partial(a) WHERE b>0')
sql('INSERT INTO partial VALUES(1,1,0)');sql('INSERT INTO partial VALUES(1,1,2) ON CONFLICT(a) WHERE b>0 DO UPDATE SET c=excluded.c')
assert sql('SELECT c FROM partial')==[['2']]
sql('INSERT INTO partial VALUES(2,1,2) ON CONFLICT(a) DO NOTHING',False)
sql('CREATE TABLE n(x NUMERIC)');sql("INSERT INTO n VALUES('12')")
assert sql("SELECT '12' IN (SELECT x FROM n), x IN ('12') FROM n")==[['1','1']]
sql('CREATE TABLE empty(x)');sql('SELECT unknown_function(x) FROM empty',False)
sql('SELECT lower() FROM empty',False)
sql('CREATE TABLE payload(id,j)');sql("INSERT INTO payload VALUES(1,'[1,2]'),(2,'[3]')")
assert sql('SELECT payload.id,e.value FROM payload,json_each(payload.j) e ORDER BY 1,2')==[['1','1'],['1','2'],['2','3']]
assert sql("SELECT json_array(j) FROM (SELECT json('[1,2]') j)")==[['["[1,2]"]']]
sql('CREATE TABLE composite(a,b,c,PRIMARY KEY(a DESC,b)) WITHOUT ROWID')
sql("INSERT INTO composite VALUES('a',1,0),('c',1,0),('b',1,0)")
assert sql('SELECT a FROM composite')==[['c'],['b'],['a']]

sql('CREATE TABLE cycle_gen(a,b AS(c+1),c AS(b+1))',False)
sql('CREATE TABLE all_gen(a AS(1))',False)
sql('CREATE TABLE bad_gen(a,b AS(random()))',False)
sql('CREATE TABLE bad_default(a DEFAULT missing)',False)
sql('CREATE TABLE bad_check(a CHECK((SELECT 1)))',False)
sql('CREATE TABLE added(a INT)');sql('INSERT INTO added VALUES(3)')
sql('ALTER TABLE added ADD COLUMN b AS(a*2)');assert sql('SELECT * FROM added')==[['3','6']]
sql('ALTER TABLE added ADD COLUMN c AS(a+1) STORED',False)
sql('ALTER TABLE added ADD COLUMN d INT DEFAULT 0 CHECK(d>0)',False)
assert sql("SELECT json('{a:0x10,b:[1,2,],c:NaN}'),json_valid('{a:1}'),json_valid('{a:1}',2)")==[['{"a":16,"b":[1,2],"c":null}','0','1']]
assert sql("SELECT hex(unhex('AB CD',' ')),unhex('A B',' '),unhex('AB',NULL)")==[['ABCD',None,None]]
sql('CREATE TABLE pct(x)');sql('INSERT INTO pct VALUES(1),(2),(3),(4),(NULL)')
assert sql('SELECT median(x),percentile(x,25),percentile_cont(x,0.75),percentile_disc(x,0.75) FROM pct')==[['2.5','1.75','3.25','3.0']]
assert sql('SELECT median(x) OVER(ORDER BY x ROWS 1 PRECEDING) FROM pct WHERE x IS NOT NULL ORDER BY x')==[['1.0'],['1.5'],['2.5'],['3.5']]
sql("SELECT median('abc')",False)
p.terminate();p.wait();print('PASS: sequences, conflict targets, empty-query errors, affinities, lateral JSON, descending primary keys')
