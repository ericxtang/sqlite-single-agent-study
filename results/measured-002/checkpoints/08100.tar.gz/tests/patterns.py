import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=p.stdout.readline();assert r,p.poll();return json.loads(r)
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s[:90],r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
def lit(s):return "'"+s.replace("'","''")+"'"
assert req({'op':'open','path':':memory:'})['ok']
for pat,value,want in [('%','',1),('a%z','abcxyz',1),('a%z','abczx',0),('%a%b','ab',1),('a__','a🙂é',1),('A%','abc',1),('Ä%','äbc',0),('%aaab','a'*100+'b',1),('%aaab','a'*100+'c',0),('a%a%a','aa',0)]:
 assert sql('SELECT like('+lit(pat)+','+lit(value)+')')==[[str(want)]]
for pat,value,want in [('*','',1),('A*','abc',0),('[a-c]?','b🙂',1),('[^a-c]*','def',1),('[^a-c]*','abc',0),('[]a]','a',1),('[]a]',']',1),('[-a]','-',1),('[a-]','-',1),('[a-c','a',0),('[]',']',0),('*[0-9]*','abc2def',1),('a**?z','abz',1)]:
 assert sql('SELECT glob('+lit(pat)+','+lit(value)+')')==[[str(want)]]
assert sql("SELECT like('a!%b','a%b','!'),like('a!_b','a_b','!'),like('a!','a','!')")==[['1','1','0']]
assert sql('SELECT like(\'%z\','+lit('a'*200_000)+')')==[['0']]
assert sql('SELECT glob(\'a*z\','+lit('a'*200_000+'z')+')')==[['1']]
sql('SELECT like('+lit('a'*50_001)+",'a')",False)
sql('CREATE TABLE empty(x,y)')
for q in ['UPDATE empty SET x=missing','UPDATE empty SET x=1 WHERE missing','DELETE FROM empty WHERE missing','DELETE FROM empty RETURNING missing','UPDATE empty SET x=1 RETURNING count(*)','INSERT INTO empty SELECT 1 WHERE 0','UPDATE empty SET x=sum(y)','CREATE TRIGGER no_ret AFTER INSERT ON empty BEGIN DELETE FROM empty RETURNING x; END']:
 sql(q,False)
assert sql('DELETE FROM empty RETURNING x,y')==[]
sql('INSERT INTO empty VALUES(1,2)');assert sql('UPDATE empty SET y=3 RETURNING x,(SELECT count(*) FROM empty)')==[['1','1']]
quoted=sql("SELECT unistr_quote('a'||char(10)||'\\b')")[0][0]
assert quoted=="unistr('a\\u000a\\\\b')",quoted
assert sql('SELECT '+quoted)==[['a\n\\b']]
assert sql("SELECT json_pretty('{a:Infinity,b:[]}', ' ')")==[['{\n "a": 9e999,\n "b": []\n}']]
p.terminate();p.wait();print('PASS: LIKE/GLOB semantics and long strings, DML empty-input validation and RETURNING restrictions')
