"""Inject interrupted multi-file image commits; exercise recovery through process open."""
import os,json,subprocess,shutil,pathlib
BIN=os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')
def start():return subprocess.Popen([BIN],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(p,v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());assert r['ok'],(v,r);return r
def sql(p,s):return req(p,{'op':'execute','sql':s})
paths=[pathlib.Path('/work/tests/recover-a.db'),pathlib.Path('/work/tests/recover-b.db')]
for path in paths:
 path.unlink(missing_ok=True)
 path.with_name(path.name+'.agent-transaction').unlink(missing_ok=True)
p=start();req(p,{'op':'open','path':str(paths[0])});sql(p,'CREATE TABLE t(x)');sql(p,'INSERT INTO t VALUES(1)')
sql(p,f"ATTACH '{paths[1]}' AS aux");sql(p,'CREATE TABLE aux.t(x)');sql(p,'INSERT INTO aux.t VALUES(2)')
old=[x.read_bytes() for x in paths]
sql(p,'BEGIN');sql(p,'UPDATE main.t SET x=10');sql(p,'UPDATE aux.t SET x=20');sql(p,'COMMIT')
new=[x.read_bytes() for x in paths]
req(p,{'op':'close'});p.terminate();p.wait()
for step,committed in [(0,False),(1,False),(2,False),(2,True)]:
 root=pathlib.Path(f'/work/.sqlite-agent-txn-test-{step}-{committed}')
 if root.exists():shutil.rmtree(root)
 root.mkdir()
 entries=[]
 for i,path in enumerate(paths):
  path.write_bytes(new[i] if i<step else old[i])
  backup=root/f'{i}.old';backup.write_bytes(old[i]);entries.append({'path':str(path),'backup':str(backup),'existed':True})
 manifest=root/'manifest.json';manifest.write_text(json.dumps({'committed':committed,'entries':entries}))
 for path in paths:path.with_name(path.name+'.agent-transaction').write_text(str(manifest))
 p=start();req(p,{'op':'open','path':str(paths[0])})
 assert [path.read_bytes() for path in paths]==(new if committed else old),(step,committed)
 assert sql(p,'SELECT x FROM t')['rows'][0][0]['value']==('10' if committed else '1')
 sql(p,f"ATTACH '{paths[1]}' AS b")
 assert sql(p,'SELECT x FROM b.t')['rows'][0][0]['value']==('20' if committed else '2')
 assert not root.exists()
 assert not any(path.with_name(path.name+'.agent-transaction').exists() for path in paths)
 p.terminate();p.wait()
 print('PASS interrupted commit recovery:',step,'images replaced; committed =',committed)
