import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
main='/work/tests/meta-main.db';aux='/work/tests/meta-aux.db'
for path in [main,aux]:
 try:os.unlink(path)
 except FileNotFoundError:pass
assert req({'op':'open','path':main})['ok'];sql("ATTACH '"+aux+"' AS aux")
assert sql('PRAGMA main.schema_version')==[['0']];assert sql('PRAGMA aux.schema_version')==[['0']]
sql('CREATE TABLE aux.t(x)');assert sql('PRAGMA aux.schema_version')==[['1']];assert sql('PRAGMA main.schema_version')==[['0']]
sql('CREATE TABLE m(x)');assert sql('PRAGMA main.schema_version')==[['1']];assert sql('PRAGMA aux.schema_version')==[['1']]
sql('CREATE TEMP TABLE scratch(x)');assert sql('PRAGMA temp.schema_version')==[['1']];assert sql('PRAGMA main.schema_version')==[['1']]
sql('CREATE INDEX aux.idx ON t(x)');assert sql('PRAGMA aux.schema_version')==[['2']]
sql('PRAGMA main.user_version=10');sql('PRAGMA aux.user_version=20');sql('PRAGMA aux.application_id=12345')
sql('BEGIN');sql('PRAGMA main.user_version=11');sql('PRAGMA aux.user_version=21');sql('SAVEPOINT s');sql('PRAGMA aux.application_id=99')
sql('ROLLBACK TO s');assert sql('PRAGMA aux.application_id')==[['12345']];sql('ROLLBACK')
assert sql('PRAGMA main.user_version')==[['10']];assert sql('PRAGMA aux.user_version')==[['20']]
sql('BEGIN');sql('PRAGMA aux.user_version=30');sql('PRAGMA main.user_version=40');sql('COMMIT')
sql('PRAGMA aux.foreign_keys=ON');assert sql('PRAGMA foreign_keys')==[['1']]
assert sql('PRAGMA aux.journal_mode=WAL')==[['wal']]
sql('BEGIN');sql('PRAGMA aux.journal_mode=DELETE',False);sql('ROLLBACK')
assert sql('PRAGMA aux.journal_mode')==[['wal']]
old_size=sql('PRAGMA aux.page_size');sql('PRAGMA aux.page_size=1000');assert sql('PRAGMA aux.page_size')==old_size
sql('DETACH aux');sql("ATTACH '"+aux+"' AS again")
assert sql('PRAGMA again.journal_mode')==[['wal']]
assert sql('PRAGMA again.user_version')==[['30']];assert sql('PRAGMA again.application_id')==[['12345']];assert sql('PRAGMA again.schema_version')==[['2']]
req({'op':'close'});assert req({'op':'open','path':main})['ok'];assert sql('PRAGMA user_version')==[['40']];assert sql('PRAGMA schema_version')==[['1']]
req({'op':'close'});assert req({'op':'open','path':aux})['ok'];assert sql('PRAGMA user_version')==[['30']];assert sql('PRAGMA application_id')==[['12345']];assert sql('PRAGMA schema_version')==[['2']]
p.terminate();p.wait();print('PASS: per-schema versions, qualified pragmas, savepoint/transaction rollback and persistence')
