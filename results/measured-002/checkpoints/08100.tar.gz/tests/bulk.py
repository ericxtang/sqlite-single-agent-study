import json,subprocess,os,time
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=p.stdout.readline();assert r,p.poll();return json.loads(r)
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
path='/work/tests/bulk.db'
try:os.unlink(path)
except FileNotFoundError:pass
assert req({'op':'open','path':path})['ok'];sql('CREATE TABLE bulk(x INT,y AS(x*2),CHECK(x>0))')
start=time.monotonic();sql('WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<20000) INSERT INTO bulk(x) SELECT x FROM n')
elapsed=time.monotonic()-start
assert sql('SELECT count(*),sum(x),sum(y),max(rowid) FROM bulk')==[['20000','200010000','400020000','20000']]
assert sql('SELECT changes(),last_insert_rowid()')==[['20000','20000']]
sql('INSERT OR ABORT INTO bulk(x) VALUES(20001),(-1),(20002)',False);assert sql('SELECT count(*) FROM bulk')==[['20000']]
sql('INSERT OR FAIL INTO bulk(x) VALUES(20001),(-1),(20002)',False);assert sql('SELECT max(rowid),max(x) FROM bulk')==[['20001','20001']]
sql('INSERT OR IGNORE INTO bulk(x) VALUES(-1),(20002),(-1),(20003)');assert sql('SELECT rowid,x FROM bulk WHERE x>=20001 ORDER BY rowid')==[['20001','20001'],['20002','20002'],['20003','20003']]
sql('BEGIN');sql('INSERT INTO bulk(x) VALUES(20004)');sql('ROLLBACK');assert sql('SELECT max(rowid) FROM bulk')==[['20003']]
req({'op':'close'});assert req({'op':'open','path':path})['ok'];assert sql('SELECT count(*),max(y) FROM bulk')==[['20003','40006']]
assert sql('PRAGMA integrity_check')==[['ok']]
p.terminate();p.wait();print('PASS: 20000-row insert, generated values, conflict policies, rowids and persistence; %.2fs'%elapsed)
