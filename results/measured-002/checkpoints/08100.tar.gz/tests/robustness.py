import json,subprocess,os,random
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=p.stdout.readline();assert r,(p.poll(),p.stderr.read());return json.loads(r)
assert req({'op':'open','path':':memory:'})['ok']
for s in ['SELECT '+'('*1000+'1'+')'*1000,'SELECT '+'~'*1000+'1','SELECT '+'1+'*1000+'1','EXPLAIN '*1000+'SELECT 1', 'SELECT json(\''+'['*1000+'0'+']'*1000+'\')',"SELECT json_set('{}','$.a"+'.a'*1000+"',1)", ' UNION ALL '.join(['SELECT 1']*501)]:
 r=req({'op':'execute','sql':s});assert not r['ok'],s[:50]
 assert req({'op':'execute','sql':'SELECT 1'})['ok']
# Deterministically mutate our own SQL snippets. The assertion is bounded execution
# and a valid response, without inferring undocumented results for malformed input.
rng=random.Random(745)
seeds=['SELECT (a+1) FROM t WHERE x IN (1,2)','CREATE TABLE t(a INTEGER PRIMARY KEY,b CHECK(b>0))','SELECT sum(1) OVER(ORDER BY 1 ROWS 1 PRECEDING)','WITH q(a) AS(VALUES(1),(2)) SELECT * FROM q']
for _ in range(300):
 s=rng.choice(seeds);a=rng.randrange(len(s));b=rng.randrange(a,len(s));s=s[:a]+rng.choice(['','(',')',',','NULL','SELECT','\"'])+s[b:]
 r=req({'op':'execute','sql':s});assert isinstance(r.get('ok'),bool)
assert req({'op':'execute','sql':'SELECT 123'})['ok']
p.terminate();p.wait();print('PASS: deep SQL/JSON limits and 300 deterministic SQL mutations')
