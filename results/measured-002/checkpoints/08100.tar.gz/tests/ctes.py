import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
assert sql('WITH t(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM t WHERE x<4) SELECT * FROM t')==[['1'],['2'],['3'],['4']]
assert sql('WITH a AS(SELECT * FROM b),b AS(SELECT 42 x) SELECT * FROM a')==[['42']]
sql('WITH a AS(SELECT * FROM b),b AS(SELECT * FROM a) SELECT * FROM a',False)
assert sql('WITH RECURSIVE t(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM t LIMIT 3 OFFSET 4) SELECT * FROM t')==[['5'],['6'],['7']]
assert sql('WITH RECURSIVE t(x) AS(VALUES(1),(2) UNION ALL SELECT x+2 FROM t LIMIT 0) SELECT * FROM t')==[]
assert sql('WITH RECURSIVE t(x) AS(SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT x+2 FROM t WHERE x<4) SELECT * FROM t ORDER BY 1')==[['1'],['2'],['3'],['4'],['5']]
assert sql('WITH RECURSIVE t(x) AS(VALUES(1) UNION SELECT (x+1)%4 FROM t) SELECT * FROM t ORDER BY 1')==[['0'],['1'],['2'],['3']]
# Each extraction adds a binary tree node. DESC priority visits deeper nodes first.
assert sql('WITH RECURSIVE t(x) AS(VALUES(1) UNION ALL SELECT x*2 FROM t WHERE x<8 UNION ALL SELECT x*2+1 FROM t WHERE x<8 ORDER BY 1 DESC LIMIT 5) SELECT * FROM t')==[['1'],['3'],['7'],['15'],['14']]
assert sql('WITH RECURSIVE t(x) AS(VALUES(1) UNION ALL SELECT x*2 FROM t WHERE x<8 UNION ALL SELECT x*2+1 FROM t WHERE x<8 ORDER BY 1 LIMIT 5) SELECT * FROM t')==[['1'],['2'],['3'],['4'],['5']]
sql('WITH RECURSIVE t(x) AS(VALUES(1) UNION ALL SELECT count(*) FROM t) SELECT * FROM t',False)
sql('WITH RECURSIVE t(x) AS(VALUES(1) UNION ALL SELECT row_number() OVER() FROM t) SELECT * FROM t',False)
sql('WITH RECURSIVE t(x) AS(VALUES(1) UNION ALL SELECT a.x+b.x FROM t a,t b) SELECT * FROM t',False)
assert sql("SELECT 'a' COLLATE NOCASE UNION SELECT 'A'")==[['a']]
assert sql("SELECT 'a' UNION SELECT 'A' COLLATE NOCASE")==[['a']]
assert sql("SELECT 'a' COLLATE NOCASE INTERSECT SELECT 'A'")==[['a']]
assert sql("SELECT 'a' COLLATE NOCASE EXCEPT SELECT 'A'")==[]
assert sql("SELECT '10' UNION SELECT 10 ORDER BY 1")==[['10'],['10']]
assert sql('SELECT 1+2 UNION ALL SELECT 1+1 ORDER BY 1+2')==[['2'],['3']]
assert sql('SELECT 3 a UNION ALL SELECT 2 b ORDER BY b')==[['2'],['3']]
sql('SELECT 1 a UNION ALL SELECT 2 ORDER BY a+0',False)
sql('SELECT 1 WHERE 0 UNION ALL SELECT 2 WHERE 0 ORDER BY 3',False)
assert sql("SELECT 'a' x UNION ALL SELECT 'B' ORDER BY x COLLATE NOCASE")==[['a'],['B']]
p.terminate();p.wait();print('PASS: recursive queues, offsets, compound seeds, forward CTEs, compound ordering and collations')
