import json,subprocess,os,time,threading
BIN=os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')
class DB:
 def __init__(self):self.p=subprocess.Popen([BIN],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
 def req(self,v):self.p.stdin.write(json.dumps(v)+'\n');self.p.stdin.flush();return json.loads(self.p.stdout.readline())
 def sql(self,s,ok=True):
  r=self.req({'op':'execute','sql':s});assert r['ok']==ok,(s,r);return [[v.get('value') for v in row] for row in r.get('rows',[])]
 def stop(self):self.p.terminate();self.p.wait()
path='/work/tests/busy.db'
try:os.unlink(path)
except FileNotFoundError:pass
x,y=DB(),DB()
assert x.req({'op':'open','path':path})['ok'];x.sql('CREATE TABLE t(x)')
assert y.req({'op':'open','path':path})['ok'];assert y.sql('PRAGMA busy_timeout=80')==[['80']]
x.sql('BEGIN IMMEDIATE');start=time.monotonic();y.sql('INSERT INTO t VALUES(1)',False);elapsed=time.monotonic()-start
assert elapsed>=0.06,elapsed
# The blocked writer resumes after the other process releases its reservation.
def release():time.sleep(.035);x.sql('ROLLBACK')
thread=threading.Thread(target=release);thread.start();y.sql('INSERT INTO t VALUES(1)');thread.join()
assert x.sql('SELECT * FROM t')==[['1']]
# COMMIT also waits for a reader to leave its snapshot.
x.sql('BEGIN');x.sql('SELECT * FROM t');y.sql('BEGIN IMMEDIATE');y.sql('UPDATE t SET x=2')
thread=threading.Thread(target=release);thread.start();y.sql('COMMIT');thread.join()
assert x.sql('SELECT * FROM t')==[['2']]
x.stop();y.stop();print('PASS: busy timeout expiry, writer wakeup and commit waiting for readers')
