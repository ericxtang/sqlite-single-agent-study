import json,subprocess,os
BIN=os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')
class DB:
 def __init__(self):self.p=subprocess.Popen([BIN],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
 def req(self,v):self.p.stdin.write(json.dumps(v)+'\n');self.p.stdin.flush();return json.loads(self.p.stdout.readline())
 def open(self,path):assert self.req({'op':'open','path':path})['ok']
 def sql(self,s,ok=True):
  r=self.req({'op':'execute','sql':s});assert r['ok']==ok,(s,r);return [[v.get('value') for v in row] for row in r.get('rows',[])]
 def close(self):self.req({'op':'close'})
 def stop(self):self.p.terminate();self.p.wait()
path='/work/tests/isolation.db'
try:os.unlink(path)
except FileNotFoundError:pass
x,y=DB(),DB();x.open(path);x.sql('CREATE TABLE t(x)');x.sql('INSERT INTO t VALUES(1)');y.open(path)
x.sql('BEGIN IMMEDIATE');x.sql('UPDATE t SET x=2');assert y.sql('SELECT x FROM t')==[['1']]
y.sql('INSERT INTO t VALUES(3)',False);x.sql('COMMIT');assert y.sql('SELECT x FROM t')==[['2']]
x.sql('BEGIN');assert x.sql('SELECT x FROM t')==[['2']]
y.sql('BEGIN IMMEDIATE');y.sql('UPDATE t SET x=3');y.sql('COMMIT',False)
assert x.sql('SELECT x FROM t')==[['2']];x.sql('COMMIT');y.sql('COMMIT');assert x.sql('SELECT x FROM t')==[['3']]
x.sql('BEGIN EXCLUSIVE');y.sql('SELECT * FROM t',False);x.sql('ROLLBACK')
x.sql('BEGIN');y.sql('INSERT INTO t VALUES(4)');assert x.sql('SELECT sum(x) FROM t')==[['7']];x.sql('ROLLBACK')
x.sql('PRAGMA journal_mode=WAL');assert y.sql('PRAGMA journal_mode')==[['wal']]
x.sql('BEGIN');assert x.sql('SELECT sum(x) FROM t')==[['7']]
y.sql('UPDATE t SET x=x+10');assert x.sql('SELECT sum(x) FROM t')==[['7']]
x.sql('UPDATE t SET x=0',False);x.sql('ROLLBACK');assert x.sql('SELECT sum(x) FROM t')==[['27']]
# Killing an uncommitted writer must release locks and preserve committed file.
x.sql('BEGIN IMMEDIATE');x.sql('DELETE FROM t');x.stop();assert y.sql('SELECT sum(x) FROM t')==[['27']]
y.sql('INSERT INTO t VALUES(5)');assert y.sql('SELECT sum(x) FROM t')==[['32']]
# Opening through a symlink uses the same locks and commits to the same file.
alias='/work/tests/isolation-alias.db'
try:os.unlink(alias)
except FileNotFoundError:pass
os.symlink(path,alias);z=DB();z.open(alias)
y.sql('BEGIN IMMEDIATE');z.sql('INSERT INTO t VALUES(100)',False);y.sql('ROLLBACK')
z.sql('INSERT INTO t VALUES(100)');assert y.sql('SELECT sum(x) FROM t')==[['132']]
assert os.path.islink(alias);z.stop();os.unlink(alias)
y.stop();print('PASS: two-process transactions, locks, snapshots, retry, and crash rollback')
