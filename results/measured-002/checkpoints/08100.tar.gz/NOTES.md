# Work state and continuation notes

All shell operations, reads/writes, compilation and tests use `mcp__workspace__exec` at /work. Only /docs, our own code/tests, Rust std, serde and serde_json have been used. No database engine, SQL parser, external tests/source, network, other models, or agents. User explicitly wants continued independent useful progress until the controller stops the work period.

## Integrated implementation

- Rust project and JSON-lines process contract implemented; release binary path is `target/release/sqlite-agent`.
- Lexer/Pratt parser, typed values, affinities, casts, NULL/boolean semantics, collation, rowids, overflow promotion.
- SELECT/VALUES, joins (LEFT/RIGHT/FULL/USING/NATURAL), projection, WHERE/GROUP/HAVING/ORDER/LIMIT, DISTINCT and compounds, correlated subqueries, row values, ordinary/recursive CTEs.
- Window functions with ROWS/RANGE/GROUPS, EXCLUDE forms, filters, grouped-window evaluation and named-window chaining. Percentile/median aggregates and windows included.
- Schema-aware ALTER RENAME TABLE/COLUMN and DROP COLUMN dependency checking; SQL rendering covers subqueries, compounds, windows, trigger DML. Index determinism, unique creation collations, dynamic date/time determinism are checked.
- DDL/DML, constraints/conflict algorithms, UPSERT targets, RETURNING, strict/without-rowid/generated columns, foreign keys/cascades/deferred checks.
- BEFORE/AFTER/INSTEAD OF triggers, WHEN, UPDATE OF, OLD/NEW, RAISE, recursion controls, UPSERT hooks and view DML.
- ATTACH/DETACH with flat qualified schema names, cross-database queries, per-file persistence, qualified views/triggers, temporary-table shadowing.
- Recursive CTEs use a documented extraction queue, including ORDER BY priority, LIMIT/OFFSET, compound seeds/recursive terms, forward CTE dependencies, optional RECURSIVE keyword. Compound set comparisons honor collations and ORDER BY resolves result expressions/aliases across terms.
- sqlite_sequence is an actual table, including direct modifications and lifetime after last AUTOINCREMENT table is dropped.
- Functions for strings, numbers, dates, JSON/JSON5, JSON paths/table functions, Unicode escapes, introspection pragmas.
- SQLite 3 native database images: headers, varints/records, table and index leaf/interior B-trees, overflow chains, freelist, UTF8/UTF16 reading. Descending index keys retained. Complete new image + fsync + atomic rename for commits.
- Two-file OS flock coordination (reader and writer) among our own processes. Deferred/immediate/exclusive transactions, commit retry with readers, snapshot isolation in WAL mode, crash rollback (uncommitted changes remain private). Durable application-level super-journal manifests/backups provide crash atomicity across attached files; recovery happens on open/access. Symlink aliases canonicalize to common file/lock paths. Native WAL files are NOT generated or recovered; WAL header/mode and snapshot behavior use atomic images.

## Tests and build

`cargo build --offline --bin sqlite-agent` succeeds with no warnings. Required delivery build: `cargo build --release --offline --bin sqlite-agent` (run again after changes; release may lag debug).
`cargo test --offline`: varint/record boundary round trips.
Process tests:
- `tests/semantics.py`: 118 core/documented assertions, state and reopen.
- `tests/edgecases.py`: sequence edits, upsert targeting, empty-query errors, affinities, descending PKs, schema validation, JSON5 and percentile functions.
- `tests/windows.py`: explicit RANGE/GROUPS/ROWS, exclusions, grouped windows, chaining, offsets.
- `tests/triggers.py`: row and view triggers, counters, recursive behavior, RAISE, persistence.
- `tests/attach.py`: attached files, cross-schema joins, rollback, reattach under new names, stored views/triggers, temp shadowing, attached sequences/autoindexes.
- `tests/isolation.py`: two subprocesses, writer conflicts, commit retry, snapshots, killed writer.
- `tests/storage.py`: 512/4096/65536-byte images, large indexes and overflow blobs; independent Python structural decoder verifies every page belongs to a B-tree, overflow chain or freelist, and reopened SQL values agree.
- `tests/recovery.py`: inject pending/committed manifests with 0/1/2 replaced images and verify whole-transaction recovery.
- `tests/foreignkeys.py`: cyclic/self cascades, child constraints/triggers, historical violations, parent key checks.
- `tests/names.py`: star slots, quoted identifiers/defaults/generated cycles, tuple comparisons, nested aliases, zero-row validation, collation propagation.
- `tests/ctes.py`: queue priority, offsets, compound seeds, forward dependencies, compound result ordering/collations.
- `tests/robustness.py`: deep parser/expression/JSON errors and 300 deterministic mutations of our SQL snippets.
- `tests/alter.py`: rename/drop dependencies, views/trigger programs, foreign keys, automatic indices/sequences, quoted punctuation, reopened behavior.
- `tests/indexes.py`: expression/partial-index restrictions, existing-key collations, dynamic date/time determinism, reordered FK targets and collation matching.
- `tests/corruption.py`: damaged index/freelist/header images, process survival, read-version/write-version rules, stored CHECK violations, STRICT generated typing.
- `tests/busy.py`: timeout expiry, writer wakeup, reader release during commit.
- `tests/patterns.py`: iterative LIKE/GLOB matching, 200k-character inputs, 50000-byte pattern cap, zero-row DML errors, RETURNING restrictions, unistr_quote round trip and JSON pretty infinities.
- `tests/metadata.py`: independent main/temp/attached schema versions, schema-qualified header pragmas, transaction/savepoint rollback and reopen.
- `tests/bulk.py`: 20000-row INSERT SELECT, generated values, ABORT/FAIL/IGNORE, rowids, rollback and reopen; optimized release initial insertion ~0.2s.
All 19 process suites and cargo unit tests passed against the freshly rebuilt release binary after these changes. No warnings. Build failures must stop dependent tests (use &&), to avoid accidentally running an older binary. rustfmt component is not installed, and must not be fetched; code currently has dense formatting.

## Current limitations and next candidates

1. ALTER now binds and rewrites column/table references using schema_edit.rs; tests cover direct and nested views, row triggers, FKs, checks/generated expressions, indices and persistence. Remaining edge cases: view INSTEAD OF triggers (table lookup currently expects real table), nested source scopes/CTE aliases, compound output names and UPDATE FROM/UPSERT expressions inside trigger column rewrites. USING rename may produce an invalid join when only one side changes; post-validation should reject these. Source SQL rendering now complete for supported queries and trigger DML.
2. State.schema_meta now snapshots per-schema user_version/application_id/schema_version. Qualified PRAGMA main/aux writes work; aux/temp DDL increments only their schema version; import/export preserve file metadata. Remaining attached edges: aux.journal_mode now persists and rolls back its configuration on persistence errors; each attached file locks according to its own mode. Settings like page_size need more complete pending/VACUUM persistence rules, unqualified attached object-name lookup, attachment metadata during rollback, and literal dots conflated with qualification. Child configuration pragmas are connection state (not transaction snapshots).
3. Foreign checks use a transaction-root/statement-root baseline to tolerate historical violations. Rows now carry an internal birth identity (not stored in SQLite records); baseline signatures use birth/FK-index/values. Tests ensure new rows cannot inherit historical exemptions, including deferred commit and unchanged-FK rowid updates. FK comparisons now preserve STRICT ANY affinity. Parent unique keys now compare declared collations and accept reordered target columns. Cascades now enforce child constraints and trigger hooks, self/cycles tested.
4. Trigger changes() context stack now passes tests for first/subsequent/nested DML. Keep validation appropriate if modifying DML.
5. Native WAL/rollback journals and locking interoperability with other implementations remain absent. Full-image commits use our own flock sidecars and durable manifests. Review rare I/O failures during committed-marker writes/recovery cleanup for consistency.
6. Query planner/EXPLAIN are basic placeholders, indices not used for acceleration. A guarded bulk INSERT path for unindexed rowid tables (no unique constraints, UPSERT, explicit rowid, or INSERT triggers) now avoids per-row cloning/scanning of all prior rows. It still evaluates constraints and preserves IGNORE/FAIL/ABORT and RETURNING/counter semantics. Other DML/query paths can remain quadratic. Virtual table extensions and JSONB unavailable (removed bogus JSONB aggregate registration). Complete printf/date edge behavior not implemented.
7. Remaining expression issues include scalar-subquery/tuple-comparison metadata, nested CTE shadowing/subquery recursion restrictions, row-value validation on empty results, and aggregate overflow/precision. IN now compares per-column affinity/collation and checks empty RHS width; row-valued IN-list forms are rejected per docs. Scalar min/max/nullif use first defined collation, including explicit BINARY. UPSERT/compound expression matching now folds identifier case without folding string literals. Empty-query clause/function/window/ordinal validation was strengthened. UPDATE/DELETE expression validation and INSERT SELECT width checks now run even for no affected rows. RETURNING rejects top-level aggregate/window functions and trigger placement. LIKE/GLOB matching is iterative, avoiding recursive stack growth on long values. unistr_quote escapes controls, and JSON pretty output preserves infinities.
8. Parser recursion and expression height limits are 128, JSON parser/path nesting 200, recursive CTE extraction limit 1,000,000; these are lower than some upstream compile-time defaults and documented in README. General corruption/fuzz handling merits continued work. USING/NATURAL joins now apply both sides' affinities, qualified table-star projection works, and ORDER/LIMIT following a terminal VALUES clause are rejected.
9. STRICT generated final typing and ANY preservation are fixed. Disk Reader now validates all table/index/overflow/freelist page ownership, header read/format/payload/size constraints; future write versions open read-only. Integrity/quick checks report stored CHECK/NOT NULL/type errors and integrity checks unique conflicts. Page content boundaries, fragmented-byte limits, freeblock bounds/order and cell/freeblock overlaps now validated. Remaining storage work: index/data correspondence and semantic sort order, native journals. busy_timeout now retries flock acquisition and commit locks, with tests.
10. Read-only future-write-format files refuse mutations, but TEMP/VACUUM INTO work on read-only main is not supported because persistence always writes the main image. Main/attached metadata changes still over-broad; avoid claiming full native lock/WAL compatibility.
11. Open now derives schema, settings and version from one read buffer; refresh records the version from its decoded buffer and notices other connections' WAL/header changes. Atomic-write temporary names have random suffixes to avoid leftovers colliding after PID reuse.
12. `rustfmt` is unavailable and must not be fetched. Existing modules are dense; new functions use readable formatting. Temporary *_method.tmp files were removed after integration.

Keep the implementation integrated, derive new tests from /docs, and continue useful work rather than stopping after a component.
