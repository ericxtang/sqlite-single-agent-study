#[derive(Clone,Debug,PartialEq)]
pub enum Kind{Word,String,Number,Blob,Symbol,Quoted,End}
#[derive(Clone,Debug)]
pub struct Token{pub s:String,pub k:Kind,pub start:usize,pub end:usize}
pub fn lex(s:&str)->Result<Vec<Token>,String>{let b=s.as_bytes();let mut i=0;let mut out=Vec::new();while i<b.len(){if b[i].is_ascii_whitespace(){i+=1;continue}if b.get(i..i+2)==Some(b"--"){while i<b.len()&&b[i]!=b'\n'{i+=1}continue}if b.get(i..i+2)==Some(b"/*"){i+=2;while i+1<b.len()&& &b[i..i+2]!=b"*/"{i+=1}i=(i+2).min(b.len());continue}let start=i;let (k,t);if (b[i]==b'x'||b[i]==b'X')&&b.get(i+1)==Some(&b'\''){i+=2;let a=i;while i<b.len()&&b[i]!=b'\''{i+=1}if i==b.len(){return Err("unrecognized token: blob".into())}t=s[a..i].into();i+=1;k=Kind::Blob;}else if matches!(b[i],b'\''|b'"'|b'`'|b'['){let q=b[i];let end=if q==b'['{b']'}else{q};i+=1;let mut v=Vec::new();let mut closed=false;while i<b.len(){if b[i]==end{if q!=b'['&&b.get(i+1)==Some(&end){v.push(end);i+=2}else{i+=1;closed=true;break}}else{v.push(b[i]);i+=1}}if !closed{return Err("unrecognized token: unterminated string".into())}t=String::from_utf8(v).map_err(|_|"invalid UTF-8")?;k=if q==b'\''{Kind::String}else{Kind::Quoted};}else if b[i].is_ascii_digit()||(b[i]==b'.'&&b.get(i+1).map_or(false,|c|c.is_ascii_digit())){i=numeric_end(b,start)?;t=s[start..i].into();k=Kind::Number;}else if b[i].is_ascii_alphabetic()||b[i]==b'_'||b[i]>=128{ i+=1;while i<b.len()&&(b[i].is_ascii_alphanumeric()||b[i]==b'_'||b[i]==b'$'||b[i]>=128){i+=1}t=s[start..i].into();k=Kind::Word;}else{let mut n=1;if i+3<=b.len()&& &b[i..i+3]==b"->>"{n=3}else if i+2<=b.len()&&["||","<<",">>","<=",">=","==","!=","<>","->"].iter().any(|op|op.as_bytes()==&b[i..i+2]){n=2}i+=n;t=s[start..i].into();k=Kind::Symbol;}out.push(Token{s:t,k,start,end:i});}out.push(Token{s:String::new(),k:Kind::End,start:i,end:i});Ok(out)}

// Numeric separators are allowed only singly between digits, including hex and
// exponent digits. A following identifier character belongs to a malformed
// numeric token, not an implicit column alias (for example SELECT 12abc).
fn numeric_end(bytes: &[u8], start: usize) -> Result<usize, String> {
    fn digits(bytes: &[u8], at: &mut usize, hex: bool) -> Result<usize, String> {
        let first = *at;
        let digit = |c: u8| if hex { c.is_ascii_hexdigit() } else { c.is_ascii_digit() };
        while let Some(&c) = bytes.get(*at) {
            if digit(c) { *at += 1; }
            else if c == b'_' {
                if *at == first || !bytes.get(*at + 1).copied().map_or(false, digit) {
                    return Err("unrecognized token: numeric separator".into());
                }
                *at += 1;
            } else { break; }
        }
        Ok(*at - first)
    }
    let mut at = start;
    if bytes.get(start) == Some(&b'0') && matches!(bytes.get(start + 1), Some(b'x' | b'X')) {
        at += 2;
        if digits(bytes, &mut at, true)? == 0 { return Err("unrecognized token: hexadecimal literal".into()); }
    } else {
        digits(bytes, &mut at, false)?;
        if bytes.get(at) == Some(&b'.') { at += 1; digits(bytes, &mut at, false)?; }
        if matches!(bytes.get(at), Some(b'e' | b'E')) {
            at += 1;
            if matches!(bytes.get(at), Some(b'+' | b'-')) { at += 1; }
            if digits(bytes, &mut at, false)? == 0 { return Err("unrecognized token: numeric exponent".into()); }
        }
    }
    if bytes.get(at).map_or(false, |c| c.is_ascii_alphabetic() || *c == b'_' || *c == b'$' || *c >= 128) {
        return Err("unrecognized token: numeric literal".into());
    }
    Ok(at)
}
