use crate::value::{Val,cmp,hex,unhex};
use crate::parser::Res;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicU64,Ordering as AO};
static RAND:AtomicU64=AtomicU64::new(0);
pub fn random()->u64{let old=RAND.load(AO::Relaxed);let mut n=if old==0{std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos() as u64}else{old};n^=n<<13;n^=n>>7;n^=n<<17;RAND.store(n,AO::Relaxed);n}
pub fn scalar(name:&str,a:&[Val],coll:&str,case_like:bool)->Res<Val>{use Val::*;let n=name.to_ascii_lowercase();let null=Val::Null;let x=a.first().unwrap_or(&null);let y=a.get(1).unwrap_or(&null);let z=a.get(2).unwrap_or(&null);let argc=|lo,hi|->Res<()>{if a.len()<lo||a.len()>hi{Err(format!("wrong number of arguments to function {}()",name))}else{Ok(())}};match n.as_str(){
 "typeof"=>{argc(1,1)?;Ok(Text(x.kind().into()))},
 "abs"=>{argc(1,1)?;Ok(match x{Int(i)=>Int(i.checked_abs().ok_or("integer overflow")?),Null=>Null,_=>Real(x.float().abs())})},
 "length"|"octet_length"=>{argc(1,1)?;Ok(if x.null(){Null}else{Int(if n=="octet_length"{x.bytes().len()}else{match x{Blob(b)=>b.len(),_=>x.text().split('\0').next().unwrap_or("").chars().count()}} as i64)})},
 "lower"|"upper"=>{argc(1,1)?;Ok(if x.null(){Null}else if n=="lower"{Text(x.text().to_ascii_lowercase())}else{Text(x.text().to_ascii_uppercase())})},
 "coalesce"|"ifnull"=>{argc(2,if n=="ifnull"{2}else{usize::MAX})?;Ok(a.iter().find(|v|!v.null()).cloned().unwrap_or(Null))},
 "nullif"=>{argc(2,2)?;Ok(if cmp(x,y,coll)==Ordering::Equal{Null}else{x.clone()})},
 "concat"=>{argc(1,usize::MAX)?;Ok(Text(a.iter().map(|v|v.text()).collect::<Vec<_>>().join("")))},
 "concat_ws"=>{argc(2,usize::MAX)?;Ok(if x.null(){Null}else{Text(a[1..].iter().filter(|v|!v.null()).map(|v|v.text()).collect::<Vec<_>>().join(&x.text()))})},
 "trim"|"ltrim"|"rtrim"=>{argc(1,2)?;if x.null()||(a.len()>1&&y.null()){return Ok(Null)}let chars=if a.len()>1{y.text()}else{" ".into()};let s=x.text();let f=|c:char|chars.contains(c);Ok(Text(match n.as_str(){"ltrim"=>s.trim_start_matches(f),"rtrim"=>s.trim_end_matches(f),_=>s.trim_matches(f)}.into()))},
 "replace"=>{argc(3,3)?;if a.iter().any(Val::null){return Ok(Null)}Ok(Text(if y.text().is_empty(){x.text()}else{x.text().replace(&y.text(),&z.text())}))},
 "substr"|"substring"=>{argc(2,3)?;if a.iter().any(Val::null){return Ok(Null)}let blob=matches!(x,Blob(_));let chars:Vec<u32>=if blob{x.bytes().iter().map(|x|*x as u32).collect()}else{x.text().chars().map(|c|c as u32).collect()};let len=chars.len() as i64;let p=y.int();let mut st=if p>0{p-1}else if p<0{len.saturating_add(p)}else{0};let mut count=if a.len()==3{z.int()}else{len};if p==0&&count>0{count-=1}if count<0{let en=st;st=st.saturating_add(count);count=en.saturating_sub(st)}if st<0{count=count.saturating_add(st);st=0}let st=st.min(len) as usize;let en=(st as i64).saturating_add(count.max(0)).min(len) as usize;Ok(if blob{Blob(chars[st..en].iter().map(|x|*x as u8).collect())}else{Text(chars[st..en].iter().filter_map(|x|char::from_u32(*x)).collect())})},
 "instr"=>{argc(2,2)?;if x.null()||y.null(){return Ok(Null)}if let (Blob(a),Blob(b))=(x,y){return Ok(Int(if b.is_empty(){1}else{a.windows(b.len()).position(|p|p==b).map_or(0,|i|i as i64+1)}))}let (s,t)=(x.text(),y.text());Ok(Int(s.find(&t).map_or(0,|i|s[..i].chars().count() as i64+1)))},
 "hex"=>{argc(1,1)?;Ok(Text(hex(&x.bytes())))},
 "unhex"=>{argc(1,2)?;if x.null(){return Ok(Null)}let ignore=if a.len()==2{if y.null(){return Ok(Null)}y.text()}else{String::new()};let mut s=String::new();for c in x.text().chars(){if c.is_ascii_hexdigit(){s.push(c)}else if !ignore.contains(c)||s.len()%2!=0{return Ok(Null)}}Ok(unhex(&s).map(Blob).unwrap_or(Null))},
 "zeroblob"|"randomblob"=>{argc(1,1)?;let size=x.int().max(if n=="randomblob"{1}else{0}) as usize;if size>16_000_000{return Err("string or blob too big".into())}Ok(Blob((0..size).map(|_|if n=="zeroblob"{0}else{random() as u8}).collect()))},
 "random"=>{argc(0,0)?;Ok(Int((random() as i64).max(i64::MIN+1)))},
 "unistr"=>{argc(1,1)?;if x.null(){return Ok(Null)}let s=x.text();let mut chars=s.chars().peekable();let mut out=String::new();while let Some(c)=chars.next(){if c!='\\'{out.push(c);continue}if chars.peek()==Some(&'\\'){chars.next();out.push('\\');continue}let count=match chars.peek(){Some('u')=>{chars.next();4},Some('U')=>{chars.next();8},Some('+')=>{chars.next();6},_=>4};let mut n=0;for _ in 0..count{n=n*16+chars.next().and_then(|c|c.to_digit(16)).ok_or("invalid Unicode escape")?;}out.push(char::from_u32(n).ok_or("invalid Unicode escape")?);}Ok(Text(out))},"unicode"=>{argc(1,1)?;Ok(x.text().chars().next().map(|c|Int(c as i64)).unwrap_or(Null))},
 "char"=>Ok(Text(a.iter().map(|v|char::from_u32(v.int() as u32).unwrap_or('\u{fffd}')).collect())),
 "round"=>{argc(1,2)?;if x.null()||(a.len()>1&&y.null()){return Ok(Null)}let p=if a.len()>1{y.int().clamp(0,30)}else{0}as i32;let scale=10f64.powi(p);let f=x.float();Ok(Val::real(if f.abs()>1e16{f}else{(f*scale).round()/scale}))},
 "sign"=>{argc(1,1)?;if x.null(){return Ok(Null)}let v=x.apply(crate::value::Aff::Numeric);Ok(if matches!(v,Int(_)|Real(_)){Int(if v.float()>0.0{1}else if v.float()<0.0{-1}else{0})}else{Null})},
 "min"|"max"=>{argc(2,usize::MAX)?;if a.iter().any(Val::null){return Ok(Null)}let mut b=x;for v in &a[1..]{let c=cmp(v,b,coll);if (n=="min"&&c==Ordering::Less)||(n=="max"&&c==Ordering::Greater){b=v}}Ok(b.clone())},
 "quote"|"unistr_quote"=>{argc(1,1)?;Ok(Text(match x{Null=>"NULL".into(),Int(_)|Real(_)=>x.text(),Blob(b)=>format!("X'{}'",hex(b)),Text(s)|Json(s)=>{let s=s.split('\0').next().unwrap_or("");if n=="unistr_quote"&&s.chars().any(|c|('\u{1}'..='\u{1f}').contains(&c)){let mut out=String::from("unistr('");for c in s.chars(){match c{'\u{1}'..='\u{1f}'=>out.push_str(&format!("\\u{:04x}",c as u32)),'\\'=>out.push_str("\\\\"),'\''=>out.push_str("''"),_=>out.push(c)}}out.push_str("')");out}else{format!("'{}'",s.replace('\'',"''"))}}}))},
 "like"|"glob"=>{argc(2,if n=="like"{3}else{2})?;if a.iter().any(Val::null){return Ok(Null)}let escape=if a.len()==3{let s=z.text();let c=s.chars().collect::<Vec<_>>();if c.len()!=1{return Err("ESCAPE expression must be a single character".into())}Some(c[0])}else{None};if x.bytes().len()>50_000{return Err("LIKE or GLOB pattern too complex".into())}Ok(Val::boolean(pattern(&x.text(),&y.text(),n=="glob",escape,case_like)))},
 "likelihood"=>{argc(2,2)?;Ok(x.clone())},"likely"|"unlikely"=>{argc(1,1)?;Ok(x.clone())},
 "printf"|"format"=>{argc(0,usize::MAX)?;if x.null(){Ok(Null)}else{crate::format::sql(&x.text(),&a[1..]).map(Text)}},
 "sqlite_version"=>{argc(0,0)?;Ok(Text("3.53.4".into()))},"sqlite_source_id"=>{argc(0,0)?;Ok(Text("sqlite-agent independent Rust implementation".into()))},
 "sqlite_compileoption_used"=>{argc(1,1)?;Ok(Int(0))},"sqlite_compileoption_get"=>{argc(1,1)?;Ok(Null)},
 "pi"=>{argc(0,0)?;Ok(Real(std::f64::consts::PI))},
 "sqrt"|"sin"|"cos"|"tan"|"asin"|"acos"|"atan"|"sinh"|"cosh"|"tanh"|"asinh"|"acosh"|"atanh"|"ceil"|"ceiling"|"floor"|"trunc"|"exp"|"ln"|"log10"|"log2"|"radians"|"degrees"=>{argc(1,1)?;let v=x.apply(crate::value::Aff::Numeric);if !matches!(v,Int(_)|Real(_)){return Ok(Null)}let f=v.float();let r=match n.as_str(){"sqrt"=>f.sqrt(),"sin"=>f.sin(),"cos"=>f.cos(),"tan"=>f.tan(),"asin"=>f.asin(),"acos"=>f.acos(),"atan"=>f.atan(),"sinh"=>f.sinh(),"cosh"=>f.cosh(),"tanh"=>f.tanh(),"asinh"=>f.asinh(),"acosh"=>f.acosh(),"atanh"=>f.atanh(),"ceil"|"ceiling"=>f.ceil(),"floor"=>f.floor(),"trunc"=>f.trunc(),"exp"=>f.exp(),"ln"=>f.ln(),"log10"=>f.log10(),"log2"=>f.log2(),"radians"=>f.to_radians(),_=>f.to_degrees()};Ok(if matches!(x,Int(_))&&["ceil","ceiling","floor","trunc"].contains(&n.as_str()){x.clone()}else{Val::real(r)})},
 "pow"|"power"|"atan2"|"mod"|"log"=>{argc(if n=="log"{1}else{2},2)?;if a.iter().any(|x|!matches!(x.apply(crate::value::Aff::Numeric),Int(_)|Real(_))){return Ok(Null)}let f=x.float();let g=y.float();Ok(Val::real(match n.as_str(){"pow"|"power"=>f.powf(g),"atan2"=>f.atan2(g),"mod"=>f%g,"log" if a.len()==1=>f.log10(),_=>g.log(f)}))},
 "date"|"time"|"datetime"|"julianday"|"unixepoch"|"strftime"|"timediff"=>crate::date::call(&n,a),
 _ if n.starts_with("json")=>crate::jsonfunc::call(&n,a),
 _=>Err(format!("no such function: {}",name))
}}
pub fn pattern(p:&str,s:&str,glob:bool,esc:Option<char>,case:bool)->bool{
 enum Atom{Many,One,Literal(char),Class(Vec<(char,char)>,bool),Never}
 let chars=p.chars().collect::<Vec<_>>();let mut atoms=vec![];let mut i=0;
 while i<chars.len(){let c=chars[i];i+=1;
  if Some(c)==esc{if let Some(c)=chars.get(i){atoms.push(Atom::Literal(*c));i+=1}else{atoms.push(Atom::Never)}}
  else if c==if glob{'*'}else{'%'}{if !matches!(atoms.last(),Some(Atom::Many)){atoms.push(Atom::Many)}}
  else if c==if glob{'?'}else{'_'}{atoms.push(Atom::One)}
  else if glob&&c=='['{let neg=chars.get(i)==Some(&'^');if neg{i+=1}let mut ranges=vec![];if chars.get(i)==Some(&']'){ranges.push((']',']'));i+=1}while i<chars.len()&&chars[i]!=']'{if chars.get(i+1)==Some(&'-')&&i+2<chars.len()&&chars[i+2]!=']'{ranges.push((chars[i],chars[i+2]));i+=3}else{ranges.push((chars[i],chars[i]));i+=1}}if i==chars.len(){atoms.push(Atom::Never)}else{i+=1;atoms.push(Atom::Class(ranges,neg));}}
  else{atoms.push(Atom::Literal(c))}
 }
 let input=s.chars().collect::<Vec<_>>();let(mut pi,mut si)=(0,0);let mut star:Option<(usize,usize)>=None;
 while si<input.len(){
  if matches!(atoms.get(pi),Some(Atom::Many)){pi+=1;star=Some((pi,si));continue}
  let matched=match atoms.get(pi){Some(Atom::One)=>true,Some(Atom::Literal(c))=>if glob||case{*c==input[si]}else{c.eq_ignore_ascii_case(&input[si])},Some(Atom::Class(ranges,neg))=>ranges.iter().any(|(a,b)|*a<=input[si]&&input[si]<=*b)!=*neg,_=>false};
  if matched{pi+=1;si+=1}else if let Some((resume,used))=star{if used>=input.len(){return false}si=used+1;pi=resume;star=Some((resume,si));}else{return false}
 }
 while matches!(atoms.get(pi),Some(Atom::Many)){pi+=1}pi==atoms.len()
}

