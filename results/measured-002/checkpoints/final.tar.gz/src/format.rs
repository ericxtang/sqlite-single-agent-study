//! SQL format()/printf() conversions, following printf.txt and lang_corefunc.txt.
use crate::{parser::Res, value::Val};
const MAX_OUTPUT: usize = 16_000_000;

#[derive(Default)]
struct Flags { left: bool, plus: bool, space: bool, zero: bool, alternate: bool, chars: bool, comma: bool }
fn number(chars: &[char], at: &mut usize) -> Res<usize> {
    let mut n = 0usize;
    while let Some(d) = chars.get(*at).and_then(|c| c.to_digit(10)) {
        n = n.checked_mul(10).and_then(|n| n.checked_add(d as usize)).ok_or("string or blob too big")?;
        if n > MAX_OUTPUT { return Err("string or blob too big".into()); }
        *at += 1;
    }
    Ok(n)
}
fn argument(args: &[Val], at: &mut usize) -> Val {
    let result = args.get(*at).cloned().unwrap_or(Val::Null); *at += 1; result
}
fn star(args: &[Val], at: &mut usize) -> Res<i64> {
    let n = argument(args, at).int();
    if n.unsigned_abs() > MAX_OUTPUT as u64 { return Err("string or blob too big".into()); }
    Ok(n)
}
fn truncate(value: &str, precision: Option<usize>, chars: bool) -> String {
    let value = value.split('\0').next().unwrap_or("");
    match precision {
        None => value.into(), Some(n) if chars => value.chars().take(n).collect(),
        Some(n) => String::from_utf8_lossy(&value.as_bytes()[..n.min(value.len())]).into_owned(),
    }
}
fn quoted(value: &Val, kind: char, precision: Option<usize>, flags: &Flags) -> String {
    if value.null() { return if kind == 'Q' { "NULL".into() } else { String::new() }; }
    let text = truncate(&value.text(), precision, flags.chars);
    let controls = text.chars().any(|c| ('\u{1}'..='\u{1f}').contains(&c));
    let escaped = flags.alternate && (kind == 'q' || (kind == 'Q' && controls));
    let mut out = String::new();
    if kind == 'Q' { out.push_str(if escaped { "unistr('" } else { "'" }); }
    for c in text.chars() {
        if c == if kind == 'w' { '"' } else { '\'' } { out.push(c); out.push(c); }
        else if escaped && c == '\\' { out.push_str("\\\\"); }
        else if escaped && ('\u{1}'..='\u{1f}').contains(&c) { out.push_str(&format!("\\u{:04x}", c as u32)); }
        else { out.push(c); }
    }
    if kind == 'Q' { out.push_str(if escaped { "')" } else { "'" }); }
    out
}
fn grouped(s: &str) -> String {
    let end = s.find(['.', 'e', 'E']).unwrap_or(s.len());
    let mut out = String::new();
    for (i, c) in s[..end].chars().enumerate() {
        if i > 0 && (end - i) % 3 == 0 { out.push(','); }
        out.push(c);
    }
    out.push_str(&s[end..]); out
}
fn exponent(s: &str) -> (String, i32) {
    let (mantissa, exp) = s.split_once('e').unwrap_or((s, "0"));
    (mantissa.replace('.', ""), exp.parse().unwrap_or(0))
}
fn fixed(digits: &str, exp: i32, precision: usize) -> String {
    let point = exp + 1;
    let mut out = String::new();
    if point <= 0 { out.push('0'); }
    else { for i in 0..point as usize { out.push(digits.as_bytes().get(i).copied().unwrap_or(b'0') as char); } }
    if precision > 0 {
        out.push('.');
        for j in 0..precision {
            let at = point as i64 + j as i64;
            out.push(if at < 0 { '0' } else { digits.as_bytes().get(at as usize).copied().unwrap_or(b'0') as char });
        }
    }
    out
}
fn strip_fraction(s: &mut String) {
    if s.contains('.') { while s.ends_with('0') { s.pop(); } if s.ends_with('.') { s.pop(); } }
}
fn float(value: f64, kind: char, precision: Option<usize>, f: &Flags) -> (String, bool) {
    if !value.is_finite() {
        let text = if value.is_nan() { if f.zero { "null" } else { "NaN" } }
            else if f.zero { "9.0e+999" } else { "Inf" };
        return (text.into(), value.is_sign_negative() && !value.is_nan());
    }
    let mag = value.abs();
    let kind_lower = kind.to_ascii_lowercase();
    let p = precision.unwrap_or(6);
    let significant = if f.chars { 26usize } else { 16 };
    let natural_exp = if mag == 0.0 { 0 } else { exponent(&format!("{:e}", mag)).1 };
    let requested = match kind_lower {
        'g' => p.max(1), 'e' => p.saturating_add(1),
        _ => (p as i64 + natural_exp as i64 + 1).max(1) as usize,
    };
    let (digits, exp) = exponent(&format!("{:.*e}", requested.min(significant) - 1, mag));
    let scientific = kind_lower == 'e' || (kind_lower == 'g' && (exp < -4 || exp >= p.max(1) as i32));
    let mut suffix = String::new();
    let mut text = if scientific {
        let fraction = if kind_lower == 'g' { requested - 1 } else { p };
        suffix = format!("{}{}{:02}", if kind == 'E' || kind == 'G' { 'E' } else { 'e' },
            if exp < 0 { '-' } else { '+' }, exp.unsigned_abs());
        fixed(&digits, 0, fraction)
    } else if kind_lower == 'g' {
        fixed(&digits, exp, (requested as i64 - exp as i64 - 1).max(0) as usize)
    } else if p as i64 + natural_exp as i64 + 1 <= 0 {
        // Rounding below the leading significant digit, e.g. %.2f of 0.004.
        format!("{:.*}", p, mag)
    } else { fixed(&digits, exp, p) };
    if kind_lower == 'g' { strip_fraction(&mut text); }
    if f.alternate || f.chars {
        if !text.contains('.') { text.push('.'); }
        if f.chars && text.ends_with('.') { text.push('0'); }
    }
    let zero = text.chars().all(|c| c == '0' || c == '.');
    let negative = value.is_sign_negative() && !(f.alternate && !f.plus && kind_lower == 'f' && zero);
    text.push_str(&suffix); (text, negative)
}

pub(crate) fn sql(fmt: &str, args: &[Val]) -> Res<String> {
    let chars = fmt.split('\0').next().unwrap_or("").chars().collect::<Vec<_>>();
    let (mut at, mut ai) = (0, 0);
    let mut out = String::new();
    while at < chars.len() {
        if chars[at] != '%' { out.push(chars[at]); at += 1; continue; }
        at += 1;
        if chars.get(at) == Some(&'%') { out.push('%'); at += 1; continue; }
        let mut flags = Flags::default();
        while let Some(c) = chars.get(at) {
            match c { '-' => flags.left = true, '+' => flags.plus = true, ' ' => flags.space = true,
                '0' => flags.zero = true, '#' => flags.alternate = true, '!' => flags.chars = true,
                ',' => flags.comma = true, _ => break }
            at += 1;
        }
        let width = if chars.get(at) == Some(&'*') {
            at += 1; let n = star(args, &mut ai)?; flags.left |= n < 0; n.unsigned_abs() as usize
        } else { number(&chars, &mut at)? };
        let precision = if chars.get(at) == Some(&'.') {
            at += 1;
            Some(if chars.get(at) == Some(&'*') { at += 1; star(args, &mut ai)?.unsigned_abs() as usize }
                else { number(&chars, &mut at)? })
        } else { None };
        while matches!(chars.get(at), Some('l' | 'h')) { at += 1; }
        let Some(&kind) = chars.get(at) else { break; }; at += 1;
        if kind == 'n' { continue; }
        let value = argument(args, &mut ai);
        let numeric = "diuoxXpfFeEgG".contains(kind);
        let mut prefix = String::new();
        let mut text = match kind {
            'd' | 'i' | 'u' | 'o' | 'x' | 'X' | 'p' => {
                let signed = kind == 'd' || kind == 'i';
                let n = value.int();
                if signed {
                    if n < 0 { prefix.push('-'); } else if flags.plus { prefix.push('+'); } else if flags.space { prefix.push(' '); }
                }
                let n = if signed { n.unsigned_abs() } else { n as u64 };
                let mut digits = match kind { 'o' => format!("{:o}", n), 'x' => format!("{:x}", n),
                    'X' | 'p' => format!("{:X}", n), _ => n.to_string() };
                if let Some(p) = precision { if p > digits.len() { digits = "0".repeat(p - digits.len()) + &digits; } }
                if flags.alternate && n != 0 {
                    match kind { 'x' => prefix.push_str("0x"), 'X' | 'p' => prefix.push_str("0X"),
                        'o' if !digits.starts_with('0') => prefix.push('0'), _ => {} }
                }
                if flags.comma && "diu".contains(kind) { digits = grouped(&digits); }
                digits
            }
            'f' | 'F' | 'e' | 'E' | 'g' | 'G' => {
                let (mut text, negative) = float(value.float(), kind, precision, &flags);
                if negative { prefix.push('-'); } else if flags.plus { prefix.push('+'); } else if flags.space { prefix.push(' '); }
                if flags.comma && value.float().is_finite() { text = grouped(&text); }
                text
            }
            's' | 'z' => truncate(&value.text(), precision, flags.chars),
            'q' | 'Q' | 'w' => quoted(&value, kind, precision, &flags),
            'c' => value.text().chars().next().unwrap_or('\0').to_string().repeat(precision.unwrap_or(1).max(1)),
            _ => break,
        };
        let length = prefix.len() + if flags.chars { text.chars().count() } else { text.len() };
        let padding = width.saturating_sub(length);
        if out.len().saturating_add(prefix.len()).saturating_add(text.len()).saturating_add(padding) > MAX_OUTPUT {
            return Err("string or blob too big".into());
        }
        if !flags.left && flags.zero && numeric && !text.contains("Inf") && text != "9.0e+999" && text != "null" {
            prefix.push_str(&"0".repeat(padding));
        } else if flags.left { text.push_str(&" ".repeat(padding)); }
        else { out.push_str(&" ".repeat(padding)); }
        out.push_str(&prefix); out.push_str(&text);
    }
    if out.len() > MAX_OUTPUT { Err("string or blob too big".into()) } else { Ok(out) }
}
