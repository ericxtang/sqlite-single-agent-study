//! SQLite 3 page and record codec, implemented from /docs/fileformat.txt.
//! Commits use a complete new image and atomic rename; pages have no freeblocks.
use crate::{ast::*,db::{Connection,State,Table,Row},parser::{Res,Parser,colname},query::{Ctx,Ctes},value::{Val,cmp}};
use std::cmp::Ordering;
const CORRUPT:&str="database disk image is malformed";
fn put16(b:&mut[u8],p:usize,v:usize){b[p..p+2].copy_from_slice(&(v as u16).to_be_bytes())}
fn put32(b:&mut[u8],p:usize,v:u32){b[p..p+4].copy_from_slice(&v.to_be_bytes())}
fn get16(b:&[u8],p:usize)->Res<usize>{Ok(u16::from_be_bytes(b.get(p..p+2).ok_or(CORRUPT)?.try_into().unwrap()) as usize)}
fn get32(b:&[u8],p:usize)->Res<u32>{Ok(u32::from_be_bytes(b.get(p..p+4).ok_or(CORRUPT)?.try_into().unwrap()))}
pub fn varint(mut n:u64)->Vec<u8>{if n>0x00ff_ffff_ffff_ffff{let mut a=vec![0;9];a[8]=n as u8;n>>=8;for i in (0..8).rev(){a[i]=(n as u8&127)|128;n>>=7}a}else{let mut a=vec![(n&127) as u8];n>>=7;while n>0{a.push(((n&127) as u8)|128);n>>=7}a.reverse();a}}
pub fn read_varint(b:&[u8],p:&mut usize)->Res<u64>{let mut v=0;for i in 0..9{let c=*b.get(*p).ok_or(CORRUPT)?;*p+=1;if i==8{return Ok((v<<8)|c as u64)}v=(v<<7)|(c&127) as u64;if c<128{return Ok(v)}}Err(CORRUPT.into())}
pub fn record(row:&[Val],enc:u32)->Vec<u8>{let mut serial=vec![];let mut body=vec![];for v in row{let ty=match v{Val::Null=>0,Val::Int(0)=>8,Val::Int(1)=>9,Val::Int(i)=>{let sz=if (-128..=127).contains(i){1}else if (-32768..=32767).contains(i){2}else if (-8388608..=8388607).contains(i){3}else if (i32::MIN as i64..=i32::MAX as i64).contains(i){4}else if (-140737488355328..=140737488355327).contains(i){6}else{8};body.extend(&i.to_be_bytes()[8-sz..]);match sz{1=>1,2=>2,3=>3,4=>4,6=>5,_=>6}},Val::Real(f)=>{body.extend(f.to_be_bytes());7},Val::Text(s)|Val::Json(s)=>{let bytes=text_bytes(s,enc);let ty=13+bytes.len() as u64*2;body.extend(bytes);ty},Val::Blob(b)=>{body.extend(b);12+b.len() as u64*2}};serial.extend(varint(ty))}let mut len=serial.len()+1;loop{let n=serial.len()+varint(len as u64).len();if n==len{break}len=n}let mut out=varint(len as u64);out.extend(serial);out.extend(body);out}
pub fn decode_record(b:&[u8],enc:u32)->Res<Vec<Val>>{let mut p=0;let h=read_varint(b,&mut p)? as usize;if h>b.len()||h<p{return Err(CORRUPT.into())}let mut serial=vec![];while p<h{serial.push(read_varint(b,&mut p)?)}if p!=h{return Err(CORRUPT.into())}let mut out=vec![];for s in serial{let len=match s{0|8|9=>0,1=>1,2=>2,3=>3,4=>4,5=>6,6|7=>8,10|11=>return Err(CORRUPT.into()),s=>(s as usize-12)/2};let bytes=b.get(p..p.checked_add(len).ok_or(CORRUPT)?).ok_or(CORRUPT)?;p+=len;out.push(match s{0=>Val::Null,8=>Val::Int(0),9=>Val::Int(1),1..=6=>{let mut a=if bytes[0]&128!=0{[255;8]}else{[0;8]};a[8-len..].copy_from_slice(bytes);Val::Int(i64::from_be_bytes(a))},7=>Val::real(f64::from_be_bytes(bytes.try_into().unwrap())),s if s%2==0=>Val::Blob(bytes.to_vec()),_=>Val::Text(if enc==1{String::from_utf8_lossy(bytes).into_owned()}else{if len%2!=0{return Err(CORRUPT.into())}let u=bytes.chunks(2).map(|p|if enc==2{u16::from_le_bytes([p[0],p[1]])}else{u16::from_be_bytes([p[0],p[1]])}).collect::<Vec<_>>();String::from_utf16_lossy(&u)})})}Ok(out)}
fn local_size(payload:usize,u:usize,table:bool)->usize{let x=if table{u-35}else{(u-12)*64/255-23};if payload<=x{return payload}let m=(u-12)*32/255-23;let k=m+(payload-m)%(u-4);if k<=x{k}else{m}}
struct Writer{ps:usize,pages:Vec<Vec<u8>>,used:Vec<bool>}
impl Writer{
 fn new(ps:usize,maxroot:usize)->Self{Self{ps,pages:vec![vec![0;ps];maxroot],used:vec![false;maxroot]}}
 fn alloc(&mut self)->u32{self.pages.push(vec![0;self.ps]);self.used.push(true);self.pages.len() as u32}
 fn cell(&mut self,payload:&[u8],rowid:Option<i64>)->Vec<u8>{let n=local_size(payload.len(),self.ps,rowid.is_some());let mut cell=varint(payload.len() as u64);if let Some(r)=rowid{cell.extend(varint(r as u64))}cell.extend(&payload[..n]);if n<payload.len(){let mut first=0;let mut prev=0;for chunk in payload[n..].chunks(self.ps-4){let id=self.alloc();if first==0{first=id}if prev!=0{put32(&mut self.pages[prev as usize-1],0,id)}self.pages[id as usize-1][4..4+chunk.len()].copy_from_slice(chunk);prev=id;}cell.extend(first.to_be_bytes());}cell}
 fn page(&mut self,id:u32,kind:u8,cells:&[Vec<u8>],right:u32)->Res<()>{let head=if id==1{100}else{0};let hs=if kind==2||kind==5{12}else{8};let need=head+hs+cells.iter().map(|c|c.len()+2).sum::<usize>();if need>self.ps{return Err("page packing overflow".into())}let b=&mut self.pages[id as usize-1];b.fill(0);b[head]=kind;put16(b,head+3,cells.len());if hs==12{put32(b,head+8,right)}let mut p=self.ps;for(i,c)in cells.iter().enumerate(){p-=c.len();b[p..p+c.len()].copy_from_slice(c);put16(b,head+hs+i*2,p)}put16(b,head+5,p);self.used[id as usize-1]=true;Ok(())}
 fn table(&mut self,root:u32,rows:&[(i64,Vec<u8>)])->Res<()>{let mut cells=vec![];for(id,r)in rows{cells.push((*id,self.cell(r,Some(*id))))}let total=cells.iter().map(|(_,c)|c.len()+2).sum::<usize>();if total+8+if root==1{100}else{0}<=self.ps{return self.page(root,13,&cells.into_iter().map(|(_,c)|c).collect::<Vec<_>>(),0)}let mut children=vec![];let mut chunk=vec![];let mut size=8;let mut max=0;for(id,c)in cells{if size+c.len()+2>self.ps&&!chunk.is_empty(){let p=self.alloc();self.page(p,13,&chunk,0)?;children.push((p,max));chunk.clear();size=8;}max=id;size+=c.len()+2;chunk.push(c)}if !chunk.is_empty(){let p=self.alloc();self.page(p,13,&chunk,0)?;children.push((p,max))}
 loop{let mut cells=vec![];for (p,key)in children.iter().take(children.len()-1){let mut cell=p.to_be_bytes().to_vec();cell.extend(varint(*key as u64));cells.push(cell)}if cells.iter().map(|c|c.len()+2).sum::<usize>()+12+if root==1{100}else{0}<=self.ps{return self.page(root,5,&cells,children.last().unwrap().0)}let fanout=(self.ps-12)/15+1;let groups=children.len().div_ceil(fanout);let base=children.len()/groups;let extra=children.len()%groups;let mut begin=0;let mut next=vec![];for group in 0..groups{let end=begin+base+usize::from(group<extra);let chunk=&children[begin..end];begin=end;let p=self.alloc();let mut cs=vec![];for (id,k)in chunk.iter().take(chunk.len()-1){let mut c=id.to_be_bytes().to_vec();c.extend(varint(*k as u64));cs.push(c)}self.page(p,5,&cs,chunk.last().unwrap().0)?;next.push((p,chunk.last().unwrap().1))}children=next;}}
 // Bulk-load an index by promoting separators out of leaf pages. All children have equal depth.
 fn index(&mut self,root:u32,records:&[Vec<u8>])->Res<()>{let mut cells=vec![];for r in records{cells.push(self.cell(r,None))}let mut leaves:Vec<Vec<Vec<u8>>>=vec![];let mut separators:Vec<Vec<u8>>=vec![];let mut current=vec![];let mut size=8;let mut iter=cells.into_iter().peekable();while let Some(c)=iter.next(){if size+c.len()+2>self.ps&&!current.is_empty(){leaves.push(current);current=vec![];size=8;separators.push(c);}else{size+=c.len()+2;current.push(c)}}if current.is_empty()&&!separators.is_empty(){current.push(separators.pop().unwrap());let previous=leaves.last_mut().unwrap();let separator=previous.pop().unwrap();separators.push(separator)}leaves.push(current);if leaves.len()==1{return self.page(root,10,&leaves.remove(0),0)}let mut children=vec![];for leaf in leaves{let p=self.alloc();self.page(p,10,&leaf,0)?;children.push(p)}
 loop{let full=12+separators.iter().map(|c|c.len()+6).sum::<usize>();if full<=self.ps{let cs=separators.iter().zip(&children).map(|(c,p)|{let mut out=p.to_be_bytes().to_vec();out.extend(c);out}).collect::<Vec<_>>();return self.page(root,2,&cs,*children.last().unwrap())}let max_cell=separators.iter().map(|c|c.len()+6).max().unwrap_or(1);let capacity=(self.ps-12)/max_cell+1;let groups=children.len().div_ceil(capacity);let base=children.len()/groups;let extra=children.len()%groups;let mut next_children=vec![];let mut next_sep=vec![];let mut begin=0;for group in 0..groups{let count=base+usize::from(group<extra);let end=begin+count;let p=self.alloc();let cells=(begin..end-1).map(|j|{let mut c=children[j].to_be_bytes().to_vec();c.extend(&separators[j]);c}).collect::<Vec<_>>();self.page(p,2,&cells,children[end-1])?;next_children.push(p);if end<children.len(){next_sep.push(separators[end-1].clone())}begin=end;}children=next_children;separators=next_sep;}}
 fn finish(mut self,state:&State,change:u32,wal:bool,encoding:u32)->Vec<u8>{let free=self.used.iter().enumerate().filter(|(_,v)|!**v).map(|(i,_)|i as u32+1).collect::<Vec<_>>();let max=(self.ps-8)/4;let chunks=free.chunks(max+1).collect::<Vec<_>>();for(i,chunk)in chunks.iter().enumerate(){let p=chunk[0];let b=&mut self.pages[p as usize-1];put32(b,0,chunks.get(i+1).map_or(0,|c|c[0]));put32(b,4,(chunk.len()-1) as u32);for(j,v)in chunk[1..].iter().enumerate(){put32(b,8+j*4,*v)}}let count=self.pages.len() as u32;let b=&mut self.pages[0];b[..16].copy_from_slice(b"SQLite format 3\0");put16(b,16,if self.ps==65536{1}else{self.ps});b[18]=if wal{2}else{1};b[19]=b[18];b[21]=64;b[22]=32;b[23]=32;put32(b,24,change);put32(b,28,count);put32(b,32,free.first().copied().unwrap_or(0));put32(b,36,free.len() as u32);put32(b,40,state.schema_version as u32);put32(b,44,4);put32(b,56,encoding);put32(b,60,state.user_version as u32);put32(b,68,state.application_id as u32);put32(b,92,change);put32(b,96,3053004);self.pages.concat()}
}
fn storage_order(t:&Table)->Vec<usize>{let mut ord=if t.without{t.primary_key().into_iter().map(|(i,_,_)|i).collect()}else{vec![]};for(i,c)in t.cols.iter().enumerate(){if (c.generated.is_none()||c.stored)&&(!t.without||c.pk==0){ord.push(i)}}ord}
pub fn encode(conn:&Connection)->Res<Vec<u8>>{let enc=conn.encoding();let s=&conn.state;let tables=s.tables.values().filter(|t|!t.temp&&!t.name.contains('.')).collect::<Vec<_>>();let indexes=s.indexes.values().filter(|i|!i.table.contains('.')&&s.tables.get(&i.table.to_ascii_lowercase()).map_or(false,|t|!t.temp)).collect::<Vec<_>>();let maxroot=tables.iter().map(|t|t.root).chain(indexes.iter().map(|i|i.root)).max().unwrap_or(1) as usize;let ps=conn.pragmas.get("page_size").map_or(4096,|v|v.int()) as usize;let ps=if (512..=65536).contains(&ps)&&ps.is_power_of_two(){ps}else{4096};let mut w=Writer::new(ps,maxroot);let mut schema=vec![];for t in &tables{let ord=storage_order(t);let records=t.rows.iter().map(|r|{let vals=ord.iter().map(|i|if t.ipk()==Some(*i){Val::Null}else{r.vals[*i].clone()}).collect::<Vec<_>>();(r.id,record(&vals,enc))}).collect::<Vec<_>>();if t.without{w.index(t.root as u32,&records.into_iter().map(|r|r.1).collect::<Vec<_>>())?}else{w.table(t.root as u32,&records)?}schema.push(vec![Val::Text("table".into()),Val::Text(t.name.clone()),Val::Text(t.name.clone()),Val::Int(t.root),Val::Text(t.sql.clone())]);}
 for i in indexes{let t=conn.table_key(&i.table)?;let layout=index_layout(conn,i,t);let records=index_records(conn,i,t,&layout)?;w.index(i.root as u32,&records.iter().map(|r|record(r,enc)).collect::<Vec<_>>())?;schema.push(vec![Val::Text("index".into()),Val::Text(i.name.clone()),Val::Text(i.table.clone()),Val::Int(i.root),i.sql.clone().map(Val::Text).unwrap_or(Val::Null)]);}
 for v in s.views.values().filter(|v|!v.temp&&!v.name.contains('.')){schema.push(vec![Val::Text("view".into()),Val::Text(v.name.clone()),Val::Text(v.name.clone()),Val::Int(0),Val::Text(v.sql.clone())]);}
 for t in s.triggers.values().filter(|t|!t.temp&&!t.name.contains('.')){schema.push(vec![Val::Text("trigger".into()),Val::Text(t.name.clone()),Val::Text(t.table.clone()),Val::Int(0),Val::Text(t.sql.clone())]);}let rows=schema.iter().enumerate().map(|(i,r)|(i as i64+1,record(r,enc))).collect::<Vec<_>>();w.table(1,&rows)?;let change=conn.path.as_ref().and_then(|p|std::fs::read(p).ok()).and_then(|b|get32(&b,24).ok()).unwrap_or(0).wrapping_add(1);let image=w.finish(s,change,conn.wal(),enc);if (image.len()/ps) as i64>conn.pragmas.get("max_page_count").map_or(crate::pagelimit::MAX_PAGES,Val::int){return Err("database or disk is full".into())}Ok(image)}
struct Reader<'a>{b:&'a[u8],ps:usize,u:usize,enc:u32}
impl<'a>Reader<'a>{fn new(b:&'a[u8])->Res<Self>{if b.get(..16)!=Some(b"SQLite format 3\0"){return Err("file is not a database".into())}let p=get16(b,16)?;let ps=if p==1{65536}else{p};if !(512..=65536).contains(&ps)||!ps.is_power_of_two()||b.len()%ps!=0{return Err(CORRUPT.into())}let u=ps-b[20] as usize;if u<480{return Err(CORRUPT.into())}if ![1,2].contains(&b[19]){return Err("unsupported database read version".into())}if b[21..24]!=[64,32,32]{return Err(CORRUPT.into())}let format=get32(b,44)?;if format>4{return Err("unsupported schema format".into())}let mut enc=get32(b,56)?;if enc==0&&format==0{enc=1}if !(1..=3).contains(&enc){return Err("unsupported database encoding".into())}let count=get32(b,28)? as usize;let b=if count>0&&get32(b,24)?==get32(b,92)?{b.get(..count.checked_mul(ps).ok_or(CORRUPT)?).ok_or(CORRUPT)?}else{b};Ok(Self{b,ps,u,enc})}
 fn page(&self,id:u32)->Res<&[u8]>{if id==0{return Err(CORRUPT.into())}self.b.get((id as usize-1)*self.ps..id as usize*self.ps).ok_or(CORRUPT.into())}
 fn payload(&self,page:&[u8],p:&mut usize,n:usize,table:bool,seen:&mut std::collections::HashSet<u32>)->Res<Vec<u8>>{if n>100_000_000{return Err("string or blob too big".into())}let loc=local_size(n,self.u,table);let mut out=page.get(..self.u).ok_or(CORRUPT)?.get(*p..p.checked_add(loc).ok_or(CORRUPT)?).ok_or(CORRUPT)?.to_vec();*p+=loc;if n>loc{let mut id=get32(page,*p)?;*p+=4;while out.len()<n{if !seen.insert(id){return Err(CORRUPT.into())}let b=self.page(id)?;let count=(n-out.len()).min(self.u-4);out.extend(&b[4..4+count]);id=get32(b,0)?;}if id!=0{return Err(CORRUPT.into())}}Ok(out)}
 fn tree(&self,root:u32)->Res<Vec<(i64,Vec<Val>)>>{let mut seen=std::collections::HashSet::new();let mut out=vec![];let table=matches!(self.page(root)?[if root==1{100}else{0}],5|13);self.walk(root,0,table,&mut seen,&mut out)?;Ok(out)}
 fn walk(&self,id:u32,depth:usize,table:bool,seen:&mut std::collections::HashSet<u32>,out:&mut Vec<(i64,Vec<Val>)>)->Res<usize>{
  if depth>100||!seen.insert(id){return Err(CORRUPT.into())}
  let b=self.page(id)?;let head=if id==1{100}else{0};let kind=b[head];let inner=kind==2||kind==5;
  if ![2,5,10,13].contains(&kind)||matches!(kind,5|13)!=table{return Err(CORRUPT.into())}
  let count=get16(b,head+3)?;let hs=if inner{12}else{8};
  if head+hs+count*2>self.u||b[head+7]>60{return Err(CORRUPT.into())}
  // The schema root can have a single child because its file header takes
  // space that is available to every other page. Other interior pages need keys.
  if count==0&&(depth>0||(inner&&id!=1)){return Err(CORRUPT.into())}
  let content=get16(b,head+5)?;let content=if content==0{65536}else{content};
  if content<head+hs+count*2||content>self.u{return Err(CORRUPT.into())}
  let mut ranges=vec![];let first_free=get16(b,head+1)?;let mut free=first_free;
  while free!=0{
   if free<content||free+4>self.u{return Err(CORRUPT.into())}
   let next=get16(b,free)?;let len=get16(b,free+2)?;
   if len<4||free+len>self.u||(next!=0&&next<free+len){return Err(CORRUPT.into())}
   ranges.push((free,free+len));free=next;
  }
  let mut first_cell=self.u;let mut child_height=None;
  for i in 0..count{
   let mut p=get16(b,head+hs+2*i)?;let start=p;first_cell=first_cell.min(start);
   if start<content||p<head+hs+count*2||p>=self.u{return Err(CORRUPT.into())}
   if inner{
    let child=get32(b,p)?;p+=4;let height=self.walk(child,depth+1,table,seen,out)?;
    if child_height.map_or(false,|h|h!=height){return Err(CORRUPT.into())}child_height=Some(height);
   }
   if kind==5{read_varint(b,&mut p)?;if p>self.u{return Err(CORRUPT.into())}ranges.push((start,p));continue}
   let n=read_varint(b,&mut p)? as usize;let rowid=if kind==13{read_varint(b,&mut p)? as i64}else{0};
   let bytes=self.payload(b,&mut p,n,kind==13,seen)?;
   if p>self.u{return Err(CORRUPT.into())}ranges.push((start,p));out.push((rowid,decode_record(&bytes,self.enc)?));
  }
  if first_free!=0&&first_cell>=first_free{return Err(CORRUPT.into())}
  ranges.sort_unstable();let mut end=content;let mut fragments=0;
  for(start,stop)in ranges{if start<end||start-end>3{return Err(CORRUPT.into())}fragments+=start-end;end=stop;}
  if self.u-end>3{return Err(CORRUPT.into())}fragments+=self.u-end;
  if fragments!=b[head+7] as usize{return Err(CORRUPT.into())}
  if count==0&&content!=self.u{return Err(CORRUPT.into())}
  if inner{
   let height=self.walk(get32(b,head+8)?,depth+1,table,seen,out)?;
   if child_height.map_or(false,|h|h!=height){return Err(CORRUPT.into())}Ok(height+1)
  }else{Ok(1)}
 }
}

impl Reader<'_>{
 fn validate_layout(&self,schema:&[(i64,Vec<Val>)])->Res<()>{
  let count=self.b.len()/self.ps;let mut used=std::collections::HashSet::new();
  if get32(self.b,52)?!=0{let step=self.u/5+1;let mut page=2;while page<=count{used.insert(page as u32);page+=step;}}
  let mut roots=vec![1];for(_,row)in schema{if row.len()!=5{return Err(CORRUPT.into())}let root=row[3].int();if root<0||root as usize>count{return Err(CORRUPT.into())}if root>0{roots.push(root as u32)}}
  for root in roots{let table=matches!(self.page(root)?[if root==1{100}else{0}],5|13);let mut rows=vec![];self.walk(root,0,table,&mut used,&mut rows)?;}
  let mut free=get32(self.b,32)?;let mut free_count=0;while free!=0{if !used.insert(free){return Err(CORRUPT.into())}free_count+=1;let page=self.page(free)?;let n=get32(page,4)? as usize;if n>(self.u-8)/4{return Err(CORRUPT.into())}for i in 0..n{let id=get32(page,8+i*4)?;if id==0||id as usize>count||!used.insert(id){return Err(CORRUPT.into())}free_count+=1;}free=get32(page,0)?;}
  if free_count!=get32(self.b,36)?||used.len()!=count{return Err(CORRUPT.into())}Ok(())
 }
}
pub fn decode(b:&[u8])->Res<State>{let reader=Reader::new(b)?;let schema=reader.tree(1)?;if !schema.is_empty()&&get32(b,44)?==0{return Err(CORRUPT.into())}reader.validate_layout(&schema)?;let mut conn=Connection::open(":memory:")?;conn.pragmas.insert("encoding".into(),Val::Text(encoding_name(reader.enc).into()));let ctes=Ctes::new();for(_,r)in &schema{if r.len()!=5{return Err(CORRUPT.into())}if r[0].text()=="table"&&r[1].text()=="sqlite_sequence"{conn.ensure_sequence();}else if r[0].text()=="table"&&r[1].text()=="sqlite_stat1"{conn.ensure_stat1("main");}else if r[0].text()=="table"{let stmt=Parser::parse(&r[4].text())?;if !matches!(stmt,Stmt::CreateTable(_)){return Err(CORRUPT.into())}conn.run(&stmt,&r[4].text(),&ctes)?;conn.state.tables.get_mut(&r[1].text().to_ascii_lowercase()).ok_or(CORRUPT)?.root=r[3].int();}}
 for(_,r)in &schema{let kind=r[0].text();if kind=="table"{if let Some(t)=conn.state.tables.get_mut(&r[1].text().to_ascii_lowercase()){t.root=r[3].int();}}if kind=="index"{if !r[4].null(){conn.run(&Parser::parse(&r[4].text())?,&r[4].text(),&ctes)?;}if let Some(i)=conn.state.indexes.get_mut(&r[1].text().to_ascii_lowercase()){i.root=r[3].int()}}else if kind=="view"||kind=="trigger"{conn.run(&Parser::parse(&r[4].text())?,&r[4].text(),&ctes)?;}}
 for(_,r)in &schema{if r[0].text()!="table"{continue}let key=r[1].text().to_ascii_lowercase();let mut t=conn.state.tables.get(&key).ok_or(CORRUPT)?.clone();let ord=storage_order(&t);for(i,(id,vals))in reader.tree(t.root as u32)?.into_iter().enumerate(){let mut row=Row{birth:crate::db::row_birth(),id:if t.without{i as i64+1}else{id},vals:vec![Val::Null;t.cols.len()]};for(j,k)in ord.iter().enumerate(){row.vals[*k]=if let Some(v)=vals.get(j){v.clone()}else if let Some(e)=&t.cols[*k].default{conn.eval(e,&Ctx::empty(&ctes))?}else{Val::Null};}if let Some(k)=t.ipk(){row.vals[k]=Val::Int(id)}conn.affinities(&t,&mut row,&ctes)?;t.rows.push(row)}conn.state.tables.insert(key,t);}
 conn.state.schema_version=get32(b,40)? as i64;conn.state.user_version=get32(b,60)? as i32 as i64;conn.state.application_id=get32(b,68)? as i32 as i64;Ok(conn.state)}
pub fn page_size(b:&[u8])->usize{get16(b,16).ok().map(|p|if p==1{65536}else{p}).unwrap_or(4096)}
#[cfg(test)]mod tests{use super::*;#[test]fn varints_and_record_types(){for n in [0,1,127,128,16383,16384,1<<32,1<<56,u64::MAX]{let b=varint(n);let mut p=0;assert_eq!(read_varint(&b,&mut p).unwrap(),n);assert_eq!(p,b.len());}let row=vec![Val::Null,Val::Int(0),Val::Int(1),Val::Int(-128),Val::Int(128),Val::Int(-8388608),Val::Int(i64::MIN),Val::Real(1.25),Val::Text("a\0🙂".into()),Val::Blob(vec![0,255])];for enc in [1,2,3]{assert_eq!(decode_record(&record(&row,enc),enc).unwrap(),row);}}}

pub fn statistics(b:&[u8])->Res<(i64,i64)>{let reader=Reader::new(b)?;Ok(((reader.b.len()/reader.ps) as i64,get32(b,36)? as i64))}

pub fn encoding_name(enc:u32)->&'static str{match enc{2=>"UTF-16le",3=>"UTF-16be",_=>"UTF-8"}}

pub fn text_bytes(s:&str,enc:u32)->Vec<u8>{if enc==1{s.as_bytes().to_vec()}else{s.encode_utf16().flat_map(|u|if enc==2{u.to_le_bytes()}else{u.to_be_bytes()}).collect()}}

struct IndexLayout{suffix:Vec<usize>,colls:Vec<String>,descending:Vec<bool>}
fn index_layout(conn:&Connection,i:&crate::db::Index,t:&Table)->IndexLayout{
 let fields=t.fields(None);let nil=vec![Val::Null;fields.len()];let cs=Ctes::new();let ctx=Ctx{fields:&fields,row:&nil,..Ctx::empty(&cs)};
 let mut layout=IndexLayout{suffix:vec![],colls:i.cols.iter().map(|e|conn.meta(e,&ctx).1).collect(),descending:i.cols.iter().map(|e|matches!(e,Expr::Unary(n,_)if n=="DESC")).collect()};
 if t.without{for(k,coll,desc)in t.primary_key(){if !i.cols.iter().enumerate().any(|(j,e)|colname(e).map_or(false,|n|n.eq_ignore_ascii_case(&t.cols[k].name))&&layout.colls[j].eq_ignore_ascii_case(&coll)){layout.suffix.push(k);layout.colls.push(coll);layout.descending.push(desc)}}}else{layout.colls.push("BINARY".into());layout.descending.push(false)}layout
}
fn key_compare(a:&[Val],b:&[Val],colls:&[String],descending:&[bool])->Ordering{for(k,(x,y))in a.iter().zip(b).enumerate(){let c=cmp(x,y,colls.get(k).map_or("BINARY",String::as_str));let c=if descending.get(k)==Some(&true){c.reverse()}else{c};if c!=Ordering::Equal{return c}}a.len().cmp(&b.len())}
fn index_records(conn:&Connection,i:&crate::db::Index,t:&Table,layout:&IndexLayout)->Res<Vec<Vec<Val>>>{
 let fields=t.fields(None);let cs=Ctes::new();let mut records=vec![];
 for r in &t.rows{let vals=t.values(r);let ctx=Ctx{fields:&fields,row:&vals,..Ctx::empty(&cs)};if let Some(e)=&i.wh{if conn.eval_schema(e,&ctx)?.truth()!=Some(true){continue}}let mut key=i.cols.iter().map(|e|conn.eval_schema(e,&ctx)).collect::<Res<Vec<_>>>()?;if t.without{key.extend(layout.suffix.iter().map(|k|r.vals[*k].clone()))}else{key.push(Val::Int(r.id))}records.push(key)}
 records.sort_by(|a,b|key_compare(a,b,&layout.colls,&layout.descending));Ok(records)
}
pub fn index_integrity(conn:&Connection,bytes:&[u8],selected:Option<&str>,full:bool)->Res<Vec<String>>{
 let reader=Reader::new(bytes)?;let schema=reader.tree(1)?;reader.validate_layout(&schema)?;let mut errors=vec![];if selected.map_or(true,|n|n.eq_ignore_ascii_case("sqlite_schema")||n.eq_ignore_ascii_case("sqlite_master")){if !reader.table_separators(1)?.1||schema.windows(2).any(|r|r[0].0>=r[1].0){errors.push("keys out of order in sqlite_schema".into())}}
 let selected=|table:&str|selected.map_or(true,|n|n.eq_ignore_ascii_case(table));
 for t in conn.state.tables.values().filter(|t|!t.name.contains('.')&&!t.temp&&selected(&t.name)){
  let valid=if t.without{let key=t.primary_key();let colls=key.iter().map(|(_,c,_)|c.clone()).collect::<Vec<_>>();let descending=key.iter().map(|(_,_,d)|*d).collect::<Vec<_>>();let records=t.rows.iter().map(|r|key.iter().map(|(i,_,_)|r.vals[*i].clone()).collect::<Vec<_>>()).collect::<Vec<_>>();records.windows(2).all(|r|key_compare(&r[0],&r[1],&colls,&descending)==Ordering::Less)}else{t.rows.windows(2).all(|r|r[0].id<r[1].id)};
  if !valid{errors.push(format!("row keys out of order in table {}",t.name))}if !t.without&&!reader.table_separators(t.root as u32)?.1{errors.push(format!("interior keys out of range in table {}",t.name))}
 }
 for i in conn.state.indexes.values().filter(|i|!i.table.contains('.')&&selected(&i.table)){
  let t=conn.table_key(&i.table)?;let layout=index_layout(conn,i,t);let actual=reader.tree(i.root as u32)?.into_iter().map(|(_,v)|v).collect::<Vec<_>>();
  if actual.iter().any(|r|r.len()!=layout.colls.len()){errors.push(format!("invalid record width in index {}",i.name));continue}
  if actual.windows(2).any(|r|key_compare(&r[0],&r[1],&layout.colls,&layout.descending)!=Ordering::Less){errors.push(format!("keys out of order in index {}",i.name))}
  if full{let expected=index_records(conn,i,t,&layout)?;if expected.len()!=actual.len(){errors.push(format!("wrong number of entries in index {}",i.name))}else if expected.iter().zip(&actual).any(|(a,b)|key_compare(a,b,&layout.colls,&layout.descending)!=Ordering::Equal){errors.push(format!("entry in index {} does not match table {}",i.name,t.name))}}
 }Ok(errors)
}

pub fn index_uses_collation(conn:&Connection,i:&crate::db::Index,t:&Table,coll:&str)->bool{index_layout(conn,i,t).colls.iter().any(|c|c.eq_ignore_ascii_case(coll))}
pub fn validate_index(conn:&Connection,i:&crate::db::Index,t:&Table)->Res<()>{let layout=index_layout(conn,i,t);let records=index_records(conn,i,t,&layout)?;let n=i.cols.len();if i.unique&&records.windows(2).any(|rows|!rows[0][..n].iter().any(Val::null)&&key_compare(&rows[0][..n],&rows[1][..n],&layout.colls,&layout.descending)==Ordering::Equal){return Err(format!("UNIQUE constraint failed: index '{}'",i.name))}Ok(())}

// Stat1 counts declared key prefixes, excluding auxiliary rowid/primary-key
// suffixes. NULL values form distinct selectivity samples, including unique keys.
fn prefix_statistics(records: &[Vec<Val>], colls: &[String], limit: usize, unique: bool) -> String {
 let n=records.len();let mut sampled=records.iter().take(if limit==0{n}else{limit}).collect::<Vec<_>>();
 if limit>0&&limit<n&&!colls.is_empty()&&sampled.iter().all(|r|cmp(&r[0],&records[0][0],&colls[0])==Ordering::Equal){
  // Equal leftmost keys occupy a contiguous range. Skip it with binary search.
  let end=records.partition_point(|r|cmp(&r[0],&records[0][0],&colls[0])==Ordering::Equal);
  sampled.extend(records[end..].iter().take(limit));
 }
 let mut counts=vec![1usize;colls.len()];
 for pair in sampled.windows(2){let mut different=false;for(k,coll)in colls.iter().enumerate(){different|=pair[0][k].null()||pair[1][k].null()||cmp(&pair[0][k],&pair[1][k],coll)!=Ordering::Equal;if different{counts[k]+=1}}}
 let mut result=n.to_string();for (k,count) in counts.into_iter().enumerate(){let average=if unique&&k+1==colls.len(){1}else if count==1{n}else{(sampled.len()+count-1)/count};result.push(' ');result.push_str(&average.to_string());}result
}
pub(crate) fn index_statistics(conn:&Connection,i:&crate::db::Index,t:&Table)->Res<Option<String>>{
 let layout=index_layout(conn,i,t);let records=index_records(conn,i,t,&layout)?;
 Ok(if records.is_empty(){None}else{Some(prefix_statistics(&records,&layout.colls[..i.cols.len()],conn.analysis_limit(),i.unique))})
}
pub(crate) fn primary_statistics(t:&Table,limit:usize)->String{
 let pk=t.primary_key();let colls=pk.iter().map(|(_,c,_)|c.clone()).collect::<Vec<_>>();
 let records=t.rows.iter().map(|r|pk.iter().map(|(k,_,_)|r.vals[*k].clone()).collect()).collect::<Vec<_>>();prefix_statistics(&records,&colls,limit,true)
}

impl Reader<'_>{
 // Logical table separator checks are reported by integrity_check/quick_check.
 // Structural layout checks during open already established page ownership.
 fn table_separators(&self,id:u32)->Res<(Option<(i64,i64)>,bool)>{
  let b=self.page(id)?;let h=if id==1{100}else{0};let kind=b[h];let count=get16(b,h+3)?;
  let mut bounds:Option<(i64,i64)>=None;let mut valid=true;let mut previous=None;
  for i in 0..count{
   let mut p=get16(b,h+if kind==5{12}else{8}+i*2)?;
   if kind==13{read_varint(b,&mut p)?;let key=read_varint(b,&mut p)? as i64;bounds=Some(bounds.map_or((key,key),|(lo,hi)|(lo.min(key),hi.max(key))));}
   else if kind==5{
    let child=get32(b,p)?;p+=4;let key=read_varint(b,&mut p)? as i64;
    let(child_bounds,good)=self.table_separators(child)?;valid&=good;
    if let Some((lo,hi))=child_bounds{valid&=hi<=key&&previous.map_or(true,|p|lo>p&&key>p);bounds=Some(bounds.map_or((lo,hi),|(a,b)|(a.min(lo),b.max(hi))));}else{valid=false}
    previous=Some(key);
   }else{return Err(CORRUPT.into())}
  }
  if kind==5{let(child_bounds,good)=self.table_separators(get32(b,h+8)?)?;valid&=good;
   if let Some((lo,hi))=child_bounds{valid&=previous.map_or(true,|p|lo>p);bounds=Some(bounds.map_or((lo,hi),|(a,b)|(a.min(lo),b.max(hi))));}else{valid=false}
  }Ok((bounds,valid))
 }
}
