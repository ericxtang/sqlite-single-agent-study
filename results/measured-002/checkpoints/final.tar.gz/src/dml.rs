//! Select UPDATE/DELETE targets before applying row mutations and triggers.
use crate::{ast::*, db::{Connection, Row, Table}, parser::Res,
    query::{Ctes, Ctx, Field, integer_limit, sortkeys}, value::Val};
impl Connection {
    pub(crate) fn mutation_candidates(&self, table: &Table, alias: Option<&str>,
        set: Option<&[(Vec<String>, Expr)]>, from: &[Join], wh: &Option<Expr>,
        order: &[Order], limit: &Option<Expr>, offset: &Option<Expr>, ctes: &Ctes)
        -> Res<(Vec<Field>, Vec<(Row, Vec<Val>)>)> {
        let bounds = self.mutation_bounds(limit, offset, ctes)?;
        self.mutation_candidates_bounded(table, alias, set, from, wh, order, bounds, ctes)
    }
    pub(crate) fn mutation_bounds(&self, limit: &Option<Expr>, offset: &Option<Expr>, ctes: &Ctes)
        -> Res<(usize,usize)> {
        let constant = Ctx::empty(ctes);
        let count = limit.as_ref().map(|e| self.eval(e, &constant).and_then(integer_limit))
            .transpose()?.unwrap_or(-1);
        let skip = offset.as_ref().map(|e| self.eval(e, &constant).and_then(integer_limit))
            .transpose()?.unwrap_or(0).max(0) as usize;
        let count = if count < 0 { usize::MAX } else { count as usize };
        Ok((count,skip))
    }
    pub(crate) fn mutation_candidates_bounded(&self, table: &Table, alias: Option<&str>,
        set: Option<&[(Vec<String>, Expr)]>, from: &[Join], wh: &Option<Expr>,
        order: &[Order], bounds: (usize,usize), ctes: &Ctes)
        -> Res<(Vec<Field>, Vec<(Row, Vec<Val>)>)> {
        let (count,skip) = bounds;
        let previous = self.shape_only.get();
        if count == 0 { self.shape_only.set(true); }
        let extra = self.from(from, ctes, None);
        self.shape_only.set(previous);
        let extra = extra?;
        let mut fields = table.fields(alias);
        fields.extend(extra.fields.clone());
        let nil = vec![Val::Null; fields.len()];
        let context = Ctx { fields: &fields, row: &nil, ..Ctx::empty(ctes) };
        if let Some(set) = set {
            for (names, expr) in set {
                for n in names {
                    let i = table.col(n)?;
                    if i < table.cols.len() && table.cols[i].generated.is_some() {
                        return Err(format!("cannot UPDATE generated column {}", n));
                    }
                }
                if crate::query::contains_aggregate_or_window(expr) {
                    return Err("aggregate or window function not allowed here".into());
                }
                if self.validate_row_expr(expr, &context)? != names.len() {
                    return Err("number of columns does not match number of values".into());
                }
            }
        }
        if let Some(e) = wh { self.validate_dml_expr(e, &context)?; }
        for o in order { self.validate_dml_expr(&o.expr, &context)?; }
        if count == 0 { return Ok((fields, vec![])); }
        let colls = order.iter().map(|o| self.meta(&o.expr, &context).1).collect::<Vec<_>>();
        let mut selected = vec![];
        for old in &table.rows {
            if order.is_empty() && selected.len() >= skip.saturating_add(count) { break; }
            for er in &extra.rows {
                let mut values = table.values(old);
                values.extend(er.clone());
                let ctx = Ctx { row: &values, ..context };
                if let Some(e) = wh { if self.eval(e, &ctx)?.truth() != Some(true) { continue; } }
                let keys = order.iter().map(|o| self.eval(&o.expr, &ctx)).collect::<Res<Vec<_>>>()?;
                selected.push((old.clone(), values, keys));
                // UPDATE FROM chooses an arbitrary matching source row per target.
                break;
            }
        }
        selected.sort_by(|a, b| sortkeys(&a.2, &b.2, order, &colls));
        let mut selected = selected.into_iter().skip(skip).take(count).map(|(r,v,_)| (r,v)).collect::<Vec<_>>();
        // ORDER BY determines membership only. Apply the chosen rows in their
        // original table traversal order, independently of the requested sort.
        let positions = table.rows.iter().enumerate().map(|(i,r)| (r.id,i)).collect::<std::collections::HashMap<_,_>>();
        selected.sort_by_key(|(r,_)| positions.get(&r.id).copied().unwrap_or(usize::MAX));
        Ok((fields, selected))
    }
}

impl Connection {
    pub(crate) fn apply_set(&self, table: &Table, old: &Row,
        set: &[(Vec<String>, Expr)], ctx: &Ctx, ctes: &Ctes) -> Res<Row> {
        let columns = set.iter().map(|(names,_)| names.iter().map(|n| table.col(n))
            .collect::<Res<Vec<_>>>()).collect::<Res<Vec<_>>>()?;
        let mut last = std::collections::HashMap::new();
        for (assignment, ids) in columns.iter().enumerate() {
            for (component, id) in ids.iter().enumerate() { last.insert(*id, (assignment,component)); }
        }
        let mut result = old.clone();
        for (assignment, ((names, expr), ids)) in set.iter().zip(&columns).enumerate() {
            let active = ids.iter().enumerate().map(|(component,id)|
                last.get(id) == Some(&(assignment,component))).collect::<Vec<_>>();
            if !active.iter().any(|a| *a) { continue; }
            let values = if let Expr::Tuple(exprs) = expr {
                exprs.iter().enumerate().map(|(i,e)| if active.get(i) == Some(&true) {
                    self.eval(e,ctx)
                } else { Ok(Val::Null) }).collect::<Res<Vec<_>>>()?
            } else { self.eval_vec(expr,ctx)? };
            if values.len() != names.len() { return Err("number of columns does not match number of values".into()); }
            for (component, (id,value)) in ids.iter().zip(values).enumerate() {
                if !active[component] { continue; }
                if *id == table.cols.len() || table.ipk() == Some(*id) { result.id = integer_limit(value.clone())?; }
                if *id < table.cols.len() {
                    if table.cols[*id].generated.is_some() { return Err(format!("cannot UPDATE generated column {}",names[component])); }
                    result.vals[*id] = value;
                }
            }
        }
        if let Some(i) = table.ipk() { result.vals[i] = Val::Int(result.id); }
        self.affinities(table,&mut result,ctes)?;
        Ok(result)
    }
}
