//! REPLACE's implicit deletes obey FK actions and conditional DELETE triggers,
//! while excluding the removed rows themselves from change counters.
use crate::{db::{Connection, Row, Table}, parser::Res, query::{Ctes, Ctx}};
impl Connection {
    pub(crate) fn not_null_constraints(&mut self, t: &Table, row: &mut Row,
        conflict: &str, ctes: &Ctes) -> Res<bool> {
        // Resolve base-column defaults before checking generated columns that
        // depend on them, regardless of their declared column order.
        let mut changed = false;
        for (i, c) in t.cols.iter().enumerate().filter(|(_, c)| c.generated.is_none()) {
            if !c.notnull || !row.vals[i].null() { continue; }
            let action = if conflict.is_empty() { c.nn_conflict.as_str() } else { conflict };
            if action == "REPLACE" {
                if let Some(default) = &c.default {
                    row.vals[i] = self.eval(default, &Ctx::empty(ctes))?;
                    changed = true;
                    if !row.vals[i].null() { continue; }
                }
            }
            return self.violation(if action == "REPLACE" { "ABORT" } else { action },
                format!("NOT NULL constraint failed: {}.{}", t.name, c.name));
        }
        if changed { self.affinities(t, row, ctes)?; }
        for (i, c) in t.cols.iter().enumerate() {
            if c.notnull && row.vals[i].null() {
                let action = if conflict.is_empty() { c.nn_conflict.as_str() } else { conflict };
                return self.violation(if action == "REPLACE" { "ABORT" } else { action },
                    format!("NOT NULL constraint failed: {}.{}", t.name, c.name));
            }
        }
        Ok(true)
    }
    pub(crate) fn replace_rows(&mut self, t: &Table, ids: &[i64], conflict: &str,
        ctes: &Ctes) -> Res<bool> {
        let mut removed = std::collections::HashSet::new();
        for id in ids {
            if !removed.insert(*id) { continue; }
            let Some(old) = self.table_key(&t.name)?.rows.iter().find(|r| r.id == *id).cloned()
                else { continue; };
            let triggers = self.flag("recursive_triggers");
            if triggers && !self.fire(t, "DELETE", "BEFORE", Some(&old), None, &[], conflict, ctes)? {
                return Ok(false);
            }
            if !self.table_key(&t.name)?.rows.iter().any(|r| r.id == old.id) { continue; }
            self.state.tables.get_mut(&t.name.to_ascii_lowercase()).unwrap().rows.retain(|r| r.id != old.id);
            self.foreign_action(t, &old, None, 0)?;
            if triggers && !self.fire(t, "DELETE", "AFTER", Some(&old), None, &[], conflict, ctes)? {
                return Ok(false);
            }
        }
        Ok(true)
    }
}
