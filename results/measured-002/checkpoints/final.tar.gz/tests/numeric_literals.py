"""Numeric token grammar, separators and likelihood constants from SQL docs."""
import json,os,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
assert sql('SELECT 1_234,0xA_B,1_2.3_4e+1_0,.1_2,1.,1.e2')==[['1234','171','123400000000.0','0.12','1.0','100.0']]
assert sql('SELECT 0x7fff_ffff_ffff_ffff,0xffff_ffff_ffff_ffff,-9_223_372_036_854_775_808')==[['9223372036854775807','-1','-9223372036854775808']]
for v in ['1__2','1_','1_.2','1._2','1_e2','1e_2','1e+_2','1.2_e3','0x_1','0x1_','0xA__B','12abc','1e2name','0x1g','1$var','1猫','1e+','0x','1.2.3','0x10000000000000000']:
 sql('SELECT '+v,False)
assert sql('SELECT 1 label,2 "quoted",3 AS three')==[['1','2','3']]
sql('CREATE TABLE _1(x)');sql('INSERT INTO _1 VALUES(5)');assert sql('SELECT x FROM _1')==[['5']]
# Separators belong only to SQL numeric literals, not runtime numeric conversion.
assert sql("SELECT CAST('1_2' AS INTEGER),CAST('1_2' AS REAL),CAST('0x12' AS INTEGER)")==[['1','1.0','0']]
assert sql('SELECT likelihood(42,0.5),likelihood(NULL,1.0),likelihood(7,+.0),likely(9),unlikely(3)')==[['42',None,'7','9','3']]
for probability in ['-0.1','1.1','0','1',"'0.5'",'NULL','0.5+0.0','CAST(0.5 AS REAL)','random()','x']:
 sql('SELECT likelihood(1,'+probability+') FROM _1 WHERE 0',False)
sql('SELECT CASE WHEN 0 THEN likelihood(1,2.0) ELSE 1 END',False)
sql('SELECT likelihood(1)',False)
assert sql('SELECT likelihood(abs(-1),0.0)')==[['1']]
assert sql("SELECT hex(unhex('AB cd:ef', ' :')),unhex('A B',' '),unhex('abc'),unhex(NULL),unhex('AB',NULL)")==[['ABCDEF',None,None,None,None]]
p.terminate();p.wait()
print('PASS: strict numeric tokens/separators, runtime conversion boundaries and likelihood constant validation')
