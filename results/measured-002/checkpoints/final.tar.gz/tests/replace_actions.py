"""REPLACE conflict deletes, FK actions, trigger timing and counters from docs."""
import os,json,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
def total():return int(sql('SELECT total_changes()')[0][0])
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE p(id INTEGER PRIMARY KEY,k UNIQUE)');sql('CREATE TABLE log(phase,id)')
sql("CREATE TRIGGER pd0 BEFORE DELETE ON p BEGIN INSERT INTO log VALUES('before',old.id); END")
sql("CREATE TRIGGER pd1 AFTER DELETE ON p BEGIN INSERT INTO log VALUES('after',old.id); END")
sql("INSERT INTO p VALUES(1,'a')");before=total();sql("INSERT OR REPLACE INTO p VALUES(2,'a')")
assert sql('SELECT * FROM log')==[];assert total()-before==1;assert sql('SELECT changes(),last_insert_rowid()')==[['1','2']]
sql('PRAGMA recursive_triggers=ON');before=total();sql("REPLACE INTO p VALUES(3,'a')")
assert sql('SELECT * FROM log ORDER BY rowid')==[['before','2'],['after','2']]
assert total()-before==3;assert sql('SELECT changes(),last_insert_rowid()')==[['1','3']]
sql("INSERT INTO p VALUES(4,'b')");before=total();sql("UPDATE OR REPLACE p SET k='a' WHERE id=4")
assert total()-before==3;assert sql('SELECT * FROM p')==[['4','a']]
assert sql('SELECT changes(),last_insert_rowid()')==[['1','4']]
# A row that conflicts on several constraints is deleted once.
sql('CREATE TABLE multi(a UNIQUE,b UNIQUE)');sql('INSERT INTO multi VALUES(1,1),(2,2)')
sql('CREATE TRIGGER md AFTER DELETE ON multi BEGIN INSERT INTO log VALUES(old.a,old.b); END')
before=total();sql('REPLACE INTO multi VALUES(1,2)');assert total()-before==3
assert sql('SELECT * FROM multi')==[['1','2']]
before=total();sql('REPLACE INTO multi VALUES(1,2)');assert total()-before==2
# Cascade actions and their own DELETE triggers run even with recursive triggers OFF.
sql('PRAGMA foreign_keys=ON');sql('PRAGMA recursive_triggers=OFF')
sql('CREATE TABLE child(id INTEGER PRIMARY KEY,p REFERENCES p(id) ON DELETE CASCADE)')
sql('INSERT INTO child VALUES(1,4)')
sql("CREATE TRIGGER cd AFTER DELETE ON child BEGIN INSERT INTO log VALUES('child',old.id); END")
before=total();sql("REPLACE INTO p VALUES(5,'a')")
assert sql('SELECT * FROM child')==[];assert total()-before==3
assert sql('SELECT changes()')==[['1']]
# NO ACTION validates the final statement, after the replacement parent is present.
sql('CREATE TABLE hold(p REFERENCES p(id))');sql('INSERT INTO hold VALUES(5)')
sql('PRAGMA recursive_triggers=ON');before=total();sql("REPLACE INTO p VALUES(5,'c')")
assert total()-before==3;assert sql('SELECT * FROM hold')==[['5']]
saved=sql('SELECT * FROM p');before=total();sql("REPLACE INTO p VALUES(6,'c')",False)
assert sql('SELECT * FROM p')==saved;assert total()==before
# RESTRICT runs on the implicit deletion, even if a same-key parent would be inserted.
sql('CREATE TABLE restrictor(p REFERENCES p(id) ON DELETE RESTRICT)');sql('INSERT INTO restrictor VALUES(5)')
sql("REPLACE INTO p VALUES(5,'c')",False);assert sql('SELECT * FROM p')==saved
sql('DROP TABLE restrictor')
sql('CREATE TABLE nullable(p REFERENCES p(id) ON DELETE SET NULL)');sql('INSERT INTO nullable VALUES(5)')
sql("REPLACE INTO p VALUES(5,'d')");assert sql('SELECT * FROM nullable')==[[None]]
# A BEFORE INSERT trigger may add a child before the outer parent insert finishes.
sql('CREATE TABLE parent2(id INTEGER PRIMARY KEY)');sql('CREATE TABLE child2(p REFERENCES parent2(id))')
sql('CREATE TRIGGER early BEFORE INSERT ON parent2 BEGIN INSERT INTO child2 VALUES(new.id); END')
sql('INSERT INTO parent2 VALUES(10)');assert sql('SELECT * FROM child2')==[['10']]
sql('CREATE TRIGGER invalid AFTER INSERT ON parent2 BEGIN INSERT INTO child2 VALUES(999); END')
sql('INSERT INTO parent2 VALUES(11)',False)
assert sql('SELECT * FROM parent2')==[['10']];assert sql('SELECT * FROM child2')==[['10']]
# FAIL may retain earlier ordinary changes, but may not retain an immediate FK violation.
sql('DROP TRIGGER invalid')
sql("CREATE TRIGGER fail_after AFTER INSERT ON parent2 BEGIN INSERT INTO child2 VALUES(999); SELECT RAISE(FAIL,'stop'); END")
sql('INSERT INTO parent2 VALUES(12)',False)
assert sql('SELECT * FROM parent2')==[['10']];assert sql('SELECT * FROM child2')==[['10']]
# RAISE(IGNORE) in the implicit-delete trigger abandons the candidate replacement.
sql('CREATE TABLE ignored(x UNIQUE)');sql('INSERT INTO ignored VALUES(1)')
sql('CREATE TRIGGER keep BEFORE DELETE ON ignored BEGIN SELECT RAISE(IGNORE); END')
sql('REPLACE INTO ignored VALUES(1)');assert sql('SELECT changes()')==[['0']]
assert sql('SELECT rowid,x FROM ignored')==[['1','1']]
# Default substitution must recompute generated values before checking constraints.
sql('CREATE TABLE defaults(b INT AS(a*2) STORED NOT NULL,a INT NOT NULL DEFAULT 3,CHECK(b=6)) STRICT')
sql('INSERT OR REPLACE INTO defaults(a) VALUES(NULL)');assert sql('SELECT * FROM defaults')==[['6','3']]
sql('UPDATE OR REPLACE defaults SET a=NULL');assert sql('SELECT * FROM defaults')==[['6','3']]
sql("CREATE TABLE bad_default(a INT NOT NULL DEFAULT 'text') STRICT")
sql('INSERT OR REPLACE INTO bad_default VALUES(NULL)',False)
assert sql('SELECT * FROM bad_default')==[]
# View DML uses the view definition's scope even when caller CTEs are also needed.
sql('CREATE TABLE base(y)');sql('INSERT INTO base VALUES(40)');sql('CREATE TEMP VIEW v AS SELECT y FROM base')
sql('CREATE TRIGGER vu INSTEAD OF UPDATE ON v BEGIN UPDATE base SET y=new.y WHERE y=old.y; END')
sql('WITH base(y) AS(VALUES(99)) UPDATE v SET y=(SELECT y FROM base)')
assert sql('SELECT * FROM base')==[['99']]
assert sql('PRAGMA foreign_key_check')==[];assert sql('PRAGMA integrity_check')==[['ok']]
p.terminate();p.wait()
print('PASS: REPLACE implicit deletes, trigger/FK actions, counters, IGNORE, generated defaults and statement FK timing')
