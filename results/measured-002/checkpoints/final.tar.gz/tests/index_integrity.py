"""Independent, structurally valid index mutations and integrity/quick-check distinctions."""
import json,subprocess,os,struct
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v,ok=True):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());assert r['ok']==ok,(v,r);return r
def sql(s,ok=True):return [[v.get('value') for v in row] for row in req({'op':'execute','sql':s},ok).get('rows',[])]
source='/work/tests/index-integrity.db';bad='/work/tests/index-integrity-bad.db'
try:os.unlink(source)
except FileNotFoundError:pass
req({'op':'open','path':source});sql('CREATE TABLE t(id INTEGER PRIMARY KEY,x TEXT)');sql('CREATE INDEX ix ON t(x)');sql("INSERT INTO t VALUES(1,'aa'),(2,'bb'),(3,'cc')");sql('CREATE TABLE other(x)')
roots={n:int(r) for n,r in sql("SELECT name,rootpage FROM sqlite_schema WHERE rootpage>0")};req({'op':'close'})
original=bytearray(open(source,'rb').read());ps=struct.unpack_from('>H',original,16)[0];root=(roots['ix']-1)*ps
assert original[root]==10
def vi(b,o):
 n=0
 for k in range(9):
  c=b[o];o+=1
  if k==8:return (n<<8)|c,o
  n=(n<<7)|(c&127)
  if c<128:return n,o
def payload(b,ordinal):
 ptr=struct.unpack_from('>H',b,root+8+ordinal*2)[0];size,o=vi(b,root+ptr);header,_=vi(b,o);return root+ptr,size+o-root-ptr,o+header
cases=[]
b=original.copy();_,_,text=payload(b,0);b[text+1]=ord('z');cases.append(('mismatched key',b,False))
b=original.copy();b[root+8:root+10],b[root+12:root+14]=b[root+12:root+14],b[root+8:root+10];cases.append(('index key ordering',b,True))
b=original.copy();_,_,text=payload(b,2);assert b[text+2]==3;b[text+2]=4;cases.append(('nonexistent rowid',b,False))
b=original.copy();start,size,_=payload(b,2);struct.pack_into('>H',b,root+3,2);struct.pack_into('>H',b,root+5,start-root+size);cases.append(('missing entry',b,False))
b=original.copy();table=(roots['t']-1)*ps;assert b[table]==13;b[table+8:table+10],b[table+12:table+14]=b[table+12:table+14],b[table+8:table+10];cases.append(('table key ordering',b,True))
for label,b,quick_fails in cases:
 open(bad,'wb').write(b);req({'op':'open','path':bad});assert sql('SELECT count(*) FROM t')==[['3']]
 full=sql('PRAGMA integrity_check');assert full!=[['ok']],(label,full)
 quick=sql('PRAGMA quick_check');assert (quick!=[['ok']])==quick_fails,(label,quick)
 assert sql('PRAGMA integrity_check(other)')==[['ok']]
 assert sql('PRAGMA main.integrity_check(t)')!=[['ok']]
 sql('PRAGMA integrity_check(missing)',False)
 if label!='table key ordering':
  version=sql('PRAGMA schema_version');sql('BEGIN');sql('SAVEPOINT repair');sql('REINDEX main.ix')
  assert sql('PRAGMA integrity_check')==[['ok']];assert open(bad,'rb').read()==b
  sql('ROLLBACK TO repair');assert sql('PRAGMA integrity_check')!=[['ok']];sql('RELEASE repair');sql('COMMIT');assert open(bad,'rb').read()==b
  sql('REINDEX BINARY');assert sql('PRAGMA integrity_check')==[['ok']];assert sql('PRAGMA schema_version')==version
  sql('REINDEX missing',False)
 # The complete-image writer rebuilds all indexes when committing a table mutation.
 sql("INSERT INTO t VALUES(4,'dd')");assert sql('PRAGMA integrity_check')==[['ok']]
 req({'op':'close'})
# A rebuild must still enforce uniqueness of the index being rebuilt.
req({'op':'open','path':':memory:'});sql('CREATE TABLE u(id INTEGER PRIMARY KEY,x INTEGER UNIQUE)');sql('INSERT INTO u VALUES(1,1),(2,2),(3,3)')
unique='/work/tests/reindex-unique.db'
try:os.unlink(unique)
except FileNotFoundError:pass
sql(f"VACUUM INTO '{unique}'");req({'op':'open','path':unique});table=(int(sql("SELECT rootpage FROM sqlite_schema WHERE name='u'")[0][0])-1)*4096
req({'op':'close'});b=bytearray(open(unique,'rb').read());cell=struct.unpack_from('>H',b,table+12)[0]+table
_,o=vi(b,cell);_,o=vi(b,o);header,_=vi(b,o);assert b[o+header]==3;b[o+header]=2;open(unique,'wb').write(b)
req({'op':'open','path':unique});sql('REINDEX sqlite_autoindex_u_1',False);assert open(unique,'rb').read()==b
sql('UPDATE u SET x=3 WHERE id=3');assert sql('PRAGMA integrity_check')==[['ok']]
sql('CREATE INDEX expression ON u(x+1)');sql('REINDEX EXPRESSIONS');sql('REINDEX u');sql('REINDEX')
p.terminate();p.wait();print('PASS: index/table order, mismatched keys/rowids, missing entries, partial integrity and quick_check')
