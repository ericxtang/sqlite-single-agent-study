"""Optional UPDATE/DELETE LIMIT/OFFSET semantics from lang_update/lang_delete."""
import json,os,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE t(id INTEGER PRIMARY KEY,name TEXT COLLATE NOCASE,n)')
sql("INSERT INTO t VALUES(1,'a',0),(2,'B',0),(3,'c',0),(4,'D',0),(5,'e',0)")
assert sorted(sql('UPDATE t SET n=1 RETURNING id ORDER BY name DESC LIMIT 2 OFFSET 1'))==[['3'],['4']]
assert sql('SELECT id FROM t WHERE n=1 ORDER BY id')==[['3'],['4']]
# Comma syntax has OFFSET first, LIMIT second.
sql('UPDATE t SET n=2 ORDER BY id LIMIT 1,2');assert sql('SELECT id FROM t WHERE n=2 ORDER BY id')==[['2'],['3']]
sql('WITH a(x) AS(VALUES(3)) DELETE FROM t WHERE n=0 ORDER BY name LIMIT -1 OFFSET(SELECT x-2 FROM a)')
assert sql('SELECT id FROM t ORDER BY id')==[['1'],['2'],['3'],['4']]
sql('DELETE FROM t ORDER BY id DESC LIMIT 1 OFFSET -100');assert sql('SELECT id FROM t ORDER BY id')==[['1'],['2'],['3']]
sql('BEGIN');sql('DELETE FROM t LIMIT 1,1');assert sql('SELECT count(*) FROM t')==[['2']];sql('ROLLBACK')
# Exactly convertible numeric arguments; errors preserve data and transaction.
for action in ['UPDATE t SET n=9','DELETE FROM t']:
 for tail in ['LIMIT NULL','LIMIT 1.5','LIMIT 1 OFFSET NULL','LIMIT 1 OFFSET 1.5',"LIMIT 'abc'",'ORDER BY id']:
  sql(action+' '+tail,False)
assert sql('SELECT count(*) FROM t')==[['3']]
sql("UPDATE t SET n=8 ORDER BY id LIMIT '1' OFFSET 1.0")
assert sql('SELECT id FROM t WHERE n=8')==[['2']]
# LIMIT 0 validates names and shapes but evaluates no predicate/order/SET values.
sql('UPDATE t SET n=abs(-9223372036854775808) WHERE abs(-9223372036854775808) ORDER BY abs(-9223372036854775808) LIMIT 0')
assert sql('SELECT changes()')==[['0']]
sql('DELETE FROM t WHERE abs(-9223372036854775808) LIMIT 0')
sql('UPDATE t SET absent=1 LIMIT 0',False);sql('DELETE FROM t WHERE missing LIMIT 0',False)
sql('CREATE TABLE generated(a,b AS(a*2))');sql('UPDATE generated SET b=1 LIMIT 0',False)
# UPDATE FROM selects matching rows before LIMIT/OFFSET and updates each target once.
sql('CREATE TABLE source(id,v)');sql('INSERT INTO source VALUES(1,11),(2,22),(3,33)')
sql('UPDATE t SET n=s.v FROM source s WHERE t.id=s.id ORDER BY s.v DESC LIMIT 1 OFFSET 1')
assert sql('SELECT n FROM t WHERE id=2')==[['22']]
# INSTEAD OF view mutations use the same bounded target selection.
sql('CREATE VIEW v AS SELECT id,n FROM t')
sql('CREATE TRIGGER vu INSTEAD OF UPDATE ON v BEGIN UPDATE t SET n=new.n WHERE id=old.id; END')
sql('CREATE TRIGGER vd INSTEAD OF DELETE ON v BEGIN DELETE FROM t WHERE id=old.id; END')
assert sorted(sql('UPDATE v SET n=44 RETURNING id ORDER BY id LIMIT 1 OFFSET 1'))==[['2']]
assert sql('SELECT n FROM t WHERE id=2')==[['44']]
sql('UPDATE v SET n=s.v FROM source s WHERE v.id=s.id ORDER BY s.v LIMIT 1 OFFSET 2')
assert sql('SELECT n FROM t WHERE id=3')==[['33']]
sql('DELETE FROM v ORDER BY id LIMIT 1,1');assert sql('SELECT id FROM t ORDER BY id')==[['1'],['3']]
# Zero-limit view mutations bind the view without evaluating its projected values.
sql('CREATE VIEW unused_value AS SELECT abs(-9223372036854775808) x')
sql('CREATE TRIGGER skip_view INSTEAD OF DELETE ON unused_value BEGIN SELECT 1; END')
sql('DELETE FROM unused_value LIMIT(SELECT 1-1)')
assert sql('SELECT changes()')==[['0']]
# Only rightmost assignments are evaluated, using original values for all RHSs.
sql('CREATE TABLE assignments(a,b)');sql('INSERT INTO assignments VALUES(1,2)')
sql('UPDATE assignments SET a=abs(-9223372036854775808),a=b,b=a')
assert sql('SELECT a,b FROM assignments')==[['2','1']]
sql('UPDATE assignments SET(a,b)=(abs(-9223372036854775808),7),a=8')
assert sql('SELECT a,b FROM assignments')==[['8','7']]
sql('UPDATE assignments SET(a,a)=(abs(-9223372036854775808),9)')
assert sql('SELECT a,b FROM assignments')==[['9','7']]
sql('UPDATE assignments SET rowid=NULL,_rowid_=5')
assert sql('SELECT rowid FROM assignments')==[['5']]
sql('CREATE TABLE up(a PRIMARY KEY,b)');sql('INSERT INTO up VALUES(1,1)')
sql('INSERT INTO up VALUES(1,2) ON CONFLICT(a) DO UPDATE SET b=abs(-9223372036854775808),b=excluded.b')
assert sql('SELECT b FROM up')==[['2']]
# The documented trigger grammar excludes limited UPDATE/DELETE statements.
sql('CREATE TRIGGER bad AFTER INSERT ON t BEGIN DELETE FROM t LIMIT 1; END',False)
sql('CREATE TRIGGER bad AFTER INSERT ON t BEGIN UPDATE t SET n=1 ORDER BY id LIMIT 1 OFFSET 1; END',False)
# Selection collation uses declared NOCASE, including explicit RTRIM override.
sql('CREATE TABLE names(x TEXT COLLATE NOCASE)');sql("INSERT INTO names VALUES('Z'),('a'),('b')")
sql('DELETE FROM names ORDER BY x LIMIT 1');assert sql('SELECT x FROM names ORDER BY x')==[['b'],['Z']]
assert sql('PRAGMA integrity_check')==[['ok']]
p.terminate();p.wait()
print('PASS: UPDATE/DELETE LIMIT OFFSET/comma forms, collations, UPDATE FROM, view triggers and zero-limit binding')
