"""Statement-local view semantics, live dependencies, and nested WITH scopes."""
import json,os,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
for definition in ['SELECT abs(-9223372036854775808)','SELECT * FROM missing','SELECT nonexistent()', 'SELECT * FROM unused']:
 assert sql('WITH unused AS('+definition+') SELECT 42')==[['42']]
assert sql('WITH a AS(SELECT * FROM b),b AS(SELECT * FROM a) SELECT 7')==[['7']]
assert sql('WITH unused AS MATERIALIZED(SELECT abs(-9223372036854775808)) SELECT 1')==[['1']]
# Required definitions still bind/evaluate, including transitive forward edges.
sql('WITH a AS(SELECT * FROM b),b AS(SELECT * FROM missing) SELECT * FROM a',False)
assert sql('WITH a AS(SELECT * FROM b),b AS(VALUES(5)),bad AS(SELECT * FROM missing) SELECT * FROM a')==[['5']]
# Dependencies can occur in every expression clause, including VALUES and limits.
assert sql('WITH a(x) AS(VALUES(4)) VALUES((SELECT x FROM a))')==[['4']]
assert sql('WITH a(x) AS(VALUES(1)) SELECT 2 UNION ALL SELECT 3 LIMIT(SELECT x FROM a)')==[['2']]
assert sql('WITH a(x) AS(VALUES(1)) SELECT 2 UNION ALL SELECT 3 LIMIT 1 OFFSET(SELECT x FROM a)')==[['3']]
assert sql('WITH a(x) AS(VALUES(1)) SELECT 2 UNION ALL SELECT 3 ORDER BY 1')==[['2'],['3']]
assert sql('WITH a(x) AS(VALUES(5)) SELECT count(*) GROUP BY(SELECT x FROM a) HAVING(SELECT x FROM a)=5')==[['1']]
assert sql('WITH a(x) AS(VALUES(5)) SELECT 2 ORDER BY(SELECT x FROM a)')==[['2']]
assert sql('WITH a(x) AS(VALUES(1)) SELECT sum(2) OVER(PARTITION BY(SELECT x FROM a))')==[['2']]
assert sql('WITH a(x) AS(VALUES(1)) SELECT sum(2) OVER win WINDOW win AS(ORDER BY(SELECT x FROM a))')==[['2']]
assert sql('WITH a(x) AS(VALUES(1)) SELECT group_concat(2 ORDER BY(SELECT x FROM a))')==[['2']]
assert sql("WITH a(x) AS(VALUES('[1,2]')) SELECT value FROM json_each((SELECT x FROM a))")==[['1'],['2']]
# Inner bindings hide outer ones; dependencies in unused inner CTEs do not leak.
assert sql('WITH a AS(SELECT * FROM missing) SELECT * FROM(WITH a(x) AS(VALUES(8)) SELECT * FROM a)')==[['8']]
assert sql('WITH a AS(SELECT * FROM missing) SELECT(WITH b AS(SELECT * FROM a) SELECT 9)')==[['9']]
assert sql('WITH t AS(WITH t(x) AS(VALUES(11)) SELECT * FROM t) SELECT * FROM t')==[['11']]
assert sql('WITH a AS(WITH b AS(SELECT * FROM c) SELECT * FROM b),c AS(VALUES(12)) SELECT * FROM a')==[['12']]
# CTEs are read sources, never DML targets. All DML expression scopes are visited.
sql('CREATE TABLE t(x UNIQUE,y)');sql('WITH t AS(SELECT * FROM missing) INSERT INTO t VALUES(1,2)')
sql('WITH unused AS(SELECT * FROM missing),a(x) AS(VALUES(4)) UPDATE t SET y=(SELECT x FROM a)')
assert sql('SELECT * FROM t')==[['1','4']]
sql('WITH a(x) AS(VALUES(5)) UPDATE t SET y=a.x FROM a')
assert sql('SELECT y FROM t')==[['5']]
sql('WITH a(x) AS(VALUES(6)) INSERT INTO t VALUES(1,1) ON CONFLICT(x) DO UPDATE SET y=(SELECT x FROM a)')
assert sql('SELECT y FROM t')==[['6']]
assert sql('WITH a(x) AS(VALUES(20)) UPDATE t SET y=7 RETURNING(SELECT x FROM a)')==[['20']]
sql('WITH a(x) AS(VALUES(1)),unused AS(SELECT * FROM missing) DELETE FROM t WHERE x IN a')
assert sql('SELECT count(*) FROM t')==[['0']]
# Stored views do not capture statement-local CTEs or correlated caller columns.
sql('INSERT INTO t VALUES(1,40)');sql('CREATE TEMP VIEW v AS SELECT y FROM t')
assert sql('WITH t(y) AS(VALUES(99)) SELECT * FROM v')==[['40']]
sql('CREATE TEMP VIEW broken AS SELECT no_such_column')
sql('SELECT(SELECT * FROM broken) FROM(SELECT 3 no_such_column)',False)
sql('CREATE TEMP VIEW own AS WITH t(x) AS(VALUES(77)) SELECT x FROM t')
assert sql('WITH t AS(SELECT * FROM missing) SELECT * FROM own')==[['77']]
# Live dependency reordering still recognizes complete recursive query scopes.
assert sql('WITH a AS(VALUES((SELECT * FROM b))),b AS(VALUES(13)) SELECT * FROM a')==[['13']]
sql('WITH a AS(VALUES((SELECT * FROM b))),b AS(VALUES((SELECT * FROM a))) SELECT * FROM a',False)
# Recursive tables are forbidden in nested SELECTs, even with a finite LIMIT.
for body in [
 'VALUES(1) UNION ALL SELECT x+1 FROM r WHERE x<(SELECT x+1 FROM r) LIMIT 3',
 'VALUES(1) UNION ALL SELECT(SELECT x+1 FROM r) FROM r LIMIT 3',
 'VALUES(1) UNION ALL SELECT x+1 FROM(SELECT * FROM r) LIMIT 3',
 'VALUES(1) UNION ALL SELECT x+1 FROM r LIMIT(SELECT x FROM r)',
 'VALUES((SELECT x FROM r)) UNION ALL SELECT x+1 FROM r LIMIT 3',
 'VALUES(1) UNION ALL SELECT a.x FROM r a JOIN(SELECT * FROM r) b LIMIT 3',
 'VALUES(1) UNION ALL SELECT x+1 FROM r UNION ALL SELECT 9 LIMIT 3',
]: sql('WITH RECURSIVE r(x) AS('+body+') SELECT * FROM r',False)
assert sql('WITH r(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM(r) WHERE x<3) SELECT * FROM r')==[['1'],['2'],['3']]
assert sql('WITH r(x) AS(VALUES(1) UNION ALL SELECT x+(WITH r(v) AS(VALUES(1)) SELECT v FROM r) FROM r WHERE x<3) SELECT * FROM r')==[['1'],['2'],['3']]
p.terminate();p.wait()
print('PASS: unused CTE elimination, complete dependency traversal, nested shadowing, DML scopes and view isolation')
