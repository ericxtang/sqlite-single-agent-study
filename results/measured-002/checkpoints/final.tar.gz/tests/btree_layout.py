"""Independently assembled B-tree layouts and logical separator corruptions."""
import os,json,subprocess,struct
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v,ok=True):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());assert r['ok']==ok,(v,r);return r
def sql(s,ok=True):return [[v.get('value') for v in row] for row in req({'op':'execute','sql':s},ok).get('rows',[])]
source='/work/tests/btree-layout-source.db';path='/work/tests/btree-layout.db'
if os.path.exists(source):os.remove(source)
req({'op':'open','path':source});sql('PRAGMA page_size=512');sql('CREATE TABLE t(id INTEGER PRIMARY KEY)');req({'op':'close'})
header=bytearray(open(source,'rb').read()[:512])
def varint(n):
 n&=(1<<64)-1
 if n>(1<<56)-1:
  tail=n&255;n>>=8;out=[tail]
  for _ in range(8):out.insert(0,(n&127)|128);n>>=7
  return bytes(out)
 out=[n&127];n>>=7
 while n:out.insert(0,(n&127)|128);n>>=7
 return bytes(out)
def leaf(keys,gap=0,fragments=0):
 b=bytearray(512);b[0]=13;struct.pack_into('>H',b,3,len(keys));b[7]=fragments
 at=512
 for i,key in enumerate(keys):
  cell=bytes([2])+varint(key)+bytes([2,0]);at-=len(cell);b[at:at+len(cell)]=cell;struct.pack_into('>H',b,8+i*2,at)
  if i+1<len(keys):at-=gap
 struct.pack_into('>H',b,5,at);return b
def inner(entries,right):
 b=bytearray(512);b[0]=5;struct.pack_into('>H',b,3,len(entries));struct.pack_into('>I',b,8,right);at=512
 for i,(child,key) in enumerate(entries):
  cell=struct.pack('>I',child)+varint(key);at-=len(cell);b[at:at+len(cell)]=cell;struct.pack_into('>H',b,12+i*2,at)
 struct.pack_into('>H',b,5,at);return b
def image(pages):
 b=header.copy();struct.pack_into('>I',b,28,1+len(pages));struct.pack_into('>II',b,32,0,0)
 for page in pages:b+=page
 return b
def opened(b,ok=True):
 req({'op':'close'});open(path,'wb').write(b);req({'op':'open','path':path},ok)
# A balanced tree with a gap between adjacent child key ranges is valid.
balanced=image([inner([(3,2)],4),leaf([1,2]),leaf([3,4])]);opened(balanced)
assert sql('SELECT id FROM t')==[['1'],['2'],['3'],['4']];assert sql('PRAGMA integrity_check')==[['ok']]
# Separator keys have inclusive left bounds and strict right bounds.
for separator in (1,3):
 opened(image([inner([(3,separator)],4),leaf([1,2]),leaf([3,4])]))
 assert sql('SELECT count(*) FROM t')==[['4']]
 for pragma in ('integrity_check','quick_check'):
  assert any('interior keys' in row[0] for row in sql('PRAGMA '+pragma))
 sql('REINDEX') # No table rebuild is implied for an ordinary rowid table.
 assert sql('PRAGMA integrity_check')!=[['ok']]
 sql('VACUUM');assert sql('PRAGMA integrity_check')==[['ok']]
# Signed rowids and valid separator gaps follow the same order rules.
opened(image([inner([(3,0)],4),leaf([-3,-1]),leaf([2,4])]))
assert sql('PRAGMA integrity_check')==[['ok']]
# All pages are reachable, but children have different depths.
opened(image([inner([(3,2)],4),leaf([1,2]),inner([(5,3)],6),leaf([3]),leaf([4])]),False)
# A non-root interior page cannot have just a right child and no keys.
opened(image([inner([(3,2)],4),inner([],5),inner([],6),leaf([1,2]),leaf([3,4])]),False)
# Fragment counts account for all untracked 1..3-byte gaps.
opened(image([leaf([1,2],gap=2,fragments=2)]));assert sql('PRAGMA integrity_check')==[['ok']]
for gap,count in [(2,0),(2,1),(2,3),(4,4),(0,1)]:opened(image([leaf([1,2],gap=gap,fragments=count)]),False)
# A tracked freeblock is valid when a cell precedes it in the content region.
b=leaf([1,2],gap=8);cell2=struct.unpack_from('>H',b,10)[0];free=cell2+4
struct.pack_into('>H',b,1,free);struct.pack_into('>HH',b,free,0,8)
opened(image([b]));assert sql('PRAGMA integrity_check')==[['ok']]
# Move the second cell to a freeblock before the first cell: invalid layout.
b=leaf([1,2]);start=struct.unpack_from('>H',b,10)[0];struct.pack_into('>H',b,3,1)
struct.pack_into('>H',b,1,start);struct.pack_into('>HH',b,start,0,4)
opened(image([b]),False)
# Bulk loading also balances the final interior group at fanout boundaries.
req({'op':'open','path':':memory:'});sql('PRAGMA page_size=512');sql('CREATE TABLE wide(id INTEGER PRIMARY KEY,v)')
sql("WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<700) INSERT INTO wide SELECT x,printf('%0300d',x) FROM n")
assert sql('PRAGMA integrity_check')==[['ok']]
p.terminate();p.wait()
print('PASS: B-tree child depths, table separators, signed bounds, fragment accounting, freeblock order and bulk layout')
