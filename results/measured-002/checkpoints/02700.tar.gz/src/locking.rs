//! OS advisory locks coordinate this implementation's independent processes.
use crate::parser::Res;
use std::{fs::{File,OpenOptions},path::Path,os::fd::AsRawFd,cell::Cell};
unsafe extern "C" {fn flock(fd:i32,operation:i32)->i32;}
const SH:i32=1;const EX:i32=2;const NB:i32=4;const UN:i32=8;
pub struct Locks{writer:File,reader:File,pub writing:Cell<bool>,pub reading:Cell<i32>}
impl Locks{
 pub fn open(p:&Path)->Res<Self>{let mut w=p.as_os_str().to_os_string();w.push(".agent-write-lock");let mut r=p.as_os_str().to_os_string();r.push(".agent-read-lock");let open=|p|OpenOptions::new().create(true).read(true).write(true).open(p).map_err(|e|e.to_string());Ok(Self{writer:open(w)?,reader:open(r)?,writing:Cell::new(false),reading:Cell::new(0)})}
 fn lock(file:&File,mode:i32)->Res<()>{let r=unsafe{flock(file.as_raw_fd(),mode|NB)};if r==0{Ok(())}else{Err("database is locked".into())}}
 pub fn read(&self)->Res<()>{if self.reading.get()==0{Self::lock(&self.reader,SH)?;self.reading.set(SH)}Ok(())}
 pub fn write(&self)->Res<()>{if !self.writing.get(){Self::lock(&self.writer,EX)?;self.writing.set(true)}Ok(())}
 pub fn exclusive(&self)->Res<()>{if self.reading.get()!=EX{let previous=self.reading.get();if let Err(e)=Self::lock(&self.reader,EX){if previous==SH{let _=Self::lock(&self.reader,SH);}return Err(e)}self.reading.set(EX)}Ok(())}
 pub fn unlock(&self){let _=Self::lock(&self.reader,UN);let _=Self::lock(&self.writer,UN);self.reading.set(0);self.writing.set(false);}
}
