# Implementation notes
All implementation and verification uses the offline workspace, with /docs as the sole SQL reference. No database engine/parser dependencies.
Architecture: hand-written lexer and Pratt expression parser; relational interpreter; typed values and affinity; schema/row state with statement rollback and transaction/savepoint snapshots. First persistence format is an atomic serialized state file; SQLite page format remains a compatibility target.
Priorities: integrated interface, expressions, DDL/DML, joins/grouping/subqueries, constraints, persistence/transactions, functions and pragmas, advanced SQL. Tests derive from documented rules, never a reference engine.

## Integrated state (current)
- `cargo build --offline --bin sqlite-agent` succeeds. `cargo build --release --offline --bin sqlite-agent` is the required delivery build.
- Hand-written parser and evaluator support SELECT/VALUES, joins including outer/USING, grouped aggregates, scalar/correlated subqueries, compounds, ordinary/recursive CTEs, common window functions, INSERT/UPDATE/DELETE RETURNING and UPSERT.
- Affinity, NULL logic, integer overflow promotion, casts, collation, constraints, strict/without-rowid/generated columns, foreign keys and cascades, transactions/savepoints.
- Scalar text/numeric functions, dates, ordered JSON objects and JSON paths, JSON table functions including correlated inputs.
- Triggers: BEFORE/AFTER row triggers, UPDATE OF, WHEN, OLD/NEW, RAISE and recursion control. INSTEAD OF syntax is parsed but view DML still needs implementation.
- Persistence now uses SQLite 3 binary page format (header, records/varints, table/index interior and leaf B-trees, overflow chains, freelist). Full-image atomic rename + fsync at commit. Read codec accepts UTF-8/UTF-16 records. Earlier JSON-state files can still be read.
- Tests: `python3 tests/semantics.py` (118 assertions); `python3 tests/storage.py` (512/4096/65536-byte pages, multi-page indexes, overflow, reopen and independent structural validation); `cargo test --offline` (record/varint codec).
- No reference database, parser, internet, external tests, or agents used. rustfmt is not installed; do not fetch it.

## Known limits / next work
1. Multi-process locking/reload not yet implemented; add before claiming concurrent isolation. WAL pragmas currently use same atomic-image persistence, no native WAL/journal codec.
2. Add trigger regression tests and INSTEAD OF view DML; UPSERT UPDATE currently misses trigger hooks.
3. Tighten UPSERT target matching (currently valid-target existence, not precise violated target), expression/empty-query validation, generated-column dependency validation.
4. Index DESC information is parsed but discarded; index records written ascending. Add retained sort direction before full index-format compatibility.
5. Window RANGE/GROUPS explicit offsets currently approximate ROWS; grouped/window combinations need work.
6. SQLite_sequence is virtualized; direct writes and exact lifetime/empty-row rules need implementation.
7. ATTACH/DETACH, virtual table modules, JSON5/JSONB not implemented. View/trigger references after ALTER need fuller rewrites.
8. Avoid repeat test runs without new changes; expand tests when fixing documented gaps. Keep code integrated and update notes with remaining work.
