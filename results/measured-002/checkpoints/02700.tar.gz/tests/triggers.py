import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[c.get('value') for c in row] for row in r.get('rows',[])]
path='/work/tests/triggers.db'
try:os.unlink(path)
except FileNotFoundError:pass
assert req({'op':'open','path':path})['ok']
sql('CREATE TABLE t(id INTEGER PRIMARY KEY,v INTEGER)');sql('CREATE TABLE log(id,old,new,event)')
sql("CREATE TRIGGER ins AFTER INSERT ON t BEGIN INSERT INTO log VALUES(new.id,NULL,new.v,'I'); END")
sql("CREATE TRIGGER upd AFTER UPDATE OF v ON t WHEN old.v<>new.v BEGIN INSERT INTO log VALUES(new.id,old.v,new.v,'U'); END")
sql("CREATE TRIGGER del AFTER DELETE ON t BEGIN INSERT INTO log VALUES(old.id,old.v,NULL,'D'); END")
sql("CREATE TRIGGER pos BEFORE INSERT ON t WHEN new.v<0 BEGIN SELECT RAISE(ABORT,'negative value'); END")
sql('INSERT INTO t VALUES(1,3),(2,4)');sql('UPDATE t SET v=v*2 WHERE id=1');sql('DELETE FROM t WHERE id=2')
assert sql('SELECT * FROM log')==[['1',None,'3','I'],['2',None,'4','I'],['1','3','6','U'],['2','4',None,'D']]
assert sql('SELECT changes(),total_changes(),last_insert_rowid()')==[['1','8','2']]
sql('INSERT INTO t VALUES(3,5),(4,-1)',False);assert sql('SELECT count(*) FROM log')==[['4']]
sql("INSERT INTO t VALUES(1,9) ON CONFLICT(id) DO UPDATE SET v=excluded.v")
assert sql("SELECT old,new,event FROM log ORDER BY rowid DESC LIMIT 1")==[['6','9','U']]
sql('CREATE VIEW v AS SELECT id,v FROM t')
sql('CREATE TRIGGER vi INSTEAD OF INSERT ON v BEGIN INSERT INTO t VALUES(new.id,new.v); END')
sql('CREATE TRIGGER vu INSTEAD OF UPDATE ON v BEGIN UPDATE t SET v=new.v WHERE id=old.id; END')
sql('CREATE TRIGGER vd INSTEAD OF DELETE ON v BEGIN DELETE FROM t WHERE id=old.id; END')
sql('INSERT INTO v VALUES(8,10)');assert sql('SELECT changes()')==[['0']]
sql('UPDATE v SET v=20 WHERE id=8');assert sql('SELECT v FROM t WHERE id=8')==[['20']]
sql('DELETE FROM v WHERE id=8');assert sql('SELECT count(*) FROM t WHERE id=8')==[['0']]
sql('CREATE TABLE r(x)');sql('INSERT INTO r VALUES(0)')
sql('CREATE TRIGGER repeat AFTER UPDATE ON r WHEN new.x<4 BEGIN UPDATE r SET x=x+1; END')
sql('UPDATE r SET x=1');assert sql('SELECT x FROM r')==[['2']]
sql('PRAGMA recursive_triggers=ON');sql('UPDATE r SET x=1');assert sql('SELECT x FROM r')==[['4']]
sql('CREATE VIEW cycle AS SELECT * FROM cycle');sql('SELECT * FROM cycle',False);sql('DROP VIEW cycle')
assert req({'op':'close'})['ok'];assert req({'op':'open','path':path})['ok']
sql('INSERT INTO v VALUES(9,12)');assert sql('SELECT v FROM t WHERE id=9')==[['12']]
sql("INSERT INTO v VALUES(10,-2)",False)
p.terminate();p.wait();print('PASS: row triggers, INSTEAD OF views, UPSERT hooks, recursion, RAISE, persistence')
