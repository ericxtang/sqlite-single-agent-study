use crate::{db::{Connection,Table},ast::*,parser::{Res,colname},query::{Rel,Ctes,Ctx},value::Val};
fn local(n:&str)->&str{n.rsplit('.').next().unwrap_or(n)}
fn schema(n:&str)->&str{n.split_once('.').map_or("main",|(s,_)|s)}
fn primary_name(t:&Table)->Option<String>{let mut n=0;for u in &t.unique{if u.primary&&t.ipk().is_some(){continue}n+=1;if u.primary{return Some(format!("{}sqlite_autoindex_{}_{}",t.name.rsplit_once('.').map_or(String::new(),|(s,_)|format!("{}.",s)),local(&t.name),n))}}None}
fn primary(t:&Table)->Vec<Expr>{t.primary_key().into_iter().map(|(i,c,d)|{let e=Expr::Collate(Box::new(Expr::Col(vec![t.cols[i].name.clone()])),c);if d{Expr::Unary("DESC".into(),Box::new(e))}else{e}}).collect()}
fn desc(e:&Expr)->bool{matches!(e,Expr::Unary(n,_)if n=="DESC")}
impl Connection{
 pub(crate) fn foreign_report(&self,db:&str,value:Option<&Val>)->Res<Rel>{
  let selected=value.filter(|v|!v.null()).map(Val::text);let mut rows=vec![];
  if let Some(n)=&selected{let k=if db=="main"{format!("main.{}",n)}else{format!("{}.{}",db,n)};self.table_key(&k)?;}
  for t in self.state.tables.values().filter(|t|schema(&t.name).eq_ignore_ascii_case(db)&&selected.as_ref().map_or(true,|n|local(&t.name).eq_ignore_ascii_case(n))){
   for(fi,f)in t.foreign.iter().rev().enumerate(){let parent=self.table_key(&f.table).ok();let target=parent.map(|p|self.checked_foreign_target(p,f)).transpose()?.unwrap_or_default();let ci=f.cols.iter().map(|c|t.col(c)).collect::<Res<Vec<_>>>()?;
    for r in &t.rows{if ci.iter().any(|i|r.vals[*i].null()){continue}let valid=parent.map_or(false,|p|p.rows.iter().any(|pr|ci.iter().zip(&target).all(|(a,b)|{let c=&p.cols[*b];let affinity=if p.strict&&c.typ.eq_ignore_ascii_case("ANY"){crate::value::Aff::Blob}else{crate::value::affinity(&c.typ)};crate::value::cmp(&r.vals[*a].apply(affinity),&pr.vals[*b],&c.coll)==std::cmp::Ordering::Equal})));
     if !valid{rows.push(vec![Val::Text(local(&t.name).into()),if t.without{Val::Null}else{Val::Int(r.id)},Val::Text(local(&f.table).into()),Val::Int(fi as i64)])}
    }
   }
  }Ok(Rel::named(&["table","rowid","parent","fkid"],rows))
 }
 pub(crate) fn pragma_function(&self,n:&str,args:&[Val])->Res<Rel>{
  let argument=["table_info","table_xinfo","index_info","index_xinfo","index_list","foreign_key_list","foreign_key_check","table_list","integrity_check","quick_check"].contains(&n);
  let schema_argument=argument||["user_version","application_id","schema_version","encoding","page_count","page_size","freelist_count","data_version","cache_size","synchronous","journal_mode","locking_mode","auto_vacuum"].contains(&n);
  let maximum=usize::from(argument)+usize::from(schema_argument);if args.len()>maximum{return Err(format!("too many arguments on pragma_{}()",n))}
  if ["wal_checkpoint","optimize","incremental_vacuum","shrink_memory"].contains(&n){return Err(format!("no such table: pragma_{}",n))}
  let v=if argument{args.first().filter(|v|!v.null())}else{None};let db=args.get(usize::from(argument)).filter(|v|!v.null()).map(Val::text);let name=db.map_or_else(||n.into(),|s|format!("{}.{}",s.to_ascii_lowercase(),n));let rel=self.pragma_query(&name,v)?;
  if rel.fields.is_empty(){return Err(format!("no such table: pragma_{}",n))}Ok(rel)
 }

 pub(crate) fn list_indexes(&self,name:&str)->Res<Rel>{let mut rows=vec![];if let Some(name)=self.object_name(name,"relation"){for i in self.state.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&name)){rows.push(vec![Val::Int(rows.len() as i64),Val::Text(local(&i.name).into()),Val::Int(i.unique as i64),Val::Text(i.origin.clone()),Val::Int(i.wh.is_some() as i64)])}if let Some(t)=self.state.tables.get(&name){if t.without{if let Some(n)=primary_name(t){rows.push(vec![Val::Int(rows.len() as i64),Val::Text(local(&n).into()),Val::Int(1),Val::Text("pk".into()),Val::Int(0)]);}}}}Ok(Rel::named(&["seq","name","unique","origin","partial"],rows))}
 pub(crate) fn index_columns(&self,name:&str,extended:bool)->Res<Rel>{
  let actual=self.object_name(name,"index").and_then(|n|self.state.indexes.get(&n));
  let table_index=if actual.is_none(){self.table(name).ok().filter(|t|t.without).or_else(||self.search_names(name).into_iter().find_map(|n|self.state.tables.values().find(|t|t.without&&primary_name(t).map_or(false,|p|p.eq_ignore_ascii_case(&n)))))}else{None};
  let mut rows=vec![];if actual.is_some()||table_index.is_some(){
   let t=if let Some(i)=actual{self.table_key(&i.table)?}else{table_index.unwrap()};let cols=actual.map_or_else(||primary(t),|i|i.cols.clone());let fields=t.fields(None);let nil=vec![Val::Null;fields.len()];let ctes=Ctes::new();let ctx=Ctx{fields:&fields,row:&nil,..Ctx::empty(&ctes)};
   for e in &cols{let column=colname(e).and_then(|n|t.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)));let mut r=vec![Val::Int(rows.len() as i64),Val::Int(column.map_or(-2,|i|i as i64)),column.map_or(Val::Null,|i|Val::Text(t.cols[i].name.clone()))];if extended{r.extend([Val::Int(desc(e) as i64),Val::Text(self.meta(e,&ctx).1),Val::Int(1)])}rows.push(r)}
   if extended{if !t.without{rows.push(vec![Val::Int(rows.len() as i64),Val::Int(-1),Val::Null,Val::Int(0),Val::Text("BINARY".into()),Val::Int(0)]);}else if table_index.is_some(){for(i,c)in t.cols.iter().enumerate().filter(|(_,c)|c.pk==0&&(c.generated.is_none()||c.stored)){rows.push(vec![Val::Int(rows.len() as i64),Val::Int(i as i64),Val::Text(c.name.clone()),Val::Int(0),Val::Text(c.coll.clone()),Val::Int(0)]);}}else{for e in primary(t){let n=colname(&e).unwrap();let i=t.col(n)?;let coll=self.meta(&e,&ctx).1;if !cols.iter().any(|e|colname(e).map_or(false,|c|c.eq_ignore_ascii_case(n))&&self.meta(e,&ctx).1.eq_ignore_ascii_case(&coll)){rows.push(vec![Val::Int(rows.len() as i64),Val::Int(i as i64),Val::Text(n.into()),Val::Int(desc(&e) as i64),Val::Text(coll),Val::Int(0)]);}}}}
  }Ok(Rel::named(if extended{&["seqno","cid","name","desc","coll","key"]}else{&["seqno","cid","name"]},rows))
 }
 pub(crate) fn list_tables(&self,only_schema:Option<&str>,name:Option<&Val>)->Res<Rel>{let name=name.map(Val::text);let mut rows=vec![];let accept=|n:&str|only_schema.map_or(true,|s|schema(n).eq_ignore_ascii_case(s))&&name.as_ref().map_or(true,|v|v.is_empty()||n.eq_ignore_ascii_case(v)||local(n).eq_ignore_ascii_case(v));
  for t in self.state.tables.values(){if accept(&t.name){rows.push(vec![Val::Text(schema(&t.name).into()),Val::Text(local(&t.name).into()),Val::Text("table".into()),Val::Int(t.cols.len() as i64),Val::Int(t.without as i64),Val::Int(t.strict as i64)]);}}
  for v in self.state.views.values(){if accept(&v.name){let n=if v.cols.is_empty(){self.query(&v.query,&Ctes::new(),None)?.fields.len()}else{v.cols.len()};rows.push(vec![Val::Text(schema(&v.name).into()),Val::Text(local(&v.name).into()),Val::Text("view".into()),Val::Int(n as i64),Val::Int(0),Val::Int(0)]);}}
  for s in ["main","temp"].into_iter().chain(self.attachment_order.iter().map(String::as_str)){let n=if s=="temp"{"sqlite_temp_schema"}else{"sqlite_schema"};let full=format!("{}.{}",s,n);if accept(&full){rows.push(vec![Val::Text(s.into()),Val::Text(n.into()),Val::Text("table".into()),Val::Int(5),Val::Int(0),Val::Int(0)]);}}
  Ok(Rel::named(&["schema","name","type","ncol","wr","strict"],rows))
 }
}
