use crate::{db::{Connection,State},parser::Res,schema,storage};
impl Connection{
 pub fn persist(&self)->Res<()>{
  let main=schema::main_state(&self.state);
  let main_changed=self.file_settings_dirty.get()||self.path.as_ref().map_or(false,|p|!p.exists())||!schema::same_data(&main,&self.main_disk_state.borrow());
  if main_changed&&self.read_only_file{return Err("attempt to write a readonly database".into())}
  let mut updates=vec![];
  for(db,cell)in &self.attachments{let c=cell.borrow();let exported=schema::export(&self.state,db,&c.state);if c.file_settings_dirty.get()||!schema::same_data(&exported,&c.state){if c.read_only_file{return Err("attempt to write a readonly attached database".into())}updates.push((db.clone(),exported));}}
  // Hold all necessary commit locks before producing or replacing any image.
  if main_changed{if let Some(l)=&self.locks{l.write()?;if !self.wal(){l.exclusive()?;}}}
  for(db,_)in &updates{let c=self.attachments[db].borrow();if let Some(l)=&c.locks{l.write()?;if !c.wal(){l.exclusive()?;}}}
  let mut images=vec![];let mut own_version=None;
  if main_changed{if let Some(p)=&self.path{let b=storage::encode(self)?;own_version=Some(u32::from_be_bytes(b[24..28].try_into().unwrap()));images.push((p.clone(),b));}}
  for(db,exported)in &updates{let c=self.attachments[db].borrow();if let Some(p)=&c.path{let mut encoder=Connection::open(":memory:")?;encoder.state=exported.clone();encoder.pragmas=c.pragmas.clone();encoder.path=Some(p.clone());images.push((p.clone(),storage::encode(&encoder)?));}}
  crate::journal::commit(&images)?;
  if main_changed{*self.main_disk_state.borrow_mut()=main;self.file_settings_dirty.set(false);self.own_commit_version.set(own_version);}
  for(db,state)in updates{let mut c=self.attachments[&db].borrow_mut();c.state=state;c.file_version=c.disk_version()?;*c.main_disk_state.borrow_mut()=c.state.clone();c.file_settings_dirty.set(false);}
  Ok(())
 }
 pub(crate) fn check_readonly_changes(&self,before:&State)->Res<()>{
  if self.read_only_file&&!schema::same_data(&schema::main_state(before),&schema::main_state(&self.state)){return Err("attempt to write a readonly database".into())}
  for(db,cell)in &self.attachments{let c=cell.borrow();if c.read_only_file&&!schema::same_data(&schema::export(before,db,&c.state),&schema::export(&self.state,db,&c.state)){return Err("attempt to write a readonly attached database".into())}}
  Ok(())
 }
 pub(crate) fn page_statistics(&self)->Res<(i64,i64)>{
  let dirty=!schema::same_data(&schema::main_state(&self.state),&self.main_disk_state.borrow());
  if !dirty{if let Some(p)=&self.path{let b=std::fs::read(p).map_err(|e|e.to_string())?;if b.len()>=100&&u32::from_be_bytes(b[24..28].try_into().unwrap())==self.file_version{return storage::statistics(&b)}}}
  storage::statistics(&storage::encode(self)?)
 }
}
