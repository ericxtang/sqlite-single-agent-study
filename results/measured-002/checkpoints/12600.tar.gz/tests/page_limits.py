"""Per-file page limits, transactional SQLITE_FULL behavior and local root allocation."""
import json,os,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 if not ok:assert 'full' in r['error'],(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
main='/work/tests/page-limits.db';aux='/work/tests/page-limits-aux.db'
for path in (main,aux):
 try:os.unlink(path)
 except FileNotFoundError:pass
assert req({'op':'open','path':main})['ok'];sql('PRAGMA page_size=512')
assert sql('PRAGMA max_page_count')==[['4294967294']]
sql('CREATE TABLE t(x)');assert sql('PRAGMA max_page_count=1')==[['2']]
assert sql('PRAGMA max_page_count=0')==[['2']]
assert sql("SELECT * FROM pragma_max_page_count('main')")==[['2']]
original=open(main,'rb').read();sql('INSERT INTO t VALUES(zeroblob(5000))',False)
assert sql('SELECT count(*) FROM t')==[['0']];assert open(main,'rb').read()==original
sql('PRAGMA max_page_count=4');sql('BEGIN');sql('INSERT INTO t VALUES(1)');sql('SAVEPOINT s')
sql('INSERT INTO t VALUES(zeroblob(5000))',False);assert sql('SELECT * FROM t')==[['1']]
sql('ROLLBACK TO s');sql('RELEASE s');sql('COMMIT');assert sql('SELECT * FROM t')==[['1']]
sql('PRAGMA max_page_count=100');sql('INSERT INTO t VALUES(zeroblob(5000))');pages=sql('PRAGMA page_count')[0][0]
assert int(pages)>4;assert sql('PRAGMA max_page_count=1')==[[pages]]
# A new attached database has its own page roots and independent limit.
sql(f"ATTACH '{aux}' AS aux");sql('PRAGMA aux.page_size=512');sql('CREATE TABLE aux.t(x)')
assert sql("SELECT rootpage FROM aux.sqlite_schema WHERE name='t'")==[['2']]
assert sql('PRAGMA aux.page_count')==[['2']];assert sql('PRAGMA aux.max_page_count=2')==[['2']]
image=open(main,'rb').read();sql('INSERT INTO aux.t VALUES(zeroblob(10000))',False);assert open(main,'rb').read()==image
sql('PRAGMA aux.max_page_count=100');sql('INSERT INTO aux.t VALUES(zeroblob(10000))');assert open(main,'rb').read()==image
# Temporary schemas also have independent roots and a limited encoded image.
sql('PRAGMA temp.max_page_count=2');sql('CREATE TEMP TABLE temporary(x)')
assert sql('PRAGMA temp.page_count')==[['2']]
sql('INSERT INTO temporary VALUES(zeroblob(30000))',False);assert sql('SELECT count(*) FROM temporary')==[['0']]
assert open(main,'rb').read()==image
req({'op':'close'});assert req({'op':'open','path':main})['ok'];assert sql('PRAGMA max_page_count')==[['4294967294']]
assert sql('SELECT count(*) FROM t')==[['2']];assert sql('PRAGMA integrity_check')==[['ok']]
p.terminate();p.wait();print('PASS: main/attached/temp page limits, SQLITE_FULL rollback, raising limits and independent root pages')
