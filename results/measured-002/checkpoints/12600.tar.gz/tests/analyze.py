"""Document-derived ANALYZE scopes, stat1 prefixes, persistence and transactions."""
import json, os, subprocess
path='/work/tests/analyze.db'
aux='/work/tests/analyze_aux.db'
for name in (path,aux):
 if os.path.exists(name): os.remove(name)
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
def stats(db='main'):
 return sql(f'SELECT tbl,idx,stat FROM {db}.sqlite_stat1 ORDER BY tbl,idx')
assert req({'op':'open','path':path})['ok']
sql('CREATE TABLE t(a TEXT COLLATE NOCASE,b INT)')
sql("INSERT INTO t VALUES('a',1),('A',1),('a',2),('b',3),('B',3),('c',4)")
sql('CREATE INDEX ab ON t(a,b DESC)')
sql('CREATE INDEX part ON t(b) WHERE b=3')
sql('CREATE INDEX expr ON t(length(a),b)')
sql('CREATE TABLE plain(x)');sql('INSERT INTO plain VALUES(1),(2),(3)')
sql('CREATE TABLE empty(x UNIQUE)')
sql('CREATE TABLE w(a,b,c,PRIMARY KEY(a DESC,b)) WITHOUT ROWID')
sql('INSERT INTO w VALUES(1,1,9),(1,2,9),(2,1,10),(2,2,10)')
sql('CREATE INDEX wc ON w(c)')
sql('ANALYZE')
expected=[['plain',None,'3'],['t','ab','6 2 2'],['t','expr','6 6 2'],['t','part','2 2'],['w','w','4 2 1'],['w','wc','4 2']]
assert stats()==expected,stats()
assert sql("SELECT name FROM pragma_table_info('sqlite_stat1')")==[['tbl'],['idx'],['stat']]
assert sql('PRAGMA integrity_check')==[['ok']]
# Statistics are snapshots and individual scopes preserve other entries.
sql("INSERT INTO t VALUES('d',5)")
assert stats()==expected
sql('ANALYZE ab')
expected[1][2]='7 2 2';assert stats()==expected,stats()
sql('BEGIN');sql('ANALYZE t');assert stats()!=expected;sql('ROLLBACK');assert stats()==expected
sql('ANALYZE missing',False);assert stats()==expected
sql("UPDATE sqlite_stat1 SET stat='999 unordered' WHERE idx='ab'")
sql('ANALYZE sqlite_schema')
assert sql("SELECT stat FROM sqlite_stat1 WHERE idx='ab'")==[['999 unordered']]
# Stats rows follow table and autoindex renames, and are removed on DROP.
sql('CREATE TABLE u(a UNIQUE,b)');sql('INSERT INTO u VALUES(1,1),(2,1)');sql('ANALYZE u')
sql('ALTER TABLE u RENAME TO renamed')
assert sql("SELECT tbl,idx,stat FROM sqlite_stat1 WHERE tbl='renamed'")==[['renamed','sqlite_autoindex_renamed_1','2 1']]
sql('ALTER TABLE w RENAME TO wr')
assert sql("SELECT tbl,idx FROM sqlite_stat1 WHERE tbl='wr' ORDER BY idx")==[['wr','wc'],['wr','wr']]
sql('DROP INDEX part');assert sql("SELECT count(*) FROM sqlite_stat1 WHERE idx='part'")==[['0']]
sql('DROP TABLE renamed');assert sql("SELECT count(*) FROM sqlite_stat1 WHERE tbl='renamed'")==[['0']]
for s in ['ALTER TABLE sqlite_stat1 RENAME TO st','ALTER TABLE sqlite_stat1 ADD COLUMN z','CREATE TABLE temp.sqlite_stat1(a,b,c)']:
 sql(s,False)
# Main and attached stats are persisted independently; no-argument excludes temp.
sql(f"ATTACH '{aux}' AS aux")
sql('CREATE TABLE aux.t(x)');sql('INSERT INTO aux.t VALUES(1),(2)')
sql('CREATE TEMP TABLE t(x)');sql('INSERT INTO temp.t VALUES(100)')
sql('ANALYZE')
assert stats('aux')==[['t',None,'2']]
sql('SELECT * FROM temp.sqlite_stat1',False)
sql('ANALYZE temp');assert stats('temp')==[['t',None,'1']]
sql('INSERT INTO temp.t VALUES(200)');sql('ANALYZE t');assert stats('temp')==[['t',None,'2']]
assert sql("SELECT stat FROM main.sqlite_stat1 WHERE idx='ab'")==[['7 2 2']]
for db in ('main','aux','temp'): assert sql(f'PRAGMA {db}.integrity_check')==[['ok']]
saved=stats();assert req({'op':'close'})['ok'];assert req({'op':'open','path':path})['ok'];assert stats()==saved
assert sql('PRAGMA integrity_check')==[['ok']]
sql(f"ATTACH '{aux}' AS aux");assert stats('aux')==[['t',None,'2']]
sql('BEGIN');sql('DROP TABLE sqlite_stat1');sql('SELECT * FROM main.sqlite_stat1',False);sql('ROLLBACK');assert stats()==saved
sql('DROP TABLE main.sqlite_stat1');sql('ANALYZE sqlite_schema');assert stats()==[]
sql("INSERT INTO sqlite_stat1 VALUES('manual',NULL,'42')");assert stats()==[['manual',None,'42']]
sql('ANALYZE main');assert sql("SELECT count(*) FROM main.sqlite_stat1 WHERE tbl='manual'")==[['0']]
p.terminate();p.wait()
print('PASS: ANALYZE statistics, collations, partial/expression/without-rowid indexes, scopes, transactions and persistence')
