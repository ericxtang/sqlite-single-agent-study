"""VACUUM, schema selection, INTO expressions, pending page sizes and failures."""
import json,os,subprocess,struct
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v,ok=True):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());assert r['ok']==ok,(v,r);return r
def sql(s,ok=True):return [[v.get('value') for v in row] for row in req({'op':'execute','sql':s},ok).get('rows',[])]
main='/work/tests/vacuum-main.db';aux='/work/tests/vacuum-aux.db';copy='/work/tests/vacuum-copy.db'
for path in (main,aux,copy):
 try:os.unlink(path)
 except FileNotFoundError:pass
req({'op':'open','path':main});sql('PRAGMA page_size=512')
sql('CREATE TABLE discard(x)');sql('CREATE TABLE t(id INTEGER PRIMARY KEY,v)');sql('CREATE INDEX ti ON t(v)')
sql("INSERT INTO t VALUES(1,'a'),(5,'b')");sql('DROP TABLE discard')
assert int(sql('PRAGMA freelist_count')[0][0])>0
before=sql('SELECT * FROM t ORDER BY id');sql('PRAGMA page_size=4096')
assert sql('PRAGMA page_size')==[['512']]
sql("INSERT INTO t VALUES(9,'c')");before.append(['9','c']);assert struct.unpack_from('>H',open(main,'rb').read(),16)[0]==512
sql('CREATE TEMP TABLE scratch(x)');sql('INSERT INTO scratch VALUES(123)')
sql('BEGIN');sql('VACUUM',False);sql('ROLLBACK')
sql('VACUUM');assert sql('PRAGMA page_size')==[['4096']];assert sql('PRAGMA freelist_count')==[['0']]
assert sql('SELECT * FROM t ORDER BY id')==before;assert sql('SELECT * FROM scratch')==[['123']]
assert struct.unpack_from('>H',open(main,'rb').read(),16)[0]==4096
sql(f"ATTACH '{aux}' AS aux");sql('PRAGMA aux.page_size=512');sql('CREATE TABLE aux.t(x)');sql('INSERT INTO aux.t VALUES(77)')
image=open(main,'rb').read();sql('PRAGMA aux.page_size=8192');sql('VACUUM aux')
assert sql('PRAGMA aux.page_size')==[['8192']];assert struct.unpack_from('>H',open(aux,'rb').read(),16)[0]==8192
assert open(main,'rb').read()==image
sql("VACUUM aux INTO '/work/tests/' || 'vacuum-copy.db'")
assert open(main,'rb').read()==image
sql(f"VACUUM INTO '{copy}'",False);sql('VACUUM nosuch',False);sql('VACUUM INTO NULL',False)
# WAL mode leaves the existing page size; a later rollback-mode VACUUM applies it.
sql('PRAGMA main.journal_mode=WAL');sql('PRAGMA main.page_size=1024');sql('VACUUM main')
assert sql('PRAGMA main.page_size')==[['4096']];assert open(main,'rb').read()[18:20]==bytes([2,2])
sql('PRAGMA main.journal_mode=DELETE');sql('VACUUM main');assert sql('PRAGMA main.page_size')==[['1024']]
req({'op':'close'});req({'op':'open','path':main});assert sql('SELECT * FROM t ORDER BY id')==before
assert sql('PRAGMA page_size')==[['1024']];assert sql('PRAGMA integrity_check')==[['ok']]
req({'op':'open','path':copy});assert sql('SELECT * FROM t')==[['77']];assert sql('PRAGMA page_size')==[['8192']]
req({'op':'close'});p.terminate();p.wait()
print('PASS: VACUUM compaction, pending page sizes, attached schemas, INTO expressions and WAL rules')
