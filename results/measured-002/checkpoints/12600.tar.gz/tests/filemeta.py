"""File-local commits, read-only formats, page counts, and per-connection data versions."""
import json,os,subprocess,struct
BIN=os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')
class Agent:
 def __init__(self,path):
  self.p=subprocess.Popen([BIN],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True);self.req({'op':'open','path':path})
 def req(self,v,ok=True):
  self.p.stdin.write(json.dumps(v)+'\n');self.p.stdin.flush();r=json.loads(self.p.stdout.readline());assert r['ok']==ok,(v,r);return r
 def sql(self,s,ok=True):return [[v.get('value') for v in row] for row in self.req({'op':'execute','sql':s},ok).get('rows',[])]
 def close(self):self.req({'op':'close'});self.p.terminate();self.p.wait()
paths=['/work/tests/filemeta.db','/work/tests/filemeta-aux.db','/work/tests/filemeta-readonly.db','/work/tests/filemeta-copy.db']
for path in paths:
 try:os.unlink(path)
 except FileNotFoundError:pass
a=Agent(paths[0]);initial=a.sql('PRAGMA data_version')
a.sql('PRAGMA page_size=512');a.sql('CREATE TABLE t(x INTEGER PRIMARY KEY,v)');a.sql("INSERT INTO t VALUES(1,zeroblob(10000))")
assert a.sql('PRAGMA data_version')==initial
image=open(paths[0],'rb').read();assert int(a.sql('PRAGMA page_count')[0][0])==len(image)//512
assert int(a.sql('PRAGMA freelist_count')[0][0])==struct.unpack_from('>I',image,36)[0]
b=Agent(paths[0]);before=b.sql('PRAGMA data_version')
a.sql('CREATE TEMP TABLE scratch(x)');a.sql('INSERT INTO scratch VALUES(1)');a.sql('DROP TABLE scratch')
assert open(paths[0],'rb').read()==image;assert b.sql('PRAGMA data_version')==before
# Attaching an existing file and writing only there does not rewrite main.
a.sql(f"ATTACH '{paths[1]}' AS aux");a.sql('CREATE TABLE aux.u(x,v)');a.sql("INSERT INTO aux.u VALUES(1,'aux')")
assert open(paths[0],'rb').read()==image;assert b.sql('PRAGMA data_version')==before
auximage=open(paths[1],'rb').read();c=Agent(paths[1]);auxversion=c.sql('PRAGMA data_version')
b.sql(f"ATTACH '{paths[1]}' AS second")
assert open(paths[1],'rb').read()==auximage;assert c.sql('PRAGMA data_version')==auxversion
own=a.sql('PRAGMA aux.data_version');a.sql('INSERT INTO aux.u VALUES(2,zeroblob(20000))')
assert a.sql('PRAGMA aux.data_version')==own;assert c.sql('PRAGMA data_version')!=auxversion
assert b.sql('SELECT count(*) FROM second.u')==[['2']]
a.sql('UPDATE t SET v=zeroblob(20000)');assert a.sql('PRAGMA data_version')==initial;assert b.sql('PRAGMA data_version')!=before
assert b.sql('SELECT length(v) FROM t')==[['20000']]
# Page statistics include pending writes, and rollback restores the visible counts.
count=a.sql('PRAGMA aux.page_count');a.sql('BEGIN');a.sql('INSERT INTO aux.u VALUES(3,zeroblob(30000))')
assert int(a.sql('PRAGMA aux.page_count')[0][0])>int(count[0][0]);a.sql('ROLLBACK');assert a.sql('PRAGMA aux.page_count')==count
# A dropped root before a retained higher root creates a real freelist page.
a.sql('CREATE TABLE spare(x)');a.sql('CREATE TABLE keeper(x)');a.sql('DROP TABLE spare')
image=open(paths[0],'rb').read();assert int(a.sql('PRAGMA freelist_count')[0][0])==struct.unpack_from('>I',image,36)[0]>0
a.close();b.close();c.close()
# A future write-format version permits reading, temporary work and VACUUM INTO.
readonly=bytearray(image);readonly[18]=3
open(paths[2],'wb').write(readonly)
a=Agent(paths[2]);a.sql('CREATE TEMP TABLE scratch(x)');a.sql('INSERT INTO scratch VALUES(8)')
a.sql('BEGIN');a.sql('INSERT INTO t VALUES(2,1)',False);assert a.sql('SELECT * FROM scratch')==[['8']];a.sql('ROLLBACK')
a.sql(f"ATTACH '{paths[1]}' AS aux");a.sql("INSERT INTO aux.u VALUES(4,'allowed')")
a.sql(f"VACUUM INTO '{paths[3]}'")
assert open(paths[2],'rb').read()==readonly
copy=Agent(paths[3]);assert copy.sql('SELECT count(*) FROM t')==[['1']];copy.close();a.close()
a=Agent(':memory:');a.sql(f"ATTACH '{paths[2]}' AS readonly");a.sql('CREATE TABLE writable(x)');a.sql('INSERT INTO readonly.t VALUES(2,2)',False)
assert a.sql('SELECT count(*) FROM readonly.t')==[['1']];assert open(paths[2],'rb').read()==readonly;a.close()
print('PASS: file-local commits, page statistics, data_version, read-only temp/attached work and VACUUM INTO')
