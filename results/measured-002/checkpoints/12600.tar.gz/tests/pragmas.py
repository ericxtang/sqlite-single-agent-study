"""Journal-mode schema scope and temporary storage lifetime from pragma documentation."""
import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
main='/work/tests/pragmas-main.db';aux='/work/tests/pragmas-aux.db'
for path in (main,aux):
 try:os.unlink(path)
 except FileNotFoundError:pass
assert req({'op':'open','path':main})['ok'];sql('CREATE TABLE t(x)')
sql(f"ATTACH '{aux}' AS aux");sql('CREATE TABLE aux.t(x)');sql("ATTACH ':memory:' AS mem")
assert sql('PRAGMA journal_mode=WAL')==[['wal']]
assert sql('PRAGMA main.journal_mode')==[['wal']];assert sql('PRAGMA aux.journal_mode')==[['wal']];assert sql('PRAGMA mem.journal_mode')==[['memory']]
assert open(main,'rb').read()[18]==2 and open(aux,'rb').read()[18]==2
sql('PRAGMA main.journal_mode=DELETE');assert sql('PRAGMA aux.journal_mode')==[['wal']]
assert open(main,'rb').read()[18]==1 and open(aux,'rb').read()[18]==2
image=open(main,'rb').read();sql('PRAGMA main.journal_mode=PERSIST');assert sql('PRAGMA main.journal_mode')==[['persist']]
assert open(main,'rb').read()==image
assert sql('PRAGMA mem.journal_mode=OFF')==[['off']];assert sql('PRAGMA mem.journal_mode=WAL')==[['off']]
assert sql('PRAGMA mem.journal_mode=MEMORY')==[['memory']]
sql('BEGIN');sql('PRAGMA journal_mode=DELETE',False);sql('ROLLBACK')
assert sql('PRAGMA main.journal_mode')==[['persist']];assert sql('PRAGMA aux.journal_mode')==[['wal']]
sql('PRAGMA journal_mode=DELETE');assert sql('PRAGMA main.journal_mode')==[['delete']];assert sql('PRAGMA aux.journal_mode')==[['delete']]
assert sql('PRAGMA journal_mode=nonsense')==[['delete']]
# Changing storage deletes all kinds of temp objects, leaving persistent bytes alone.
image=open(main,'rb').read();sql('CREATE TEMP TABLE scratch(x)');sql('CREATE INDEX sx ON scratch(x)')
sql('CREATE TEMP VIEW sv AS SELECT * FROM scratch');sql('CREATE TEMP TRIGGER st AFTER INSERT ON main.t BEGIN INSERT INTO scratch VALUES(new.x); END')
sql('INSERT INTO t VALUES(1)');assert sql('SELECT * FROM scratch')==[['1']]
image=open(main,'rb').read();assert len(sql("SELECT * FROM temp.sqlite_schema"))==4
sql('PRAGMA temp_store=MEMORY');assert sql('PRAGMA temp_store')==[['2']]
assert sql('SELECT * FROM temp.sqlite_schema')==[];sql('SELECT * FROM scratch',False)
assert open(main,'rb').read()==image
sql('CREATE TEMP TABLE retained(x)');sql('PRAGMA temp_store=2');sql('INSERT INTO retained VALUES(8)');assert sql('SELECT * FROM retained')==[['8']]
sql('BEGIN');sql('PRAGMA temp_store=FILE',False);sql('ROLLBACK');assert sql('SELECT * FROM retained')==[['8']]
sql('PRAGMA temp_store=FILE');assert sql('PRAGMA temp_store')==[['1']];sql('SELECT * FROM retained',False)
assert open(main,'rb').read()==image
req({'op':'close'});assert req({'op':'open','path':main})['ok'];assert sql('PRAGMA journal_mode')==[['delete']];assert sql('SELECT * FROM t')==[['1']]
p.terminate();p.wait();print('PASS: journal mode schema scope/persistence, memory modes, transaction failures and temp object lifetime')
