"""Once-per-statement uncorrelated subqueries versus correlated row evaluation."""
import json,os,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE t(x)');sql('WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<20) INSERT INTO t SELECT x FROM n')
rows=sql('SELECT x,(SELECT random()),(SELECT random()) FROM t ORDER BY x')
assert len({r[1] for r in rows})==1 and len({r[2] for r in rows})==1
assert rows[0][1]!=rows[0][2]
assert sql('SELECT (SELECT x) FROM t ORDER BY x')==[[str(i)] for i in range(1,21)]
assert sql('SELECT (SELECT (SELECT x)) FROM t ORDER BY x')==[[str(i)] for i in range(1,21)]
assert sql('SELECT (SELECT (SELECT z) FROM(SELECT x+1 z)) FROM t ORDER BY x')==[[str(i)] for i in range(2,22)]
rows=sql('SELECT (SELECT total((SELECT random()+z)) FROM(SELECT 1 z UNION ALL SELECT 2)) FROM t')
assert len({r[0] for r in rows})==1
rows=sql('WITH seed(x) AS(VALUES(10)) SELECT (SELECT random()|x FROM seed) FROM t')
assert len({r[0] for r in rows})==1
assert sql('SELECT (SELECT sum(value) FROM json_each(json_array(t.x))) FROM t ORDER BY x')==[[str(i)] for i in range(1,21)]
assert sql('SELECT (SELECT 99 LIMIT x-1) FROM t ORDER BY x')==[[None]]+[['99']]*19
assert sql('SELECT x IN(SELECT x+1) FROM t')==[['0']]*20
rows=sql('SELECT 1 IN(SELECT random()&1) FROM t');assert len({r[0] for r in rows})==1
assert sql("SELECT value FROM json_each((SELECT '[1,2]'))")==[['1'],['2']]
# Each expansion of a view has its own subquery evaluation site.
sql('CREATE VIEW v AS SELECT x,(SELECT random()) r FROM t')
rows=sql('SELECT a.x,a.r,b.r FROM v a JOIN v b USING(x)')
assert len({r[1] for r in rows})==1 and len({r[2] for r in rows})==1 and rows[0][1]!=rows[0][2]
# Cache lifetime ends between statements, including views whose AST is retained.
next_rows=sql('SELECT r FROM v');assert next_rows[0][0]!=rows[0][1]
# An uncorrelated read in SET is reused despite the updates made by earlier rows.
sql('CREATE TABLE changed(x)');sql('INSERT INTO changed VALUES(1),(2),(3)');sql('UPDATE changed SET x=(SELECT sum(x) FROM changed)')
assert sql('SELECT x FROM changed')==[['6']]*3
# Recursive CTE environments change on each queue extraction and cannot share old results.
assert sql('WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT x+(SELECT 1) FROM n WHERE x<4) SELECT x FROM n')==[['1'],['2'],['3'],['4']]
# Trigger invocation scopes distinguish OLD/NEW bindings and independently parsed statements.
sql('CREATE TABLE log(x)');sql('CREATE TRIGGER tr AFTER INSERT ON changed BEGIN INSERT INTO log VALUES((SELECT new.x)); END')
sql('INSERT INTO changed VALUES(7),(8)');assert sql('SELECT * FROM log')==[['7'],['8']]
p.terminate();p.wait();print('PASS: uncorrelated reuse, nested correlation, CTE/view/trigger scopes, IN caching and statement lifetime')
