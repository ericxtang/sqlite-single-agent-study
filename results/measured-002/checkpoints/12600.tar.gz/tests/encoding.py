"""UTF-8/UTF-16 records, connection casts, encoding persistence and attachment rules."""
import json,subprocess,os,struct
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v,ok=True):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());assert r['ok']==ok,(v,r);return r
def sql(s,ok=True):return [[v.get('value') for v in row] for row in req({'op':'execute','sql':s},ok).get('rows',[])]
for enc,pyenc,code in [('UTF-8','utf-8',1),('UTF-16le','utf-16le',2),('UTF-16be','utf-16be',3)]:
 path=f'/work/tests/encoding-{code}.db';aux=f'/work/tests/encoding-aux-{code}.db';copy=f'/work/tests/encoding-copy-{code}.db'
 for f in (path,aux,copy):
  try:os.unlink(f)
  except FileNotFoundError:pass
 req({'op':'open','path':path});sql(f"PRAGMA encoding='{enc}'");sql('PRAGMA page_size=512')
 assert sql('PRAGMA encoding')==[[enc]]
 sql('CREATE TABLE texts(id INTEGER PRIMARY KEY,t TEXT,u TEXT AS(upper(t)) STORED)');sql('CREATE INDEX ti ON texts(t)')
 text='Aé漢🙂';quoted="'"+text+"'";encoded=text.encode(pyenc)
 sql(f'INSERT INTO texts(id,t) VALUES(1,{quoted}),(2,{quoted}||char(0)||\'Z\')')
 assert sql(f'SELECT hex(CAST({quoted} AS BLOB)),octet_length({quoted}),length({quoted})')==[[encoded.hex().upper(),str(len(encoded)),'4']]
 assert sql(f"SELECT CAST(x'{encoded.hex()}' AS TEXT)")==[[text]]
 num='123.5'.encode(pyenc).hex();assert sql(f"SELECT CAST(x'{num}' AS INTEGER),CAST(x'{num}' AS REAL)")==[['123','123.5']]
 sql("PRAGMA encoding='UTF-8'");assert sql('PRAGMA encoding')==[[enc]]
 sql(f"ATTACH '{aux}' AS aux");assert sql('PRAGMA aux.encoding')==[[enc]]
 sql('CREATE TABLE aux.other(x)');sql(f'INSERT INTO aux.other VALUES({quoted})');sql('DETACH aux')
 sql("INSERT INTO texts(id,t) VALUES(3,printf('%03000d',1))")
 sql(f"VACUUM INTO '{copy}'")
 req({'op':'close'})
 for f in (path,aux,copy):
  data=open(f,'rb').read();assert struct.unpack_from('>I',data,56)[0]==code
  assert 'CREATE TABLE'.encode(pyenc) in data
 req({'op':'open','path':path});assert sql('PRAGMA encoding')==[[enc]]
 assert sql('SELECT t,u FROM texts WHERE id=1')==[[text,text]]
 assert sql('SELECT t FROM texts WHERE id=2')==[[text+'\0Z']]
 assert sql('SELECT length(t) FROM texts WHERE id=3')==[['3000']]
 sql("UPDATE texts SET t=t||'!' WHERE id=1");sql('VACUUM');assert struct.unpack_from('>I',open(path,'rb').read(),56)[0]==code
 if code!=1:
  sql("ATTACH '/work/tests/encoding-1.db' AS wrong",False)
  assert sql('SELECT count(*) FROM texts')==[['3']]
 req({'op':'close'})
req({'op':'open','path':':memory:'});sql("PRAGMA encoding='UTF-16'");assert sql('PRAGMA encoding')==[['UTF-16le']]
p.terminate();p.wait();print('PASS: UTF-8/UTF-16 native records, casts, lengths, encoding preservation, VACUUM and attachment rules')
