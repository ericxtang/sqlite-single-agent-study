import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE t(id,k,v)');sql('INSERT INTO t VALUES(1,1,10),(2,1,20),(3,3,30),(4,4,40),(5,4,50)')
def ck(s,values):assert sql(s)==[[None if v is None else str(v) for v in row] for row in values],s
ck('SELECT sum(v) OVER(ORDER BY k GROUPS BETWEEN 1 PRECEDING AND CURRENT ROW) FROM t ORDER BY id',[[30],[30],[60],[120],[120]])
ck('SELECT sum(v) OVER(ORDER BY k RANGE BETWEEN 1 PRECEDING AND CURRENT ROW) FROM t ORDER BY id',[[30],[30],[30],[120],[120]])
ck('SELECT sum(v) OVER(ORDER BY k DESC RANGE BETWEEN 1 PRECEDING AND CURRENT ROW) FROM t ORDER BY id',[[30],[30],[120],[90],[90]])
ck('SELECT sum(v) OVER(ORDER BY k GROUPS BETWEEN 1 PRECEDING AND 1 FOLLOWING) FROM t ORDER BY id',[[60],[60],[150],[120],[120]])
ck('SELECT sum(v) OVER(ORDER BY k RANGE UNBOUNDED PRECEDING EXCLUDE CURRENT ROW) FROM t ORDER BY id',[[20],[10],[30],[110],[100]])
ck('SELECT sum(v) OVER(ORDER BY k RANGE UNBOUNDED PRECEDING EXCLUDE TIES) FROM t ORDER BY id',[[10],[20],[60],[100],[110]])
ck('SELECT sum(v) OVER(ORDER BY k RANGE UNBOUNDED PRECEDING EXCLUDE GROUP) FROM t ORDER BY id',[[None],[None],[30],[60],[60]])
ck('SELECT count(*) FILTER(WHERE v>=30) OVER(ORDER BY id ROWS 1 PRECEDING) FROM t ORDER BY id',[[0],[0],[1],[2],[2]])
ck('SELECT lag(v,1,0) OVER(ORDER BY id),lead(v,1,0) OVER(ORDER BY id),last_value(v) OVER(ORDER BY id ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING) FROM t ORDER BY id',[[0,20,20],[10,30,30],[20,40,40],[30,50,50],[40,0,50]])
ck('SELECT k,sum(v),rank() OVER(ORDER BY sum(v)),sum(sum(v)) OVER(ORDER BY k) FROM t GROUP BY k ORDER BY k',[[1,30,1,30],[3,30,1,60],[4,90,3,150]])
ck('SELECT k,sum(v),rank() OVER(ORDER BY sum(v)) FROM t GROUP BY k HAVING sum(v)>30',[[4,90,1]])
ck('SELECT row_number() OVER w, sum(v) OVER (w ROWS 1 PRECEDING) FROM t WINDOW w AS (ORDER BY id) ORDER BY id',[[1,10],[2,30],[3,50],[4,70],[5,90]])
sql('SELECT sum(v) OVER(ORDER BY id ROWS -1 PRECEDING) FROM t',False)
sql('SELECT sum(v) OVER(ORDER BY id,k RANGE 1 PRECEDING) FROM t',False)
sql('SELECT nth_value(v,0) OVER(ORDER BY id) FROM t',False)
ck('SELECT sum(v) OVER w FROM t WINDOW w AS(ORDER BY id ROWS 1 PRECEDING) ORDER BY id',[[10],[30],[50],[70],[90]])
ck('SELECT sum(v) OVER(w ORDER BY id ROWS 1 PRECEDING) FROM t WINDOW w AS(PARTITION BY k) ORDER BY id',[[10],[30],[30],[40],[90]])
ck('SELECT sum(v) OVER w3 FROM t WINDOW w1 AS(PARTITION BY k),w2 AS(w1 ORDER BY id),w3 AS(w2 ROWS 1 PRECEDING) ORDER BY id',[[10],[30],[30],[40],[90]])
sql('CREATE TABLE empty(v)')
for q in ['SELECT sum(v) OVER(w) FROM t WINDOW w AS(ROWS UNBOUNDED PRECEDING)','SELECT sum(v) OVER(w PARTITION BY k) FROM t WINDOW w AS(ORDER BY id)','SELECT sum(v) OVER(w ORDER BY id) FROM t WINDOW w AS(ORDER BY k)','SELECT sum(v) OVER w2 FROM t WINDOW w1 AS(ROWS 1 PRECEDING),w2 AS(w1)','SELECT sum(v) OVER(w) FROM empty WINDOW w AS(ROWS UNBOUNDED PRECEDING)','SELECT sum(v) OVER(w PARTITION BY v) FROM empty WINDOW w AS()','SELECT sum(v) OVER w1 FROM t WINDOW w1 AS(w2),w2 AS(w1)']:
 sql(q,False)
# Renaming a source column must preserve bare OVER w when w includes a frame.
sql('CREATE VIEW framed AS SELECT sum(v) OVER w running FROM t WINDOW w AS(ORDER BY id ROWS 1 PRECEDING)')
sql('ALTER TABLE t RENAME COLUMN v TO value');ck('SELECT * FROM framed',[[10],[30],[50],[70],[90]])
p.terminate();p.wait();print('PASS: ROWS/RANGE/GROUPS, peer exclusions, filters, grouped windows, chaining, bounds')
