"""PRAGMA optimize masks/scopes and analysis_limit, from pragma/lang_analyze."""
import os,json,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
assert sql('PRAGMA analysis_limit')==[['0']]
assert sql('PRAGMA analysis_limit=100')==[['100']]
for v in ('-1','1.5',"'abc'"):
 assert sql('PRAGMA analysis_limit='+v)==[['100']]
assert sql('PRAGMA analysis_limit=2147483655')==[['7']]
assert sql('PRAGMA temp.analysis_limit')==[['7']]
assert sql("SELECT * FROM pragma_analysis_limit")==[['7']]
sql('CREATE TABLE t(a,b UNIQUE)')
sql('WITH RECURSIVE n(x) AS(VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<120) INSERT INTO t SELECT x/30,x FROM n')
sql('CREATE INDEX a ON t(a)')
assert sql('PRAGMA optimize(0)')==[]
assert sql("SELECT count(*) FROM sqlite_schema WHERE name='sqlite_stat1'")==[['0']]
plan=sql('PRAGMA optimize(-1)');assert len(plan)==1 and 'ANALYZE' in plan[0][0],plan
assert sql("SELECT count(*) FROM sqlite_schema WHERE name='sqlite_stat1'")==[['0']]
sql('PRAGMA query_only=ON');assert sql('PRAGMA optimize(-1)')==plan;sql('PRAGMA optimize',False);sql('PRAGMA query_only=OFF')
sql('PRAGMA optimize');assert sql('PRAGMA analysis_limit')==[['7']]
assert sql('PRAGMA optimize(-1)')==[]
assert sql("SELECT stat FROM sqlite_stat1 WHERE idx='sqlite_autoindex_t_1'")==[['120 1']]
# A full analysis restores exact prefix counts after approximate sampling.
sql('PRAGMA analysis_limit=0');sql('ANALYZE');assert sql("SELECT stat FROM sqlite_stat1 WHERE idx='a'")==[['120 24']]
# Statistics do not change with DML until optimize detects the factor of ten.
sql('DELETE FROM t WHERE b>10')
# The table was not queried yet: explicit all-table mask is required.
assert sql('PRAGMA optimize(3)')==[]
assert len(sql('PRAGMA optimize(0x10003)'))==1
sql('SELECT * FROM t LIMIT 1');assert len(sql('PRAGMA optimize(3)'))==1
sql('BEGIN');sql('PRAGMA optimize');assert sql("SELECT stat FROM sqlite_stat1 WHERE idx='a'")==[['10 10']];sql('ROLLBACK')
assert sql("SELECT stat FROM sqlite_stat1 WHERE idx='a'")==[['120 24']]
sql('PRAGMA optimize');assert sql('PRAGMA optimize(-1)')==[]
sql("ATTACH ':memory:' AS aux")
sql('CREATE TABLE aux.u(x UNIQUE)');sql('INSERT INTO aux.u VALUES(1),(2)')
sql('CREATE TEMP TABLE z(x UNIQUE)');sql('INSERT INTO temp.z VALUES(1)')
assert len(sql('PRAGMA aux.optimize(-1)'))==1
sql('PRAGMA aux.optimize');assert sql('SELECT tbl,stat FROM aux.sqlite_stat1')==[['u','2 1']]
sql('SELECT * FROM temp.sqlite_stat1',False)
sql('PRAGMA optimize');assert sql('SELECT tbl,stat FROM temp.sqlite_stat1')==[['z','1 1']]
sql('PRAGMA missing.optimize',False)
# Index-only ANALYZE of a WITHOUT ROWID primary key preserves secondary stats.
sql('CREATE TABLE w(a,b,PRIMARY KEY(a,b)) WITHOUT ROWID');sql('CREATE INDEX wb ON w(b)')
sql('INSERT INTO w VALUES(1,1),(1,2)');sql('ANALYZE w');sql('INSERT INTO w VALUES(2,3)')
sql('PRAGMA analysis_limit=1');sql('ANALYZE sqlite_autoindex_w_1')
assert sql("SELECT stat FROM main.sqlite_stat1 WHERE idx='wb'")==[['2 1']]
assert sql("SELECT stat FROM main.sqlite_stat1 WHERE idx='w'")==[['3 1 1']]
assert sql('PRAGMA integrity_check')==[['ok']]
p.terminate();p.wait()
print('PASS: optimize diagnostic/mutation masks, missing/stale stats, query history, scopes and bounded analysis')
