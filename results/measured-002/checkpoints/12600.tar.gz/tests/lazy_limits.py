"""LIMIT and scalar-subquery execution boundaries, retaining complete binding checks."""
import json,os,subprocess
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
assert req({'op':'open','path':':memory:'})['ok']
for q in ['SELECT abs(-9223372036854775808) value LIMIT 0','SELECT abs(-9223372036854775808) value LIMIT 1-1','SELECT sum(abs(-9223372036854775808)) value LIMIT 0','WITH a AS(SELECT abs(-9223372036854775808) x) SELECT x value FROM a LIMIT 0','SELECT 1 value UNION ALL SELECT abs(-9223372036854775808) LIMIT 0']:
 r=req({'op':'execute','sql':q});assert r['ok'] and r['columns']==['value'] and r['rows']==[],(q,r)
sql('CREATE TABLE t(x)');sql('INSERT INTO t VALUES(1),(2),(-9223372036854775808)')
assert sql('SELECT abs(x) FROM t LIMIT 1')==[['1']]
assert sql('SELECT abs(x) FROM t LIMIT 1 OFFSET 1')==[['2']]
assert sql('SELECT x FROM t WHERE abs(x)>0 LIMIT 1')==[['1']]
assert sql('SELECT (SELECT abs(x) FROM t)')==[['1']]
assert sql('SELECT (VALUES(7),(abs(-9223372036854775808)))')==[['7']]
assert sql('SELECT (SELECT 7 UNION ALL SELECT abs(-9223372036854775808))')==[['7']]
assert sql('SELECT 7 UNION ALL SELECT abs(-9223372036854775808) LIMIT 1')==[['7']]
assert sql('SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT abs(-9223372036854775808) LIMIT 1 OFFSET 1')==[['2']]
sql('SELECT abs(x) FROM t LIMIT 1 OFFSET 2',False)
# LIMIT cannot remove the validation of projected names, arity or compound widths.
for q in ['SELECT unknown FROM t LIMIT 0','SELECT length(1,2) LIMIT 0','SELECT 1 UNION ALL SELECT unknown LIMIT 1','SELECT 1 UNION ALL SELECT 2,3 LIMIT 1','SELECT (SELECT 1 UNION ALL SELECT unknown)','SELECT (VALUES(1),(unknown))']:
 sql(q,False)
# Values in a FROM subquery use the documented generated column names.
assert sql('SELECT DISTINCT column1 FROM(VALUES(1),(1),(2),(3)) LIMIT 1 OFFSET 1')==[['2']]
assert sql('SELECT sum(column1) OVER() FROM(VALUES(1),(2),(3)) LIMIT 1')==[['6']]
assert sql('SELECT count(*) FROM t LIMIT 1')==[['3']]
assert sql('SELECT (SELECT x FROM t ORDER BY x DESC LIMIT 2)')==[['2']]
assert sql('SELECT EXISTS(SELECT x FROM t LIMIT 0),EXISTS(SELECT x FROM t LIMIT 1 OFFSET 3)')==[['0','0']]
assert sql('SELECT 1 UNION ALL SELECT 2 LIMIT -1 OFFSET 1')==[['2']]
p.terminate();p.wait();print('PASS: LIMIT 0 metadata, bounded projections and filters, scalar/UNION ALL early completion and binding')
