"""Schema PRAGMAs and documented WITHOUT ROWID record layout, without another engine."""
import json, os, subprocess, struct
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):
 p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());assert r['ok'],(v,r);return r
def sql(s):return [[v.get('value') for v in row] for row in req({'op':'execute','sql':s}).get('rows',[])]
path='/work/tests/introspection.db'
try:os.unlink(path)
except FileNotFoundError:pass
req({'op':'open','path':path})
sql('CREATE TABLE t(a TEXT COLLATE NOCASE,b INT,c,PRIMARY KEY(a COLLATE BINARY DESC,b,a COLLATE NOCASE,a COLLATE BINARY)) WITHOUT ROWID')
sql('CREATE INDEX ib ON t(b)')
sql("INSERT INTO t VALUES('a',1,'lower'),('A',1,'upper'),('z',2,'last')")
assert sql('PRAGMA index_info(t)')==[['0','0','a'],['1','1','b'],['2','0','a']]
expected=[['0','0','a','1','BINARY','1'],['1','1','b','0','BINARY','1'],['2','0','a','0','NOCASE','1'],['3','2','c','0','BINARY','0']]
assert sql('PRAGMA index_xinfo(t)')==expected
assert sql('PRAGMA index_xinfo(sqlite_autoindex_t_1)')==expected
assert sorted(r[1:4] for r in sql('PRAGMA index_list(t)'))==[['ib','0','c'],['sqlite_autoindex_t_1','1','pk']]
assert sql('PRAGMA index_xinfo(ib)')==[['0','1','b','0','BINARY','1'],['1','0','a','1','BINARY','0'],['2','0','a','0','NOCASE','0']]
sql('CREATE TABLE single(k TEXT PRIMARY KEY DESC,v) WITHOUT ROWID')
sql("INSERT INTO single VALUES('a',1),('z',2)")
assert sql('PRAGMA index_xinfo(single)')[0]==['0','0','k','1','BINARY','1']
sql('CREATE TABLE repeated(a,b,c,d,PRIMARY KEY(a,c,a,c)) WITHOUT ROWID')
assert sql('PRAGMA index_info(repeated)')==[['0','0','a'],['1','2','c']]
sql('CREATE TABLE ordinary(id INTEGER PRIMARY KEY,a TEXT COLLATE NOCASE,b INT AS(length(a)),c INT AS(length(a)+1) STORED) STRICT')
sql('CREATE INDEX oi ON ordinary(id,a COLLATE BINARY DESC,length(a)) WHERE a IS NOT NULL')
assert sql('PRAGMA index_xinfo(oi)')==[['0','0','id','0','BINARY','1'],['1','1','a','1','BINARY','1'],['2','-2',None,'0','BINARY','1'],['3','-1',None,'0','BINARY','0']]
sql('CREATE VIEW ov AS SELECT id,a FROM ordinary')
assert sql('PRAGMA table_list(ordinary)')==[['main','ordinary','table','4','0','1']]
assert sql('PRAGMA table_list(ov)')==[['main','ov','view','2','0','0']]
assert len(sql('PRAGMA table_info(ordinary)'))==2
assert [r[-1] for r in sql('PRAGMA table_xinfo(ordinary)')]==['0','0','2','3']
sql('CREATE TEMP TABLE ordinary(other)')
assert sql('PRAGMA table_info(ordinary)')[0][1]=='other'
assert sql('PRAGMA main.table_info(ordinary)')[0][1]=='id'
assert [r[0] for r in sql('PRAGMA temp.table_list')]==['temp','temp']
sql("ATTACH ':memory:' AS aux")
sql('CREATE TABLE aux.child(x REFERENCES t(a))')
assert sql('PRAGMA aux.foreign_key_list(child)')[0][2]=='t'
assert sql('PRAGMA aux.table_list(child)')==[['aux','child','table','1','0','0']]
# Schema-qualified reports read transaction-local state, including missing parents.
sql('CREATE TABLE parent(x PRIMARY KEY)');sql('CREATE TABLE child(x REFERENCES parent(x))');sql('INSERT INTO child VALUES(4)')
sql('INSERT INTO aux.child VALUES(5)')
assert sql('PRAGMA foreign_key_check')==[['child','1','parent','0']]
assert sql('PRAGMA aux.foreign_key_check')==[['child','1','t','0']]
assert sql("SELECT * FROM pragma_foreign_key_check(NULL,'aux')")==[['child','1','t','0']]
assert sql("SELECT name FROM pragma_table_info('ordinary','main')")==[['id'],['a']]
assert sql("SELECT name FROM pragma_table_info('ordinary','temp')")==[['other']]
assert sql("SELECT name FROM pragma_index_list('t','main') ORDER BY name")==[['ib'],['sqlite_autoindex_t_1']]
sql('CREATE TABLE aux.checked(x CHECK(x>0))');sql('PRAGMA ignore_check_constraints=ON');sql('BEGIN');sql('INSERT INTO aux.checked VALUES(-1)')
assert sql('PRAGMA aux.integrity_check')==[['CHECK constraint failed in aux.checked']]
assert sql('PRAGMA main.integrity_check')==[['ok']]
sql('ROLLBACK');sql('PRAGMA ignore_check_constraints=OFF')
# Independently decode small leaf index pages and verify key order and suffixes.
roots={r[0]:int(r[1]) for r in sql("SELECT name,rootpage FROM main.sqlite_schema WHERE rootpage>0")}
req({'op':'close'})
data=open(path,'rb').read();ps=int.from_bytes(data[16:18],'big')
def vi(b,o):
 v=0
 for k in range(9):
  c=b[o];o+=1
  if k==8:return (v<<8)|c,o
  v=(v<<7)|(c&127)
  if c<128:return v,o
def records(name):
 b=data[(roots[name]-1)*ps:roots[name]*ps];assert b[0]==10
 out=[]
 for j in range(int.from_bytes(b[3:5],'big')):
  o=int.from_bytes(b[8+j*2:10+j*2],'big');size,o=vi(b,o);r=b[o:o+size];h,o=vi(r,0);ts=[]
  while o<h:t,o=vi(r,o);ts.append(t)
  row=[];o=h
  for t in ts:
   n=[0,1,2,3,4,6,8,8,0,0][t] if t<10 else (t-12)//2
   a=r[o:o+n];o+=n
   row.append(None if t==0 else t-8 if t in (8,9) else int.from_bytes(a,'big',signed=True) if t<7 else struct.unpack('>d',a)[0] if t==7 else a.decode() if t%2 else a)
  out.append(row)
 return out
assert records('t')==[['z',2,'z','last'],['a',1,'a','lower'],['A',1,'A','upper']]
assert records('ib')==[[1,'a','a'],[1,'A','A'],[2,'z','z']]
assert records('single')==[['z',2],['a',1]]
req({'op':'open','path':path})
assert sql('SELECT a,b,c FROM t ORDER BY a COLLATE BINARY DESC')==[['z','2','last'],['a','1','lower'],['A','1','upper']]
assert sql('PRAGMA index_xinfo(t)')==expected
req({'op':'close'});p.terminate();p.wait()
print('PASS: schema introspection, index key/auxiliary metadata, primary collations and native record order')
