import json,subprocess,os
p=subprocess.Popen([os.environ.get('SQLITE_AGENT_BIN','target/debug/sqlite-agent')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def req(v):p.stdin.write(json.dumps(v)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(s,ok=True):
 r=req({'op':'execute','sql':s});assert r['ok']==ok,(s,r)
 return [[v.get('value') for v in row] for row in r.get('rows',[])]
path='/work/tests/attached.db'
try:os.unlink(path)
except FileNotFoundError:pass
assert req({'op':'open','path':':memory:'})['ok']
sql('CREATE TABLE t(id INTEGER PRIMARY KEY,x)');sql("INSERT INTO t VALUES(1,'main')")
sql(f"ATTACH '{path}' AS aux")
sql('CREATE TABLE aux.t(id INTEGER PRIMARY KEY,x)');sql("INSERT INTO aux.t VALUES(1,'attached')")
assert sql('SELECT main.t.x,aux.t.x FROM main.t JOIN aux.t USING(id)')==[['main','attached']]
sql('BEGIN');sql("UPDATE aux.t SET x='changed'");sql("UPDATE main.t SET x='also changed'");sql('ROLLBACK')
assert sql('SELECT x FROM aux.t')==[['attached']]
sql('CREATE TABLE aux.log(x)')
sql('CREATE TRIGGER aux.tr AFTER INSERT ON aux.t BEGIN INSERT INTO log VALUES(new.x); END')
sql('CREATE VIEW aux.v AS SELECT id,x FROM t')
sql('INSERT INTO aux.t SELECT id+1,x FROM main.t')
assert sql('SELECT * FROM aux.log')==[['main']]
assert sql('SELECT x FROM aux.v ORDER BY id')==[['attached'],['main']]
sql('DETACH aux');sql('SELECT * FROM aux.t',False)
sql(f"ATTACH '{path}' AS other")
assert sql('SELECT x FROM other.t ORDER BY id')==[['attached'],['main']]
assert sql('SELECT x FROM other.v ORDER BY id')==[['attached'],['main']]
sql("INSERT INTO other.t VALUES(3,'third')");assert sql('SELECT * FROM other.log')==[['main'],['third']]
sql('CREATE TEMP TABLE t(x)');sql("INSERT INTO temp.t VALUES('temporary')")
assert sql('SELECT * FROM t')==[['temporary']]
assert sql('SELECT x FROM main.t')==[['main']]
sql('DROP TABLE temp.t');assert sql('SELECT x FROM t')==[['main']]
sql('CREATE TABLE other.seq(id INTEGER PRIMARY KEY AUTOINCREMENT,x)');sql("INSERT INTO other.seq(x) VALUES('one')")
assert sql('SELECT name,seq FROM other.sqlite_sequence')==[['seq','1']]
assert sql('PRAGMA other.table_info(t)')[0][1]=='id'
assert sorted(r[1] for r in sql('PRAGMA database_list'))==['main','other','temp']
sql('DROP TABLE main.t');sql('SELECT * FROM main.t',False)
sql('CREATE TABLE other.u(x UNIQUE)');sql('INSERT INTO other.u VALUES(1)');sql('DETACH other');sql(f"ATTACH '{path}' AS again");sql('INSERT INTO again.u VALUES(1)',False);assert sql("SELECT count(*) FROM again.sqlite_schema WHERE type='index' AND tbl_name='u'")==[['1']];sql('DETACH again')
p.terminate();p.wait();print('PASS: ATTACH/DETACH, qualified joins, transactions, views/triggers, persistence, temporary shadowing')
