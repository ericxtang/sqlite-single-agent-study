use crate::{db::Connection,parser::{Res,colname},query::{Rel,Ctes}};
use std::collections::HashSet;
impl Connection{
 pub(crate) fn reindex(&mut self,name:Option<&str>)->Res<Rel>{
  self.writable()?;let collation=name.filter(|n|!n.contains('.')&&["BINARY","NOCASE","RTRIM"].iter().any(|c|c.eq_ignore_ascii_case(n)));let expressions=name.map_or(false,|n|n.eq_ignore_ascii_case("expressions"));
  let relation=name.and_then(|n|self.object_name(n,"relation")).filter(|n|self.state.tables.contains_key(n));let index=name.and_then(|n|self.object_name(n,"index"));
  let primary=name.and_then(|n|self.search_names(n).into_iter().find_map(|candidate|self.state.tables.values().find(|t|t.without&&crate::introspect::primary_name(t).map_or(false,|n|n.eq_ignore_ascii_case(&candidate))).map(|t|t.name.clone())));
  if name.is_some()&&collation.is_none()&&!expressions&&relation.is_none()&&index.is_none()&&primary.is_none(){return Err("unable to identify the object to be reindexed".into())}
  let mut indexes=vec![];for i in self.state.indexes.values(){let t=self.table_key(&i.table)?;let chosen=if let Some(c)=collation{crate::storage::index_uses_collation(self,i,t,c)}else{name.is_none()||index.as_ref().map_or(false,|n|i.name.eq_ignore_ascii_case(n))||relation.as_ref().map_or(false,|n|i.table.eq_ignore_ascii_case(n))||(expressions&&i.cols.iter().any(|e|colname(e).is_none()))};if chosen{indexes.push(i.clone())}}
  let tables=self.state.tables.values().filter(|t|t.without&&(if let Some(c)=collation{t.primary_key().iter().any(|(_,coll,_)|coll.eq_ignore_ascii_case(c))}else{name.is_none()||relation.as_ref().map_or(false,|n|t.name.eq_ignore_ascii_case(n))||primary.as_ref().map_or(false,|n|t.name.eq_ignore_ascii_case(n))})).cloned().collect::<Vec<_>>();
  let mut schemas=HashSet::new();for i in &indexes{crate::storage::validate_index(self,i,self.table_key(&i.table)?)?;schemas.insert(i.table.split_once('.').map_or("main",|(s,_)|s).to_string());}
  for t in tables{let ctes=Ctes::new();for r in &t.rows{if let Some((_,_,message))=self.unique_conflicts(&t,r,Some(r.id),&ctes)?.first(){return Err(message.clone())}}crate::db::sort_rows(self.state.tables.get_mut(&t.name.to_ascii_lowercase()).unwrap());schemas.insert(t.name.split_once('.').map_or("main",|(s,_)|s).to_string());}
  // This marker participates in transaction/savepoint snapshots but is not stored in SQLite pages.
  for schema in schemas{let generation=self.state.rebuilds.entry(schema).or_default();*generation=generation.wrapping_add(1);}Ok(Rel::default())
 }
}
