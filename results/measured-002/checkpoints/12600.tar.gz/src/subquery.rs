use crate::{ast::Query,db::Connection,parser::Res,query::{Ctx,Field,Rel}};
pub(crate) struct BindingProbe{pub outer_contexts:Vec<usize>,pub correlated:bool}
struct ProbeGuard<'a>(&'a Connection);impl Drop for ProbeGuard<'_>{fn drop(&mut self){self.0.binding_probes.borrow_mut().pop();}}
impl Connection{
 pub(crate) fn note_binding(&self,ctx:&Ctx){let address=ctx as *const Ctx as usize;for p in self.binding_probes.borrow_mut().iter_mut(){if p.outer_contexts.contains(&address){p.correlated=true}}}
 pub(crate) fn bind_subquery(&self,q:&Query,ctx:&Ctx)->Res<Vec<Field>>{
  let mut outers=vec![];let mut outer=Some(ctx);while let Some(c)=outer{outers.push(c as *const Ctx as usize);outer=c.outer;}
  self.binding_probes.borrow_mut().push(BindingProbe{outer_contexts:outers,correlated:false});let _guard=ProbeGuard(self);
  let result=self.query_fields_uncached(q,ctx);if result.is_ok(){let correlated=self.binding_probes.borrow().last().unwrap().correlated;self.subquery_correlated.borrow_mut().insert((q.id,ctx.ctes.generation()),correlated);}result
 }
 pub(crate) fn subquery(&self,q:&Query,ctx:&Ctx,mode:u8)->Res<Rel>{
  if self.shape_only.get(){return self.query_capped(q,ctx.ctes,Some(ctx),if mode==1{None}else{Some(1)})}
  let binding=(q.id,ctx.ctes.generation());if !self.subquery_correlated.borrow().contains_key(&binding){self.bind_subquery(q,ctx)?;}
  let cacheable=!self.subquery_correlated.borrow().get(&binding).copied().unwrap_or(true);let key=(binding.0,binding.1,mode);
  if cacheable{if let Some(r)=self.subquery_cache.borrow().get(&key){return Ok(r.clone())}}
  let result=self.query_capped(q,ctx.ctes,Some(ctx),if mode==1{None}else{Some(1)})?;if cacheable{self.subquery_cache.borrow_mut().insert(key,result.clone());}Ok(result)
 }
}
