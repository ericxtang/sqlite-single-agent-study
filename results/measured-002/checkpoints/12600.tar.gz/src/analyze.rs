//! Persistent table and index cardinalities described by lang_analyze/fileformat2.
use crate::{ast::Column, db::{Connection, Row, State, Table}, parser::Res,
    query::Rel, value::Val};
use std::collections::BTreeMap;

fn schema(name: &str) -> &str { name.split_once('.').map_or("main", |(s, _)| s) }
fn local(name: &str) -> &str { name.rsplit('.').next().unwrap_or(name) }
fn qualified(db: &str, name: &str) -> String {
    if db == "main" { name.into() } else { format!("{}.{}", db, name) }
}
enum Scope { Database, Table(String), Index(String), Primary(String), Reload }

impl Connection {
    pub(crate) fn ensure_stat1(&mut self, db: &str) {
        let name = qualified(db, "sqlite_stat1");
        if self.state.tables.contains_key(&name) { return; }
        let root = self.next_root(&name);
        self.state.tables.insert(name.clone(), Table {
            name, cols: ["tbl", "idx", "stat"].iter().map(|n| Column {
                name: (*n).into(), coll: "BINARY".into(), ..Column::default()
            }).collect(), unique: vec![], checks: vec![], foreign: vec![],
            without: false, strict: false, temp: db == "temp", rows: vec![], seq: 0,
            sql: "CREATE TABLE sqlite_stat1(tbl,idx,stat)".into(), root,
        });
        if db == "main" { self.state.schema_version += 1; }
        else { self.state.schema_meta.entry(db.into()).or_default().schema_version += 1; }
    }

    pub(crate) fn analyze(&mut self, name: Option<&str>) -> Res<Rel> {
        self.writable()?;
        let mut scopes = vec![];
        if let Some(name) = name {
            let key = name.to_ascii_lowercase();
            if key == "main" || key == "temp" || self.attachments.contains_key(&key) {
                scopes.push((key, Scope::Database));
            } else if ["sqlite_schema", "sqlite_master"].contains(&local(&key)) {
                let db = schema(&key);
                if db != "main" && db != "temp" && !self.attachments.contains_key(db) {
                    return Err(format!("unknown database {}", db));
                }
                scopes.push((db.into(), Scope::Reload));
            } else {
                // Resolve a table and index in a single schema search, so a temp
                // index takes precedence over a same-named main table.
                let mut found = None;
                for candidate in self.search_names(name) {
                    if let Some(t) = self.state.tables.get(&candidate) {
                        found = Some((schema(&t.name).into(), Scope::Table(t.name.clone()))); break;
                    }
                    if let Some(i) = self.state.indexes.get(&candidate) {
                        found = Some((schema(&i.table).into(), Scope::Index(i.name.clone()))); break;
                    }
                    if self.state.views.contains_key(&candidate) { return Ok(Rel::default()); }
                    if let Some(t) = self.state.tables.values().find(|t| t.without &&
                        crate::introspect::primary_name(t).map_or(false, |n| n.eq_ignore_ascii_case(&candidate))) {
                        found = Some((schema(&t.name).into(), Scope::Primary(t.name.clone()))); break;
                    }
                }
                scopes.push(found.ok_or_else(|| format!("no such table: {}", name))?);
            }
        } else {
            scopes.push(("main".into(), Scope::Database));
            scopes.extend(self.attachment_order.iter().map(|db| (db.clone(), Scope::Database)));
        }
        for (db, scope) in scopes { self.analyze_scope(&db, scope)?; }
        Ok(Rel::default())
    }

    fn analyze_scope(&mut self, db: &str, scope: Scope) -> Res<()> {
        self.ensure_stat1(db);
        if matches!(scope, Scope::Reload) { return Ok(()); }
        let tables = self.state.tables.values().filter(|t| schema(&t.name) == db &&
            !local(&t.name).to_ascii_lowercase().starts_with("sqlite_") && match &scope {
                Scope::Table(n) | Scope::Primary(n) => t.name.eq_ignore_ascii_case(n),
                Scope::Index(n) => self.state.indexes.get(&n.to_ascii_lowercase())
                    .map_or(false, |i| i.table.eq_ignore_ascii_case(&t.name)),
                _ => true,
            }).cloned().collect::<Vec<_>>();
        let mut values = vec![];
        for t in tables {
            if t.rows.is_empty() { continue; }
            let tbl = Val::Text(local(&t.name).into());
            let mut covered = t.without;
            for i in self.state.indexes.values().filter(|i| i.table.eq_ignore_ascii_case(&t.name)) {
                if matches!(scope, Scope::Primary(_)) { continue; }
                if let Scope::Index(n) = &scope { if !i.name.eq_ignore_ascii_case(n) { continue; } }
                covered |= i.wh.is_none();
                if let Some(stat) = crate::storage::index_statistics(self, i, &t)? {
                    values.push(vec![tbl.clone(), Val::Text(local(&i.name).into()), Val::Text(stat)]);
                }
            }
            if !matches!(scope, Scope::Index(_)) {
                if t.without {
                    values.push(vec![tbl.clone(), tbl, Val::Text(crate::storage::primary_statistics(&t, self.analysis_limit()))]);
                } else if !covered {
                    values.push(vec![tbl, Val::Null, Val::Text(t.rows.len().to_string())]);
                }
            }
        }
        let stats = self.state.tables.get_mut(&qualified(db, "sqlite_stat1")).unwrap();
        stats.rows.retain(|r| match &scope {
            Scope::Database => false,
            Scope::Table(n) => !r.vals[0].text().eq_ignore_ascii_case(local(n)),
            Scope::Index(n) | Scope::Primary(n) => !r.vals[1].text().eq_ignore_ascii_case(local(n)),
            Scope::Reload => true,
        });
        let mut id = stats.rows.iter().map(|r| r.id).max().unwrap_or(0);
        for vals in values {
            id = id.checked_add(1).ok_or("database or disk is full")?;
            stats.rows.push(Row { id, vals, birth: crate::db::row_birth() });
        }
        Ok(())
    }
}

// Schema roots identify existing objects across an ALTER rename. Keep manually
// supplied orphan statistics intact, but remove statistics for dropped objects.
pub(crate) type Catalog = BTreeMap<(String, String, bool), i64>;
pub(crate) fn catalog(state: &State) -> Catalog {
    let mut out = Catalog::new();
    for t in state.tables.values() {
        out.insert((schema(&t.name).into(), local(&t.name).to_ascii_lowercase(), false), t.root);
        if t.without { out.insert((schema(&t.name).into(), local(&t.name).to_ascii_lowercase(), true), t.root); }
    }
    for i in state.indexes.values() {
        out.insert((schema(&i.table).into(), local(&i.name).to_ascii_lowercase(), true), i.root);
    }
    out
}
pub(crate) fn maintain(state: &mut State, before: &Catalog) {
    let mut after = BTreeMap::new();
    for t in state.tables.values() {
        after.insert((schema(&t.name).to_string(), t.root, false), local(&t.name).to_string());
        if t.without { after.insert((schema(&t.name).to_string(), t.root, true), local(&t.name).to_string()); }
    }
    for i in state.indexes.values() {
        after.insert((schema(&i.table).to_string(), i.root, true), local(&i.name).to_string());
    }
    for t in state.tables.values_mut().filter(|t| local(&t.name) == "sqlite_stat1") {
        let db = schema(&t.name).to_string();
        t.rows.retain_mut(|r| {
            for (column, index) in [(0, false), (1, true)] {
                if r.vals[column].null() { continue; }
                let key = (db.clone(), r.vals[column].text().to_ascii_lowercase(), index);
                if let Some(root) = before.get(&key) {
                    if let Some(name) = after.get(&(db.clone(), *root, index)) {
                        r.vals[column] = Val::Text(name.clone());
                    } else { return false; }
                }
            }
            true
        });
    }
}

impl Connection {
    pub(crate) fn analysis_limit(&self) -> usize {
        self.pragmas.get("analysis_limit").map_or(0, |v| v.int() as usize)
    }
    pub(crate) fn set_analysis_limit(&mut self, value: Option<&Val>) -> Rel {
        let number = value.and_then(|v| match v {
            Val::Int(n) => Some(*n), Val::Text(s) => s.parse().ok(), _ => None,
        });
        if let Some(n) = number.filter(|n| *n >= 0) {
            self.pragmas.insert("analysis_limit".into(), Val::Int(n & 0x7fff_ffff));
        }
        Rel::named(&["analysis_limit"], vec![vec![Val::Int(self.analysis_limit() as i64)]])
    }
    pub(crate) fn optimize(&mut self, db: Option<&str>, mask: Option<&Val>) -> Res<Rel> {
        if let Some(db) = db {
            if db != "main" && db != "temp" && !self.attachments.contains_key(db) {
                return Err(format!("unknown database {}", db));
            }
        }
        let mask = mask.map_or(0xfffe, Val::int);
        let debug = mask & 1 != 0;
        let mut targets = vec![];
        if mask & 2 != 0 {
            for t in self.state.tables.values() {
                let schema = schema(&t.name);
                if db.map_or(false, |db| db != schema) ||
                    local(&t.name).to_ascii_lowercase().starts_with("sqlite_") { continue; }
                let rows = self.state.tables.get(&qualified(schema, "sqlite_stat1"))
                    .map(|s| s.rows.as_slice()).unwrap_or(&[]);
                let row = |idx: &str| rows.iter().find(|r| r.vals[0].text().eq_ignore_ascii_case(local(&t.name)) &&
                    r.vals[1].text().eq_ignore_ascii_case(idx));
                let indexes = self.state.indexes.values().filter(|i| i.table.eq_ignore_ascii_case(&t.name))
                    .collect::<Vec<_>>();
                let missing = (t.without && row(local(&t.name)).is_none()) ||
                    indexes.iter().any(|i| row(local(&i.name)).is_none());
                let estimate = rows.iter().filter(|r| r.vals[0].text().eq_ignore_ascii_case(local(&t.name)))
                    .filter(|r| r.vals[1].null() || r.vals[1].text().eq_ignore_ascii_case(local(&t.name)) ||
                        indexes.iter().any(|i| i.wh.is_none() && r.vals[1].text().eq_ignore_ascii_case(local(&i.name))))
                    .filter_map(|r| r.vals[2].text().split_whitespace().next().and_then(|s| s.parse::<usize>().ok()))
                    .max();
                let changed = estimate.map_or(false, |n| n > 0 &&
                    (t.rows.len() >= n.saturating_mul(10) || t.rows.len().saturating_mul(10) <= n));
                let observed = self.observed_tables.borrow().contains(&t.name.to_ascii_lowercase());
                if missing || (changed && (mask & 0x10000 != 0 || observed)) {
                    targets.push((schema.to_string(), t.name.clone()));
                }
            }
        }
        if debug {
            return Ok(Rel::named(&["optimize"], targets.iter().map(|(db,n)| vec![Val::Text(format!(
                "ANALYZE {}.{}", crate::render::ident(db), crate::render::ident(local(n))))]).collect()));
        }
        if targets.is_empty() { return Ok(Rel::default()); }
        // Upgrade the read snapshot before generating statistics. Debug/no-op
        // calls remain usable on query_only and read-only connections.
        self.prepare_access(&crate::ast::Stmt::Analyze(None))?;
        let previous = self.pragmas.get("analysis_limit").cloned();
        if mask & 0x10 != 0 {
            let limit = self.analysis_limit();
            self.pragmas.insert("analysis_limit".into(), Val::Int(if limit == 0 { 2000 } else { limit.min(2000) } as i64));
        }
        let result = (|| {
            for (db, table) in targets { self.analyze_scope(&db, Scope::Table(table))?; }
            Ok(Rel::default())
        })();
        if let Some(v) = previous { self.pragmas.insert("analysis_limit".into(), v); }
        else { self.pragmas.remove("analysis_limit"); }
        result
    }
}
