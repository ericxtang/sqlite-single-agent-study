use crate::{ast::Window,parser::Res};
pub(crate) fn resolve(w:&Window,definitions:&[(String,Window)])->Res<Window>{
 fn walk(w:&Window,definitions:&[(String,Window)],seen:&mut Vec<String>)->Res<Window>{
  let Some(name)=&w.name else{return Ok(w.clone())};
  if seen.len()>=128||seen.iter().any(|n|n.eq_ignore_ascii_case(name)){return Err("circular window definition".into())}seen.push(name.clone());
  let base=definitions.iter().find(|(n,_)|n.eq_ignore_ascii_case(name)).ok_or_else(||format!("no such window: {}",name))?;
  let base=walk(&base.1,definitions,seen)?;
  // A bare OVER name references the complete window, including its frame.
  if !w.chained&&w.partition.is_empty()&&w.order.is_empty()&&w.frame.is_none()&&w.exclude.is_none(){return Ok(base)}
  if !w.partition.is_empty(){return Err(format!("cannot override PARTITION clause of window {}",name))}
  if !base.order.is_empty()&&!w.order.is_empty(){return Err(format!("cannot override ORDER BY clause of window {}",name))}
  if base.frame.is_some(){return Err(format!("cannot override frame specification of window {}",name))}
  let mut out=w.clone();out.name=None;out.chained=false;out.partition=base.partition;if out.order.is_empty(){out.order=base.order}Ok(out)
 }
 walk(w,definitions,&mut vec![])
}
