//! Bind column references before editing schema ASTs, then regenerate stored SQL.
use crate::{ast::*,db::{Connection,Table},query::{Ctes,Field},parser::{Parser,Res},render};
use std::collections::HashMap;
#[derive(Clone)]
struct Scope{fields:Vec<Field>,affected:Vec<bool>}
struct Edit<'a>{conn:&'a Connection,table:&'a str,old:&'a str,new:&'a str,depth:usize}
impl<'a>Edit<'a>{
 fn target(&self,name:&str)->bool{self.conn.table(name).map_or(false,|t|t.name.eq_ignore_ascii_case(self.table))}
 fn reference(&self,n:&[String],scopes:&[Scope])->Res<bool>{let Some(name)=n.last()else{return Ok(false)};if !name.eq_ignore_ascii_case(self.old){return Ok(false)}let qual=n[..n.len()-1].join(".");for scope in scopes{let found=scope.fields.iter().enumerate().filter(|(_,f)|f.name.eq_ignore_ascii_case(name)&&(if n.len()>1{f.table.eq_ignore_ascii_case(&qual)||f.table.rsplit('.').next().map_or(false,|s|s.eq_ignore_ascii_case(&qual))}else{!f.hidden})).collect::<Vec<_>>();if found.len()>1{return Err(format!("ambiguous column name: {}",n.join(".")))}if let Some((i,_))=found.first(){return Ok(scope.affected[*i])}}Ok(false)}
 fn expression(&mut self,e:&mut Expr,scopes:&[Scope],ctes:&Ctes,mapped:&HashMap<String,Vec<bool>>)->Res<bool>{
  let mut changed=false;match e{
   Expr::Col(n)=>{if self.reference(n,scopes)?{*n.last_mut().unwrap()=self.new.into();changed=true}},
   Expr::DQuote(n)=>{if self.reference(&[n.clone()],scopes)?{*n=self.new.into();changed=true}},
   Expr::Sub(q)|Expr::Exists(q)=>{let(_,c)=self.query(q,scopes,ctes,mapped)?;changed=c},
   Expr::In(a,es,q,_)=>{changed|=self.expression(a,scopes,ctes,mapped)?;for e in es{changed|=self.expression(e,scopes,ctes,mapped)?}if let Some(q)=q{changed|=self.query(q,scopes,ctes,mapped)?.1;}},
   _=>{let mut error=None;e.map_children(&mut |child|{let mut child=child.clone();match self.expression(&mut child,scopes,ctes,mapped){Ok(c)=>changed|=c,Err(e)=>error=Some(e)}child});if let Some(e)=error{return Err(e)}}
  }Ok(changed)
 }
 fn query(&mut self,q:&mut Query,outer:&[Scope],inherited:&Ctes,inherited_map:&HashMap<String,Vec<bool>>)->Res<(Vec<bool>,bool)>{
  if self.depth>=50{return Err("circular view while editing schema".into())}self.depth+=1;
  let result=self.query_inner(q,outer,inherited,inherited_map);self.depth-=1;result
 }
 fn query_inner(&mut self,q:&mut Query,outer:&[Scope],inherited:&Ctes,inherited_map:&HashMap<String,Vec<bool>>)->Res<(Vec<bool>,bool)>{
  let local=self.conn.with_ctes(&q.ctes,q.recursive,inherited,None)?;let mut mapped=inherited_map.clone();let mut changed=false;
  for c in &mut q.ctes{let(flags,yes)=self.query(&mut c.query,outer,&local,&mapped)?;mapped.insert(c.name.to_ascii_lowercase(),if c.cols.is_empty(){flags}else{vec![false;c.cols.len()]});changed|=yes;}
  let mut output=vec![];let mut order_scope=None;
  for (ci,core) in q.cores.iter_mut().enumerate(){
   let original=self.conn.from(&core.from,&local,None)?;let mut scopes=vec![Scope{fields:original.fields.clone(),affected:vec![false;original.fields.len()]}];scopes.extend_from_slice(outer);
   let mut cursor=0;for j in &mut core.from{let source_original=self.conn.from(&[Join{source:j.source.clone(),kind:"CROSS".into(),on:None,using:vec![],natural:false}],&local,None)?;let mut flags=vec![false;source_original.fields.len()];
    match &mut j.source{
     Source::Table(n,_,_)=>{if self.target(n){for(i,f)in source_original.fields.iter().enumerate(){flags[i]=f.name.eq_ignore_ascii_case(self.old)}}else if let Some(fs)=mapped.get(&n.to_ascii_lowercase()){for(i,v)in fs.iter().enumerate().take(flags.len()){flags[i]=*v;}}else if let Some(v)=self.conn.state.views.get(&n.to_ascii_lowercase()){let mut vq=v.query.clone();let(fs,_)=self.query(&mut vq,outer,&local,&mapped)?;if v.cols.is_empty(){for(i,v)in fs.iter().enumerate().take(flags.len()){flags[i]=*v;}}}},
     Source::Query(sub,_)=>{let(fs,yes)=self.query(sub,outer,&local,&mapped)?;changed|=yes;for(i,v)in fs.iter().enumerate().take(flags.len()){flags[i]=*v;}},
     Source::Nested(_,_)=>{for(i,f)in source_original.fields.iter().enumerate(){flags[i]=self.target(&f.table)&&f.name.eq_ignore_ascii_case(self.old);}},
    }
    for (i,v) in flags.iter().enumerate(){if cursor+i<scopes[0].affected.len(){scopes[0].affected[cursor+i]=*v}}cursor+=flags.len();
   }
   if ci==0{order_scope=Some(scopes.clone());}
   for row in &mut core.values{for e in row{changed|=self.expression(e,&scopes,&local,&mapped)?;}}
   for it in &mut core.items{
    if ci==0{match &it.expr{Expr::Star(qual)=>{for(i,f)in scopes[0].fields.iter().enumerate(){if !f.hidden&&qual.as_ref().map_or(true,|q|f.table.eq_ignore_ascii_case(q)){output.push(scopes[0].affected[i]);}}},Expr::Col(n)if it.alias.is_none()=>output.push(self.reference(n,&scopes)?),Expr::DQuote(n)if it.alias.is_none()=>output.push(self.reference(&[n.clone()],&scopes)?),_=>output.push(false)}}
    changed|=self.expression(&mut it.expr,&scopes,&local,&mapped)?;
   }
   for j in &mut core.from{if let Some(e)=&mut j.on{changed|=self.expression(e,&scopes,&local,&mapped)?;}for n in &mut j.using{if n.eq_ignore_ascii_case(self.old)&&scopes[0].affected.iter().any(|v|*v){*n=self.new.into();changed=true;}}}
   if let Some(e)=&mut core.wh{changed|=self.expression(e,&scopes,&local,&mapped)?;}if let Some(e)=&mut core.having{changed|=self.expression(e,&scopes,&local,&mapped)?;}for e in &mut core.group{changed|=self.expression(e,&scopes,&local,&mapped)?;}
   for(_,w)in &mut core.windows{for e in &mut w.partition{changed|=self.expression(e,&scopes,&local,&mapped)?}for o in &mut w.order{changed|=self.expression(&mut o.expr,&scopes,&local,&mapped)?}}
  }
  if let Some(scopes)=order_scope{for o in &mut q.order{changed|=self.expression(&mut o.expr,&scopes,&local,&mapped)?;}}
  Ok((output,changed))
 }
 fn table_scope(&mut self,t:&Table,alias:Option<&str>,ctes:&Ctes)->Res<Scope>{let fields=t.fields(alias);let mut affected=fields.iter().map(|f|t.name.eq_ignore_ascii_case(self.table)&&f.name.eq_ignore_ascii_case(self.old)).collect::<Vec<_>>();if let Some(v)=self.conn.state.views.get(&t.name.to_ascii_lowercase()){if v.cols.is_empty(){let (flags,_)=self.query(&mut v.query.clone(),&[],ctes,&HashMap::new())?;for(i,v)in flags.into_iter().enumerate().take(affected.len()){affected[i]=v;}}}Ok(Scope{fields,affected})}
 fn dml(&mut self,s:&mut Stmt,trigger:&Table,ctes:&Ctes)->Res<bool>{
  let empty=HashMap::new();let mut scopes=vec![];for alias in ["old","new"]{scopes.push(self.table_scope(trigger,Some(alias),ctes)?);}
  let mut changed=false;
  match s{
   Stmt::Select(q)=>changed|=self.query(q,&scopes,ctes,&empty)?.1,
   Stmt::Insert{table,cols,query,..}=>{let t=self.conn.table(table).cloned().or_else(|_|self.conn.view_table(table,"INSERT",ctes))?;let target_scope=self.table_scope(&t,None,ctes)?;for n in cols{if self.reference(&[n.clone()],&[target_scope.clone()])?{*n=self.new.into();changed=true}}if let Some(q)=query{changed|=self.query(q,&scopes,ctes,&empty)?.1;}},
   Stmt::Update{table,alias,set,wh,..}=>{let t=self.conn.table(table).cloned().or_else(|_|self.conn.view_table(table,"UPDATE",ctes))?;scopes.insert(0,self.table_scope(&t,alias.as_deref(),ctes)?);for(ns,e)in set{for n in ns{if self.reference(&[n.clone()],&scopes[..1])?{*n=self.new.into();changed=true}}changed|=self.expression(e,&scopes,ctes,&empty)?;}if let Some(e)=wh{changed|=self.expression(e,&scopes,ctes,&empty)?;}},
   Stmt::Delete{table,alias,wh,..}=>{let t=self.conn.table(table).cloned().or_else(|_|self.conn.view_table(table,"DELETE",ctes))?;scopes.insert(0,self.table_scope(&t,alias.as_deref(),ctes)?);if let Some(e)=wh{changed|=self.expression(e,&scopes,ctes,&empty)?;}},_=>()
  }Ok(changed)
 }
}
fn rename(e:&mut Expr,old:&str,new:&str){match e{Expr::Col(ns)=>{if let Some(n)=ns.last_mut(){if n.eq_ignore_ascii_case(old){*n=new.into()}}},Expr::DQuote(n)if n.eq_ignore_ascii_case(old)=>*n=new.into(),_=>e.map_children(&mut |e|{let mut e=e.clone();rename(&mut e,old,new);e})}}
fn mentions(e:&Expr,n:&str)->bool{matches!(e,Expr::Col(ns)if ns.last().map_or(false,|s|s.eq_ignore_ascii_case(n)))||matches!(e,Expr::DQuote(s)if s.eq_ignore_ascii_case(n))||e.children().iter().any(|e|mentions(e,n))}
impl Connection{
 pub(crate) fn rename_column(&mut self,table:&str,old:&str,new:&str,ctes:&Ctes)->Res<()>{
  let mut t=self.table_key(table)?.clone();let index=t.col(old)?;if index>=t.cols.len(){return Err("no such column".into())}if t.cols.iter().any(|c|c.name.eq_ignore_ascii_case(new)){return Err("duplicate column name".into())}
  let mut edit=Edit{conn:self,table,old,new,depth:0};let mut next=self.state.clone();
  for v in next.views.values_mut(){if edit.query(&mut v.query,&[],ctes,&HashMap::new())?.1{v.sql=render::view(v);}}
  for tr in next.triggers.values_mut(){let tt=self.table_key(&tr.table).cloned().or_else(|_|self.view_table(&tr.table,&tr.event,ctes))?;let target_scope=edit.table_scope(&tt,None,ctes)?;let mut changed=false;for n in &mut tr.of{if edit.reference(&[n.clone()],&[target_scope.clone()])?{*n=new.into();changed=true;}}
   if let Some(e)=&mut tr.when{let scopes=vec![edit.table_scope(&tt,Some("old"),ctes)?,edit.table_scope(&tt,Some("new"),ctes)?];changed|=edit.expression(e,&scopes,ctes,&HashMap::new())?;}
   for body in &mut tr.body{let mut stmt=Parser::parse(body)?;if edit.dml(&mut stmt,&tt,ctes)?{*body=render::statement(&stmt).ok_or("cannot rewrite trigger statement")?;changed=true;}}
   if changed{tr.sql=render::trigger(tr);}
  }
  t.cols[index].name=new.into();for c in &mut t.cols{if let Some(e)=&mut c.generated{rename(e,old,new)}}for e in &mut t.checks{rename(e,old,new)}for u in &mut t.unique{for e in &mut u.cols{rename(e,old,new)}}for f in &mut t.foreign{for n in &mut f.cols{if n.eq_ignore_ascii_case(old){*n=new.into()}}}
  for idx in next.indexes.values_mut().filter(|i|i.table.eq_ignore_ascii_case(table)){for e in &mut idx.cols{rename(e,old,new)}if let Some(e)=&mut idx.wh{rename(e,old,new)}if idx.sql.is_some(){idx.sql=Some(render::index(idx));}}
  t.sql=render::table(&t);next.tables.insert(table.to_ascii_lowercase(),t);
  for t in next.tables.values_mut(){let mut changed=false;for f in &mut t.foreign{if self.table_key(&f.table).map_or(false,|p|p.name.eq_ignore_ascii_case(table)){for n in &mut f.target{if n.eq_ignore_ascii_case(old){*n=new.into();changed=true}}}}if changed{t.sql=render::table(t);}}
  self.state=next;
  for t in self.state.tables.values(){self.validate_table(t,ctes)?;}
  for v in self.state.views.values(){self.query(&v.query,ctes,None)?;}
  Ok(())
 }
 pub(crate) fn drop_column(&mut self,table:&str,name:&str,ctes:&Ctes)->Res<()>{
  let mut t=self.table_key(table)?.clone();let index=t.col(name)?;if index>=t.cols.len(){return Err("no such column".into())}if t.cols.len()==1{return Err("cannot drop last column".into())}if t.cols[index].pk>0||t.unique.iter().any(|u|u.cols.iter().any(|e|mentions(e,name))){return Err("cannot drop PRIMARY KEY or UNIQUE column".into())}
  for i in self.state.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(table)){if i.cols.iter().any(|e|mentions(e,name))||i.wh.as_ref().map_or(false,|e|mentions(e,name)){return Err(format!("column is used by index {}",i.name))}}
  for ot in self.state.tables.values(){for f in &ot.foreign{if (ot.name.eq_ignore_ascii_case(table)&&f.cols.iter().any(|n|n.eq_ignore_ascii_case(name)))||(self.table_key(&f.table).map_or(false,|p|p.name.eq_ignore_ascii_case(table))&&f.target.iter().any(|n|n.eq_ignore_ascii_case(name))){return Err("column is used in a foreign key".into())}}}
  // Parse a copy with the column's entire definition removed; its own CHECKs vanish.
  let sql=remove_column_sql(&t.sql,name)?;let Stmt::CreateTable(d)=Parser::parse(&sql)?else{return Err("invalid table definition".into())};
  if d.checks.iter().any(|e|mentions(e,name))||d.cols.iter().any(|c|c.generated.as_ref().map_or(false,|e|mentions(e,name))){return Err("column is used in a CHECK or generated expression".into())}
  let mut edit=Edit{conn:self,table,old:name,new:"__dropped_column__",depth:0};
  for v in self.state.views.values(){let mut q=v.query.clone();if edit.query(&mut q,&[],ctes,&HashMap::new())?.1{return Err(format!("column is used by view {}",v.name))}}
  for tr in self.state.triggers.values(){let tt=self.table_key(&tr.table).cloned().or_else(|_|self.view_table(&tr.table,&tr.event,ctes))?;let target_scope=edit.table_scope(&tt,None,ctes)?;for n in &tr.of{if edit.reference(&[n.clone()],&[target_scope.clone()])?{return Err("column is used by trigger".into())}}let scopes=vec![edit.table_scope(&tt,Some("old"),ctes)?,edit.table_scope(&tt,Some("new"),ctes)?];if let Some(e)=&tr.when{if edit.expression(&mut e.clone(),&scopes,ctes,&HashMap::new())?{return Err("column is used by trigger".into())}}for body in &tr.body{if edit.dml(&mut Parser::parse(body)?,&tt,ctes)?{return Err("column is used by trigger".into())}}}
  t.cols=d.cols;t.unique=d.unique;t.checks=d.checks;t.foreign=d.foreign;t.sql=sql;for r in &mut t.rows{r.vals.remove(index);}self.validate_table(&t,ctes)?;self.state.tables.insert(table.to_ascii_lowercase(),t);Ok(())
 }
}
fn remove_column_sql(sql:&str,name:&str)->Res<String>{let tokens=crate::lex::lex(sql)?;let mut depth=0;let mut begin=None;let mut segments=vec![];for (i,t) in tokens.iter().enumerate(){if t.k==crate::lex::Kind::Symbol&&t.s=="("{if depth==0&&begin.is_none(){begin=Some(i+1)}depth+=1;}else if t.k==crate::lex::Kind::Symbol&&t.s==")"{depth-=1;if depth==0{if let Some(a)=begin.take(){segments.push((a,i));}break}}else if t.k==crate::lex::Kind::Symbol&&t.s==","&&depth==1{if let Some(a)=begin.replace(i+1){segments.push((a,i));}}}let pos=segments.iter().position(|(a,_)|tokens[*a].s.eq_ignore_ascii_case(name)).ok_or("cannot locate column definition")?;let(a,b)=segments[pos];let(start,end)=if pos+1<segments.len(){(tokens[a].start,tokens[b].end)}else{(tokens[a-1].start,tokens[b-1].end)};Ok(format!("{}{}",&sql[..start],&sql[end..]))}
struct TableEdit<'a>{conn:&'a Connection,old:&'a str,new:&'a str}
impl TableEdit<'_>{
 fn target(&self,n:&str,ctes:&[String])->bool{!ctes.iter().any(|c|c.eq_ignore_ascii_case(n))&&self.conn.table(n).map_or(false,|t|t.name.eq_ignore_ascii_case(self.old))}
 fn expression(&self,e:&mut Expr,qualifiers:&[(String,String)],ctes:&[String])->bool{let mut changed=false;match e{
  Expr::Col(ns)if ns.len()>1=>{let qual=ns[..ns.len()-1].join(".");if let Some((_,new))=qualifiers.iter().find(|(old,_)|old.eq_ignore_ascii_case(&qual)){let col=ns.last().unwrap().clone();*ns=new.split('.').map(String::from).collect();ns.push(col);changed=true}},
  Expr::Sub(q)|Expr::Exists(q)=>changed|=self.query(q,qualifiers,ctes),
  Expr::In(e,es,q,_)=>{changed|=self.expression(e,qualifiers,ctes);for e in es{changed|=self.expression(e,qualifiers,ctes)}if let Some(q)=q{changed|=self.query(q,qualifiers,ctes)}},
  _=>e.map_children(&mut |e|{let mut e=e.clone();changed|=self.expression(&mut e,qualifiers,ctes);e})
 }changed}
 fn source(&self,s:&mut Source,qualifiers:&mut Vec<(String,String)>,ctes:&[String])->bool{let mut changed=false;match s{
  Source::Table(n,a,args)=>{for e in args{changed|=self.expression(e,qualifiers,ctes)}if self.target(n,ctes){if a.is_none(){qualifiers.insert(0,(n.clone(),self.new.into()));qualifiers.insert(0,(n.rsplit('.').next().unwrap().into(),self.new.rsplit('.').next().unwrap().into()));}*n=self.new.into();changed=true}},
  Source::Query(q,_)=>changed|=self.query(q,qualifiers,ctes),Source::Nested(js,_)=>for j in js{changed|=self.source(&mut j.source,qualifiers,ctes)}
 }changed}
 fn query(&self,q:&mut Query,outer:&[(String,String)],inherited:&[String])->bool{let mut ctes=inherited.to_vec();ctes.extend(q.ctes.iter().map(|c|c.name.clone()));let mut changed=false;for c in &mut q.ctes{changed|=self.query(&mut c.query,outer,&ctes)}let mut first=outer.to_vec();for(i,c)in q.cores.iter_mut().enumerate(){let mut quals=outer.to_vec();for j in &mut c.from{changed|=self.source(&mut j.source,&mut quals,&ctes)}if i==0{first=quals.clone()}for it in &mut c.items{if let Expr::Star(Some(n))=&mut it.expr{if let Some((_,new))=quals.iter().find(|(old,_)|old.eq_ignore_ascii_case(n)){*n=new.clone();changed=true}}changed|=self.expression(&mut it.expr,&quals,&ctes)}for row in &mut c.values{for e in row{changed|=self.expression(e,&quals,&ctes)}}for j in &mut c.from{if let Some(e)=&mut j.on{changed|=self.expression(e,&quals,&ctes)}}if let Some(e)=&mut c.wh{changed|=self.expression(e,&quals,&ctes)}if let Some(e)=&mut c.having{changed|=self.expression(e,&quals,&ctes)}for e in &mut c.group{changed|=self.expression(e,&quals,&ctes)}for(_,w)in &mut c.windows{for e in &mut w.partition{changed|=self.expression(e,&quals,&ctes)}for o in &mut w.order{changed|=self.expression(&mut o.expr,&quals,&ctes)}}}for o in &mut q.order{changed|=self.expression(&mut o.expr,&first,&ctes)}changed}
 fn statement(&self,s:&mut Stmt)->bool{let mut changed=false;match s{
  Stmt::Select(q)=>changed|=self.query(q,&[],&[]),
  Stmt::With(cs,_,s)=>{for c in cs{changed|=self.query(&mut c.query,&[],&[])}changed|=self.statement(s)},
  Stmt::Insert{table,query,upsert,ret,..}=>{let mut quals=vec![];if self.target(table,&[]){quals.push((table.clone(),self.new.into()));*table=self.new.into();changed=true}if let Some(q)=query{changed|=self.query(q,&quals,&[])}for u in upsert{for(_,e)in &mut u.set{changed|=self.expression(e,&quals,&[])}if let Some(e)=&mut u.wh{changed|=self.expression(e,&quals,&[])}}for it in ret{changed|=self.expression(&mut it.expr,&quals,&[])}},
  Stmt::Update{table,alias,set,wh,from,ret,order,..}=>{let mut quals=vec![];if self.target(table,&[]){if alias.is_none(){quals.push((table.clone(),self.new.into()))}*table=self.new.into();changed=true}for j in from{changed|=self.source(&mut j.source,&mut quals,&[])}for(_,e)in set{changed|=self.expression(e,&quals,&[])}if let Some(e)=wh{changed|=self.expression(e,&quals,&[])}for it in ret{changed|=self.expression(&mut it.expr,&quals,&[])}for o in order{changed|=self.expression(&mut o.expr,&quals,&[])}},
  Stmt::Delete{table,alias,wh,ret,order,..}=>{let mut quals=vec![];if self.target(table,&[]){if alias.is_none(){quals.push((table.clone(),self.new.into()))}*table=self.new.into();changed=true}if let Some(e)=wh{changed|=self.expression(e,&quals,&[])}for it in ret{changed|=self.expression(&mut it.expr,&quals,&[])}for o in order{changed|=self.expression(&mut o.expr,&quals,&[])}},_=>()
 }changed}
}
impl Connection{
 pub(crate) fn rename_table(&mut self,old:&str,new:&str,ctes:&Ctes)->Res<()>{
  if self.state.tables.contains_key(&new.to_ascii_lowercase())||self.state.views.contains_key(&new.to_ascii_lowercase())||self.state.indexes.contains_key(&new.to_ascii_lowercase()){return Err("there is already an object with this name".into())}if new.rsplit('.').next().unwrap_or(new).to_ascii_lowercase().starts_with("sqlite_"){return Err("object name reserved for internal use".into())}
  let edit=TableEdit{conn:self,old,new};let mut next=self.state.clone();
  for v in next.views.values_mut(){if edit.query(&mut v.query,&[],&[]){v.sql=render::view(v)}}
  for tr in next.triggers.values_mut(){let mut changed=false;if tr.table.eq_ignore_ascii_case(old){tr.table=new.into();changed=true}if let Some(e)=&mut tr.when{changed|=edit.expression(e,&[],&[])}for body in &mut tr.body{let mut st=Parser::parse(body)?;if edit.statement(&mut st){*body=render::statement(&st).ok_or("cannot rewrite trigger")?;changed=true}}if changed{tr.sql=render::trigger(tr)}}
  let mut t=next.tables.remove(&old.to_ascii_lowercase()).ok_or("no such table")?;t.name=new.into();t.sql=render::table(&t);next.tables.insert(new.to_ascii_lowercase(),t);
  for t in next.tables.values_mut(){let mut changed=false;for f in &mut t.foreign{if self.table_key(&f.table).map_or(false,|p|p.name.eq_ignore_ascii_case(old)){f.table=new.into();changed=true;}}if changed{t.sql=render::table(t);}if t.name.rsplit('.').next()==Some("sqlite_sequence")&&t.name.rsplit_once('.').map(|(s,_)|s)==old.rsplit_once('.').map(|(s,_)|s){for row in &mut t.rows{if row.vals.first().map_or(false,|v|v.text().eq_ignore_ascii_case(old.rsplit('.').next().unwrap())){row.vals[0]=crate::value::Val::Text(new.rsplit('.').next().unwrap().into());}}}}
  let mut indexes=std::collections::BTreeMap::new();for(_,mut i)in next.indexes{if i.table.eq_ignore_ascii_case(old){i.table=new.into();if i.sql.is_some(){i.sql=Some(render::index(&i))}else if let Some(suffix)=i.name.rsplit('_').next(){let prefix=new.rsplit_once('.').map_or(String::new(),|(s,_)|format!("{}.",s));i.name=format!("{}sqlite_autoindex_{}_{}",prefix,new.rsplit('.').next().unwrap(),suffix)}}indexes.insert(i.name.to_ascii_lowercase(),i);}next.indexes=indexes;
  self.state=next;for v in self.state.views.values(){self.query(&v.query,ctes,None)?;}Ok(())
 }
}
