use crate::{db::{Connection,State},parser::Res,query::Rel,value::Val,schema,storage};
pub const MAX_PAGES:i64=4_294_967_294;
impl Connection{
 pub(crate) fn schema_snapshot(&self,db:&str)->Res<Connection>{
  let mut c=Connection::open(":memory:")?;
  if db=="main"{c.state=schema::main_state(&self.state);c.pragmas=self.pragmas.clone();c.path=self.path.clone();c.file_version=self.file_version;*c.main_disk_state.borrow_mut()=self.main_disk_state.borrow().clone();}
  else if db=="temp"{c.state=schema::export(&self.state,db,&State::default());for t in c.state.tables.values_mut(){t.temp=false}for v in c.state.views.values_mut(){v.temp=false}for t in c.state.triggers.values_mut(){t.temp=false}c.pragmas=self.pragmas.clone();c.pragmas.insert("journal_mode".into(),Val::Text("memory".into()));c.pragmas.insert("max_page_count".into(),Val::Int(self.page_limit(db)?));}
  else{let child=self.attachments.get(db).ok_or_else(||format!("unknown database {}",db))?.borrow();c.state=schema::export(&self.state,db,&child.state);c.pragmas=child.pragmas.clone();c.path=child.path.clone();c.file_version=child.file_version;*c.main_disk_state.borrow_mut()=child.state.clone();}Ok(c)
 }
 pub(crate) fn page_limit(&self,db:&str)->Res<i64>{Ok(if db=="main"{self.pragmas.get("max_page_count").map_or(MAX_PAGES,Val::int)}else if db=="temp"{self.pragmas.get("temp_max_page_count").map_or(MAX_PAGES,Val::int)}else{self.attachments.get(db).ok_or_else(||format!("unknown database {}",db))?.borrow().pragmas.get("max_page_count").map_or(MAX_PAGES,Val::int)})}
 pub(crate) fn set_page_limit(&mut self,db:&str,value:Option<&Val>)->Res<Rel>{
  let mut maximum=self.page_limit(db)?;if let Some(value)=value{let requested=value.int();if requested>0{let pages=self.schema_snapshot(db)?.page_statistics()?.0;maximum=requested.min(MAX_PAGES).max(pages);if db=="main"{self.pragmas.insert("max_page_count".into(),Val::Int(maximum));}else if db=="temp"{self.pragmas.insert("temp_max_page_count".into(),Val::Int(maximum));}else{self.attachments[db].borrow_mut().pragmas.insert("max_page_count".into(),Val::Int(maximum));}}}Ok(Rel::named(&["max_page_count"],vec![vec![Val::Int(maximum)]]))
 }
 pub(crate) fn check_page_limits(&self,before:&State)->Res<()>{
  for db in ["main","temp"].into_iter().chain(self.attachment_order.iter().map(String::as_str)){if self.page_limit(db)?==MAX_PAGES{continue}let current=self.schema_snapshot(db)?;let previous=if db=="main"{schema::main_state(before)}else{let mut s=schema::export(before,db,&current.state);if db=="temp"{for t in s.tables.values_mut(){t.temp=false}for v in s.views.values_mut(){v.temp=false}for t in s.triggers.values_mut(){t.temp=false}}s};if !schema::same_data(&current.state,&previous){storage::encode(&current)?;}}
  Ok(())
 }
}
