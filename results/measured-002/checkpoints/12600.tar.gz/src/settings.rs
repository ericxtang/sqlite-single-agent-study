use crate::{db::Connection,parser::Res,value::Val,query::Rel};
impl Connection{
 pub(crate) fn journal_mode_result(&self,db:&str)->Res<Rel>{let v=if db=="main"{self.pragmas.get("journal_mode").cloned().unwrap()}else if db=="temp"{self.pragmas.get("temp_journal_mode").cloned().unwrap_or(Val::Text("memory".into()))}else{self.attachments.get(db).ok_or_else(||format!("unknown database {}",db))?.borrow().pragmas.get("journal_mode").cloned().unwrap()};Ok(Rel::named(&["journal_mode"],vec![vec![v]]))}
 pub(crate) fn set_journal_mode(&mut self,db:Option<&str>,value:&Val)->Res<Rel>{
  let mode=value.text().to_ascii_lowercase();let selected=db.unwrap_or("main");self.journal_mode_result(selected)?;
  if !["delete","truncate","persist","memory","wal","off"].contains(&mode.as_str()){return self.journal_mode_result(selected)}
  let schemas=db.map_or_else(||std::iter::once("main".to_string()).chain(self.attachment_order.iter().cloned()).collect::<Vec<_>>(),|s|vec![s.into()]);
  let mut changes=vec![];
  for schema in schemas{let old=self.journal_mode_result(&schema)?.rows[0][0].clone();let disk=if schema=="main"{self.path.is_some()}else if schema=="temp"{false}else{self.attachments[&schema].borrow().path.is_some()};let new=if !disk&&mode!="memory"&&mode!="off"{old.text()}else{mode.clone()};if old.text()==new{continue}if !self.tx.is_empty(){return Err("cannot change journal mode from within a transaction".into())}
   let header=disk&&((old.text()=="wal")!=(new=="wal"));let readonly=if schema=="main"{self.read_only_file}else if schema=="temp"{false}else{self.attachments[&schema].borrow().read_only_file};if header&&readonly{return Err("attempt to write a readonly database".into())}changes.push((schema,old,Val::Text(new),header));
  }
  for(db,_,new,header)in &changes{if db=="main"{self.pragmas.insert("journal_mode".into(),new.clone());if *header{self.file_settings_dirty.set(true)}}else if db=="temp"{self.pragmas.insert("temp_journal_mode".into(),new.clone());}else{let mut c=self.attachments[db].borrow_mut();c.pragmas.insert("journal_mode".into(),new.clone());if *header{c.file_settings_dirty.set(true)}}}
  if changes.iter().any(|(_,_,_,header)|*header){if let Err(e)=self.persist(){for(db,old,_,_)in changes{if db=="main"{self.pragmas.insert("journal_mode".into(),old);self.file_settings_dirty.set(false)}else if db=="temp"{self.pragmas.insert("temp_journal_mode".into(),old);}else{let mut c=self.attachments[&db].borrow_mut();c.pragmas.insert("journal_mode".into(),old);c.file_settings_dirty.set(false)}}return Err(e)}}
  self.journal_mode_result(selected)
 }
 pub(crate) fn set_temp_store(&mut self,value:&Val)->Res<()>{
  let n=match value.text().to_ascii_lowercase().as_str(){"file"=>1,"memory"=>2,"default"=>0,_=>{let n=value.int();if (0..=2).contains(&n){n}else{0}}};if self.pragmas.get("temp_store").map_or(0,Val::int)==n{return Ok(())}
  if !self.tx.is_empty(){return Err("temporary storage cannot be changed from within a transaction".into())}
  self.state.tables.retain(|name,_|!name.starts_with("temp."));self.state.indexes.retain(|name,_|!name.starts_with("temp."));self.state.views.retain(|name,_|!name.starts_with("temp."));self.state.triggers.retain(|name,_|!name.starts_with("temp."));self.state.schema_meta.remove("temp");self.pragmas.remove("temp_journal_mode");self.pragmas.insert("temp_store".into(),Val::Int(n));Ok(())
 }
}
