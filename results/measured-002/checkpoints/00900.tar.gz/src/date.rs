use crate::{value::Val,parser::Res};
pub fn call(_n:&str,_a:&[Val])->Res<Val>{Ok(Val::Null)}
