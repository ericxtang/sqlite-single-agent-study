use crate::{value::Val,parser::Res};
pub fn call(n:&str,_a:&[Val])->Res<Val>{Err(format!("no such function: {}",n))}
