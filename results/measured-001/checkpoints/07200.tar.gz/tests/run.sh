#!/usr/bin/env bash
set -euo pipefail
cd /work
cargo build --release --offline --bin sqlite-agent
python3 tests/smoke.py
python3 tests/regression.py
python3 tests/properties.py
python3 tests/persistence.py
