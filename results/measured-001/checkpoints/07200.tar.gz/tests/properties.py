"""Deterministic properties derived from documented SQL arithmetic/NULL rules."""
import itertools,json,random,subprocess
p=subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
def send(o):
 p.stdin.write(json.dumps(o)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def q(s):
 r=send({'op':'execute','sql':s});assert r['ok'],(s,r)
 return [[None if c['type']=='null' else int(c['value']) if c['type']=='integer' else float(c['value']) if c['type']=='real' else c['value'] for c in row]for row in r['rows']]
send({'op':'open','path':':memory:'})
rng=random.Random(4182);n=0
for _ in range(250):
 a=rng.randrange(-1000000,1000001);b=rng.randrange(-1000000,1000001)
 div=None if b==0 else (abs(a)//abs(b))*(-1 if (a<0)!=(b<0) else 1)
 mod=None if b==0 else a-div*b
 want=[[a+b,a-b,a*b,div,mod,a&b,a|b,int(a<b),int(a==b)]]
 sql=f'SELECT ({a})+({b}),({a})-({b}),({a})*({b}),({a})/({b}),({a})%({b}),({a})&({b}),({a})|({b}),({a})<({b}),({a})=({b})'
 assert q(sql)==want,(sql,q(sql),want);n+=1
for a,b in itertools.product([None,0,1],repeat=2):
 sa='NULL' if a is None else str(a);sb='NULL' if b is None else str(b)
 and_=0 if a==0 or b==0 else None if a is None or b is None else 1
 or_=1 if a==1 or b==1 else None if a is None or b is None else 0
 eq=None if a is None or b is None else int(a==b)
 assert q(f'SELECT {sa} AND {sb},{sa} OR {sb},{sa}={sb},{sa} IS {sb}')==[[and_,or_,eq,int(a==b)]];n+=1
q('CREATE TABLE t(id INTEGER PRIMARY KEY,x UNIQUE,y INTEGER CHECK(y>=0))')
q('INSERT INTO t VALUES(1,1,1),(2,2,2)')
for conflict in ['ABORT','ROLLBACK','FAIL','IGNORE','REPLACE']:
 q('SAVEPOINT p')
 r=send({'op':'execute','sql':f'INSERT OR {conflict} INTO t VALUES(3,3,3),(4,1,4)'})
 if conflict in ['ABORT','ROLLBACK']:assert not r['ok'];assert q('SELECT id FROM t ORDER BY id')==[[1],[2]]
 elif conflict=='FAIL':assert not r['ok'];assert q('SELECT id FROM t ORDER BY id')==[[1],[2],[3]]
 elif conflict=='IGNORE':assert r['ok'];assert q('SELECT id FROM t ORDER BY id')==[[1],[2],[3]]
 else:assert r['ok'];assert q('SELECT id FROM t ORDER BY id')==[[2],[3],[4]]
 if conflict!='ROLLBACK':q('ROLLBACK TO p');q('RELEASE p')
 n+=1
# Schema/data changes participate in transaction rollback together.
q('BEGIN');q('CREATE TABLE transient(x)');q('INSERT INTO transient VALUES(7)');q('ROLLBACK')
assert not send({'op':'execute','sql':'SELECT * FROM transient'})['ok'];n+=1
# Malformed statements must not kill or desynchronize the process.
for bad in ['SELECT','SELECT (','CREATE TABLE','INSERT INTO t VALUES(','SELECT 1 +','SELECT x FROM no_such_table','UPDATE t SET','DELETE FROM','SELECT x FROM t ORDER BY 999','SELECT abs(-9223372036854775808)']:
 assert not send({'op':'execute','sql':bad})['ok'],bad
 assert q('SELECT 42')==[[42]];n+=1
p.terminate();print(f'{n} arithmetic, NULL, conflict, transaction and error-recovery properties passed')
