use crate::value::Value;
use crate::parser::Res;
thread_local!{
    static STATEMENT_NOW:std::cell::Cell<Option<f64>>=const{
        std::cell::Cell::new(None)
    }
    ;
}
fn clock_now()->f64{
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d|d.as_secs_f64()).unwrap_or(0.0)
}
pub fn begin_statement(){
    STATEMENT_NOW.with(|t|t.set(Some(clock_now())))
}
fn now()->f64{
    STATEMENT_NOW.with(|t|t.get()).unwrap_or_else(clock_now)
}
pub fn current(n:&str)->Res<Value>{
    call(match n.to_ascii_uppercase().as_str(){
        "CURRENT_DATE"=>"date","CURRENT_TIME"=>"time",_=>"datetime"
    }
    ,&[])
}
pub fn call(n:&str,a:&[Value])->Res<Value>{
    if a.iter().any(Value::null){
        return Ok(Value::Null)
    }
    let off=usize::from(n=="strftime");
    if off==1&&a.is_empty(){
        return Ok(Value::Null)
    }
    if n=="timediff"{
        if a.len()!=2{
            return Err("wrong number of arguments to function timediff()".into())
        }
        let(x,y)=(parse(&a[0],false),parse(&a[1],false));
        if let(Some(x),Some(y))=(x,y){
            return Ok(Value::Text(timedifference(x,y)))
        }
        return Ok(Value::Null)
    }
    let subfirst=a.get(off).is_some_and(|v|["subsec","subsecond"].contains(&v.text().to_lowercase().as_str()));
    let modifiers=&a[(off+usize::from(a.len()>off&&!subfirst)).min(a.len())..];
    let unix=modifiers.first().is_some_and(|v|v.text().eq_ignore_ascii_case("unixepoch"));
    let auto=modifiers.first().is_some_and(|v|v.text().eq_ignore_ascii_case("auto"));
    let v=a.get(off).cloned().unwrap_or(Value::Text("now".into()));
    let numeric=v.text().parse::<f64>().ok();
    let mut sec=if subfirst{
        now()
    }
    else if let Some(x)=parse(&v,unix||(auto&&numeric.is_some_and(|v|!(0.0..=5373484.499999).contains(&v)))){
        x
    }
    else{
        return Ok(Value::Null)
    }
    ;
    let mut sub=false;
    let mut overflow_days=0;
    for v in modifiers{
        let m=v.text().to_ascii_lowercase();
        match m.as_str(){
            "unixepoch"|"auto"|"julianday"|"utc"|"localtime"=>{
            }
            ,"subsec"|"subsecond"=>sub=true,"ceiling"=>overflow_days=0,"floor"=>{
                sec-=overflow_days as f64*86400.0;
                overflow_days=0
            }
            ,"start of day"=>sec=(sec/86400.0).floor()*86400.0,"start of month"|"start of year"=>{
                let(y,mo,_)=civil((sec/86400.0).floor() as i64);
                sec=days(y,if m=="start of year"{
                    1
                }
                else{
                    mo
                }
                ,1) as f64*86400.0
            }
            ,_=>{
                if let Some(s)=m.strip_prefix("weekday "){
                    if let Ok(d)=s.parse::<i64>(){
                        if !(0..=6).contains(&d){
                            return Ok(Value::Null)
                        }
                        let current=((sec/86400.0).floor() as i64+4).rem_euclid(7);
                        sec+=(d-current).rem_euclid(7) as f64*86400.0;
                    }
                    else{
                        return Ok(Value::Null)
                    }
                }
                else{
                    let mut parts=m.split_whitespace();
                    let amount=parts.next().and_then(|s|s.parse::<f64>().ok());
                    let unit=parts.next().unwrap_or("").trim_end_matches('s');
                    if let Some(x)=amount{
                        match unit{
                            "day"=>sec+=x*86400.0,"hour"=>sec+=x*3600.0,"minute"=>sec+=x*60.0,"second"=>sec+=x,"month"|"year"=>{
                                let(y,mo,d)=civil((sec/86400.0).floor() as i64);
                                let delta=if unit=="year"{
                                    x*12.0
                                }
                                else{
                                    x
                                }
                                ;
                                let total=y*12+mo-1+delta as i64;
                                let ny=total.div_euclid(12);
                                let nm=total.rem_euclid(12)+1;
                                let maxday=days(ny,if nm==12{
                                    1
                                }
                                else{
                                    nm+1
                                }
                                ,1)+if nm==12{
                                    days(ny+1,1,1)-days(ny,1,1)
                                }
                                else{
                                    0
                                }
                                -days(ny,nm,1);
                                overflow_days=(d-maxday).max(0);
                                sec=days(ny,nm,d) as f64*86400.0+sec.rem_euclid(86400.0)+(delta.fract()*30.0)*86400.0
                            }
                            ,_=>return Ok(Value::Null)
                        }
                    }
                    else if m.starts_with('+')||m.starts_with('-'){
                        let sign=if m.starts_with('-'){
                            -1.0
                        }
                        else{
                            1.0
                        }
                        ;
                        let shift=&m[1..];
                        if shift.len()>=10&&shift.as_bytes()[4]==b'-'&&shift.as_bytes()[7]==b'-'{
                            let yy=shift[..4].parse::<i64>().ok();
                            let mm=shift[5..7].parse::<i64>().ok();
                            let dd=shift[8..10].parse::<i64>().ok();
                            if let(Some(yy),Some(mm),Some(dd))=(yy,mm,dd){
                                sec=shift_months(sec,(sign as i64)*(yy*12+mm))+sign*dd as f64*86400.0;
                                let time=shift[10..].trim();
                                if !time.is_empty(){
                                    if let Some(time)=parse_time(time){
                                        sec+=sign*time
                                    }
                                    else{
                                        return Ok(Value::Null)
                                    }
                                }
                            }
                            else{
                                return Ok(Value::Null)
                            }
                        }
                        else if let Some(d)=parse_time(shift){
                            sec+=sign*d
                        }
                        else{
                            return Ok(Value::Null)
                        }
                    }
                    else{
                        return Ok(Value::Null)
                    }
                }
            }
        }
    }
    if !(-210866760000.0..253402300800.0).contains(&sec){
        return Ok(Value::Null)
    }
    sec=(sec*1000.0).round()/1000.0;
    let day=(sec/86400.0).floor() as i64;
    let(y,m,d)=civil(day);
    let sod=sec.rem_euclid(86400.0);
    let h=(sod/3600.0).floor() as i64;
    let mi=((sod%3600.0)/60.0).floor() as i64;
    let ss=sod%60.0;
    let date=format!("{:04}-{:02}-{:02}",y,m,d);
    let time=if sub{
        format!("{:02}:{:02}:{:06.3}",h,mi,ss)
    }
    else{
        format!("{:02}:{:02}:{:02}",h,mi,ss as i64)
    }
    ;
    Ok(match n{
        "date"=>Value::Text(date),"time"=>Value::Text(time),"datetime"=>Value::Text(format!("{} {}",date,time)),"julianday"=>Value::Real(sec/86400.0+2440587.5),"unixepoch"=>if sub{
            Value::Real(sec)
        }
        else{
            Value::Integer(sec.floor() as i64)
        }
        ,"strftime"=>{
            let fmt=a[0].text();
            let mut cs=fmt.chars();
            let mut out=String::new();
            while let Some(c)=cs.next(){
                if c!='%'{
                    out.push(c);
                    continue
                }
                let Some(c)=cs.next()else{
                    return Ok(Value::Null)
                }
                ;
                let s=match c{
                    '%'=>"%".into(),'Y'=>format!("{:04}",y),'m'=>format!("{:02}",m),'d'=>format!("{:02}",d),'e'=>format!("{:2}",d),'H'=>format!("{:02}",h),'k'=>format!("{:2}",h),'I'=>format!("{:02}",(h+11)%12+1),'l'=>format!("{:2}",(h+11)%12+1),'M'=>format!("{:02}",mi),'S'=>format!("{:02}",ss as i64),'f'=>format!("{:06.3}",ss),'F'=>date.clone(),'T'=>format!("{:02}:{:02}:{:02}",h,mi,ss as i64),'R'=>format!("{:02}:{:02}",h,mi),'j'=>format!("{:03}",day-days(y,1,1)+1),'w'=>((day+4).rem_euclid(7)).to_string(),'u'=>((day+3).rem_euclid(7)+1).to_string(),'s'=>if sub{
                        format!("{:.3}",sec)
                    }
                    else{
                        (sec.floor() as i64).to_string()
                    }
                    ,'J'=>(sec/86400.0+2440587.5).to_string(),'p'=>if h<12{
                        "AM"
                    }
                    else{
                        "PM"
                    }
                    .into(),'P'=>if h<12{
                        "am"
                    }
                    else{
                        "pm"
                    }
                    .into(),'W'=>format!("{:02}",(day-days(y,1,1)+7-(day+3).rem_euclid(7))/7),'U'=>format!("{:02}",(day-days(y,1,1)+7-(day+4).rem_euclid(7))/7),_=>return Ok(Value::Null)
                }
                ;
                out.push_str(&s)
            }
            Value::Text(out)
        }
        ,_=>Value::Null
    }
    )
}
fn parse(v:&Value,unix:bool)->Option<f64>{
    let s=v.text();
    let s=s.trim();
    if s.eq_ignore_ascii_case("now"){
        return Some(now())
    }
    if let Ok(n)=s.parse::<f64>(){
        return Some(if unix{
            n
        }
        else{
            (n-2440587.5)*86400.0
        }
        )
    }
    let b=s.as_bytes();
    if b.len()>=10&&b[4]==b'-'&&b[7]==b'-'{
        let y=s[..4].parse().ok()?;
        let m=s[5..7].parse().ok()?;
        let d=s[8..10].parse().ok()?;
        if !(1..=12).contains(&m)||!(1..=31).contains(&d){
            return None
        }
        let base=days(y,m,d) as f64*86400.0;
        let time=s[10..].trim_start_matches(['T',' ']);
        if time.is_empty(){
            Some(base)
        }
        else{
            Some(base+parse_time(time)?)
        }
    }
    else{
        Some(days(2000,1,1) as f64*86400.0+parse_time(s)?)
    }
}
fn parse_time(s:&str)->Option<f64>{
    let mut zone=0.0;
    let mut s=s.trim();
    if s.ends_with('Z'){
        s=&s[..s.len()-1]
    }
    else if let Some(p)=s.char_indices().skip(1).find(|(_,c)|*c=='+'||*c=='-').map(|(i,_)|i){
        let z=&s[p+1..];
        let(h,m)=z.split_once(':')?;
        zone=(h.parse::<f64>().ok()?*3600.0+m.parse::<f64>().ok()?*60.0)*if s.as_bytes()[p]==b'+'{
            1.0
        }
        else{
            -1.0
        }
        ;
        s=&s[..p]
    }
    let parts=s.split(':').collect::<Vec<_>>();
    if parts.len()<2||parts.len()>3{
        return None
    }
    let h=parts[0].parse::<f64>().ok()?;
    let m=parts[1].parse::<f64>().ok()?;
    let ss=if parts.len()==3{
        parts[2].parse::<f64>().ok()?
    }
    else{
        0.0
    }
    ;
    if h>24.0||m>=60.0||ss>=60.0{
        return None
    }
    Some(h*3600.0+m*60.0+ss-zone)
}
pub fn days(y:i64,m:i64,d:i64)->i64{
    let y=y-i64::from(m<=2);
    let era=y.div_euclid(400);
    let yo=y-era*400;
    let mp=m+if m>2{
        -3
    }
    else{
        9
    }
    ;
    let doy=(153*mp+2)/5+d-1;
    era*146097+yo*365+yo/4-yo/100+doy-719468
}
pub fn civil(z:i64)->(i64,i64,i64){
    let z=z+719468;
    let era=z.div_euclid(146097);
    let doe=z-era*146097;
    let yo=(doe-doe/1460+doe/36524-doe/146096)/365;
    let y=yo+era*400;
    let doy=doe-(365*yo+yo/4-yo/100);
    let mp=(5*doy+2)/153;
    let d=doy-(153*mp+2)/5+1;
    let m=mp+if mp<10{
        3
    }
    else{
        -9
    }
    ;
    (y+i64::from(m<=2),m,d)
}
fn shift_months(sec:f64,months:i64)->f64{
    let(y,m,d)=civil((sec/86400.0).floor() as i64);
    let total=y*12+m-1+months;
    days(total.div_euclid(12),total.rem_euclid(12)+1,d) as f64*86400.0+sec.rem_euclid(86400.0)
}
fn timedifference(a:f64,b:f64)->String{
    let sign=if a<b{
        -1
    }
    else{
        1
    }
    ;
    let(ay,am,_)=civil((a/86400.0).floor() as i64);
    let(by,bm,_)=civil((b/86400.0).floor() as i64);
    let mut months=((ay-by)*12+am-bm).abs();
    let mut shifted=shift_months(b,sign*months);
    while months>0&&((sign>0&&shifted>a)||(sign<0&&shifted<a)){
        months-=1;
        shifted=shift_months(b,sign*months);
    }
    let delta=(((a-shifted).abs())*1000.0).round()/1000.0;
    format!("{}{:04}-{:02}-{:02} {:02}:{:02}:{:06.3}",if sign<0{
        '-'
    }
    else{
        '+'
    }
    ,months/12,months%12,(delta/86400.0) as i64,((delta%86400.0)/3600.0) as i64,((delta%3600.0)/60.0) as i64,delta%60.0)
}
