use crate::{
    engine::*,ast::*,storage::*,value::{
        Value,affinity,Affinity,compare
    }
    ,parser::Res
}
;
use std::{
    collections::BTreeMap,cmp::Ordering
}
;
impl Engine{
    pub fn run(&mut self,stmt:Statement)->Res<Relation> {
        let dml=matches!(stmt,Statement::Insert{..}|Statement::Update{..}|Statement::Delete{..});
        if dml { self.active_change_values.push((self.trigger_change_values.len(),self.visible_changes())); }
        let result=self.run_impl(stmt);
        if dml {
            self.active_change_values.pop();
            if result.is_ok() { if let Some(value)=self.trigger_change_values.last_mut() { *value=self.changes; } }
        }
        result
    }
    fn run_impl(&mut self,mut stmt:Statement)->Res<Relation>{
        if let Some(schema)=self.route_attachment(&mut stmt)?{
            let a=self.attachments.get_mut(&schema).unwrap();
            a.changes=self.changes;
            a.last_id=self.last_id;
            let old_total=a.total_changes;
            let r=a.execute_statement(stmt);
            self.changes=a.changes;
            self.last_id=a.last_id;
            self.total_changes+=a.total_changes-old_total;
            return r
        }
        if let Some(temp)=self.sequence_target(&stmt){
            return self.modify_sequence(stmt,temp)
        }
        match stmt{
            Statement::Vacuum(schema,into)=>{
                if let Some(schema)=schema { if !schema.eq_ignore_ascii_case("main") { let a=self.attachments.get_mut(&key(&schema)).ok_or(format!("unknown database {}",schema))?;return a.execute_statement(Statement::Vacuum(None,into)); } }
                self.vacuum(into.as_ref())
            },
            Statement::Analyze(target)=>self.analyze(target.as_deref()),
            Statement::IndexGuard(stmt,index)=>{if let Statement::Update{table,..}|Statement::Delete{table,..}=stmt.as_ref(){self.check_index(table,&index)?;}self.run(*stmt)},
            Statement::Attach(e,name)=>{
                let k=key(&name);
                if k=="main"||k=="temp"||self.attachments.contains_key(&k){
                    return Err(format!("database {} is already in use",name))
                }
                if self.attachments.len()>=10{
                    return Err("too many attached databases".into())
                }
                let path=self.eval(&e,&Env::default(),None,&Ctes::new(),0)?.text();
                let mut a=Engine::open(&path)?;
                a.foreign_keys=self.foreign_keys;
                if self.tx.is_some(){
                    a.execute_statement(Statement::Begin("DEFERRED".into()))?;
                }
                self.attachment_order.push(k.clone());
                self.attachments.insert(k,Box::new(a));
                Ok(Relation::default())
            }
            ,
            Statement::Detach(name)=>{
                let k=key(&name);
                let a=self.attachments.get(&k).ok_or(format!("no such database: {}",name))?;
                if a.writer.is_some(){
                    return Err(format!("database {} is locked",name))
                }
                self.attachments.remove(&k);
                self.attachment_order.retain(|n|n!=&k);
                Ok(Relation::default())
            }
            ,
            Statement::With(ctes,recursive,s)=>{
                let previous=self.scoped_ctes.clone();
                let result=(||{
                    for (i,c)in ctes.iter().enumerate(){
                        let q=Query{
                            ctes:ctes[..=i].to_vec(),recursive,cores:vec![Select{
                                items:vec![Item{
                                    expr:Expr::Star(None),name:"*".into(),alias:None
                                }
                                ],from:Some(Source::Table(c.name.clone(),None,vec![])),..Default::default()
                            }
                            ],..Default::default()
                        }
                        ;
                        let r=self.query(&q,&Env::default(),&Ctes::new(),0)?;
                        self.scoped_ctes.insert(key(&c.name),r);
                    }
                    self.run(*s)
                }
                )();
                self.scoped_ctes=previous;
                result
            }
            ,
            Statement::CreateTrigger(mut t,ine)=>{
                t.table=self.resolve_relation_key(&t.table);
                t.temporary|=t.table.starts_with("temp.")||t.name.starts_with("temp.");
                if t.temporary&&!t.name.starts_with("temp."){t.name=format!("temp.{}",t.name)}
                crate::schema::check_object_name(&t.name)?;
                t.sql=crate::schema::normalize_schema_sql(&t.sql);
                let k=key(&t.name);
                if self.db.triggers.contains_key(&k){
                    if ine{
                        return Ok(Relation::default())
                    }
                    return Err(format!("trigger {} already exists",t.name))
                }
                let view=self.db.views.contains_key(&key(&t.table));
                if !view&&!self.db.tables.contains_key(&key(&t.table)){
                    return Err(format!("no such table: {}",t.table))
                }
                if (t.timing=="INSTEAD OF")!=view{
                    return Err("invalid trigger timing for table or view".into())
                }
                self.db.triggers.insert(k,t);
                self.db.schema_version+=1;
                Ok(Relation::default())
            }
            ,
            Statement::Query(q)=>self.query(&q,&Env::default(),&Ctes::new(),0),
            Statement::Begin(mode)=>{
                if self.tx.is_some(){
                    return Err("cannot start a transaction within a transaction".into())
                }
                for a in self.attachments.values_mut(){
                    a.execute_statement(Statement::Begin(mode.clone()))?;
                }
                self.tx=Some(self.db.clone());
                self.snapshot_active=mode!="DEFERRED";
                self.explicit=true;
                Ok(Relation::default())
            }
            ,
            Statement::Commit=>{
                if self.tx.is_none(){
                    return Err("cannot commit - no transaction is active".into())
                }
                self.check_foreign(true)?;
                for a in self.attachments.values(){
                    a.check_foreign(true)?;
                }
                for a in self.attachments.values_mut(){
                    if a.tx.is_some(){
                        a.execute_statement(Statement::Commit)?;
                    }
                }
                if self.writer.is_some()||self.path.is_none(){
                    self.persist()?;
                }
                self.tx=None;
                self.savepoints.clear();
                self.explicit=false;
                self.defer_foreign=false;
                Ok(Relation::default())
            }
            ,
            Statement::Rollback(name)=>{
                for a in self.attachments.values_mut(){
                    if a.tx.is_some(){
                        a.execute_statement(Statement::Rollback(name.clone()))?;
                    }
                }
                if let Some(n)=name{
                    let i=self.savepoints.iter().rposition(|(s,_)|s.eq_ignore_ascii_case(&n)).ok_or(format!("no such savepoint: {}",n))?;
                    self.db=self.savepoints[i].1.clone();
                    self.savepoints.truncate(i+1)
                }
                else{
                    self.db=self.tx.take().ok_or("cannot rollback - no transaction is active")?;
                    self.savepoints.clear();
                    self.explicit=false;
                    self.defer_foreign=false;
                }
                Ok(Relation::default())
            }
            ,
            Statement::Savepoint(n)=>{
                for a in self.attachments.values_mut(){
                    a.execute_statement(Statement::Savepoint(n.clone()))?;
                }
                if self.tx.is_none(){
                    self.tx=Some(self.db.clone());
                    self.snapshot_active=false;
                    self.explicit=false
                }
                self.savepoints.push((n,self.db.clone()));
                Ok(Relation::default())
            }
            ,
            Statement::Release(n)=>{
                for a in self.attachments.values_mut(){
                    a.execute_statement(Statement::Release(n.clone()))?;
                }
                let i=self.savepoints.iter().rposition(|(s,_)|s.eq_ignore_ascii_case(&n)).ok_or(format!("no such savepoint: {}",n))?;
                if i==0&&!self.explicit{
                    self.check_foreign(true)?;
                    for a in self.attachments.values(){
                        a.check_foreign(true)?;
                    }
                    for a in self.attachments.values_mut(){
                        if a.tx.is_some(){
                            a.execute_statement(Statement::Commit)?;
                        }
                    }
                    if self.writer.is_some()||self.path.is_none(){
                        self.persist()?;
                    }
                    self.tx=None;
                    self.defer_foreign=false;
                }
                self.savepoints.truncate(i);
                Ok(Relation::default())
            }
            ,
            Statement::CreateTable(mut d,ine,q)=>{
                if d.temporary&&!d.name.starts_with("temp."){
                    d.name=format!("temp.{}",d.name);
                }
                d.sql=crate::schema::normalize_schema_sql(&d.sql);
                let k=key(&d.name);
                if self.db.tables.contains_key(&k)||self.db.views.contains_key(&k){
                    if ine{
                        return Ok(Relation::default())
                    }
                    return Err(format!("table {} already exists",d.name))
                }
                if self.db.indexes.contains_key(&k) {return Err(format!("there is already an index named {}",d.name))}
                if k.rsplit('.').next().unwrap_or(&k).starts_with("sqlite_"){
                    return Err("object name reserved for internal use".into())
                }
                let mut initial=vec![];
                if let Some(q)=q{
                    let r=self.query(&q,&Env::default(),&Ctes::new(),0)?;
                    d.cols=r.fields.iter().map(|f|Column{
                        name:f.name.clone(),typ:match f.affinity{
                            Affinity::Text=>"TEXT",Affinity::Integer=>"INT",Affinity::Real=>"REAL",Affinity::Numeric=>"NUM",_=>""
                        }
                        .into(),collate:"BINARY".into(),..Default::default()
                    }
                    ).collect();
                    for c in &mut d.cols {c.sql=format!("\"{}\"{}{}",c.name.replace('"',"\"\""),if c.typ.is_empty(){""}else{" "},c.typ);}
                    d.sql=format!("CREATE TABLE \"{}\"({})",d.name.trim_start_matches("temp.").replace('"',"\"\""),d.cols.iter().map(|c|c.sql.clone()).collect::<Vec<_>>().join(","));
                    initial=r.rows;
                }
                if d.cols.is_empty(){
                    return Err("table must have at least one column".into())
                }
                for(i,c)in d.cols.iter().enumerate(){
                    if d.cols[..i].iter().any(|x|x.name.eq_ignore_ascii_case(&c.name)){
                        return Err(format!("duplicate column name: {}",c.name))
                    }
                    if d.strict&&!["INT","INTEGER","REAL","TEXT","BLOB","ANY"].contains(&c.typ.to_uppercase().as_str()){
                        return Err(format!("unknown datatype for {}.{}: {}",d.name,c.name,c.typ))
                    }
                    if c.auto&&(d.without_rowid||!c.typ.eq_ignore_ascii_case("INTEGER")||c.primary==0||c.pk_desc){
                        return Err("AUTOINCREMENT is only allowed on an INTEGER PRIMARY KEY".into())
                    }
                }
                let pk:Vec<_>=d.cols.iter().filter(|c|c.primary>0).collect();
                if pk.iter().filter(|c|c.primary==1).count()>1{
                    return Err("table has more than one primary key".into())
                }
                if d.without_rowid&&pk.is_empty(){
                    return Err(format!("PRIMARY KEY missing on table {}",d.name))
                }
                let mut t=Table{
                    def:d,rows:vec![],sequence:0,sequence_written:false
                }
                ;
                crate::schema::bind_schema_quotes(&mut t);
            self.validate_table_definition(&t)?;
                if t.def.cols.iter().any(|c|c.auto){
                    if t.def.temporary{
                        self.db.temp_sequence_exists=true
                    }
                    else{
                        self.db.sequence_exists=true
                    }
                }
                if t.def.without_rowid||t.def.strict{
                    let ipk=t.ipk();
                    for(i,c)in t.def.cols.iter_mut().enumerate(){
                        if c.primary>0&&Some(i)!=ipk{
                            c.not_null=true
                        }
                    }
                }
                for (i,r)in initial.into_iter().enumerate(){
                    t.rows.push(Row{
                        id:i as i64+1,values:r
                    }
                    )
                }
                let mut constraints=t.def.keys.clone();
                if constraints.is_empty() {
                    for cols in &t.def.uniques {constraints.push(KeyConstraint{primary:false,cols:cols.iter().map(|n|Order{expr:Expr::Col(vec![n.clone()]),desc:false,nulls:None}).collect(),conflict:String::new()});}
                    let mut pk=t.def.cols.iter().filter(|c|c.primary>0).collect::<Vec<_>>();pk.sort_by_key(|c|c.primary);
                    if !pk.is_empty(){constraints.insert(0,KeyConstraint{primary:true,cols:pk.iter().map(|c|Order{expr:Expr::Col(vec![c.name.clone()]),desc:c.pk_desc,nulls:None}).collect(),conflict:pk[0].primary_conflict.clone()});}
                    for c in &t.def.cols {if c.unique{constraints.push(KeyConstraint{primary:false,cols:vec![Order{expr:Expr::Col(vec![c.name.clone()]),desc:false,nulls:None}],conflict:c.unique_conflict.clone()});}}
                }
                let mut number=0;
                for constraint in constraints {
                    if constraint.primary&&t.ipk().is_some(){continue}
                    number+=1;
                    let name=format!("{}sqlite_autoindex_{}_{}",if t.def.temporary{"temp."}else{""},t.def.name.trim_start_matches("temp."),number);
                    self.db.indexes.insert(key(&name),Index{name,table:t.def.name.clone(),cols:constraint.cols,unique:true,filter:None,sql:String::new(),origin:if constraint.primary{"pk"}else{"u"}.into(),conflict:constraint.conflict});
                }
                self.db.tables.insert(k,t);
                self.db.schema_version+=1;
                Ok(Relation::default())
            }
            ,
            Statement::CreateView(name,cols,query,ine,sql)=>{
                crate::schema::check_object_name(&name)?;
                let sql=crate::schema::normalize_schema_sql(&sql);
                let k=key(&name);
                if self.db.tables.contains_key(&k)||self.db.views.contains_key(&k){
                    if ine{
                        return Ok(Relation::default())
                    }
                    return Err(format!("table {} already exists",name))
                }
                if self.db.indexes.contains_key(&k) {return Err(format!("there is already an index named {}",name))}
                self.db.views.insert(k,View{
                    name,cols,query,sql
                }
                );
                self.db.schema_version+=1;
                Ok(Relation::default())
            }
            ,
            Statement::CreateIndex(mut name,table,cols,unique,filter,ine,sql)=>{
                let table=self.resolve_relation_key(&table);
                if table.starts_with("temp.")&&!name.starts_with("temp."){
                    name=format!("temp.{}",name)
                }
                let k=key(&name);
                if self.db.indexes.contains_key(&k){
                    if ine{
                        return Ok(Relation::default())
                    }
                    return Err(format!("index {} already exists",name))
                }
                crate::schema::check_object_name(&name)?;
                if self.db.tables.contains_key(&k)||self.db.views.contains_key(&k) {return Err(format!("there is already a table named {}",name))}
                let sql=crate::schema::normalize_schema_sql(&sql);
                let t=self.db.tables.get(&key(&table)).ok_or(format!("no such table: {}",table))?;
                let mut index=Index{
                    name,table,cols,unique,filter,sql,origin:"c".into(),conflict:String::new()
                }
                ;
                crate::schema::bind_index_quotes(&mut index,t);
                self.validate_index_definition(t,&index)?;
                let r=self.table_relation(t,&t.def.name);
                let mut seen:Vec<Vec<Value>>=vec![];
                for row in &r.rows{
                    let e=Env{
                        fields:r.fields.clone(),values:row.clone(),outer:None
                    }
                    ;
                    if !self.index_applies(&index,&e)?{
                        continue
                    }
                    let vals=self.index_values(&index,&e)?;
                    if unique&&!vals.iter().any(Value::null)&&seen.iter().any(|v|vals.iter().zip(v).zip(&index.cols).all(|((a,b),o)|compare(a,b,&self.meta(&o.expr,&e).1)==Ordering::Equal)){
                        return Err("UNIQUE constraint failed".into())
                    }
                    seen.push(vals);
                }
                self.db.indexes.insert(k,index);
                self.db.schema_version+=1;
                Ok(Relation::default())
            }
            ,
            Statement::Drop(kind,name,ie)=>{
                let k=self.resolve_object_key(&name,&key(&kind));
                let exists=match key(&kind).as_str(){
                    "table"=>{
                        if let Some(t)=self.db.tables.get(&k).cloned(){
                            if self.foreign_keys{
                                for row in &t.rows{
                                    self.foreign_actions(&t,Some(row),None,0)?
                                }
                            }
                            self.db.tables.remove(&k);
                            self.db.triggers.retain(|_,t|!t.table.eq_ignore_ascii_case(&k));
                            self.db.indexes.retain(|_,i|!i.table.eq_ignore_ascii_case(&k));
                            true
                        }
                        else{
                            false
                        }
                    }
                    ,"view"=>{
                        self.db.triggers.retain(|_,t|!t.table.eq_ignore_ascii_case(&k));
                        self.db.views.remove(&k).is_some()
                    }
                    ,"trigger"=>self.db.triggers.remove(&k).is_some(),"index"=>{
                        if self.db.indexes.get(&k).is_some_and(|i|i.origin!="c"){
                            return Err("index associated with UNIQUE or PRIMARY KEY constraint cannot be dropped".into())
                        }
                        self.db.indexes.remove(&k).is_some()
                    }
                    ,_=>false
                }
                ;
                if !exists&&!ie{
                    return Err(format!("no such {}: {}",kind,name))
                }
                if exists{
                    self.db.schema_version+=1
                }
                self.check_foreign(false)?;
                Ok(Relation::default())
            }
            ,
            Statement::Insert{
                table,alias,cols,query,default,conflict,upsert,returning
            }
            =>self.insert(&table,alias.as_deref(),&cols,query.as_ref(),default,&conflict,&upsert,&returning),
            Statement::Update{
                table,alias,assignments,filter,conflict,returning,from,order,limit
            }
            =>self.update(&table,alias.as_deref(),&assignments,filter.as_ref(),&conflict,&returning,from.as_ref(),&order,limit.as_ref()),
            Statement::Delete{
                table,alias,filter,returning,order,limit
            }
            =>self.delete(&table,alias.as_deref(),filter.as_ref(),&returning,&order,limit.as_ref()),
            Statement::Pragma(n,v)=>self.pragma(&n,v.as_ref()),
            Statement::Alter(table,action,name,col)=>self.alter(&table,&action,name.as_deref(),col),
            Statement::Explain(stmt,qp)=>{
                if qp{
                    let detail=match *stmt{
                        Statement::Query(q)=>q.cores.first().and_then(|s|s.from.as_ref()).map(|s|match s{
                            Source::Table(n,..)=>format!("SCAN {}",n),_=>"SCAN SUBQUERY".into()
                        }
                        ).unwrap_or("SCAN CONSTANT ROW".into()),_=>"SCAN".into()
                    }
                    ;
                    Ok(Relation::simple(&["id","parent","notused","detail"],vec![vec![Value::Integer(2),Value::Integer(0),Value::Integer(0),Value::Text(detail)]]))
                }
                else{
                    Ok(Relation::simple(&["addr","opcode","p1","p2","p3","p4","p5","comment"],vec![]))
                }
            }
            ,
            Statement::Noop=>Ok(Relation::default())
        }
    }
    pub fn row_env(&self,t:&Table,row:&Row,alias:Option<&str>)->Env{
        let c=Table{
            def:t.def.clone(),rows:vec![row.clone()],sequence:t.sequence,sequence_written:t.sequence_written
        }
        ;
        let r=self.table_relation(&c,alias.unwrap_or(&t.def.name));
        Env{
            fields:r.fields,values:r.rows.into_iter().next().unwrap(),outer:None
        }
    }
    fn index_applies(&self,i:&Index,e:&Env)->Res<bool>{
        i.filter.as_ref().map(|x|self.eval_schema(x,e).map(|v|v.truth()==Some(true))).unwrap_or(Ok(true))
    }
    fn index_values(&self,i:&Index,e:&Env)->Res<Vec<Value>>{
        i.cols.iter().map(|o|self.eval_schema(&o.expr,e)).collect()
    }
    fn prepare_row(&self,t:&Table,mut vals:Vec<Value>,id:Option<i64>)->Res<Row>{
        let ipk=t.ipk();
        for v in &mut vals {if v.is_json(){*v=v.clone().into_plain();}}
        for(i,c)in t.def.cols.iter().enumerate(){
            if !(t.def.strict&&c.typ.eq_ignore_ascii_case("ANY")){
                vals[i]=vals[i].apply(affinity(&c.typ))
            }
        }
        let id=if let Some(i)=ipk{
            if vals[i].null(){
                id
            }
            else{
                match vals[i].apply(Affinity::Integer){
                    Value::Integer(n)=>Some(n),_=>return Err("datatype mismatch".into())
                }
            }
        }
        else{
            id
        }
        ;
        let id=if let Some(id)=id{
            id
        }
        else{
            let max=t.rows.iter().map(|r|r.id).max().unwrap_or(0);
            if t.def.cols.iter().any(|c|c.auto){
                max.max(t.sequence).checked_add(1).ok_or("database or disk is full")?
            }
            else if let Some(id)=max.checked_add(1){
                id
            }
            else{
                let mut chosen=None;
                for _ in 0..100{
                    let id=crate::functions::scalar("random",&[],false)?.int().unsigned_abs().min(i64::MAX as u64) as i64;
                    if id>0&&!t.rows.iter().any(|r|r.id==id){
                        chosen=Some(id);
                        break
                    }
                }
                chosen.ok_or("database or disk is full")?
            }
        }
        ;
        if let Some(i)=ipk{
            vals[i]=Value::Integer(id)
        }
        let mut row=Row{
            id,values:vals
        }
        ;
        for _ in 0..t.def.cols.len(){
            for(i,c)in t.def.cols.iter().enumerate(){
                if let Some(e)=&c.generated{
                    let env=self.row_env(t,&row,None);
                    row.values[i]=self.eval_schema(e,&env)?.apply(affinity(&c.typ)).into_plain();
                }
            }
        }
        Ok(row)
    }
    fn validate_row(&self,t:&Table,row:&Row,exclude:Option<usize>)->Res<Vec<usize>>{
        let env=self.row_env(t,row,None);
        for (i,c)in t.def.cols.iter().enumerate(){
            let v=&row.values[i];
            if c.not_null&&v.null(){
                return Err(format!("NOT NULL constraint failed: {}.{}",t.def.name,c.name))
            }
            if t.def.strict&&!v.null(){
                let ok=match c.typ.to_uppercase().as_str(){
                    "INT"|"INTEGER"=>matches!(v,Value::Integer(_)),"REAL"=>matches!(v,Value::Real(_)|Value::Integer(_)),"TEXT"=>matches!(v,Value::Text(_)),"BLOB"=>matches!(v,Value::Blob(_)),"ANY"=>true,_=>false
                }
                ;
                if !ok{
                    return Err(format!("cannot store {} value in {} column {}.{}",v.typ(),c.typ,t.def.name,c.name))
                }
            }
        }
        for e in &t.def.checks{
            if self.eval_schema(e,&env)?.truth()==Some(false){
                return Err(format!("CHECK constraint failed: {}",t.def.name))
            }
        }
        let mut unique_values=vec![];
        for index in self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&t.def.name)) {
            if self.index_applies(index,&env)? {
                let values=self.index_values(index,&env)?;
                if index.unique&&!values.iter().any(Value::null) {unique_values.push((index,values));}
            }
        }
        let mut conflicts=vec![];
        for(j,r)in t.rows.iter().enumerate(){
            if Some(j)==exclude{
                continue
            }
            if !t.def.without_rowid&&r.id==row.id{
                conflicts.push(j);
                continue
            }
            let other=self.row_env(t,r,None);
            for (index,a) in &unique_values {
                if !self.index_applies(index,&other)? {continue}
                let b=self.index_values(index,&other)?;
                if !a.iter().any(Value::null)&&a.iter().zip(&b).zip(&index.cols).all(|((a,b),o)|compare(a,b,&self.meta(&o.expr,&env).1)==Ordering::Equal){
                    conflicts.push(j);
                    break
                }
            }
        }
        Ok(conflicts)
    }
    fn replace_null_defaults(&self,t:&Table,values:&mut [Value],override_action:&str)->Res<()> {
        for (i,c) in t.def.cols.iter().enumerate() {
            let action=if !override_action.is_empty(){override_action}else if !c.not_null_conflict.is_empty(){&c.not_null_conflict}else{&c.conflict};
            if c.not_null&&values[i].null()&&action=="REPLACE" {
                if let Some(default)=&c.default {values[i]=self.eval(default,&Env::default(),None,&Ctes::new(),0)?;}
            }
        }
        Ok(())
    }
    fn row_conflict_action(&self,t:&Table,row:&Row,override_action:&str,error:Option<&str>,collisions:&[usize])->Res<String> {
        let policy=|default:&str|if !override_action.is_empty(){override_action.to_string()}else if !default.is_empty(){default.to_string()}else{"ABORT".into()};
        if let Some(error)=error {
            if error.starts_with("NOT NULL constraint failed") {
                let c=t.def.cols.iter().enumerate().find(|(i,c)|c.not_null&&row.values[*i].null()).map(|(_,c)|c);
                let action=policy(c.map(|c|if c.not_null_conflict.is_empty(){c.conflict.as_str()}else{c.not_null_conflict.as_str()}).unwrap_or(""));
                return Ok(if action=="REPLACE"{"ABORT".into()}else{action});
            }
            if error.starts_with("CHECK constraint failed") {let action=policy("");return Ok(if action=="REPLACE"{"ABORT".into()}else{action});}
            return Ok("ABORT".into());
        }
        if !override_action.is_empty(){return Ok(override_action.into())}
        if !t.def.without_rowid&&collisions.iter().any(|i|t.rows[*i].id==row.id) {
            let default=t.def.keys.iter().find(|k|k.primary).map(|k|k.conflict.as_str()).or_else(||t.ipk().map(|i|t.def.cols[i].primary_conflict.as_str())).unwrap_or("");
            return Ok(policy(default));
        }
        let env=self.row_env(t,row,None);
        for index in self.db.indexes.values().filter(|i|i.unique&&i.table.eq_ignore_ascii_case(&t.def.name)) {
            if !self.index_applies(index,&env)?{continue}
            let values=self.index_values(index,&env)?;
            if values.iter().any(Value::null){continue}
            for i in collisions {
                let other=self.row_env(t,&t.rows[*i],None);
                if self.index_applies(index,&other)? {
                    let old=self.index_values(index,&other)?;
                    if values.iter().zip(old.iter()).zip(&index.cols).all(|((a,b),o)|compare(a,b,&self.meta(&o.expr,&env).1)==Ordering::Equal){return Ok(policy(&index.conflict))}
                }
            }
        }
        Ok(policy(""))
    }
    fn constraint_error(&self,t:&Table)->String{
        let pk:Vec<_>=t.def.cols.iter().filter(|c|c.primary>0||c.unique).map(|c|format!("{}.{}",t.def.name,c.name)).collect();
        format!("UNIQUE constraint failed: {}",if pk.is_empty(){
            t.def.name.clone()
        }
        else{
            pk.join(", ")
        }
        )
    }
    fn defaults(&self,t:&Table)->Res<Vec<Value>>{
        t.def.cols.iter().map(|c|c.default.as_ref().map(|e|self.eval(e,&Env::default(),None,&Ctes::new(),0)).unwrap_or(Ok(Value::Null))).collect()
    }
    pub fn output_template(&self,t:&Table,items:&[Item])->Res<(Vec<Item>,Relation)>{
        if items.is_empty(){
            return Ok((vec![],Relation::default()))
        }
        let r=self.table_relation(t,&t.def.name);
        let items=expand_items(items,&r.fields)?;
        let env=Env{fields:r.fields,values:vec![Value::Null;t.def.cols.len()+3],outer:None};
        for item in &items {self.validate_row_expr(&item.expr,&env)?;}
        let fields=items.iter().map(|i|Field::new(&i.name)).collect();
        Ok((items,Relation{
            fields,rows:vec![]
        }
        ))
    }
    pub fn output_row(&self,t:&Table,row:&Row,items:&[Item])->Res<Vec<Value>>{
        let env=self.row_env(t,row,None);
        items.iter().map(|i|self.eval(&i.expr,&env,None,&Ctes::new(),0)).collect()
    }
    fn insert(&mut self,name:&str,alias:Option<&str>,cols:&[String],query:Option<&Query>,default:bool,conflict:&str,upsert:&[Upsert],returning:&[Item])->Res<Relation>{
        let k=self.resolve_relation_key(name);
        if self.db.views.contains_key(&k){
            return self.insert_view(name,cols,query,default,returning)
        }
        let mut t=self.db.tables.get(&k).cloned().ok_or(format!("no such table: {}",name))?;
        let inputs=if default{
            vec![vec![]]
        }
        else{
            self.query(query.ok_or("missing SELECT")?,&Env::default(),&Ctes::new(),0)?.rows
        }
        ;
        let indexes=if cols.is_empty(){
            t.def.cols.iter().enumerate().filter(|(_,c)|c.generated.is_none()).map(|(i,_)|Some(i)).collect::<Vec<_>>()
        }
        else{
            cols.iter().map(|n|{
                if let Some(i)=t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)){
                    if t.def.cols[i].generated.is_some(){
                        Err(format!("cannot INSERT into generated column {}",n))
                    }
                    else{
                        Ok(Some(i))
                    }
                }
                else if !t.def.without_rowid&&["rowid","_rowid_","oid"].contains(&key(n).as_str()){
                    Ok(None)
                }
                else{
                    Err(format!("table {} has no column named {}",name,n))
                }
            }
            ).collect::<Res<Vec<_>>>()?
        }
        ;
        for u in upsert{
            if !u.target.is_empty(){
                let valid=self.db.indexes.values().any(|i|i.unique&&i.table.eq_ignore_ascii_case(&t.def.name)&&i.cols.len()==u.target.len()&&i.cols.iter().zip(&u.target).all(|(o,n)|crate::schema::column_name(&o.expr).is_some_and(|column|column.eq_ignore_ascii_case(n))))||t.ipk().is_some_and(|i|u.target.len()==1&&u.target[0].eq_ignore_ascii_case(&t.def.cols[i].name));
                if !valid{
                    return Err("ON CONFLICT clause does not match any PRIMARY KEY or UNIQUE constraint".into())
                }
            }
        }
        let (outitems,mut out)=self.output_template(&t,returning)?;
        self.changes=0;
        for input in inputs{
            if !default&&input.len()!=indexes.len(){
                return Err(format!("table {} has {} columns but {} values were supplied",name,indexes.len(),input.len()))
            }
            let mut vals=self.defaults(&t)?;
            let mut id=None;
            if !default{
                for (col,v)in indexes.iter().zip(input){
                    if let Some(i)=col{
                        vals[*i]=v
                    }
                    else if !v.null(){
                        match v.apply(Affinity::Integer){
                            Value::Integer(n)=>id=Some(n),_=>return Err("datatype mismatch".into())
                        }
                    }
                }
            }
            self.replace_null_defaults(&t,&mut vals,conflict)?;
            let mut row=self.prepare_row(&t,vals,id)?;
            if !self.fire_triggers(&t,"BEFORE","INSERT",None,Some(&row),&[])?{
                continue
            }
            t=self.db.tables.get(&k).cloned().unwrap_or(t);
            if t.def.cols.iter().any(|c|c.auto){
                t.sequence=t.sequence.max(row.id);
                t.sequence_written=true;
            }
            let conflicts=match self.validate_row(&t,&row,None){
                Ok(c)=>c,Err(e)=>{
                    let action=self.row_conflict_action(&t,&row,conflict,Some(&e),&[])?;
                    if action=="IGNORE"{
                        continue
                    }
                    self.db.tables.insert(k.clone(),t);
                    return Err(conflict_message(&action,e))
                }
            }
            ;
            let action=self.row_conflict_action(&t,&row,conflict,None,&conflicts)?;
            if !conflicts.is_empty(){
                if let Some(u)=upsert.iter().find(|u|conflicts.iter().any(|j|upsert_matches(&t,u,&row,&t.rows[*j]))){
                    if u.assignments.is_empty(){
                        continue
                    }
                    let idx=*conflicts.iter().find(|j|upsert_matches(&t,u,&row,&t.rows[**j])).unwrap();
                    let old=t.rows[idx].clone();
                    let mut env=self.row_env(&t,&old,alias);
                    let excluded=self.row_env(&t,&row,Some("excluded"));
                    env.outer=Some(Box::new(excluded));
                    if u.filter.as_ref().map(|e|self.eval(e,&env,None,&Ctes::new(),0).map(|v|v.truth()==Some(true))).transpose()?.unwrap_or(true){
                        let mut vals=old.values.clone();
                        for(n,e)in &u.assignments{
                            let ci=t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or(format!("no such column: {}",n))?;
                            vals[ci]=self.eval(e,&env,None,&Ctes::new(),0)?;
                        }
                        row=self.prepare_row(&t,vals,Some(old.id))?;
                        let changed=u.assignments.iter().map(|(n,_)|n.clone()).collect::<Vec<_>>();
                        if !self.fire_triggers(&t,"BEFORE","UPDATE",Some(&old),Some(&row),&changed)?{
                            continue
                        }
                        t=self.db.tables.get(&k).cloned().unwrap_or(t);
                        if !self.validate_row(&t,&row,Some(idx))?.is_empty(){
                            return Err(self.constraint_error(&t))
                        }
                        let Some(idx)=t.rows.iter().position(|r|r.id==old.id)else{
                            continue
                        }
                        ;
                        t.rows[idx]=row.clone();
                        self.changes+=1;
                        self.total_changes+=1;
                        self.db.tables.insert(k.clone(),t.clone());
                        if !outitems.is_empty(){
                            out.rows.push(self.output_row(&t,&row,&outitems)?)
                        }
                        self.foreign_actions(&t,Some(&old),Some(&row),0)?;
                        self.fire_triggers(&t,"AFTER","UPDATE",Some(&old),Some(&row),&changed)?;
                        t=self.db.tables.get(&k).cloned().unwrap_or(t);
                    }
                    continue
                }
                else if action=="IGNORE"{
                    continue
                }
                else if action=="REPLACE"{
                    let recursive=self.pragmas.get("recursive_triggers").is_some_and(|v|v.truth()==Some(true)||v.text().eq_ignore_ascii_case("on"));
                    for i in conflicts.into_iter().rev(){
                        let old=t.rows[i].clone();
                        if recursive{
                            self.fire_triggers(&t,"BEFORE","DELETE",Some(&old),None,&[])?;
                        }
                        t.rows.remove(i);
                        self.db.tables.insert(k.clone(),t.clone());
                        self.foreign_actions(&t,Some(&old),None,0)?;
                        if recursive{
                            self.fire_triggers(&t,"AFTER","DELETE",Some(&old),None,&[])?;
                        }
                        t=self.db.tables.get(&k).cloned().unwrap_or(t);
                    }
                }
                else{
                    let e=self.constraint_error(&t);
                    self.db.tables.insert(k.clone(),t);
                    return Err(conflict_message(&action,e))
                }
            }
            if t.def.cols.iter().any(|c|c.auto){
                t.sequence=t.sequence.max(row.id);
                t.sequence_written=true;
            }
            t.rows.push(row.clone());
            if !t.def.without_rowid{
                self.last_id=row.id
            }
            self.changes+=1;
            self.total_changes+=1;
            self.db.tables.insert(k.clone(),t.clone());
            if !outitems.is_empty(){
                out.rows.push(self.output_row(&t,&row,&outitems)?)
            }
            self.fire_triggers(&t,"AFTER","INSERT",None,Some(&row),&[])?;
            t=self.db.tables.get(&k).cloned().unwrap_or(t);
        }
        self.db.tables.insert(k,t);
        self.check_foreign(false)?;
        Ok(out)
    }
    fn update(&mut self,name:&str,alias:Option<&str>,assignments:&[(String,Expr)],filter:Option<&Expr>,conflict:&str,returning:&[Item],from:Option<&Source>,order:&[Order],limit:Option<&Expr>)->Res<Relation>{
        let k=self.resolve_relation_key(name);
        if self.db.views.contains_key(&k){
            return self.change_view(name,alias,assignments,filter,returning,false)
        }
        let mut t=self.db.tables.get(&k).cloned().ok_or(format!("no such table: {}",name))?;
        let targets=assignments.iter().map(|(n,_)|{
            if let Some(i)=t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)){
                if t.def.cols[i].generated.is_some(){
                    return Err(format!("cannot UPDATE generated column {}",n))
                }
                Ok(Some(i))
            }
            else if !t.def.without_rowid&&["rowid","_rowid_","oid"].contains(&key(n).as_str()){
                Ok(None)
            }
            else{
                Err(format!("no such column: {}",n))
            }
        }
        ).collect::<Res<Vec<_>>>()?;
        let extra=from.map(|s|self.source(s,&Env::default(),&Ctes::new(),0)).transpose()?;
        let (outitems,mut out)=self.output_template(&t,returning)?;
        let mut bind=self.row_env(&t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},alias);
        if let Some(extra)=&extra {bind.fields.extend(extra.fields.clone());bind.values.extend(vec![Value::Null;extra.fields.len()]);}
        for e in assignments.iter().map(|(_,e)|e).chain(filter.into_iter()).chain(order.iter().map(|o|&o.expr)) {self.validate_row_expr(e,&bind)?;}
        let mut selected=vec![];
        for (idx,row)in t.rows.iter().enumerate(){
            let env=self.row_env(&t,row,alias);
            let envs=if let Some(r)=&extra{
                r.rows.iter().map(|v|{
                    let mut e=env.clone();
                    e.fields.extend(r.fields.clone());
                    e.values.extend(v.clone());
                    e
                }
                ).collect()
            }
            else{
                vec![env]
            }
            ;
            for e in envs{
                if filter.map(|f|self.eval(f,&e,None,&Ctes::new(),0).map(|v|v.truth()==Some(true))).transpose()?.unwrap_or(true){
                    selected.push((idx,e));
                    break
                }
            }
        }
        self.sort_selection(&mut selected,order,limit)?;
        let selected=selected.into_iter().map(|(idx,env)|(t.rows[idx].id,env)).collect::<Vec<_>>();
        self.changes=0;
        for (old_id,env)in selected{
            let Some(idx)=t.rows.iter().position(|r|r.id==old_id)else{
                continue
            }
            ;
            let old=t.rows[idx].clone();
            let mut vals=old.values.clone();
            let mut id=Some(old.id);
            for ((_,e),target)in assignments.iter().zip(&targets){
                let v=self.eval(e,&env,None,&Ctes::new(),0)?;
                if let Some(i)=target{
                    if Some(*i)==t.ipk()&&v.null(){
                        return Err("datatype mismatch".into())
                    }
                    vals[*i]=v
                }
                else{
                    let v=v.apply(Affinity::Integer);
                    if let Value::Integer(n)=v{
                        id=Some(n);
                        if let Some(i)=t.ipk(){
                            vals[i]=Value::Integer(n)
                        }
                    }
                    else{
                        return Err("datatype mismatch".into())
                    }
                }
            }
            self.replace_null_defaults(&t,&mut vals,conflict)?;
            let row=self.prepare_row(&t,vals,id)?;
            let changed=assignments.iter().map(|(n,_)|n.clone()).collect::<Vec<_>>();
            if !self.fire_triggers(&t,"BEFORE","UPDATE",Some(&old),Some(&row),&changed)?{
                continue
            }
            t=self.db.tables.get(&k).cloned().unwrap_or(t);
            let collisions=match self.validate_row(&t,&row,Some(idx)){
                Ok(c)=>c,Err(e)=>{
                    let action=self.row_conflict_action(&t,&row,conflict,Some(&e),&[])?;
                    if action=="IGNORE"{
                        continue
                    }
                    self.db.tables.insert(k.clone(),t);
                    return Err(conflict_message(&action,e))
                }
            }
            ;
            let action=self.row_conflict_action(&t,&row,conflict,None,&collisions)?;
            if !collisions.is_empty(){
                if action=="IGNORE"{
                    continue
                }
                else if action=="REPLACE"{
                    let recursive=self.pragmas.get("recursive_triggers").is_some_and(|v|v.truth()==Some(true)||v.text().eq_ignore_ascii_case("on"));
                    for c in collisions.into_iter().rev(){
                        let removed=t.rows[c].clone();
                        if recursive{self.fire_triggers(&t,"BEFORE","DELETE",Some(&removed),None,&[])?;}
                        t.rows.remove(c);
                        self.db.tables.insert(k.clone(),t.clone());
                        self.foreign_actions(&t,Some(&removed),None,0)?;
                        if recursive{self.fire_triggers(&t,"AFTER","DELETE",Some(&removed),None,&[])?;}
                        t=self.db.tables.get(&k).cloned().unwrap_or(t);
                    }
                }
                else{
                    let e=self.constraint_error(&t);
                    self.db.tables.insert(k.clone(),t);
                    return Err(conflict_message(&action,e))
                }
            }
            let Some(idx)=t.rows.iter().position(|r|r.id==old.id)else{
                continue
            }
            ;
            t.rows[idx]=row.clone();
            self.changes+=1;
            self.total_changes+=1;
            self.db.tables.insert(k.clone(),t.clone());
            self.foreign_actions(&t,Some(&old),Some(&row),0)?;
            if !outitems.is_empty(){
                out.rows.push(self.output_row(&t,&row,&outitems)?)
            }
            self.fire_triggers(&t,"AFTER","UPDATE",Some(&old),Some(&row),&changed)?;
            t=self.db.tables.get(&k).cloned().unwrap_or(t);
        }
        self.db.tables.insert(k,t);
        self.check_foreign(false)?;
        Ok(out)
    }
    fn delete(&mut self,name:&str,alias:Option<&str>,filter:Option<&Expr>,returning:&[Item],order:&[Order],limit:Option<&Expr>)->Res<Relation>{
        let k=self.resolve_relation_key(name);
        if self.db.views.contains_key(&k){
            return self.change_view(name,alias,&[],filter,returning,true)
        }
        let mut t=self.db.tables.get(&k).cloned().ok_or(format!("no such table: {}",name))?;
        let(outitems,mut out)=self.output_template(&t,returning)?;
        let bind=self.row_env(&t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},alias);
        for e in filter.into_iter().chain(order.iter().map(|o|&o.expr)) {self.validate_row_expr(e,&bind)?;}
        let mut selected=vec![];
        for(i,r)in t.rows.iter().enumerate(){
            let env=self.row_env(&t,r,alias);
            if filter.map(|e|self.eval(e,&env,None,&Ctes::new(),0).map(|v|v.truth()==Some(true))).transpose()?.unwrap_or(true){
                selected.push((i,env))
            }
        }
        self.sort_selection(&mut selected,order,limit)?;
        self.changes=0;
        let original=t.clone();
        for(i,_)in &selected{
            let row=original.rows[*i].clone();
            if !self.fire_triggers(&t,"BEFORE","DELETE",Some(&row),None,&[])?{
                continue
            }
            t=self.db.tables.get(&k).cloned().unwrap_or(t);
            if !outitems.is_empty(){
                out.rows.push(self.output_row(&t,&row,&outitems)?)
            }
            t.rows.retain(|r|r.id!=row.id);
            self.db.tables.insert(k.clone(),t.clone());
            self.foreign_actions(&t,Some(&row),None,0)?;
            self.changes+=1;
            self.total_changes+=1;
            self.fire_triggers(&t,"AFTER","DELETE",Some(&row),None,&[])?;
            t=self.db.tables.get(&k).cloned().unwrap_or(t);
        }
        self.db.tables.insert(k,t);
        self.check_foreign(false)?;
        Ok(out)
    }
    fn sort_selection(&self,sel:&mut Vec<(usize,Env)>,order:&[Order],limit:Option<&Expr>)->Res<()>{
        let mut keys=BTreeMap::new();
        for (i,e)in sel.iter(){
            keys.insert(*i,order.iter().map(|o|self.eval(&o.expr,e,None,&Ctes::new(),0)).collect::<Res<Vec<_>>>()?);
        }
        sel.sort_by(|(a,ea),(b,_)|{
            for(i,o)in order.iter().enumerate(){
                let c=compare(&keys[a][i],&keys[b][i],&self.meta(&o.expr,ea).1);
                if c!=Ordering::Equal{
                    return if o.desc{
                        c.reverse()
                    }
                    else{
                        c
                    }
                }
            }
            Ordering::Equal
        }
        );
        if let Some(e)=limit{
            let n=integer_limit(&self.eval(e,&Env::default(),None,&Ctes::new(),0)?)?;
            if n>=0{
                sel.truncate(n as usize)
            }
        }
        Ok(())
    }
    pub fn check_foreign(&self,all:bool)->Res<()>{
        if !self.foreign_keys||(!all&&!self.active_triggers.is_empty()){
            return Ok(())
        }
        let baseline=if all{
            self.tx.as_ref().map(crate::foreign::violations).unwrap_or_else(||self.foreign_baseline.clone())
        }
        else{
            self.foreign_baseline.clone()
        }
        ;
        for t in self.db.tables.values(){
            for(fk,f)in t.def.foreign.iter().enumerate(){
                if t.rows.is_empty(){
                    continue
                }
                if !all&&self.tx.is_some()&&(f.deferred||self.defer_foreign){
                    continue
                }
                let parent=self.db.tables.get(&if t.def.temporary{
                    format!("temp.{}",key(&f.table))
                }
                else{
                    key(&f.table)
                }
                ).ok_or(format!("no such table: main.{}",f.table))?;
                let child=self.col_indexes(t,&f.cols)?;
                let names=if f.target.is_empty(){
                    let mut p=parent.def.cols.iter().filter(|c|c.primary>0).collect::<Vec<_>>();
                    p.sort_by_key(|c|c.primary);
                    p.iter().map(|c|c.name.clone()).collect()
                }
                else{
                    f.target.clone()
                }
                ;
                let target=self.col_indexes(parent,&names)?;
                let valid_key=parent.ipk().is_some_and(|i|names.len()==1&&names[0].eq_ignore_ascii_case(&parent.def.cols[i].name))||self.db.indexes.values().any(|idx|idx.unique&&idx.filter.is_none()&&idx.table.eq_ignore_ascii_case(&parent.def.name)&&idx.cols.len()==names.len()&&idx.cols.iter().all(|o|crate::schema::column_name(&o.expr).is_some_and(|n|names.iter().any(|name|name.eq_ignore_ascii_case(n))&&parent.def.cols.iter().find(|c|c.name.eq_ignore_ascii_case(n)).is_some_and(|c|explicit_collate(&o.expr).unwrap_or_else(||c.collate.clone()).eq_ignore_ascii_case(&c.collate)))));
                if !valid_key{
                    return Err("foreign key mismatch".into())
                }
                if child.len()!=target.len(){
                    return Err("foreign key mismatch".into())
                }
                for row in &t.rows{
                    if baseline.contains(&crate::foreign::violation_key(t,fk,f,row)){
                        continue
                    }
                    if child.iter().any(|i|row.values[*i].null()){
                        continue
                    }
                    let exists=parent.rows.iter().any(|r|child.iter().zip(&target).all(|(i,j)|compare(&row.values[*i].apply(affinity(&parent.def.cols[*j].typ)),&r.values[*j],&parent.def.cols[*j].collate)==Ordering::Equal));
                    if !exists{
                        return Err("FOREIGN KEY constraint failed".into())
                    }
                }
            }
        }
        Ok(())
    }
    fn col_indexes(&self,t:&Table,names:&[String])->Res<Vec<usize>>{
        names.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or(format!("no such column: {}",n))).collect()
    }
    fn foreign_actions(&mut self,parent:&Table,old:Option<&Row>,new:Option<&Row>,depth:usize)->Res<()>{
        if !self.foreign_keys{
            return Ok(())
        }
        if depth>50{
            return Err("too many levels of trigger recursion".into())
        }
        let Some(old)=old else{
            return Ok(())
        }
        ;
        let children=self.db.tables.values().cloned().collect::<Vec<_>>();
        for mut t in children{
            for f in t.def.foreign.clone(){
                let parent_name=if t.def.temporary{
                    format!("temp.{}",f.table)
                }
                else{
                    f.table.clone()
                }
                ;
                if !parent_name.eq_ignore_ascii_case(&parent.def.name){
                    continue
                }
                let names=if f.target.is_empty(){
                    let mut p=parent.def.cols.iter().filter(|c|c.primary>0).collect::<Vec<_>>();
                    p.sort_by_key(|c|c.primary);
                    p.iter().map(|c|c.name.clone()).collect()
                }
                else{
                    f.target.clone()
                }
                ;
                let target=self.col_indexes(parent,&names)?;
                let cols=self.col_indexes(&t,&f.cols)?;
                if new.is_some_and(|r|target.iter().all(|i|compare(&r.values[*i],&old.values[*i],&parent.def.cols[*i].collate)==Ordering::Equal)){
                    continue
                }
                let action=if new.is_some(){
                    &f.update
                }
                else{
                    &f.delete
                }
                ;
                let mut affected=vec![];
                for(i,r)in t.rows.iter().enumerate(){
                    if cols.iter().any(|i|r.values[*i].null()){
                        continue
                    }
                    if cols.iter().zip(&target).all(|(i,j)|compare(&r.values[*i].apply(affinity(&parent.def.cols[*j].typ)),&old.values[*j],&parent.def.cols[*j].collate)==Ordering::Equal){
                        affected.push(i)
                    }
                }
                if !affected.is_empty()&&action=="RESTRICT"{
                    return Err("FOREIGN KEY constraint failed".into())
                }
                if action=="NO ACTION"{
                    continue
                }
                for idx in affected.into_iter().rev(){
                    let before=t.rows[idx].clone();
                    if action=="CASCADE"&&new.is_none(){
                        if !self.fire_triggers(&t,"BEFORE","DELETE",Some(&before),None,&[])?{
                            continue
                        }
                        t.rows.remove(idx);
                        self.db.tables.insert(key(&t.def.name),t.clone());
                        self.foreign_actions(&t,Some(&before),None,depth+1)?;
                        self.fire_triggers(&t,"AFTER","DELETE",Some(&before),None,&[])?;
                        t=self.db.tables.get(&key(&t.def.name)).cloned().unwrap_or(t);
                    }
                    else{
                        let mut vals=before.values.clone();
                        for(i,j)in cols.iter().zip(&target){
                            vals[*i]=match action.as_str(){
                                "CASCADE"=>new.unwrap().values[*j].clone(),"SET NULL"=>Value::Null,"SET DEFAULT"=>t.def.cols[*i].default.as_ref().map(|e|self.eval(e,&Env::default(),None,&Ctes::new(),0)).unwrap_or(Ok(Value::Null))?,_=>vals[*i].clone()
                            }
                            ;
                        }
                        let after=self.prepare_row(&t,vals,Some(before.id))?;
                        if !self.fire_triggers(&t,"BEFORE","UPDATE",Some(&before),Some(&after),&f.cols)?{
                            continue
                        }
                        if !self.validate_row(&t,&after,Some(idx))?.is_empty(){return Err(self.constraint_error(&t))}
                        t.rows[idx]=after.clone();
                        self.db.tables.insert(key(&t.def.name),t.clone());
                        self.foreign_actions(&t,Some(&before),Some(&after),depth+1)?;
                        self.fire_triggers(&t,"AFTER","UPDATE",Some(&before),Some(&after),&f.cols)?;
                        t=self.db.tables.get(&key(&t.def.name)).cloned().unwrap_or(t);
                    }
                    self.total_changes+=1;
                }
                self.db.tables.insert(key(&t.def.name),t.clone());
            }
        }
        Ok(())
    }
    fn alter(&mut self,name:&str,action:&str,new:Option<&str>,col:Option<Column>)->Res<Relation>{
        let k=self.resolve_relation_key(name);
        let mut t=self.db.tables.get(&k).cloned().ok_or(format!("no such table: {}",name))?;
        match action{
            "rename"=>{
                let short=new.unwrap();
                crate::schema::check_object_name(short)?;
                let n=if t.def.temporary {format!("temp.{}",short)}else{short.into()};
                if self.db.tables.contains_key(&key(&n))||self.db.views.contains_key(&key(&n))||self.db.indexes.contains_key(&key(&n)) {
                    return Err("there is already another table or index with this name".into());
                }
                let old_short=t.def.name.trim_start_matches("temp.").to_string();
                self.db.tables.remove(&k);
                self.rename_table_dependencies(&t.def.name,&n);
                let indexes=std::mem::take(&mut self.db.indexes);
                for (_,mut index) in indexes {
                    if index.table.eq_ignore_ascii_case(&t.def.name) {
                        index.table=n.clone();
                        if index.origin!="c" {
                            if let Some(suffix)=index.name.rsplit('_').next() {index.name=format!("{}sqlite_autoindex_{}_{}",if t.def.temporary{"temp."}else{""},short,suffix);}
                        }
                    }
                    self.db.indexes.insert(key(&index.name),index);
                }
                for tab in self.db.tables.values_mut() {
                    for f in &mut tab.def.foreign {
                        if f.table.eq_ignore_ascii_case(&t.def.name)||f.table.eq_ignore_ascii_case(&old_short) {f.table=short.into();}
                    }
                }
                for f in &mut t.def.foreign {if f.table.eq_ignore_ascii_case(&t.def.name)||f.table.eq_ignore_ascii_case(&old_short){f.table=short.into();}}
                t.def.name=n.clone();
                t.def.sql=crate::schema::rewrite_sql(&t.def.sql,&old_short,short);
                self.db.tables.insert(key(&n),t);
            }
            ,"add"=>{
                let c=col.unwrap();
                if c.stored{
                    return Err("cannot add a STORED column".into())
                }
                if c.default_parenthesized||c.default.as_ref().is_some_and(|e|matches!(e,Expr::Col(n) if n.len()==1&&n[0].to_uppercase().starts_with("CURRENT_"))){
                    return Err("Cannot add a column with non-constant default".into())
                }
                if t.def.cols.iter().any(|x|x.name.eq_ignore_ascii_case(&c.name)){
                    return Err(format!("duplicate column name: {}",c.name))
                }
                if c.primary>0||c.unique{
                    return Err("Cannot add a PRIMARY KEY or UNIQUE column".into())
                }
                let val=c.default.as_ref().map(|e|self.eval(e,&Env::default(),None,&Ctes::new(),0)).unwrap_or(Ok(Value::Null))?;
                if c.not_null&&c.generated.is_none()&&val.null()&&!t.rows.is_empty(){
                    return Err("Cannot add a NOT NULL column with default value NULL".into())
                }
                if self.foreign_keys&&!c.foreigns.is_empty()&&!val.null(){
                    return Err("Cannot add a REFERENCES column with non-NULL default value".into())
                }
                for r in &mut t.rows{
                    r.values.push(val.apply(affinity(&c.typ)))
                }
                t.def.checks.extend(c.checks.clone());
                t.def.foreign.extend(c.foreigns.clone());
                if let Some(p)=t.def.sql.rfind(')'){
                    t.def.sql.insert_str(p,&format!(", {}",c.sql));
                }
                t.def.cols.push(c);
                crate::schema::bind_schema_quotes(&mut t);
            self.validate_table_definition(&t)?;
                for i in 0..t.rows.len(){
                    let row=self.prepare_row(&t,t.rows[i].values.clone(),Some(t.rows[i].id))?;
                    self.validate_row(&t,&row,Some(i))?;
                    t.rows[i]=row;
                }
                self.db.tables.insert(k,t);
            }
            ,"set_not_null"|"drop_not_null"=>{
                let n=new.unwrap();
                let i=t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("no such column")?;
                let set=action=="set_not_null";
                if t.def.cols[i].not_null==set {return Ok(Relation::default())}
                if set&&t.rows.iter().any(|r|r.values[i].null()) {return Err(format!("NOT NULL constraint failed: {}.{}",t.def.name,n))}
                if !set&&t.def.cols[i].primary>0&&(t.def.without_rowid||t.def.strict) {return Err("cannot drop NOT NULL constraint from PRIMARY KEY".into())}
                let c=&mut t.def.cols[i];
                let original=crate::schema::column_sql(&t.def.sql,n).unwrap_or_else(||c.sql.clone());
                c.sql=if set {format!("{} NOT NULL",original)}else{crate::schema::remove_not_null(&original)};
                c.not_null=set;
                t.def.sql=crate::schema::edit_column_sql(&t.def.sql,n,Some(&c.sql));
                self.db.tables.insert(k,t);
            }
            ,"drop"=>{
                let n=new.unwrap();
                let i=t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("no such column")?;
                if t.def.cols[i].primary>0||t.def.cols[i].unique||self.column_has_dependencies(&t,n){
                    return Err("cannot drop column referenced by schema constraints".into())
                }
                if t.def.cols.len()==1{
                    return Err("cannot drop only column".into())
                }
                let removed=t.def.cols.remove(i);
                let own_checks=removed.checks.iter().map(|e|serde_json::to_string(e).unwrap()).collect::<Vec<_>>();
                t.def.checks.retain(|e|!own_checks.contains(&serde_json::to_string(e).unwrap()));
                t.def.sql=crate::schema::edit_column_sql(&t.def.sql,n,None);
                for r in &mut t.rows{
                    r.values.remove(i);
                }
                self.db.tables.insert(k,t);
            }
            ,a if a.starts_with("column:")=>{
                let old=&a[7..];
                let n=new.unwrap();
                if t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n)){
                    return Err("duplicate column name".into())
                }
                let c=t.def.cols.iter_mut().find(|c|c.name.eq_ignore_ascii_case(old)).ok_or("no such column")?;
                c.name=n.into();
                for c in &mut t.def.cols{
                    c.sql=crate::schema::rewrite_sql(&c.sql,old,n);
                }
                self.rename_column_dependencies(name,old,n);
                t.def.sql=crate::schema::rewrite_sql(&t.def.sql,old,n);
                for constraint in &mut t.def.keys{for o in &mut constraint.cols{rename_expr(&mut o.expr,old,n)}}
                for u in &mut t.def.uniques{
                    for x in u{
                        if x.eq_ignore_ascii_case(old){
                            *x=n.into()
                        }
                    }
                }
                for f in &mut t.def.foreign{
                    for x in &mut f.cols{
                        if x.eq_ignore_ascii_case(old){
                            *x=n.into()
                        }
                    }
                }
                for i in self.db.indexes.values_mut().filter(|i|i.table.eq_ignore_ascii_case(name)){
                    for o in &mut i.cols{
                        rename_expr(&mut o.expr,old,n)
                    }
                }
                for c in &mut t.def.cols{
                    if let Some(e)=&mut c.generated{
                        rename_expr(e,old,n)
                    }
                }
                for e in &mut t.def.checks{
                    rename_expr(e,old,n)
                }
                self.db.tables.insert(k,t);
            }
            ,_=>return Err("unsupported ALTER TABLE".into())
        }
        self.db.schema_version+=1;
        Ok(Relation::default())
    }
}
fn conflict_message(a:&str,e:String)->String{
    if a=="ROLLBACK"{
        format!("ROLLBACK:{}",e)
    }
    else if a=="FAIL"{
        format!("FAIL:{}",e)
    }
    else{
        e
    }
}
fn rename_expr(e:&mut Expr,old:&str,new:&str){
    match e{
        Expr::Col(n)=>{
            if n.last().is_some_and(|s|s.eq_ignore_ascii_case(old)){
                *n.last_mut().unwrap()=new.into()
            }
        }
        ,Expr::Unary(_,e)|Expr::Cast(e,_)|Expr::Collate(e,_)=>rename_expr(e,old,new),Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>{
            rename_expr(a,old,new);
            rename_expr(b,old,new)
        }
        ,Expr::Call{
            args,..
        }
        =>{
            for a in args{
                rename_expr(a,old,new)
            }
        }
        ,_=>{
        }
    }
}
fn upsert_matches(t:&Table,u:&Upsert,new:&Row,old:&Row)->bool{
    u.target.is_empty()||u.target.iter().all(|n|if let Some(i)=t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)){
        !new.values[i].null()&&compare(&new.values[i],&old.values[i],&t.def.cols[i].collate)==Ordering::Equal
    }
    else{
        !t.def.without_rowid&&["rowid","_rowid_","oid"].contains(&n.to_ascii_lowercase().as_str())&&new.id==old.id
    }
    )
}
