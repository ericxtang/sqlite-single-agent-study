// An opaque binary JSON parse tree for this implementation's storage format.
use crate::json_value::{
    Json as J,Object
}
;
const HEADER:&[u8]=b"RJB\x01";
pub fn looks(b:&[u8])->bool{
    b.starts_with(HEADER)
}
pub fn encode(j:&J)->Vec<u8>{
    let mut b=HEADER.to_vec();
    write(j,&mut b);
    b
}
fn size(mut n:u64,b:&mut Vec<u8>){
    while n>=128{
        b.push((n as u8&127)|128);
        n>>=7
    }
    b.push(n as u8)
}
fn string(s:&str,b:&mut Vec<u8>){
    size(s.len() as u64,b);
    b.extend_from_slice(s.as_bytes())
}
fn write(j:&J,b:&mut Vec<u8>){
    match j{
        J::Null=>b.push(0),J::Bool(false)=>b.push(1),J::Bool(true)=>b.push(2),J::Number(n)=>{
            if let Some(i)=n.as_i64(){
                b.push(3);
                size(((i as u64)<<1)^((i>>63) as u64),b)
            }
            else{
                b.push(4);
                string(&n.to_string(),b)
            }
        }
        ,J::String(s)=>{
            b.push(5);
            string(s,b)
        }
        ,J::Array(a)=>{
            b.push(6);
            size(a.len() as u64,b);
            for v in a{
                write(v,b)
            }
        }
        ,J::Object(o)=>{
            b.push(7);
            size(o.0.len() as u64,b);
            for(k,v)in o{
                string(k,b);
                write(v,b)
            }
        }
    }
}
pub fn decode(b:&[u8])->Option<J>{
    if !looks(b){
        return None
    }
    let mut p=HEADER.len();
    let j=read(b,&mut p,0)?;
    if p==b.len(){
        Some(j)
    }
    else{
        None
    }
}
fn number(b:&[u8],p:&mut usize)->Option<u64>{
    let mut n=0u64;
    for shift in (0..70).step_by(7){
        let x=*b.get(*p)?;
        *p+=1;
        if shift==63&&x>1{
            return None
        }
        n|=((x&127) as u64)<<shift;
        if x<128{
            return Some(n)
        }
    }
    None
}
fn text(b:&[u8],p:&mut usize)->Option<String>{
    let len=usize::try_from(number(b,p)?).ok()?;
    let end=p.checked_add(len)?;
    let s=std::str::from_utf8(b.get(*p..end)?).ok()?.to_owned();
    *p=end;
    Some(s)
}
fn read(b:&[u8],p:&mut usize,depth:usize)->Option<J>{
    if depth>1000{
        return None
    }
    let tag=*b.get(*p)?;
    *p+=1;
    Some(match tag{
        0=>J::Null,1=>J::Bool(false),2=>J::Bool(true),3=>{
            let n=number(b,p)?;
            J::from(((n>>1) as i64)^-((n&1) as i64))
        }
        ,4=>J::Number(text(b,p)?.parse().ok()?),5=>J::String(text(b,p)?),6=>{
            let n=usize::try_from(number(b,p)?).ok()?;
            if n>b.len(){
                return None
            }
            let mut a=vec![];
            for _ in 0..n{
                a.push(read(b,p,depth+1)?)
            }
            J::Array(a)
        }
        ,7=>{
            let n=usize::try_from(number(b,p)?).ok()?;
            if n>b.len(){
                return None
            }
            let mut o=Object::new();
            for _ in 0..n{
                o.0.push((text(b,p)?,read(b,p,depth+1)?))
            }
            J::Object(o)
        }
        ,_=>return None
    }
    )
}
