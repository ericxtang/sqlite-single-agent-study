#[derive(Clone,Debug,PartialEq)]
pub enum Kind {
    Word, Quoted, Str, Num, Blob, Sym, Param, Eof
}
#[derive(Clone,Debug)]
pub struct Token {
    pub kind:Kind,pub text:String,pub start:usize,pub end:usize
}
pub fn lex(s:&str)->Result<Vec<Token>,String>{
    let b=s.as_bytes();
    let mut out=vec![];
    let mut i=0;
    while i<b.len(){
        let start=i;
        let c=b[i];
        if c.is_ascii_whitespace(){
            i+=1;
            continue
        }
        if c==b'-'&&b.get(i+1)==Some(&b'-'){
            while i<b.len()&&b[i]!=b'\n'{
                i+=1
            }
            continue
        }
        if c==b'/'&&b.get(i+1)==Some(&b'*'){
            i+=2;
            while i+1<b.len()&& &b[i..i+2]!=b"*/"{
                i+=1
            }
            i=(i+2).min(b.len());
            continue
        }
        let (kind,text)=if [b'\'',b'"',b'`',b'['].contains(&c)||((c==b'x'||c==b'X')&&b.get(i+1)==Some(&b'\'')){
            let blob=c==b'x'||c==b'X';
            if blob{
                i+=1
            }
            let q=b[i];
            let end=if q==b'['{
                b']'
            }
            else{
                q
            }
            ;
            i+=1;
            let mut buf=vec![];
            loop{
                if i>=b.len(){
                    return Err("unrecognized token: unterminated quote".into())
                }
                if b[i]==end {
                    i+=1;
                    if q!=b'['&&b.get(i)==Some(&end){
                        buf.push(end);
                        i+=1
                    }
                    else{
                        break
                    }
                }
                else{
                    buf.push(b[i]);
                    i+=1
                }
            }
            (if blob{
                Kind::Blob
            }
            else if q==b'\''{
                Kind::Str
            }
            else{
                Kind::Quoted
            }
            ,String::from_utf8_lossy(&buf).into_owned())
        }
        else if c.is_ascii_digit()||(c==b'.'&&b.get(i+1).is_some_and(u8::is_ascii_digit)){
            i+=1;
            if c==b'0'&&b.get(i).is_some_and(|x|*x==b'x'||*x==b'X'){
                i+=1;
                while i<b.len()&&(b[i].is_ascii_hexdigit()||b[i]==b'_'){
                    i+=1
                }
            }
            else{
                while i<b.len()&&(b[i].is_ascii_digit()||b[i]==b'_'||b[i]==b'.'){
                    i+=1
                }
                if i<b.len()&&(b[i]==b'e'||b[i]==b'E'){
                    i+=1;
                    if i<b.len()&&(b[i]==b'+'||b[i]==b'-'){
                        i+=1
                    }
                    while i<b.len()&&(b[i].is_ascii_digit()||b[i]==b'_'){
                        i+=1
                    }
                }
            }
            (Kind::Num,s[start..i].into())
        }
        else if c.is_ascii_alphabetic()||c==b'_'||c>=128 {
            i+=1;
            while i<b.len()&&(b[i].is_ascii_alphanumeric()||b[i]==b'_'||b[i]==b'$'||b[i]>=128){
                i+=1
            }
            (Kind::Word,s[start..i].into())
        }
        else if [b'?',b':',b'@',b'$'].contains(&c){
            i+=1;
            while i<b.len()&&(b[i].is_ascii_alphanumeric()||b[i]==b'_'){
                i+=1
            }
            (Kind::Param,s[start..i].into())
        }
        else{
            i+=1;
            if i<b.len()&&["<=",">=","!=","<>","==","||","<<",">>","->"].contains(&&s[start..i+1]){
                i+=1;
                if &s[start..i]=="->"&&b.get(i)==Some(&b'>'){
                    i+=1
                }
            }
            (Kind::Sym,s[start..i].into())
        }
        ;
        out.push(Token{
            kind,text,start,end:i
        }
        );
    }
    out.push(Token{
        kind:Kind::Eof,text:String::new(),start:i,end:i
    }
    );
    Ok(out)
}
