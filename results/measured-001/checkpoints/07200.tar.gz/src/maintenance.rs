use crate::{engine::*,ast::*,storage::*,value::{Value,compare},parser::Res};
use std::cmp::Ordering;
impl Engine {
    pub fn vacuum(&mut self,into:Option<&Expr>)->Res<Relation> {
        if self.tx.is_some(){return Err("cannot VACUUM from within a transaction".into())}
        if let Some(e)=into {
            let name=self.eval(e,&Env::default(),None,&Ctes::new(),0)?;
            if !matches!(name,Value::Text(_)|Value::JsonText(_)){return Err("non-text filename".into())}
            let path=confined(&name.text())?;
            if path.exists()&&std::fs::metadata(&path).map_err(|e|e.to_string())?.len()!=0{return Err("output file already exists".into())}
            save(&path,&self.db)?;
        }
        Ok(Relation::default())
    }
    pub fn analyze(&mut self,target:Option<&str>)->Res<Relation> {
        if let Some(n)=target {
            if let Some((schema,name))=n.split_once('.') { if let Some(a)=self.attachments.get_mut(&key(schema)){return a.execute_statement(Statement::Analyze(Some(name.into())))} }
            if let Some(a)=self.attachments.get_mut(&key(n)){return a.execute_statement(Statement::Analyze(None))}
        }
        let temp=target.is_some_and(|n|n.eq_ignore_ascii_case("temp"));
        let target=target.filter(|n|!n.eq_ignore_ascii_case("main")&&!n.eq_ignore_ascii_case("temp"));
        let target_key=target.map(|n|self.resolve_relation_key(n));
        let index_key=target.map(|n|self.resolve_index_key(n));
        let target_table=target_key.as_ref().filter(|n|self.db.tables.contains_key(*n)).cloned().or_else(||index_key.as_ref().and_then(|n|self.db.indexes.get(n)).map(|i|key(&i.table)));
        if target.is_some()&&target_table.is_none(){return Err(format!("no such table: {}",target.unwrap()))}
        let temp=target_table.as_ref().and_then(|n|self.db.tables.get(n)).map(|t|t.def.temporary).unwrap_or(temp);
        let stat_name=if temp{"temp.sqlite_stat1"}else{"sqlite_stat1"};
        let mut stats=self.db.tables.get(stat_name).cloned().unwrap_or_else(||Table {
            def:TableDef{name:stat_name.into(),cols:["tbl","idx","stat"].iter().map(|n|Column{name:(*n).into(),typ:"TEXT".into(),collate:"BINARY".into(),..Default::default()}).collect(),temporary:temp,sql:"CREATE TABLE sqlite_stat1(tbl,idx,stat)".into(),..Default::default()},
            rows:vec![],sequence:0,sequence_written:false
        });
        if !self.db.tables.contains_key(stat_name){self.db.schema_version+=1}
        if let Some(n)=&target_table{let name=n.trim_start_matches("temp.");stats.rows.retain(|r|!r.values[0].text().eq_ignore_ascii_case(name))}else{stats.rows.clear()}
        for (name,t) in &self.db.tables {
            if t.def.temporary!=temp||name.trim_start_matches("temp.").starts_with("sqlite_")||target_table.as_ref().is_some_and(|n|n!=name)||t.rows.is_empty(){continue}
            let indexes=self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(name)).collect::<Vec<_>>();
            if !indexes.iter().any(|i|i.filter.is_none()) {
                stats.rows.push(Row{id:stats.rows.len() as i64+1,values:vec![Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Null,Value::Text(t.rows.len().to_string())]});
            }
            for idx in indexes {
                let mut keys=vec![];
                let mut collations=vec![];
                for row in &t.rows {
                    let env=self.row_env(t,row,None);
                    if let Some(e)=&idx.filter{if self.eval(e,&env,None,&Ctes::new(),0)?.truth()!=Some(true){continue}}
                    if collations.is_empty(){collations=idx.cols.iter().map(|o|self.meta(&o.expr,&env).1).collect()}
                    keys.push(idx.cols.iter().map(|o|self.eval(&o.expr,&env,None,&Ctes::new(),0)).collect::<Res<Vec<_>>>()?);
                }
                if keys.is_empty(){continue}
                let mut counts=vec![keys.len().to_string()];
                for len in 1..=idx.cols.len(){
                    let mut distinct:Vec<Vec<Value>>=vec![];
                    for row in &keys{if !distinct.iter().any(|r|(0..len).all(|i|compare(&row[i],&r[i],&collations[i])==Ordering::Equal)){distinct.push(row.clone())}}
                    counts.push(keys.len().div_ceil(distinct.len()).to_string());
                }
                stats.rows.push(Row{id:stats.rows.len() as i64+1,values:vec![Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Text(idx.name.trim_start_matches("temp.").into()),Value::Text(counts.join(" "))]});
            }
        }
        self.db.tables.insert(stat_name.into(),stats);
        Ok(Relation::default())
    }
}
