use crate::{
    ast::*,engine::*,storage::*,parser::Res,value::Value
}
;
fn visit_expr(e:&mut Expr,f:&mut impl FnMut(&mut Expr)){
    visit_expr_tables(e,f,&mut |_|{
    }
    )
}
fn visit_expr_tables(e:&mut Expr,f:&mut impl FnMut(&mut Expr),t:&mut impl FnMut(&mut String)){
    match e{
        Expr::Unary(_,e)|Expr::Cast(e,_)|Expr::Collate(e,_)|Expr::RowAccess(e,_)=>visit_expr_tables(e,f,t),Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>{
            visit_expr_tables(a,f,t);
            visit_expr_tables(b,f,t)
        }
        ,Expr::Between(a,b,c,_)=>{
            visit_expr_tables(a,f,t);
            visit_expr_tables(b,f,t);
            visit_expr_tables(c,f,t)
        }
        ,Expr::Tuple(es)=>for e in es{
            visit_expr_tables(e,f,t)
        }
        ,Expr::In(e,es,q,_)=>{
            visit_expr_tables(e,f,t);
            for e in es{
                visit_expr_tables(e,f,t)
            }
            if let Some(q)=q{
                visit_query(q,f,t)
            }
        }
        ,Expr::Subquery(q)|Expr::Exists(q)=>visit_query(q,f,t),Expr::Case(e,arms,o)=>{
            if let Some(e)=e{
                visit_expr_tables(e,f,t)
            }
            for(a,b)in arms{
                visit_expr_tables(a,f,t);
                visit_expr_tables(b,f,t)
            }
            if let Some(e)=o{
                visit_expr_tables(e,f,t)
            }
        }
        ,Expr::Call{
            args,filter,order,over,..
        }
        =>{
            for e in args{
                visit_expr_tables(e,f,t)
            }
            if let Some(e)=filter{
                visit_expr_tables(e,f,t)
            }
            for o in order{
                visit_expr_tables(&mut o.expr,f,t)
            }
            if let Some(w)=over{
                for e in &mut w.partition{
                    visit_expr_tables(e,f,t)
                }
                for o in &mut w.order{
                    visit_expr_tables(&mut o.expr,f,t)
                }
            }
        }
        ,_=>{
        }
    }
    f(e)
}
fn visit_source(s:&mut Source,e:&mut impl FnMut(&mut Expr),t:&mut impl FnMut(&mut String)){
    match s{
        Source::Indexed(s,_)=>visit_source(s,e,t),
        Source::Table(n,_,args)=>{
            t(n);
            for x in args{
                visit_expr_tables(x,e,t)
            }
        }
        ,Source::Query(q,_)=>visit_query(q,e,t),Source::Join(a,b,_,on,_,_)=>{
            visit_source(a,e,t);
            visit_source(b,e,t);
            if let Some(x)=on{
                visit_expr_tables(x,e,t)
            }
        }
    }
}
fn visit_query(q:&mut Query,e:&mut impl FnMut(&mut Expr),t:&mut impl FnMut(&mut String)){
    for c in &mut q.ctes{
        visit_query(&mut c.query,e,t)
    }
    for s in &mut q.cores{
        for i in &mut s.items{
            visit_expr_tables(&mut i.expr,e,t)
        }
        if let Some(f)=&mut s.from{
            visit_source(f,e,t)
        }
        for x in s.filter.iter_mut().chain(s.having.iter_mut()).chain(s.group.iter_mut()){
            visit_expr_tables(x,e,t)
        }
        if let Some(rows)=&mut s.values{
            for row in rows{
                for x in row{
                    visit_expr_tables(x,e,t)
                }
            }
        }
        for(_,w)in &mut s.windows{
            for x in &mut w.partition{
                visit_expr_tables(x,e,t)
            }
            for o in &mut w.order{
                visit_expr_tables(&mut o.expr,e,t)
            }
        }
    }
    for o in &mut q.order{
        visit_expr_tables(&mut o.expr,e,t)
    }
    for x in q.limit.iter_mut().chain(q.offset.iter_mut()){
        visit_expr_tables(x,e,t)
    }
}
fn visit_statement(s:&mut Statement,e:&mut impl FnMut(&mut Expr),t:&mut impl FnMut(&mut String)){
    match s{
        Statement::IndexGuard(s,_)=>visit_statement(s,e,t),
        Statement::Query(q)=>visit_query(q,e,t),Statement::With(cs,_,s)=>{
            for c in cs{
                visit_query(&mut c.query,e,t)
            }
            visit_statement(s,e,t)
        }
        ,Statement::Insert{
            table,query,upsert,returning,..
        }
        =>{
            t(table);
            if let Some(q)=query{
                visit_query(q,e,t)
            }
            for u in upsert{
                for(_,x)in &mut u.assignments{
                    visit_expr_tables(x,e,t)
                }
                if let Some(x)=&mut u.filter{
                    visit_expr_tables(x,e,t)
                }
            }
            for i in returning{
                visit_expr_tables(&mut i.expr,e,t)
            }
        }
        ,Statement::Update{
            table,assignments,filter,returning,from,..
        }
        =>{
            t(table);
            for(_,x)in assignments{
                visit_expr_tables(x,e,t)
            }
            if let Some(x)=filter{
                visit_expr_tables(x,e,t)
            }
            if let Some(s)=from{
                visit_source(s,e,t)
            }
            for i in returning{
                visit_expr_tables(&mut i.expr,e,t)
            }
        }
        ,Statement::Delete{
            table,filter,returning,..
        }
        =>{
            t(table);
            if let Some(x)=filter{
                visit_expr_tables(x,e,t)
            }
            for i in returning{
                visit_expr_tables(&mut i.expr,e,t)
            }
        }
        ,_=>{
        }
    }
}
pub fn rewrite_sql(sql:&str,old:&str,new:&str)->String{
    let Ok(tokens)=crate::lexer::lex(sql)else{
        return sql.into()
    }
    ;
    let mut result=String::new();
    let mut end=0;
    for t in tokens{
        if matches!(t.kind,crate::lexer::Kind::Word|crate::lexer::Kind::Quoted)&&t.text.eq_ignore_ascii_case(old){
            result.push_str(&sql[end..t.start]);
            result.push('"');
            result.push_str(&new.replace('"',"\"\""));
            result.push('"');
            end=t.end
        }
    }
    result.push_str(&sql[end..]);
    result
}
impl Engine{
    pub fn rename_table_dependencies(&mut self,old:&str,new:&str) {
        let old_name=old.trim_start_matches("temp.");let new_name=new.trim_start_matches("temp.");
        let old_temp=old.starts_with("temp.");
        let temp_shadow=self.db.tables.contains_key(&format!("temp.{}",old_name.to_ascii_lowercase()))||self.db.views.contains_key(&format!("temp.{}",old_name.to_ascii_lowercase()));
        let targets=|n:&str,context_temp:bool| {
            if let Some((schema,name))=n.split_once('.') {name.eq_ignore_ascii_case(old_name)&&schema.eq_ignore_ascii_case(if old_temp{"temp"}else{"main"})}
            else {n.eq_ignore_ascii_case(old_name)&&if context_temp{old_temp||!temp_shadow}else{!old_temp}}
        };
        let mut expr=|e:&mut Expr|if let Expr::Col(ns)=e {if ns.len()>1 {let i=ns.len()-2;if ns[i].eq_ignore_ascii_case(old_name){ns[i]=new_name.into();}}};
        let rewrite=|n:&mut String| {if let Some((schema,_))=n.split_once('.') {*n=format!("{}.{}",schema,new_name);}else{*n=new_name.into();}};
        for view in self.db.views.values_mut() {
            let context=view.name.starts_with("temp.");let mut used=false;
            visit_query(&mut view.query.clone(),&mut |_|{},&mut |n|used|=targets(n,context));
            if used {
                visit_query(&mut view.query,&mut expr,&mut |n|if targets(n,context){rewrite(n)});
                view.sql=rewrite_sql(&view.sql,old_name,new_name);
            }
        }
        for trigger in self.db.triggers.values_mut() {
            let context=trigger.temporary;let mut used=trigger.table.eq_ignore_ascii_case(old);
            if used {trigger.table=new.into();}
            for mut stmt in trigger.body.clone() {visit_statement(&mut stmt,&mut |_|{},&mut |n|used|=targets(n,context));}
            if used {
                if let Some(e)=&mut trigger.when {visit_expr(e,&mut expr);}
                for stmt in &mut trigger.body {visit_statement(stmt,&mut expr,&mut |n|if targets(n,context){rewrite(n)});}
                trigger.sql=rewrite_sql(&trigger.sql,old_name,new_name);
            }
        }
        for index in self.db.indexes.values_mut().filter(|i|i.table.eq_ignore_ascii_case(old)) {
            index.sql=rewrite_sql(&index.sql,old_name,new_name);
            for o in &mut index.cols {visit_expr(&mut o.expr,&mut expr);}
            if let Some(e)=&mut index.filter {visit_expr(e,&mut expr);}
        }
    }
    pub fn rename_column_dependencies(&mut self,table:&str,old:&str,new:&str){
        let mut expr=|e:&mut Expr|{if let Expr::Dqs(n)=e{if n.eq_ignore_ascii_case(old){*n=new.into()}}if let Expr::Col(ns)=e{
            if ns.last().is_some_and(|s|s.eq_ignore_ascii_case(old)){
                *ns.last_mut().unwrap()=new.into()
            }
        }}
        ;
        for t in self.db.tables.values_mut(){
            for fk in &mut t.def.foreign{
                if fk.table.eq_ignore_ascii_case(table){
                    for n in &mut fk.target{
                        if n.eq_ignore_ascii_case(old){
                            *n=new.into()
                        }
                    }
                }
            }
        }
        for v in self.db.views.values_mut(){
            let mut references=false;
            let mut q=v.query.clone();
            visit_query(&mut q,&mut |_|{
            }
            ,&mut |n|{
                references|=n.eq_ignore_ascii_case(table)
            }
            );
            if references{
                visit_query(&mut v.query,&mut expr,&mut |_|{
                }
                );
                for s in &mut v.query.cores{
                    for i in &mut s.items{
                        if i.alias.is_none()&&i.name.eq_ignore_ascii_case(old){
                            i.name=new.into()
                        }
                    }
                }
                v.sql=rewrite_sql(&v.sql,old,new)
            }
        }
        for tr in self.db.triggers.values_mut(){
            let mut references=tr.table.eq_ignore_ascii_case(table);
            for mut s in tr.body.clone(){
                visit_statement(&mut s,&mut |_|{
                }
                ,&mut |n|references|=n.eq_ignore_ascii_case(table))
            }
            if references{
                for n in &mut tr.columns{
                    if n.eq_ignore_ascii_case(old){
                        *n=new.into()
                    }
                }
                if let Some(e)=&mut tr.when{
                    visit_expr(e,&mut expr)
                }
                for s in &mut tr.body{
                    visit_statement(s,&mut expr,&mut |_|{
                    }
                    );
                    match s{
                        Statement::Insert{
                            table:t,cols,..
                        }
                        if t.eq_ignore_ascii_case(table)=>for n in cols{
                            if n.eq_ignore_ascii_case(old){
                                *n=new.into()
                            }
                        }
                        ,Statement::Update{
                            table:t,assignments,..
                        }
                        if t.eq_ignore_ascii_case(table)=>for(n,_)in assignments{
                            if n.eq_ignore_ascii_case(old){
                                *n=new.into()
                            }
                        }
                        ,_=>{
                        }
                    }
                }
                tr.sql=rewrite_sql(&tr.sql,old,new)
            }
        }
    }
    pub fn validate_schema_expression(&self,e:&Expr,env:&Env,context:&str,deterministic:bool)->Res<()> {
        let mut error=None;
        visit_expr(&mut e.clone(),&mut |node| {
            if matches!(node,Expr::Subquery(_)|Expr::Exists(_)|Expr::In(_,_,Some(_),_)) {
                error=Some(format!("subqueries prohibited in {}",context));
            }
            if let Expr::Call{name,args,over,..}=node {
                if is_aggregate(name,args.len())||over.is_some() {
                    error=Some(format!("aggregate and window functions prohibited in {}",context));
                }
                if deterministic&&["random","randomblob","changes","last_insert_rowid","total_changes","sqlite_version","sqlite_source_id","sqlite_compileoption_get","sqlite_compileoption_used"].contains(&name.to_ascii_lowercase().as_str()) {
                    error=Some(format!("non-deterministic functions prohibited in {}",context));
                }
            }
            if deterministic {
                if let Expr::Col(names)=node {
                    if names.len()==1&&["CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP"].contains(&names[0].to_ascii_uppercase().as_str())&&env.get(names).ok().flatten().is_none() {
                        error=Some(format!("non-deterministic functions prohibited in {}",context));
                    }
                }
            }
        });
        if let Some(error)=error {return Err(error)}
        self.validate_expr(e,env,&Ctes::new(),0)
    }
    pub fn validate_index_definition(&self,t:&Table,index:&Index)->Res<()> {
        if crate::lexer::lex(&index.sql)?.iter().any(|t|t.kind==crate::lexer::Kind::Param) {
            return Err("parameters prohibited in index expressions".into());
        }
        let env=self.row_env(t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},None);
        for e in index.cols.iter().map(|o|&o.expr).chain(index.filter.iter()) {
            self.validate_schema_expression(e,&env,"index expressions",true)?;
            let mut rowid=false;
            visit_expr(&mut e.clone(),&mut |e| {
                if let Expr::Col(n)=e {
                    rowid|=n.last().is_some_and(|n|["rowid","_rowid_","oid"].contains(&n.to_ascii_lowercase().as_str())&&!t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n)));
                }
            });
            if rowid {return Err("no such column: rowid".into())}
        }
        if index.cols.iter().any(|o|o.nulls.is_some()) {return Err("unsupported use of NULLS FIRST or NULLS LAST in index".into())}
        Ok(())
    }
    pub fn eval_schema(&self,e:&Expr,env:&Env)->Res<Value> {
        let _scope=DeterministicScope::enter();
        self.eval(e,env,None,&Ctes::new(),0)
    }
    pub fn validate_table_definition(&self,t:&Table)->Res<()>{
        for c in &t.def.cols{
            if !["binary","nocase","rtrim"].contains(&c.collate.to_ascii_lowercase().as_str()){
                return Err(format!("no such collation sequence: {}",c.collate))
            }
        }
        let env=self.row_env(t,&Row{
            id:0,values:vec![Value::Null;
            t.def.cols.len()]
        }
        ,None);
        for key in &t.def.keys {for order in &key.cols {self.validate_schema_expression(&order.expr,&env,"table constraints",true)?;}}
        if t.def.keys.iter().filter(|k|k.primary).count()>1 {return Err("table has more than one primary key".into())}
        for u in &t.def.uniques{
            for n in u{
                if !t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n)){
                    return Err(format!("no such column: {}",n))
                }
            }
        }
        for f in &t.def.foreign{
            for n in &f.cols{
                if !t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n)){
                    return Err(format!("unknown column {} in foreign key definition",n))
                }
            }
        }
        for e in &t.def.checks {
            self.validate_schema_expression(e,&env,"CHECK constraints",false)?;
        }
        if t.def.cols.iter().all(|c|c.generated.is_some()){
            return Err("must have at least one non-generated column".into())
        }
        for c in &t.def.cols{
            if let Some(e)=&c.generated{
                let mut rowid=false;
                visit_expr(&mut e.clone(),&mut |e|if let Expr::Col(n)=e{
                    rowid|=n.last().is_some_and(|n|["rowid","_rowid_","oid"].contains(&n.to_ascii_lowercase().as_str())&&!t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n)))
                }
                );
                if rowid{
                    return Err("no such column: rowid".into())
                }
                if c.primary>0||c.default.is_some(){
                    return Err("generated columns cannot be part of the PRIMARY KEY or have a DEFAULT".into())
                }
                self.validate_schema_expression(e,&env,"generated columns",true)?;
            }
            if let Some(e)=&c.default{
                let mut bad=false;
                visit_expr(&mut e.clone(),&mut |e|{
                    if let Expr::Col(n)=e{
                        bad|=!(n.len()==1&&["TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP"].contains(&n[0].to_ascii_uppercase().as_str()))
                    }
                    bad|=matches!(e,Expr::Subquery(_)|Expr::Exists(_))
                }
                );
                if bad{
                    return Err(format!("default value of column [{}] is not constant",c.name))
                }
            }
        }
        let mut dependencies=vec![vec![];
        t.def.cols.len()];
        for(i,c)in t.def.cols.iter().enumerate(){
            if let Some(e)=&c.generated{
                visit_expr(&mut e.clone(),&mut |e|if let Expr::Col(n)=e{
                    if let Some(j)=t.def.cols.iter().position(|c|c.generated.is_some()&&c.name.eq_ignore_ascii_case(n.last().unwrap())){
                        dependencies[i].push(j)
                    }
                }
                )
            }
        }
        fn cycle(i:usize,edges:&[Vec<usize>],state:&mut [u8])->bool{
            if state[i]==1{
                return true
            }
            if state[i]==2{
                return false
            }
            state[i]=1;
            for j in &edges[i]{
                if cycle(*j,edges,state){
                    return true
                }
            }
            state[i]=2;
            false
        }
        let mut state=vec![0;
        t.def.cols.len()];
        for i in 0..state.len(){
            if cycle(i,&dependencies,&mut state){
                return Err("generated column loop".into())
            }
        }
        Ok(())
    }
    pub fn column_has_dependencies(&self,t:&Table,name:&str)->bool{
        let references=|e:&Expr|{
            let mut found=false;
            visit_expr(&mut e.clone(),&mut |e|if let Expr::Col(n)=e{
                found|=n.last().is_some_and(|n|n.eq_ignore_ascii_case(name))
            }
            );
            found
        }
        ;
        let own_checks=t.def.cols.iter().find(|c|c.name.eq_ignore_ascii_case(name)).map(|c|c.checks.iter().map(|e|serde_json::to_string(e).unwrap()).collect::<Vec<_>>()).unwrap_or_default();
        if t.def.checks.iter().filter(|e|!own_checks.contains(&serde_json::to_string(e).unwrap())).any(references)||t.def.cols.iter().filter_map(|c|c.generated.as_ref()).any(references){
            return true
        }
        for i in self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&t.def.name)){
            if i.cols.iter().any(|o|references(&o.expr))||i.filter.as_ref().is_some_and(references){
                return true
            }
        }
        for child in self.db.tables.values() {
            for fk in &child.def.foreign {
                if child.def.name.eq_ignore_ascii_case(&t.def.name)&&fk.cols.iter().any(|n|n.eq_ignore_ascii_case(name)) {return true}
                if fk.table.eq_ignore_ascii_case(&t.def.name)&&fk.target.iter().any(|n|n.eq_ignore_ascii_case(name)) {return true}
            }
        }
        for trigger in self.db.triggers.values() {
            let mut table_used=trigger.table.eq_ignore_ascii_case(&t.def.name);
            let mut column_used=trigger.when.as_ref().is_some_and(references);
            for mut stmt in trigger.body.clone() {
                visit_statement(&mut stmt,&mut |e|column_used|=references(e),&mut |n|table_used|=n.eq_ignore_ascii_case(&t.def.name));
                match stmt {Statement::Insert{table,cols,..} if table.eq_ignore_ascii_case(&t.def.name)=>column_used|=cols.iter().any(|n|n.eq_ignore_ascii_case(name)),Statement::Update{table,assignments,..} if table.eq_ignore_ascii_case(&t.def.name)=>column_used|=assignments.iter().any(|(n,_)|n.eq_ignore_ascii_case(name)),_=>{}}
            }
            if table_used&&column_used {return true}
        }
        for v in self.db.views.values(){
            let mut q=v.query.clone();
            let mut uses=false;
            let mut col=false;
            visit_query(&mut q,&mut |e|{
                if let Expr::Col(n)=e{
                    col|=n.last().is_some_and(|s|s.eq_ignore_ascii_case(name))
                }
            }
            ,&mut |n|uses|=n.eq_ignore_ascii_case(&t.def.name));
            if uses&&col{
                return true
            }
        }
        false
    }
}
pub fn qualify_main_view(q:&mut Query){
    let mut names=vec![];
    fn ctes(q:&Query,n:&mut Vec<String>){
        for c in &q.ctes{
            n.push(c.name.to_ascii_lowercase());
            ctes(&c.query,n)
        }
        fn src(s:&Source,n:&mut Vec<String>){
            match s{
                Source::Query(q,_)=>ctes(q,n),Source::Join(a,b,..)=>{
                    src(a,n);
                    src(b,n)
                }
                ,_=>{
                }
            }
        }
        for s in &q.cores{
            if let Some(s)=&s.from{
                src(s,n)
            }
        }
    }
    ctes(q,&mut names);
    visit_query(q,&mut |_|{
    }
    ,&mut |n|if !n.contains('.')&&!names.contains(&n.to_ascii_lowercase()){
        *n=format!("main.{}",n);
    }
    );
}

pub fn bind_schema_quotes(t:&mut Table) {
    let names=t.def.cols.iter().map(|c|c.name.clone()).collect::<Vec<_>>();
    let mut bind=|e:&mut Expr| { if let Expr::Dqs(n)=e { *e=if names.iter().any(|c|c.eq_ignore_ascii_case(n)) { Expr::Col(vec![n.clone()]) } else { Expr::Lit(Value::Text(n.clone())) }; } };
    for c in &mut t.def.cols { if let Some(e)=&mut c.generated { visit_expr(e,&mut bind); } for e in &mut c.checks {visit_expr(e,&mut bind);} }
    for e in &mut t.def.checks { visit_expr(e,&mut bind); }
}

thread_local! {static DETERMINISTIC_DEPTH:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
struct DeterministicScope;
impl DeterministicScope {
    fn enter()->Self {DETERMINISTIC_DEPTH.with(|d|d.set(d.get()+1));Self}
}
impl Drop for DeterministicScope {
    fn drop(&mut self) {DETERMINISTIC_DEPTH.with(|d|d.set(d.get()-1));}
}
pub fn check_datetime_args(name:&str,args:&[Value])->Res<()> {
    if !DETERMINISTIC_DEPTH.with(|d|d.get()>0) {return Ok(())}
    let values=if name=="strftime" {args.get(1..).unwrap_or(&[])} else {args};
    let dynamic=values.is_empty()||values.iter().any(|v|matches!(v,Value::Text(t) if ["now","localtime","utc"].contains(&t.to_ascii_lowercase().as_str())))||values.first().is_some_and(|v|["subsec","subsecond"].contains(&v.text().to_ascii_lowercase().as_str()));
    if dynamic {return Err(format!("non-deterministic use of {}() in a schema expression",name))}
    Ok(())
}

pub fn bind_index_quotes(index:&mut Index,t:&Table) {
    let mut bind=|e:&mut Expr| {
        if let Expr::Dqs(n)=e {
            *e=if t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n))||["rowid","_rowid_","oid"].contains(&n.to_ascii_lowercase().as_str()) {Expr::Col(vec![n.clone()])} else {Expr::Lit(Value::Text(n.clone()))};
        }
    };
    for order in &mut index.cols {visit_expr(&mut order.expr,&mut bind);}
    if let Some(e)=&mut index.filter {visit_expr(e,&mut bind);}
}

pub fn check_object_name(name:&str)->Res<()> {
    if name.rsplit('.').next().unwrap_or(name).to_ascii_lowercase().starts_with("sqlite_") {return Err("object name reserved for internal use".into())}
    Ok(())
}
pub fn normalize_schema_sql(sql:&str)->String {
    let Ok(ts)=crate::lexer::lex(sql)else{return sql.into()};
    let mut i=0;
    while ts.get(i).is_some_and(|t|t.text==";"){i+=1;}
    if !ts.get(i).is_some_and(|t|t.text.eq_ignore_ascii_case("CREATE")){return sql.into()}
    i+=1;
    if ts.get(i).is_some_and(|t|["TEMP","TEMPORARY"].contains(&t.text.to_ascii_uppercase().as_str())){i+=1;}
    let unique=ts.get(i).is_some_and(|t|t.text.eq_ignore_ascii_case("UNIQUE"));if unique{i+=1;}
    let Some(kind)=ts.get(i)else{return sql.into()};i+=1;
    if ts.get(i).is_some_and(|t|t.text.eq_ignore_ascii_case("IF")){i+=3;}
    if ts.get(i+1).is_some_and(|t|t.text=="."){i+=2;}
    let Some(name)=ts.get(i)else{return sql.into()};
    format!("CREATE {}{} {}{}",if unique{"UNIQUE "}else{""},kind.text.to_ascii_uppercase(),&sql[name.start..name.end],&sql[name.end..].trim_end_matches(';'))
}

// Locate top-level column definitions without confusing commas in types/defaults.
fn column_spans(sql:&str)->Vec<(String,usize,usize)> {
    let Ok(ts)=crate::lexer::lex(sql)else{return vec![]};
    let Some(open)=ts.iter().position(|t|t.text=="(")else{return vec![]};
    let mut depth=0;let mut first=open+1;let mut out=vec![];
    for i in open+1..ts.len() {
        let t=&ts[i];
        if t.text=="(" {depth+=1;}
        else if t.text==")"&&depth>0 {depth-=1;}
        else if depth==0&&(t.text==","||t.text==")") {
            if first<i {out.push((ts[first].text.clone(),ts[first].start,ts[i-1].end));}
            first=i+1;
            if t.text==")" {break}
        }
    }
    out
}
pub fn edit_column_sql(sql:&str,name:&str,replacement:Option<&str>)->String {
    let spans=column_spans(sql);
    let Some(i)=spans.iter().position(|(n,_,_)|n.eq_ignore_ascii_case(name))else{return sql.into()};
    let (_,mut start,mut end)=spans[i];
    if replacement.is_none() {
        if i>0 {start=spans[i-1].2;}else if i+1<spans.len(){end=spans[i+1].1;}
    }
    format!("{}{}{}",&sql[..start],replacement.unwrap_or(""),&sql[end..])
}
pub fn remove_not_null(sql:&str)->String {
    let Ok(ts)=crate::lexer::lex(sql)else{return sql.into()};
    let mut depth=0;let mut cuts=vec![];let mut i=0;
    while i<ts.len() {
        if ts[i].text=="(" {depth+=1;}
        else if ts[i].text==")" {depth-=1;}
        else if depth==0&&ts[i].text.eq_ignore_ascii_case("NOT")&&ts.get(i+1).is_some_and(|t|t.text.eq_ignore_ascii_case("NULL")) {
            let start=if i>=2&&ts[i-2].text.eq_ignore_ascii_case("CONSTRAINT"){ts[i-2].start}else{ts[i].start};
            let mut end=i+1;
            if ts.get(i+2).is_some_and(|t|t.text.eq_ignore_ascii_case("ON"))&&ts.get(i+3).is_some_and(|t|t.text.eq_ignore_ascii_case("CONFLICT")){end=i+4;}
            if let Some(last)=ts.get(end){cuts.push((start,last.end));i=end;}
        }
        i+=1;
    }
    let mut out=String::new();let mut at=0;
    for (a,b) in cuts {out.push_str(&sql[at..a]);at=b;}
    out.push_str(&sql[at..]);out.trim().into()
}
pub fn column_sql(sql:&str,name:&str)->Option<String> {
    column_spans(sql).into_iter().find(|(n,_,_)|n.eq_ignore_ascii_case(name)).map(|(_,a,b)|sql[a..b].into())
}

pub fn column_name(e:&Expr)->Option<&str> {
    match e {Expr::Col(n)=>n.last().map(String::as_str),Expr::Collate(e,_)=>column_name(e),_=>None}
}
