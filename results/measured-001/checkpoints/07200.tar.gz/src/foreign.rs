use crate::{
    storage::{
        Database,Table,Row,key
    }
    ,ast::Foreign,value::{
        Value,affinity,compare
    }
}
;
use std::{
    collections::BTreeSet,cmp::Ordering
}
;
pub fn violation_key(t:&Table,fk:usize,f:&Foreign,r:&Row)->String{
    let values=f.cols.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).map(|i|r.values[i].clone()).unwrap_or(Value::Null)).collect::<Vec<_>>();
    serde_json::to_string(&(key(&t.def.name),fk,r.id,values)).unwrap()
}
pub fn violations(db:&Database)->BTreeSet<String>{
    let mut result=BTreeSet::new();
    for t in db.tables.values(){
        for(fk,f)in t.def.foreign.iter().enumerate(){
            let cols=f.cols.iter().filter_map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n))).collect::<Vec<_>>();
            let parent=db.tables.get(&if t.def.temporary{
                format!("temp.{}",key(&f.table))
            }
            else{
                key(&f.table)
            }
            );
            let targets=parent.map(|p|{
                if f.target.is_empty(){
                    let mut cs=p.def.cols.iter().enumerate().filter(|(_,c)|c.primary>0).collect::<Vec<_>>();
                    cs.sort_by_key(|(_,c)|c.primary);
                    cs.into_iter().map(|(i,_)|i).collect::<Vec<_>>()
                }
                else{
                    f.target.iter().filter_map(|n|p.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n))).collect()
                }
            }
            );
            for r in &t.rows{
                if cols.iter().any(|i|r.values[*i].null()){
                    continue
                }
                let found=if let(Some(p),Some(target))=(parent,&targets){
                    cols.len()==target.len()&&p.rows.iter().any(|pr|cols.iter().zip(target).all(|(i,j)|compare(&r.values[*i].apply(affinity(&p.def.cols[*j].typ)),&pr.values[*j],&p.def.cols[*j].collate)==Ordering::Equal))
                }
                else{
                    false
                }
                ;
                if !found{
                    result.insert(violation_key(t,fk,f,r));
                }
            }
        }
    }
    result
}
