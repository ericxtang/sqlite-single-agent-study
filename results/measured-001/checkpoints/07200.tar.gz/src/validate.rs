use crate::{
    engine::*,ast::*,value::Value,parser::Res,functions
}
;
impl Engine{
    pub fn bind_source(&self,s:&Source,env:&Env,ctes:&Ctes,depth:usize)->Res<Relation> {
        let _scope=BindingScope::enter();self.source(s,env,ctes,depth)
    }
    pub fn bind_query(&self,q:&Query,env:&Env,ctes:&Ctes,depth:usize)->Res<Relation> {
        let _scope=BindingScope::enter();
        self.query(q,env,ctes,depth)
    }
    pub fn validate_row_expr(&self,e:&Expr,env:&Env)->Res<()> {
        if has_aggregate(e)||has_window(e){return Err("misuse of aggregate or window function".into())}
        self.validate_expr(e,env,&Ctes::new(),0)
    }
    pub fn validate_expr(&self,e:&Expr,env:&Env,ctes:&Ctes,depth:usize)->Res<()>{
        if depth>100{
            return Err("expression tree too large".into())
        }
        let sub=|e:&Expr|self.validate_expr(e,env,ctes,depth+1);
        match e{
            Expr::Tuple(es)=>{
                for e in es{
                    sub(e)?
                }
            }
            ,Expr::RowAccess(e,_)=>sub(e)?,Expr::Dqs(n)=>{env.get(&[n.clone()])?;},Expr::Lit(_)=>{
            }
            ,Expr::Col(n)=>{
                if env.get(n)?.is_none()&&self.trigger_env.as_ref().map(|e|e.get(n)).transpose()?.flatten().is_none()&&!(n.len()==1&&["TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP"].contains(&n[0].to_ascii_uppercase().as_str())){
                    return Err(format!("no such column: {}",n.join(".")))
                }
            }
            ,Expr::Star(_)=>{
            }
            ,Expr::Collate(e,c)=>{
                if !["binary","nocase","rtrim"].contains(&c.to_ascii_lowercase().as_str()){
                    return Err(format!("no such collation sequence: {}",c))
                }
                sub(e)?
            }
            ,Expr::Unary(_,e)|Expr::Cast(e,_)=>sub(e)?,Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>{
                sub(a)?;
                sub(b)?
            }
            ,Expr::Between(a,b,c,_)=>{
                sub(a)?;
                sub(b)?;
                sub(c)?
            }
            ,Expr::In(e,es,q,_)=>{
                sub(e)?;
                for x in es{
                    sub(x)?
                }
                if let Some(q)=q{
                    self.bind_query(q,env,ctes,depth+1)?;
                }
            }
            ,Expr::Case(base,arms,other)=>{
                if let Some(e)=base{
                    sub(e)?
                }
                for(a,b)in arms{
                    sub(a)?;
                    sub(b)?
                }
                if let Some(e)=other{
                    sub(e)?
                }
            }
            ,Expr::Subquery(q)|Expr::Exists(q)=>{
                self.bind_query(q,env,ctes,depth+1)?;
            }
            ,Expr::Call{
                name,args,filter,order,over,distinct
            }
            =>{
                let n=name.to_ascii_lowercase();
                if n=="raise"{
                    if self.trigger_env.is_none(){
                        return Err("RAISE() may only be used within a trigger-program".into())
                    }
                    if let Some(e)=args.get(1){
                        sub(e)?
                    }
                    return Ok(())
                }
                if n.starts_with("json") {crate::json::validate_call(&n,args.len())?;}
                if ["changes","total_changes","last_insert_rowid"].contains(&n.as_str())&&!args.is_empty(){return Err("wrong number of arguments".into())}
                if (n=="strftime"&&args.is_empty())||(n=="timediff"&&args.len()!=2){return Err("wrong number of arguments".into())}
                if ["row_number","rank","dense_rank","percent_rank","cume_dist","ntile","lag","lead","first_value","last_value","nth_value"].contains(&n.as_str())&&over.is_none(){return Err("misuse of window function".into())}
                if is_aggregate(name,args.len())&&over.is_none()&&(args.iter().any(has_aggregate)||args.iter().any(has_window)||filter.as_ref().is_some_and(|e|has_aggregate(e)||has_window(e))){return Err("misuse of aggregate function".into())}
                let agg=is_aggregate(name,args.len());
                let valid_arity=match n.as_str(){
                    "row_number"|"rank"|"dense_rank"|"percent_rank"|"cume_dist"=>args.is_empty(),"ntile"|"first_value"|"last_value"|"sum"|"total"|"avg"|"count"|"median"|"json_group_array"|"jsonb_group_array"=>args.len()==1,"nth_value"|"percentile"|"percentile_cont"|"percentile_disc"|"json_group_object"|"jsonb_group_object"|"string_agg"=>args.len()==2,"lag"|"lead"=>(1..=3).contains(&args.len()),"group_concat"=>(1..=2).contains(&args.len()),_=>true
                }
                ;
                if !valid_arity{
                    return Err(format!("wrong number of arguments to function {}()",name))
                }
                if over.is_some(){
                    if *distinct{
                        return Err("DISTINCT is not supported for window functions".into())
                    }
                    if !agg&&!["row_number","rank","dense_rank","percent_rank","cume_dist","ntile","lag","lead","first_value","last_value","nth_value"].contains(&n.as_str()){
                        return Err(format!("{}() may not be used as a window function",name))
                    }
                }
                if !agg&&filter.is_some(){
                    return Err("FILTER may only be used with aggregate functions".into())
                }
                if !agg&&!order.is_empty(){
                    return Err("ORDER BY may only be used with aggregate functions".into())
                }
                for e in args{
                    sub(e)?
                }
                if let Some(f)=filter{
                    sub(f)?
                }
                for o in order{
                    sub(&o.expr)?
                }
                if let Some(w)=over{
                    for e in &w.partition{
                        sub(e)?
                    }
                    for o in &w.order{
                        sub(&o.expr)?
                    }
                }
                if !is_aggregate(name,args.len())&&!n.starts_with("json")&&!matches!(n.as_str(),"changes"|"total_changes"|"last_insert_rowid"|"date"|"time"|"datetime"|"julianday"|"unixepoch"|"strftime"|"timediff"|"row_number"|"rank"|"dense_rank"|"percent_rank"|"cume_dist"|"ntile"|"lag"|"lead"|"first_value"|"last_value"|"nth_value"){
                    functions::scalar(name,&vec![Value::Null;
                    args.len()],self.case_like)?;
                }
            }
        }
        Ok(())
    }
}

thread_local! {static BINDING_DEPTH:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
pub fn binding()->bool {BINDING_DEPTH.with(|d|d.get()>0)}
struct BindingScope;
impl BindingScope {fn enter()->Self{BINDING_DEPTH.with(|d|d.set(d.get()+1));Self}}
impl Drop for BindingScope {fn drop(&mut self){BINDING_DEPTH.with(|d|d.set(d.get()-1));}}
