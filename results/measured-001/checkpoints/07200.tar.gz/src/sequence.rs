use crate::{
    engine::*,ast::*,storage::*,value::Value,parser::Res
}
;
impl Engine{
    pub fn sequence_relation(&self,temp:bool)->Res<Relation>{
        if !(if temp{
            self.db.temp_sequence_exists
        }
        else{
            self.db.sequence_exists
        }
        ){
            return Err("no such table: sqlite_sequence".into())
        }
        Ok(Relation::simple(&["name","seq"],self.db.tables.values().filter(|t|t.def.temporary==temp&&t.def.cols.iter().any(|c|c.auto)&&t.sequence_written).map(|t|vec![Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Integer(t.sequence)]).collect()))
    }
    pub fn sequence_target(&self,s:&Statement)->Option<bool>{
        let name=match s{
            Statement::Insert{
                table,..
            }
            |Statement::Update{
                table,..
            }
            |Statement::Delete{
                table,..
            }
            =>table,_=>return None
        }
        ;
        let temp=if name.eq_ignore_ascii_case("temp.sqlite_sequence"){
            true
        }
        else if name.eq_ignore_ascii_case("main.sqlite_sequence"){
            false
        }
        else if name.eq_ignore_ascii_case("sqlite_sequence"){
            self.db.temp_sequence_exists
        }
        else{
            return None
        }
        ;
        let key=if temp{
            "temp.sqlite_sequence"
        }
        else{
            "sqlite_sequence"
        }
        ;
        if self.db.tables.contains_key(key){
            None
        }
        else{
            Some(temp)
        }
    }
    pub fn modify_sequence(&mut self,s:Statement,temp:bool)->Res<Relation>{
        let r=self.sequence_relation(temp)?;
        let name=if temp{
            "temp.sqlite_sequence"
        }
        else{
            "sqlite_sequence"
        }
        ;
        let cols=r.fields.iter().map(|f|Column{
            name:f.name.clone(),collate:"BINARY".into(),..Default::default()
        }
        ).collect();
        let table=Table{
            def:TableDef{
                name:name.into(),cols,temporary:temp,sql:"CREATE TABLE sqlite_sequence(name,seq)".into(),..Default::default()
            }
            ,rows:r.rows.into_iter().enumerate().map(|(i,values)|Row{
                id:i as i64+1,values
            }
            ).collect(),sequence:0,sequence_written:false
        }
        ;
        self.db.tables.insert(name.into(),table);
        let result=self.run(s);
        let system=self.db.tables.remove(name).unwrap();
        for t in self.db.tables.values_mut().filter(|t|t.def.temporary==temp&&t.def.cols.iter().any(|c|c.auto)){
            let tabname=t.def.name.trim_start_matches("temp.");
            if let Some(r)=system.rows.iter().find(|r|r.values[0].text()==tabname){
                t.sequence=r.values[1].int();
                t.sequence_written=true
            }
            else{
                t.sequence=0;
                t.sequence_written=false
            }
        }
        result
    }
}
