use serde::{
    Serialize,Serializer,ser::SerializeMap
}
;
#[derive(Clone,Debug,Serialize)]
#[serde(untagged)]
pub enum Json {
    Null,Bool(bool),Number(serde_json::Number),String(String),Array(Vec<Json>),Object(Object)
}
#[derive(Clone,Debug,Default)]
pub struct Object(pub Vec<(String,Json)>);
impl Serialize for Object{
    fn serialize<S:Serializer>(&self,s:S)->Result<S::Ok,S::Error>{
        let mut map=s.serialize_map(Some(self.0.len()))?;
        for(k,v)in &self.0{
            map.serialize_entry(k,v)?;
        }
        map.end()
    }
}
impl std::fmt::Display for Json{
    fn fmt(&self,f:&mut std::fmt::Formatter)->std::fmt::Result{
        write!(f,"{}",serde_json::to_string(self).map_err(|_|std::fmt::Error)? )
    }
}
impl From<i64> for Json{
    fn from(n:i64)->Self{
        Self::Number(n.into())
    }
}
impl From<f64> for Json{
    fn from(n:f64)->Self{
        serde_json::Number::from_f64(n).map(Self::Number).unwrap_or(Self::Null)
    }
}
impl Json{
    pub fn is_null(&self)->bool{
        matches!(self,Self::Null)
    }
    pub fn is_object(&self)->bool{
        matches!(self,Self::Object(_))
    }
    pub fn is_array(&self)->bool{
        matches!(self,Self::Array(_))
    }
    pub fn as_array(&self)->Option<&Vec<Json>>{
        if let Self::Array(a)=self{
            Some(a)
        }
        else{
            None
        }
    }
    pub fn as_array_mut(&mut self)->Option<&mut Vec<Json>>{
        if let Self::Array(a)=self{
            Some(a)
        }
        else{
            None
        }
    }
    pub fn as_object_mut(&mut self)->Option<&mut Object>{
        if let Self::Object(o)=self{
            Some(o)
        }
        else{
            None
        }
    }
    pub fn get(&self,k:&str)->Option<&Json>{
        if let Self::Object(o)=self{
            o.0.iter().find(|(n,_)|n==k).map(|(_,v)|v)
        }
        else{
            None
        }
    }
}
impl Object{
    pub fn new()->Self{
        Self::default()
    }
    pub fn contains_key(&self,k:&str)->bool{
        self.0.iter().any(|(n,_)|n==k)
    }
    pub fn insert(&mut self,k:String,v:Json){
        if let Some((_,old))=self.0.iter_mut().find(|(n,_)|*n==k){
            *old=v
        }
        else{
            self.0.push((k,v))
        }
    }
    pub fn remove(&mut self,k:&str){
        if let Some(i)=self.0.iter().position(|(n,_)|n==k){
            self.0.remove(i);
        }
    }
    pub fn entry(&mut self,k:String)->Entry<'_>{
        Entry{
            object:self,key:k
        }
    }
}
pub struct Entry<'a>{
    object:&'a mut Object,key:String
}
impl<'a> Entry<'a>{
    pub fn or_insert(self,v:Json)->&'a mut Json{
        let i=if let Some(i)=self.object.0.iter().position(|(k,_)|k==&self.key){
            i
        }
        else{
            self.object.0.push((self.key,v));
            self.object.0.len()-1
        }
        ;
        &mut self.object.0[i].1
    }
}
impl IntoIterator for Object{
    type Item=(String,Json);
    type IntoIter=std::vec::IntoIter<Self::Item>;
    fn into_iter(self)->Self::IntoIter{
        self.0.into_iter()
    }
}
impl<'a> IntoIterator for &'a Object{
    type Item=&'a(String,Json);
    type IntoIter=std::slice::Iter<'a,(String,Json)>;
    fn into_iter(self)->Self::IntoIter{
        self.0.iter()
    }
}
pub fn parse(s:&str)->Result<Json,usize>{
    let mut p=Parser{
        s,pos:0
    }
    ;
    let v=p.value(0)?;
    p.space()?;
    if p.pos!=s.len(){
        return Err(p.pos+1)
    }
    Ok(v)
}
struct Parser<'a>{
    s:&'a str,pos:usize
}
impl Parser<'_>{
    fn next(&mut self)->Option<char>{
        let c=self.s[self.pos..].chars().next()?;
        self.pos+=c.len_utf8();
        Some(c)
    }
    fn peek(&self)->Option<char>{
        self.s[self.pos..].chars().next()
    }
    fn err<T>(&self)->Result<T,usize>{
        Err(self.pos+1)
    }
    fn space(&mut self)->Result<(),usize>{
        loop{
            while self.peek().is_some_and(char::is_whitespace){
                self.next();
            }
            if self.s[self.pos..].starts_with("//"){
                while let Some(c)=self.next(){
                    if c=='\n'{
                        break
                    }
                }
            }
            else if self.s[self.pos..].starts_with("/*"){
                self.pos+=2;
                let Some(end)=self.s[self.pos..].find("*/")else{
                    return self.err()
                }
                ;
                self.pos+=end+2;
            }
            else{
                break
            }
        }
        Ok(())
    }
    fn value(&mut self,depth:usize)->Result<Json,usize>{
        if depth>1000{
            return self.err()
        }
        self.space()?;
        match self.peek(){
            Some('"'|'\'')=>Ok(Json::String(self.string()?)),Some('[')=>{
                self.next();
                let mut a=vec![];
                self.space()?;
                if self.peek()==Some(']'){
                    self.next();
                    return Ok(Json::Array(a))
                }
                loop{
                    a.push(self.value(depth+1)?);
                    self.space()?;
                    match self.next(){
                        Some(']')=>break,Some(',')=>{
                            self.space()?;
                            if self.peek()==Some(']'){
                                self.next();
                                break
                            }
                        }
                        ,_=>return self.err()
                    }
                }
                Ok(Json::Array(a))
            }
            ,Some('{')=>{
                self.next();
                let mut o=Object::new();
                self.space()?;
                if self.peek()==Some('}'){
                    self.next();
                    return Ok(Json::Object(o))
                }
                loop{
                    self.space()?;
                    let k=if matches!(self.peek(),Some('"'|'\'')){
                        self.string()?
                    }
                    else{
                        let start=self.pos;
                        if !self.peek().is_some_and(|c|c.is_alphabetic()||c=='_'||c=='$'||(c as u32>127&&!c.is_whitespace())){
                            return self.err()
                        }
                        self.next();
                        while self.peek().is_some_and(|c|c.is_alphanumeric()||c=='_'||c=='$'||(c as u32>127&&!c.is_whitespace())){
                            self.next();
                        }
                        self.s[start..self.pos].to_string()
                    }
                    ;
                    self.space()?;
                    if self.next()!=Some(':'){
                        return self.err()
                    }
                    o.0.push((k,self.value(depth+1)?));
                    self.space()?;
                    match self.next(){
                        Some('}')=>break,Some(',')=>{
                            self.space()?;
                            if self.peek()==Some('}'){
                                self.next();
                                break
                            }
                        }
                        ,_=>return self.err()
                    }
                }
                Ok(Json::Object(o))
            }
            ,Some(_)=>{
                let start=self.pos;
                while self.peek().is_some_and(|c|!c.is_whitespace()&&!['}',']',',','/'].contains(&c)){
                    self.next();
                }
                if self.pos==start{
                    return self.err()
                }
                let raw=&self.s[start..self.pos];
                match raw{
                    "true"=>Ok(Json::Bool(true)),"false"=>Ok(Json::Bool(false)),"null"=>Ok(Json::Null),_=>{
                        let lower=raw.to_ascii_lowercase();
                        if ["nan","qnan","snan"].contains(&lower.as_str()){
                            return Ok(Json::Null)
                        }
                        let raw=if ["inf","infinity","+inf","+infinity"].contains(&lower.as_str()){
                            "9e999"
                        }
                        else if ["-inf","-infinity"].contains(&lower.as_str()){
                            "-9e999"
                        }
                        else{
                            raw
                        }
                        ;
                        let mut raw=raw.trim_start_matches('+').to_string();
                        let sign=if raw.starts_with('-'){
                            -1i128
                        }
                        else{
                            1
                        }
                        ;
                        let digits=raw.trim_start_matches('-');
                        if digits.starts_with("0x")||digits.starts_with("0X"){
                            let n=i128::from_str_radix(&digits[2..],16).map_err(|_|start+1)?;
                            raw=(sign*n).to_string()
                        }
                        if raw.starts_with('.') {
                            raw.insert(0,'0')
                        }
                        else if raw.starts_with("-."){
                            raw.insert(1,'0')
                        }
                        if raw.ends_with('.') {
                            raw.push('0')
                        }
                        let n=raw.parse::<serde_json::Number>().map_err(|_|start+1)?;
                        Ok(Json::Number(n))
                    }
                }
            }
            ,None=>self.err()
        }
    }
    fn string(&mut self)->Result<String,usize>{
        let quote=self.next().ok_or(self.pos+1)?;
        let mut out=String::new();
        while let Some(c)=self.next(){
            if c==quote{
                return Ok(out)
            }
            if c=='\n'||c=='\r'{
                return self.err()
            }
            if c!='\\'{
                out.push(c);
                continue
            }
            let c=self.next().ok_or(self.pos+1)?;
            match c{
                '\n'=>{
                }
                ,'\r'=>{
                    if self.peek()==Some('\n'){
                        self.next();
                    }
                }
                ,'b'=>out.push('\u{0008}'),'f'=>out.push('\u{000c}'),'n'=>out.push('\n'),'r'=>out.push('\r'),'t'=>out.push('\t'),'v'=>out.push('\u{000b}'),'0'=>out.push('\0'),'x'|'u'=>{
                    let n=if c=='x'{
                        2
                    }
                    else{
                        4
                    }
                    ;
                    let mut code=0u32;
                    for _ in 0..n{
                        code=code*16+self.next().and_then(|c|c.to_digit(16)).ok_or(self.pos+1)?;
                    }
                    if (0xd800..=0xdbff).contains(&code)&&self.s[self.pos..].starts_with("\\u"){
                        self.pos+=2;
                        let mut low=0u32;
                        for _ in 0..4{
                            low=low*16+self.next().and_then(|c|c.to_digit(16)).ok_or(self.pos+1)?;
                        }
                        if !(0xdc00..=0xdfff).contains(&low){
                            return self.err()
                        }
                        code=0x10000+(code-0xd800)*1024+low-0xdc00;
                    }
                    out.push(char::from_u32(code).ok_or(self.pos+1)?);
                }
                ,_=>out.push(c)
            }
        }
        self.err()
    }
}
