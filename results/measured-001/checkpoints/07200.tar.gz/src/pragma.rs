use crate::{
    engine::*,storage::*,ast::*,value::Value,parser::Res
}
;
impl Engine{
    pub fn schema_relation(&self,temp:bool)->Relation{
        let mut rows=vec![];
        let mut page=2;
        for t in self.db.tables.values().filter(|t|t.def.temporary==temp){
            rows.push(vec![Value::Text("table".into()),Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Integer(page),Value::Text(t.def.sql.clone())]);
            page+=1;
        }
        if if temp{
            self.db.temp_sequence_exists
        }
        else{
            self.db.sequence_exists
        }
        {
            rows.push(vec![Value::Text("table".into()),Value::Text("sqlite_sequence".into()),Value::Text("sqlite_sequence".into()),Value::Integer(page),Value::Text("CREATE TABLE sqlite_sequence(name,seq)".into())]);
            page+=1;
        }
        for v in self.db.views.values().filter(|v|v.name.starts_with("temp.")==temp){
            rows.push(vec![Value::Text("view".into()),Value::Text(v.name.trim_start_matches("temp.").into()),Value::Text(v.name.trim_start_matches("temp.").into()),Value::Integer(0),Value::Text(v.sql.clone())]);
        }
        for i in self.db.indexes.values().filter(|i|i.table.starts_with("temp.")==temp){
            if i.origin=="pk"&&self.db.tables.get(&key(&i.table)).is_some_and(|t|t.def.without_rowid){continue}
            rows.push(vec![Value::Text("index".into()),Value::Text(i.name.trim_start_matches("temp.").into()),Value::Text(i.table.trim_start_matches("temp.").into()),Value::Integer(page),if i.sql.is_empty(){
                Value::Null
            }
            else{
                Value::Text(i.sql.clone())
            }
            ]);
            page+=1;
        }
        for t in self.db.triggers.values().filter(|t|(t.temporary||t.table.starts_with("temp."))==temp){
            rows.push(vec![Value::Text("trigger".into()),Value::Text(t.name.trim_start_matches("temp.").into()),Value::Text(t.table.trim_start_matches("temp.").into()),Value::Integer(0),Value::Text(t.sql.clone())]);
        }
        Relation::simple(&["type","name","tbl_name","rootpage","sql"],rows)
    }
    pub fn pragma(&mut self,name:&str,e:Option<&Expr>)->Res<Relation>{
        let n=key(name);
        let val=e.map(|e|match e{
            Expr::Col(ns)=>Ok(Value::Text(ns.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)
        }
        ).transpose()?;
        if let Some(v)=&val{
            let boolean=if let Value::Text(s)=v{
                ["on","yes","true","1"].contains(&key(s).as_str())
            }
            else{
                v.truth()==Some(true)
            }
            ;
            match n.as_str(){
                "foreign_keys"=>{
                    if self.tx.is_none(){
                        self.foreign_keys=boolean;
                        for a in self.attachments.values_mut(){
                            a.foreign_keys=boolean;
                        }
                    }
                    return Ok(Relation::default())
                }
                ,"defer_foreign_keys"=>{
                    self.defer_foreign=boolean;
                    return Ok(Relation::default())
                }
                ,"case_sensitive_like"=>{
                    self.case_like=boolean;
                    return Ok(Relation::default())
                }
                ,"user_version"=>{
                    self.db.user_version=v.int();
                    return Ok(Relation::default())
                }
                ,"application_id"=>{
                    self.db.application_id=v.int();
                    return Ok(Relation::default())
                }
                ,"schema_version"=>{
                    self.db.schema_version=v.int();
                    return Ok(Relation::default())
                }
                ,"journal_mode"=>{
                    let j=key(&v.text());
                    if ["delete","truncate","persist","memory","wal","off"].contains(&j.as_str()){
                        self.journal=if self.path.is_none()&&j=="wal"{
                            "memory".into()
                        }
                        else{
                            j
                        }
                    }
                    return self.pragma_read(&n,None)
                }
                ,"table_info"|"table_xinfo"|"index_list"|"index_info"|"index_xinfo"|"foreign_key_list"|"foreign_key_check"|"integrity_check"|"quick_check"=>{
                }
                ,_=>{
                    self.pragmas.insert(n.clone(),v.clone());
                    return Ok(Relation::default())
                }
            }
        }
        self.pragma_read(&n,val.as_ref())
    }
    pub fn pragma_read(&self,name:&str,val:Option<&Value>)->Res<Relation>{
        let n=key(name);
        let arg=val.map(Value::text).unwrap_or_default();
        let integer=|x|Relation::simple(&[name],vec![vec![Value::Integer(x)]]);
        Ok(match n.as_str(){
            "data_version"=>integer(self.data_version),"foreign_keys"=>integer(self.foreign_keys as i64),"defer_foreign_keys"=>integer(self.defer_foreign as i64),"user_version"=>integer(self.db.user_version),"application_id"=>integer(self.db.application_id),"schema_version"=>integer(self.db.schema_version),"journal_mode"=>Relation::simple(&["journal_mode"],vec![vec![Value::Text(if self.path.is_none()&&self.journal=="delete"{
                "memory".into()
            }
            else{
                self.journal.clone()
            }
            )]]),"encoding"=>Relation::simple(&["encoding"],vec![vec![Value::Text("UTF-8".into())]]),"page_size"=>integer(4096),"page_count"=>integer((self.db.tables.len()+self.db.indexes.len()+1) as i64),"freelist_count"=>integer(0),"auto_vacuum"=>integer(0),"synchronous"=>integer(2),"cache_size"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(-2000)),"busy_timeout"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(0)),"recursive_triggers"|"read_uncommitted"|"query_only"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(0)),
            "database_list"=>{
                let mut rows=vec![vec![Value::Integer(0),Value::Text("main".into()),Value::Text(self.path.as_ref().map(|p|p.to_string_lossy().to_string()).unwrap_or_default())]];
                if self.db.tables.values().any(|t|t.def.temporary)||self.db.views.keys().any(|k|k.starts_with("temp.")){
                    rows.push(vec![Value::Integer(1),Value::Text("temp".into()),Value::Text(String::new())]);
                }
                for(i,n)in self.attachment_order.iter().enumerate(){
                    let a=&self.attachments[n];
                    rows.push(vec![Value::Integer(i as i64+2),Value::Text(n.clone()),Value::Text(a.path.as_ref().map(|p|p.to_string_lossy().to_string()).unwrap_or_default())])
                }
                Relation::simple(&["seq","name","file"],rows)
            }
            ,
            "table_info"|"table_xinfo"=>{
                let mut rows=vec![];
                if (arg.eq_ignore_ascii_case("sqlite_sequence")||arg.to_ascii_lowercase().ends_with(".sqlite_sequence"))&&(self.db.sequence_exists||self.db.temp_sequence_exists){
                    for(i,nm)in ["name","seq"].iter().enumerate(){
                        let mut row=vec![Value::Integer(i as i64),Value::Text((*nm).into()),Value::Text(String::new()),Value::Integer(0),Value::Null,Value::Integer(0)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(0))
                        }
                        rows.push(row)
                    }
                }
                if let Some(t)=self.db.tables.get(&self.resolve_relation_key(&arg)){
                    let mut cid=0;
                    for c in &t.def.cols{
                        if n=="table_info"&&c.generated.is_some(){
                            continue
                        }
                        let mut row=vec![Value::Integer(cid),Value::Text(c.name.clone()),Value::Text(c.typ.clone()),Value::Integer(c.not_null as i64),c.default_sql.as_ref().map(|s|Value::Text(s.clone())).unwrap_or(Value::Null),Value::Integer(c.primary as i64)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(if c.generated.is_some(){
                                if c.stored{
                                    3
                                }
                                else{
                                    2
                                }
                            }
                            else{
                                0
                            }
                            ))
                        }
                        rows.push(row);
                        cid+=1
                    }
                }
                else if let Some(v)=self.db.views.get(&self.resolve_relation_key(&arg)){
                    let r=self.query(&v.query,&Env::default(),&Ctes::new(),0)?;
                    for(i,c)in r.fields.iter().enumerate(){
                        let mut row=vec![Value::Integer(i as i64),Value::Text(v.cols.get(i).unwrap_or(&c.name).clone()),Value::Text(String::new()),Value::Integer(0),Value::Null,Value::Integer(0)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(0))
                        }
                        rows.push(row)
                    }
                }
                Relation::simple(if n=="table_info"{
                    &["cid","name","type","notnull","dflt_value","pk"]
                }
                else{
                    &["cid","name","type","notnull","dflt_value","pk","hidden"]
                }
                ,rows)
            }
            ,
            "table_list"=>{
                let mut rows=self.db.tables.values().filter(|t|arg.is_empty()||t.def.name.eq_ignore_ascii_case(&arg)).map(|t|vec![Value::Text(if t.def.temporary{
                    "temp"
                }
                else{
                    "main"
                }
                .into()),Value::Text(t.def.name.clone()),Value::Text("table".into()),Value::Integer(t.def.cols.len() as i64),Value::Integer(t.def.without_rowid as i64),Value::Integer(t.def.strict as i64)]).collect::<Vec<_>>();
                for v in self.db.views.values(){
                    rows.push(vec![Value::Text("main".into()),Value::Text(v.name.clone()),Value::Text("view".into()),Value::Integer(v.cols.len() as i64),Value::Integer(0),Value::Integer(0)])
                }
                Relation::simple(&["schema","name","type","ncol","wr","strict"],rows)
            }
            ,
            "index_list"=>Relation::simple(&["seq","name","unique","origin","partial"],self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&self.resolve_relation_key(&arg))).enumerate().map(|(j,i)|vec![Value::Integer(j as i64),Value::Text(i.name.trim_start_matches("temp.").into()),Value::Integer(i.unique as i64),Value::Text(i.origin.clone()),Value::Integer(i.filter.is_some() as i64)]).collect()),
            "index_info"|"index_xinfo"=>{
                let mut rows=vec![];
                let index=self.db.indexes.get(&self.resolve_index_key(&arg)).or_else(|| {
                    let table=self.db.tables.get(&self.resolve_relation_key(&arg))?;
                    if !table.def.without_rowid{return None}
                    self.db.indexes.values().find(|i|i.table.eq_ignore_ascii_case(&table.def.name)&&i.origin=="pk")
                });
                if let Some(idx)=index {
                    if let Some(t)=self.db.tables.get(&key(&idx.table)) {
                        let env=self.row_env(t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},None);
                        let mut entries=idx.cols.iter().map(|o|(o.clone(),true)).collect::<Vec<_>>();
                        if n=="index_xinfo" {
                            if t.def.without_rowid {
                                if idx.origin=="pk" {
                                    for c in &t.def.cols {if !entries.iter().any(|(o,_)|crate::schema::column_name(&o.expr).is_some_and(|n|n.eq_ignore_ascii_case(&c.name))) {entries.push((Order{expr:Expr::Col(vec![c.name.clone()]),desc:false,nulls:None},false));}}
                                } else if let Some(pk)=self.db.indexes.values().find(|i|i.table.eq_ignore_ascii_case(&t.def.name)&&i.origin=="pk") {
                                    for o in &pk.cols {if !entries.iter().any(|(e,_)|crate::schema::column_name(&e.expr)==crate::schema::column_name(&o.expr)&&self.meta(&e.expr,&env).1.eq_ignore_ascii_case(&self.meta(&o.expr,&env).1)) {entries.push((o.clone(),false));}}
                                }
                            }
                        }
                        for (o,is_key) in entries {
                            let(ci,nm)=if let Some(name)=crate::schema::column_name(&o.expr) {(t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(name)).map(|i|i as i64).unwrap_or(-1),Value::Text(name.into()))}else{(-2,Value::Null)};
                            let mut row=vec![Value::Integer(rows.len() as i64),Value::Integer(ci),nm];
                            if n=="index_xinfo" {row.extend([Value::Integer(o.desc as i64),Value::Text(self.meta(&o.expr,&env).1),Value::Integer(is_key as i64)]);}
                            rows.push(row);
                        }
                        if n=="index_xinfo"&&!t.def.without_rowid {rows.push(vec![Value::Integer(rows.len() as i64),Value::Integer(-1),Value::Null,Value::Integer(0),Value::Text("BINARY".into()),Value::Integer(0)]);}
                    }
                }
                Relation::simple(if n=="index_info"{
                    &["seqno","cid","name"]
                }
                else{
                    &["seqno","cid","name","desc","coll","key"]
                }
                ,rows)
            }
            ,
            "foreign_key_list"=>{
                let mut rows=vec![];
                if let Some(t)=self.db.tables.get(&self.resolve_relation_key(&arg)){
                    for(i,f)in t.def.foreign.iter().rev().enumerate(){
                        for(j,n)in f.cols.iter().enumerate(){
                            rows.push(vec![Value::Integer(i as i64),Value::Integer(j as i64),Value::Text(f.table.clone()),Value::Text(n.clone()),f.target.get(j).map(|s|Value::Text(s.clone())).unwrap_or(Value::Null),Value::Text(f.update.clone()),Value::Text(f.delete.clone()),Value::Text("NONE".into())])
                        }
                    }
                }
                Relation::simple(&["id","seq","table","from","to","on_update","on_delete","match"],rows)
            }
            ,
            "foreign_key_check"=>self.foreign_check_relation(&arg)?,"integrity_check"|"quick_check"=>Relation::simple(&[name],vec![vec![Value::Text("ok".into())]]),"collation_list"=>Relation::simple(&["seq","name"],vec![vec![Value::Integer(0),Value::Text("RTRIM".into())],vec![Value::Integer(1),Value::Text("NOCASE".into())],vec![Value::Integer(2),Value::Text("BINARY".into())]]),"compile_options"=>Relation::simple(&["compile_options"],vec![]),"wal_checkpoint"=>Relation::simple(&["busy","log","checkpointed"],vec![vec![Value::Integer(0),Value::Integer(-1),Value::Integer(-1)]]),_=>if let Some(v)=self.pragmas.get(&n){
                Relation::simple(&[name],vec![vec![v.clone()]])
            }
            else{
                Relation::default()
            }
        }
        )
    }
}
impl Engine{
    fn foreign_check_relation(&self,name:&str)->Res<Relation>{
        use crate::value::{
            affinity,compare
        }
        ;
        use std::cmp::Ordering;
        let mut rows=vec![];
        for t in self.db.tables.values(){
            if !name.is_empty()&&!t.def.name.eq_ignore_ascii_case(name){
                continue
            }
            for (fk,f) in t.def.foreign.iter().rev().enumerate(){
                let child=f.cols.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch".to_string())).collect::<Res<Vec<_>>>()?;
                let parent=self.db.tables.get(&if t.def.temporary{
                    format!("temp.{}",key(&f.table))
                }
                else{
                    key(&f.table)
                }
                );
                let names=if let Some(parent)=parent{
                    if f.target.is_empty(){
                        let mut cols=parent.def.cols.iter().filter(|c|c.primary>0).collect::<Vec<_>>();
                        cols.sort_by_key(|c|c.primary);
                        cols.iter().map(|c|c.name.clone()).collect()
                    }
                    else{
                        f.target.clone()
                    }
                }
                else{
                    f.target.clone()
                }
                ;
                let target=parent.map(|p|names.iter().map(|n|p.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch".to_string())).collect::<Res<Vec<_>>>()).transpose()?;
                for r in &t.rows{
                    if child.iter().any(|i|r.values[*i].null()){
                        continue
                    }
                    let found=if let (Some(p),Some(target))=(parent,&target){
                        if child.len()!=target.len(){
                            return Err("foreign key mismatch".into())
                        }
                        p.rows.iter().any(|pr|child.iter().zip(target).all(|(i,j)|compare(&r.values[*i].apply(affinity(&p.def.cols[*j].typ)),&pr.values[*j],&p.def.cols[*j].collate)==Ordering::Equal))
                    }
                    else{
                        false
                    }
                    ;
                    if !found{
                        rows.push(vec![Value::Text(t.def.name.clone()),if t.def.without_rowid{
                            Value::Null
                        }
                        else{
                            Value::Integer(r.id)
                        }
                        ,Value::Text(f.table.clone()),Value::Integer(fk as i64)]);
                    }
                }
            }
        }
        Ok(Relation::simple(&["table","rowid","parent","fkid"],rows))
    }
}
