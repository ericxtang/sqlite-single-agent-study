use crate::{
    ast::*,lexer::{
        lex,Kind,Token
    }
    ,value::{
        Value,unhex
    }
}
;
pub type Res<T>=Result<T,String>;
pub struct Parser<'a>{
    pub sql:&'a str,pub ts:Vec<Token>,pub p:usize
}
impl<'a> Parser<'a>{
    pub fn new(sql:&'a str)->Res<Self>{
        Ok(Self{
            sql,ts:lex(sql)?,p:0
        }
        )
    }
    pub fn peek(&self)->&Token{
        &self.ts[self.p]
    }
    pub fn at(&self,s:&str)->bool{
        self.peek().kind!=Kind::Str&&self.peek().kind!=Kind::Quoted&&self.peek().text.eq_ignore_ascii_case(s)
    }
    pub fn eat(&mut self,s:&str)->bool{
        if self.at(s){
            self.p+=1;
            true
        }
        else{
            false
        }
    }
    pub fn need(&mut self,s:&str)->Res<()>{
        if self.eat(s){
            Ok(())
        }
        else{
            Err(format!("near \"{}\": syntax error (expected {})",self.peek().text,s))
        }
    }
    pub fn id(&mut self)->Res<String>{
        let t=self.peek().clone();
        if matches!(t.kind,Kind::Word|Kind::Quoted|Kind::Str){
            self.p+=1;
            Ok(t.text)
        }
        else{
            Err(format!("near \"{}\": expected identifier",t.text))
        }
    }
    pub fn fullname(&mut self)->Res<String>{
        let mut n=self.id()?;
        if self.eat("."){
            let x=self.id()?;
            n=format!("{}.{}",n,x)
        }
        Ok(n)
    }
    pub fn parse(mut self)->Res<Statement>{
        while self.eat(";") {}
        if self.peek().kind==Kind::Eof{
            return Ok(Statement::Noop)
        }
        let s=self.statement()?;
        while self.eat(";") {}
        if self.peek().kind!=Kind::Eof{
            return Err(format!("near \"{}\": syntax error",self.peek().text))
        }
        Ok(s)
    }
    pub fn statement(&mut self)->Res<Statement>{
        if self.eat("WITH"){
            let recursive=self.eat("RECURSIVE");
            let mut ctes=vec![];
            loop{
                let name=self.id()?;
                let cols=if self.eat("("){
                    self.idlist_end()?
                }
                else{
                    vec![]
                }
                ;
                self.need("AS")?;
                self.eat("NOT");
                self.eat("MATERIALIZED");
                self.need("(")?;
                let query=self.query()?;
                self.need(")")?;
                ctes.push(Cte{
                    name,cols,query
                }
                );
                if !self.eat(","){
                    break
                }
            }
            if self.at("SELECT")||self.at("VALUES"){
                let mut q=self.query()?;
                q.ctes=ctes;
                q.recursive=recursive;
                return Ok(Statement::Query(q))
            }
            return Ok(Statement::With(ctes,recursive,Box::new(self.statement()?)))
        }
        if self.at("SELECT")||self.at("VALUES"){
            return Ok(Statement::Query(self.query()?))
        }
        if self.eat("EXPLAIN"){
            let qp=self.eat("QUERY");
            if qp{
                self.need("PLAN")?
            }
            return Ok(Statement::Explain(Box::new(self.statement()?),qp))
        }
        if self.eat("CREATE"){
            return self.create()
        }
        if self.eat("DROP"){
            let kind=self.id()?;
            let ie=if self.eat("IF"){
                self.need("EXISTS")?;
                true
            }
            else{
                false
            }
            ;
            return Ok(Statement::Drop(kind,self.fullname()?,ie))
        }
        if self.eat("INSERT")||self.eat("REPLACE"){
            let mut conflict=if self.ts[self.p-1].text.eq_ignore_ascii_case("REPLACE"){
                "REPLACE".into()
            }
            else{
                String::new()
            }
            ;
            if self.eat("OR"){
                conflict=self.conflict_action()?
            }
            self.need("INTO")?;
            let table=self.fullname()?;
            let alias=if self.eat("AS"){
                Some(self.id()?)
            }
            else{
                None
            }
            ;
            let cols=if self.eat("("){
                self.idlist_end()?
            }
            else{
                vec![]
            }
            ;
            let default=self.eat("DEFAULT");
            let query=if default{
                self.need("VALUES")?;
                None
            }
            else{
                Some(self.query()?)
            }
            ;
            let mut upsert=vec![];
            while self.eat("ON"){
                self.need("CONFLICT")?;
                let target=if self.eat("("){
                    self.index_names()?
                }
                else{
                    vec![]
                }
                ;
                if self.eat("WHERE"){
                    self.expr()?;
                }
                self.need("DO")?;
                let assignments=if self.eat("NOTHING"){
                    vec![]
                }
                else{
                    self.need("UPDATE")?;
                    self.need("SET")?;
                    self.assignments()?
                }
                ;
                let filter=if self.eat("WHERE"){
                    Some(self.expr()?)
                }
                else{
                    None
                }
                ;
                upsert.push(Upsert{
                    target,assignments,filter
                }
                );
            }
            let returning=self.returning()?;
            return Ok(Statement::Insert{
                table,alias,cols,query,default,conflict,upsert,returning
            }
            )
        }
        if self.eat("UPDATE"){
            let conflict=if self.eat("OR"){
                self.conflict_action()?
            }
            else{
                String::new()
            }
            ;
            let table=self.fullname()?;
            let alias=self.alias()?;
            let index=self.indexed()?;
            self.need("SET")?;
            let assignments=self.assignments()?;
            let from=if self.eat("FROM"){
                Some(self.source()?)
            }
            else{
                None
            }
            ;
            let filter=if self.eat("WHERE"){
                Some(self.expr()?)
            }
            else{
                None
            }
            ;
            let returning=self.returning()?;
            let order=self.order()?;
            let limit=if self.eat("LIMIT"){
                Some(self.expr()?)
            }
            else{
                None
            }
            ;
            let stmt=Statement::Update{table,alias,assignments,filter,conflict,returning,from,order,limit};
            return Ok(if let Some(index)=index{Statement::IndexGuard(Box::new(stmt),index)}else{stmt})
        }
        if self.eat("DELETE"){
            self.need("FROM")?;
            let table=self.fullname()?;
            let alias=self.alias()?;
            let index=self.indexed()?;
            let filter=if self.eat("WHERE"){
                Some(self.expr()?)
            }
            else{
                None
            }
            ;
            let returning=self.returning()?;
            let order=self.order()?;
            let limit=if self.eat("LIMIT"){
                Some(self.expr()?)
            }
            else{
                None
            }
            ;
            let stmt=Statement::Delete{table,alias,filter,returning,order,limit};
            return Ok(if let Some(index)=index{Statement::IndexGuard(Box::new(stmt),index)}else{stmt})
        }
        if self.eat("BEGIN"){
            let mode=if self.at("DEFERRED")||self.at("IMMEDIATE")||self.at("EXCLUSIVE"){
                self.id()?.to_uppercase()
            }
            else{
                "DEFERRED".into()
            }
            ;
            self.eat("TRANSACTION");
            return Ok(Statement::Begin(mode))
        }
        if self.eat("COMMIT")||self.eat("END"){
            self.eat("TRANSACTION");
            return Ok(Statement::Commit)
        }
        if self.eat("ROLLBACK"){
            self.eat("TRANSACTION");
            let n=if self.eat("TO"){
                self.eat("SAVEPOINT");
                Some(self.id()?)
            }
            else{
                None
            }
            ;
            return Ok(Statement::Rollback(n))
        }
        if self.eat("SAVEPOINT"){
            return Ok(Statement::Savepoint(self.id()?))
        }
        if self.eat("RELEASE"){
            self.eat("SAVEPOINT");
            return Ok(Statement::Release(self.id()?))
        }
        if self.eat("ATTACH"){
            self.eat("DATABASE");
            let path=self.expr()?;
            self.need("AS")?;
            return Ok(Statement::Attach(path,self.id()?))
        }
        if self.eat("DETACH"){
            self.eat("DATABASE");
            return Ok(Statement::Detach(self.id()?))
        }
        if self.eat("PRAGMA"){
            let name=self.fullname()?;
            let val=if self.eat("="){
                Some(self.expr()?)
            }
            else if self.eat("("){
                let v=self.expr()?;
                self.need(")")?;
                Some(v)
            }
            else{
                None
            }
            ;
            return Ok(Statement::Pragma(name,val))
        }
        if self.eat("ALTER"){
            self.need("TABLE")?;
            let t=self.fullname()?;
            if self.eat("RENAME"){
                if self.eat("TO"){
                    return Ok(Statement::Alter(t,"rename".into(),Some(self.id()?),None))
                }
                self.eat("COLUMN");
                let old=self.id()?;
                self.need("TO")?;
                return Ok(Statement::Alter(t,format!("column:{}",old),Some(self.id()?),None))
            }
            if self.eat("ADD"){
                self.eat("COLUMN");
                let (c,_,_)=self.column()?;
                return Ok(Statement::Alter(t,"add".into(),None,Some(c)))
            }
            if self.eat("DROP"){
                self.eat("COLUMN");
                return Ok(Statement::Alter(t,"drop".into(),Some(self.id()?),None))
            }
            if self.eat("ALTER") {
                self.eat("COLUMN");let column=self.id()?;
                let set=if self.eat("SET"){true}else{self.need("DROP")?;false};
                self.need("NOT")?;self.need("NULL")?;
                return Ok(Statement::Alter(t,if set{"set_not_null"}else{"drop_not_null"}.into(),Some(column),None));
            }
            return Err("invalid ALTER TABLE".into())
        }
        if self.eat("VACUUM") {
            let schema=if self.at("INTO")||self.at(";")||self.peek().kind==Kind::Eof {None}else{Some(self.id()?)};
            let into=if self.eat("INTO"){Some(self.expr()?)}else{None};
            return Ok(Statement::Vacuum(schema,into));
        }
        if self.eat("ANALYZE") { let target=if self.at(";")||self.peek().kind==Kind::Eof{None}else{Some(self.fullname()?)};return Ok(Statement::Analyze(target)); }
        if self.eat("REINDEX"){
            while self.peek().kind!=Kind::Eof&&!self.at(";"){
                self.p+=1
            }
            return Ok(Statement::Noop)
        }
        Err(format!("near \"{}\": syntax error",self.peek().text))
    }
    fn indexed(&mut self)->Res<Option<String>> {
        if self.eat("INDEXED") { self.need("BY")?;return Ok(Some(self.id()?)); }
        if self.eat("NOT") { self.need("INDEXED")?;return Ok(Some(String::new())); }
        Ok(None)
    }
    fn assignments(&mut self)->Res<Vec<(String,Expr)>>{
        let mut a=vec![];
        loop{
            if self.eat("("){
                let names=self.idlist_end()?;
                self.need("=")?;
                self.need("(")?;
                let es=if self.at("SELECT")||self.at("WITH")||self.at("VALUES"){
                    let q=self.query()?;
                    self.need(")")?;
                    let e=Expr::Subquery(Box::new(q));
                    (0..names.len()).map(|i|Expr::RowAccess(Box::new(e.clone()),i)).collect()
                }
                else{
                    self.exprlist_end()?
                }
                ;
                if names.len()!=es.len(){
                    return Err("assignment count mismatch".into())
                }
                a.extend(names.into_iter().zip(es));
            }
            else{
                let n=self.id()?;
                self.need("=")?;
                a.push((n,self.expr()?));
            }
            if !self.eat(","){
                break
            }
        }
        Ok(a)
    }
    fn returning(&mut self)->Res<Vec<Item>>{
        if self.eat("RETURNING"){
            self.items()
        }
        else{
            Ok(vec![])
        }
    }
    fn ifnot(&mut self)->Res<bool>{
        if self.eat("IF"){
            self.need("NOT")?;
            self.need("EXISTS")?;
            Ok(true)
        }
        else{
            Ok(false)
        }
    }
    fn create(&mut self)->Res<Statement>{
        let temporary=self.eat("TEMP")||self.eat("TEMPORARY");
        let unique=self.eat("UNIQUE");
        if unique&&!self.at("INDEX"){return Err("UNIQUE is only allowed for indexes".into())}
        if temporary&&self.at("INDEX"){return Err("temporary indexes use the table schema".into())}
        if self.eat("TABLE"){
            let ine=self.ifnot()?;
            let name=self.fullname()?;
            if temporary&&name.split_once('.').is_some_and(|(schema,_)|!schema.eq_ignore_ascii_case("temp")){return Err("temporary table name must be unqualified".into())}
            let mut d=TableDef{
                name,temporary,..Default::default()
            }
            ;
            if self.eat("AS"){
                let q=self.query()?;
                d.sql=self.sql.trim().trim_end_matches(';').into();
                return Ok(Statement::CreateTable(d,ine,Some(q)))
            }
            self.need("(")?;
            let mut table_pk:Vec<String>=vec![];
            loop{
                if self.eat("CONSTRAINT"){
                    self.id()?;
                }
                if self.eat("PRIMARY"){
                    self.need("KEY")?;
                    self.need("(")?;
                    if !table_pk.is_empty(){return Err("table has more than one primary key".into())}
                    let cols=self.key_columns()?;
                    table_pk=cols.iter().map(|o|key_column_name(&o.expr).unwrap().to_string()).collect();
                    let conflict=self.conflict_clause()?;
                    d.keys.push(KeyConstraint{primary:true,cols,conflict});
                }
                else if self.eat("UNIQUE"){
                    self.need("(")?;
                    let cols=self.key_columns()?;
                    d.uniques.push(cols.iter().map(|o|key_column_name(&o.expr).unwrap().to_string()).collect());
                    let conflict=self.conflict_clause()?;
                    d.keys.push(KeyConstraint{primary:false,cols,conflict});
                }
                else if self.eat("CHECK"){
                    self.need("(")?;
                    d.checks.push(self.expr()?);
                    self.need(")")?;
                    self.conflict_clause()?;
                }
                else if self.eat("FOREIGN"){
                    self.need("KEY")?;
                    self.need("(")?;
                    let cols=self.idlist_end()?;
                    self.need("REFERENCES")?;
                    d.foreign.push(self.foreign(cols)?);
                }
                else{
                    let(c,checks,fks)=self.column()?;
                    for kind in &c.key_order {
                        let primary=kind=="primary";
                        d.keys.push(KeyConstraint{primary,cols:vec![Order{expr:Expr::Col(vec![c.name.clone()]),desc:primary&&c.pk_desc,nulls:None}],conflict:if primary{c.primary_conflict.clone()}else{c.unique_conflict.clone()}});
                    }
                    d.cols.push(c);
                    d.checks.extend(checks);
                    d.foreign.extend(fks)
                }
                if self.eat(")"){
                    break
                }
                self.need(",")?;
            }
            for (i,n) in table_pk.iter().enumerate(){
                let c=d.cols.iter_mut().find(|c|c.name.eq_ignore_ascii_case(n)).ok_or(format!("no such column: {}",n))?;
                c.primary=i+1;
            }
            loop{
                if self.eat("WITHOUT"){
                    self.need("ROWID")?;
                    d.without_rowid=true;
                }
                else if self.eat("STRICT"){
                    d.strict=true
                }
                else{
                    break
                }
                self.eat(",");
            }
            d.sql=self.sql.trim().trim_end_matches(';').into();
            return Ok(Statement::CreateTable(d,ine,None))
        }
        if self.eat("TRIGGER"){
            let ine=self.ifnot()?;
            let mut name=self.fullname()?;
            if temporary&&name.split_once('.').is_some_and(|(schema,_)|!schema.eq_ignore_ascii_case("temp")){return Err("temporary trigger name must be unqualified".into())}
            if temporary&&!name.contains('.'){name=format!("temp.{}",name);}
            let timing=if self.eat("AFTER"){
                "AFTER"
            }
            else if self.eat("INSTEAD"){
                self.need("OF")?;
                "INSTEAD OF"
            }
            else{
                self.eat("BEFORE");
                "BEFORE"
            }
            .to_string();
            let event=self.id()?.to_uppercase();
            if !["INSERT","UPDATE","DELETE"].contains(&event.as_str()){
                return Err("invalid trigger event".into())
            }
            let mut columns=vec![];
            if self.eat("OF"){
                loop{
                    columns.push(self.id()?);
                    if !self.eat(","){
                        break
                    }
                }
            }
            self.need("ON")?;
            let table=self.fullname()?;
            if self.eat("FOR"){
                self.need("EACH")?;
                self.need("ROW")?;
            }
            let when=if self.eat("WHEN"){
                Some(self.expr()?)
            }
            else{
                None
            }
            ;
            self.need("BEGIN")?;
            let mut body=vec![];
            while !self.at("END"){
                if self.peek().kind==Kind::Eof{
                    return Err("incomplete trigger".into())
                }
                body.push(self.statement()?);
                self.need(";")?;
            }
            self.need("END")?;
            let sql=self.sql.trim().trim_end_matches(';').to_string();
            return Ok(Statement::CreateTrigger(Trigger{
                name,table,timing,event,columns,when,body,sql,temporary
            }
            ,ine))
        }
        if self.eat("VIEW"){
            let ine=self.ifnot()?;
            let mut n=self.fullname()?;
            if temporary&&n.split_once('.').is_some_and(|(schema,_)|!schema.eq_ignore_ascii_case("temp")){return Err("temporary view name must be unqualified".into())}
            if temporary&&!n.contains('.'){
                n=format!("temp.{}",n);
            }
            let cols=if self.eat("("){
                self.idlist_end()?
            }
            else{
                vec![]
            }
            ;
            self.need("AS")?;
            let q=self.query()?;
            return Ok(Statement::CreateView(n,cols,q,ine,self.sql.trim().trim_end_matches(';').into()))
        }
        if self.eat("INDEX"){
            let ine=self.ifnot()?;
            let n=self.fullname()?;
            self.need("ON")?;
            let t=self.fullname()?;
            self.need("(")?;
            let cols=self.orders()?;
            self.need(")")?;
            let filter=if self.eat("WHERE"){
                Some(self.expr()?)
            }
            else{
                None
            }
            ;
            return Ok(Statement::CreateIndex(n,t,cols,unique,filter,ine,self.sql.trim().trim_end_matches(';').into()))
        }
        Err(format!("near \"{}\": unsupported CREATE",self.peek().text))
    }
    fn index_names(&mut self)->Res<Vec<String>>{
        let mut ns=vec![];
        loop{
            ns.push(self.id()?);
            if self.eat("COLLATE"){
                self.id()?;
            }
            if !self.eat("ASC"){
                self.eat("DESC");
            }
            if self.eat(")"){
                break
            }
            self.need(",")?;
        }
        Ok(ns)
    }
    fn key_columns(&mut self)->Res<Vec<Order>> {
        let mut out=vec![];
        loop {
            let mut expr=Expr::Col(vec![self.id()?]);
            if self.eat("COLLATE"){expr=Expr::Collate(Box::new(expr),self.id()?);}
            let desc=self.eat("DESC");if !desc{self.eat("ASC");}
            out.push(Order{expr,desc,nulls:None});
            if self.eat(")"){break}self.need(",")?;
        }
        Ok(out)
    }
    fn conflict_action(&mut self)->Res<String> {
        let action=self.id()?.to_ascii_uppercase();
        if !["ROLLBACK","ABORT","FAIL","IGNORE","REPLACE"].contains(&action.as_str()){return Err(format!("unknown conflict resolution: {}",action))}
        Ok(action)
    }
    fn conflict_clause(&mut self)->Res<String>{
        if self.eat("ON"){
            self.need("CONFLICT")?;
            self.conflict_action()
        }
        else{
            Ok(String::new())
        }
    }
    fn column(&mut self)->Res<(Column,Vec<Expr>,Vec<Foreign>)>{
        let column_start=self.peek().start;
        let name=self.id()?;
        let mut c=Column{
            name,collate:"BINARY".into(),..Default::default()
        }
        ;
        let mut ty=vec![];
        while (self.peek().kind==Kind::Word||self.peek().kind==Kind::Quoted)&&!["CONSTRAINT","PRIMARY","NOT","NULL","UNIQUE","CHECK","DEFAULT","COLLATE","REFERENCES","GENERATED","AS"].iter().any(|x|self.at(x)){
            ty.push(self.id()?)
        }
        c.typ=ty.join(" ");
        if self.eat("("){
            let start=self.ts[self.p-1].start;
            while !self.at(")")&&self.peek().kind!=Kind::Eof{
                self.p+=1
            }
            self.need(")")?;
            c.typ.push_str(&self.sql[start..self.ts[self.p-1].end]);
        }
        let mut checks=vec![];
        let mut foreign=vec![];
        loop{
            if self.eat("CONSTRAINT"){
                self.id()?;
                continue
            }
            if self.eat("PRIMARY"){
                self.need("KEY")?;
                c.primary=1;
                c.pk_desc=self.eat("DESC");
                self.eat("ASC");
                c.primary_conflict=self.conflict_clause()?;
                c.key_order.push("primary".into());
                c.auto=self.eat("AUTOINCREMENT");
            }
            else if self.eat("NOT"){
                self.need("NULL")?;
                c.not_null=true;
                c.not_null_conflict=self.conflict_clause()?;
            }
            else if self.eat("NULL"){
                self.conflict_clause()?;
            }
            else if self.eat("UNIQUE"){
                c.unique=true;
                c.unique_conflict=self.conflict_clause()?;
                c.key_order.push("unique".into());
            }
            else if self.eat("DEFAULT"){
                let start=self.peek().start;
                c.default_parenthesized=self.at("(");
                let e=if self.eat("("){
                    let e=self.expr()?;
                    self.need(")")?;
                    e
                }
                else{
                    self.bp(12)?
                }
                ;
                c.default=Some(e);
                c.default_sql=Some({
                    let raw=self.sql[start..self.ts[self.p-1].end].trim();
                    if raw.starts_with('(')&&raw.ends_with(')'){
                        raw[1..raw.len()-1].into()
                    }
                    else{
                        raw.into()
                    }
                }
                );
            }
            else if self.eat("COLLATE"){
                c.collate=self.id()?;
            }
            else if self.eat("CHECK"){
                self.need("(")?;
                checks.push(self.expr()?);
                self.need(")")?;
            }
            else if self.eat("REFERENCES"){
                foreign.push(self.foreign(vec![c.name.clone()])?);
            }
            else if self.at("GENERATED")||self.at("AS"){
                if self.eat("GENERATED"){
                    self.eat("ALWAYS");
                }
                self.need("AS")?;
                self.need("(")?;
                c.generated=Some(self.expr()?);
                self.need(")")?;
                c.stored=self.eat("STORED");
                self.eat("VIRTUAL");
            }
            else{
                break
            }
        }
        c.sql=self.sql[column_start..self.ts[self.p-1].end].into();
        c.checks=checks.clone();
        c.foreigns=foreign.clone();
        Ok((c,checks,foreign))
    }
    fn foreign(&mut self,cols:Vec<String>)->Res<Foreign>{
        let table=self.fullname()?;
        let target=if self.eat("("){
            self.idlist_end()?
        }
        else{
            vec![]
        }
        ;
        let mut f=Foreign{
            cols,table,target,delete:"NO ACTION".into(),update:"NO ACTION".into(),deferred:false
        }
        ;
        loop{
            if self.eat("ON"){
                let what=self.id()?;
                let mut action=self.id()?.to_uppercase();
                if action=="SET"||action=="NO"{
                    action.push(' ');
                    action.push_str(&self.id()?.to_uppercase())
                }
                if what.eq_ignore_ascii_case("DELETE"){
                    f.delete=action
                }
                else{
                    f.update=action
                }
            }
            else if self.eat("MATCH"){
                self.id()?;
            }
            else if self.eat("DEFERRABLE"){
                if self.eat("INITIALLY"){
                    f.deferred=self.eat("DEFERRED");
                    self.eat("IMMEDIATE");
                }
            }
            else if self.at("NOT")&&self.ts.get(self.p+1).is_some_and(|t|t.text.eq_ignore_ascii_case("DEFERRABLE")){
                self.p+=2;
            }
            else{
                break
            }
        }
        Ok(f)
    }
    fn idlist_end(&mut self)->Res<Vec<String>>{
        let mut out=vec![];
        loop{
            out.push(self.id()?);
            if self.eat(")"){
                return Ok(out)
            }
            self.need(",")?
        }
    }
    fn exprlist_end(&mut self)->Res<Vec<Expr>>{
        let mut out=vec![];
        if self.eat(")"){
            return Ok(out)
        }
        loop{
            out.push(self.expr()?);
            if self.eat(")"){
                return Ok(out)
            }
            self.need(",")?
        }
    }
    pub fn query(&mut self)->Res<Query>{
        let mut q=Query::default();
        if self.eat("WITH"){
            q.recursive=self.eat("RECURSIVE");
            loop{
                let name=self.id()?;
                let cols=if self.eat("("){
                    self.idlist_end()?
                }
                else{
                    vec![]
                }
                ;
                self.need("AS")?;
                self.eat("NOT");
                self.eat("MATERIALIZED");
                self.need("(")?;
                let query=self.query()?;
                self.need(")")?;
                q.ctes.push(Cte{
                    name,cols,query
                }
                );
                if !self.eat(","){
                    break
                }
            }
        }
        q.cores.push(self.core()?);
        while self.at("UNION")||self.at("INTERSECT")||self.at("EXCEPT"){
            let mut op=self.id()?.to_uppercase();
            if self.eat("ALL"){
                op.push_str(" ALL")
            }
            q.ops.push(op);
            q.cores.push(self.core()?);
        }
        q.order=self.order()?;
        if self.eat("LIMIT"){
            q.limit=Some(self.expr()?);
            if self.eat("OFFSET"){
                q.offset=Some(self.expr()?)
            }
            else if self.eat(","){
                q.offset=q.limit.take();
                q.limit=Some(self.expr()?)
            }
        }
        Ok(q)
    }
    fn core(&mut self)->Res<Select>{
        let mut s=Select::default();
        if self.eat("VALUES"){
            let mut rows=vec![];
            loop{
                self.need("(")?;
                rows.push(self.exprlist_end()?);
                if !self.eat(","){
                    break
                }
            }
            s.values=Some(rows);
            return Ok(s)
        }
        self.need("SELECT")?;
        s.distinct=self.eat("DISTINCT");
        self.eat("ALL");
        s.items=self.items()?;
        if self.eat("FROM"){
            s.from=Some(self.source()?)
        }
        if self.eat("WHERE"){
            s.filter=Some(self.expr()?)
        }
        if self.eat("GROUP"){
            self.need("BY")?;
            loop{
                s.group.push(self.expr()?);
                if !self.eat(","){
                    break
                }
            }
        }
        if self.eat("HAVING"){
            s.having=Some(self.expr()?)
        }
        if self.eat("WINDOW"){
            loop{
                let n=self.id()?;
                self.need("AS")?;
                self.need("(")?;
                s.windows.push((n,self.window()?));
                if !self.eat(","){
                    break
                }
            }
        }
        Ok(s)
    }
    fn items(&mut self)->Res<Vec<Item>>{
        let mut items=vec![];
        loop{
            let start=self.peek().start;
            let expr=self.expr()?;
            let end=self.ts[self.p-1].end;
            let alias=self.alias()?;
            let name=alias.clone().unwrap_or_else(||match &expr{
                Expr::Col(c)=>c.last().unwrap().clone(),_=>self.sql[start..end].trim().to_string()
            }
            );
            items.push(Item{
                expr,name,alias
            }
            );
            if !self.eat(","){
                break
            }
        }
        Ok(items)
    }
    fn alias(&mut self)->Res<Option<String>>{
        if self.eat("AS"){
            return Ok(Some(self.id()?))
        }
        if matches!(self.peek().kind,Kind::Word|Kind::Quoted|Kind::Str)&&!is_reserved(&self.peek().text){
            return Ok(Some(self.id()?))
        }
        Ok(None)
    }
    fn source_atom(&mut self)->Res<Source>{
        if self.eat("("){
            if self.at("SELECT")||self.at("WITH")||self.at("VALUES"){
                let q=self.query()?;
                self.need(")")?;
                return Ok(Source::Query(Box::new(q),self.alias()?))
            }
            let s=self.source()?;
            self.need(")")?;
            self.alias()?;
            return Ok(s)
        }
        let n=self.fullname()?;
        let args=if self.eat("("){
            self.exprlist_end()?
        }
        else{
            vec![]
        }
        ;
        let alias=self.alias()?;
        let index=self.indexed()?;
        let source=Source::Table(n,alias,args);
        Ok(if let Some(index)=index{Source::Indexed(Box::new(source),index)}else{source})
    }
    fn source(&mut self)->Res<Source>{
        let mut s=self.source_atom()?;
        loop{
            let mut kind=String::new();
            let natural=self.eat("NATURAL");
            if self.eat(","){
                kind="CROSS".into()
            }
            else{
                for k in ["LEFT","RIGHT","FULL","INNER","CROSS"]{
                    if self.eat(k){
                        kind=k.into();
                        break
                    }
                }
                self.eat("OUTER");
                if !self.eat("JOIN"){
                    if natural||!kind.is_empty(){
                        return Err("expected JOIN".into())
                    }
                    break
                }
                if kind.is_empty(){
                    kind="INNER".into()
                }
            }
            let r=self.source_atom()?;
            let mut on=None;
            let mut using=vec![];
            if self.eat("ON"){
                on=Some(self.expr()?)
            }
            else if self.eat("USING"){
                self.need("(")?;
                using=self.idlist_end()?
            }
            s=Source::Join(Box::new(s),Box::new(r),kind,on,using,natural)
        }
        Ok(s)
    }
    fn order(&mut self)->Res<Vec<Order>>{
        if self.eat("ORDER"){
            self.need("BY")?;
            self.orders()
        }
        else{
            Ok(vec![])
        }
    }
    fn orders(&mut self)->Res<Vec<Order>>{
        let mut out=vec![];
        loop{
            let expr=self.expr()?;
            let desc=self.eat("DESC");
            self.eat("ASC");
            let nulls=if self.eat("NULLS"){
                if self.eat("FIRST"){
                    Some(true)
                }
                else{
                    self.need("LAST")?;
                    Some(false)
                }
            }
            else{
                None
            }
            ;
            out.push(Order{
                expr,desc,nulls
            }
            );
            if !self.eat(","){
                break
            }
        }
        Ok(out)
    }
    fn window(&mut self)->Res<Window>{
        let mut w=Window::default();
        if !self.at("PARTITION")&&!self.at("ORDER")&&!self.at("ROWS")&&!self.at("RANGE")&&!self.at("GROUPS")&&!self.at(")"){
            w.name=Some(self.id()?)
        }
        if self.eat("PARTITION"){
            self.need("BY")?;
            loop{
                w.partition.push(self.expr()?);
                if !self.eat(","){
                    break
                }
            }
        }
        w.order=self.order()?;
        let mut nested=0;
        while (!self.at(")")||nested>0)&&self.peek().kind!=Kind::Eof{
            if self.at("("){
                nested+=1
            }
            else if self.at(")"){
                nested-=1
            }
            w.frame.push(self.peek().text.to_uppercase());
            self.p+=1
        }
        self.need(")")?;
        Ok(w)
    }
    pub fn expr(&mut self)->Res<Expr>{
        self.bp(0)
    }
    fn bp(&mut self,min:u8)->Res<Expr>{
        let mut left=if self.eat("NOT"){
            Expr::Unary("NOT".into(),Box::new(self.bp(3)?))
        }
        else if self.at("+")||self.at("-")||self.at("~"){
            let op=self.peek().text.clone();
            self.p+=1;
            if op=="-"&&self.peek().kind==Kind::Num&&self.peek().text.replace('_',"")=="9223372036854775808"{
                self.p+=1;
                Expr::Lit(Value::Integer(i64::MIN))
            }
            else{
                Expr::Unary(op,Box::new(self.bp(12)?))
            }
        }
        else if self.eat("("){
            if self.at("SELECT")||self.at("WITH")||self.at("VALUES"){
                let q=self.query()?;
                self.need(")")?;
                Expr::Subquery(Box::new(q))
            }
            else{
                let e=self.expr()?;
                if self.eat(","){
                    let mut items=vec![e];
                    loop{
                        items.push(self.expr()?);
                        if self.eat(")"){
                            break
                        }
                        self.need(",")?
                    }
                    Expr::Tuple(items)
                }
                else{
                    self.need(")")?;
                    e
                }
            }
        }
        else if self.eat("EXISTS"){
            self.need("(")?;
            let q=self.query()?;
            self.need(")")?;
            Expr::Exists(Box::new(q))
        }
        else if self.eat("CASE"){
            let base=if self.at("WHEN"){
                None
            }
            else{
                Some(Box::new(self.expr()?))
            }
            ;
            let mut arms=vec![];
            while self.eat("WHEN"){
                let w=self.expr()?;
                self.need("THEN")?;
                arms.push((w,self.expr()?))
            }
            let otherwise=if self.eat("ELSE"){
                Some(Box::new(self.expr()?))
            }
            else{
                None
            }
            ;
            self.need("END")?;
            Expr::Case(base,arms,otherwise)
        }
        else if self.eat("CAST"){
            self.need("(")?;
            let e=self.expr()?;
            self.need("AS")?;
            let mut ty=vec![];
            while !self.at(")")&&self.peek().kind!=Kind::Eof{
                if self.eat("("){
                    while !self.eat(")")&&self.peek().kind!=Kind::Eof{
                        self.p+=1
                    }
                }
                else{
                    ty.push(self.peek().text.clone());
                    self.p+=1
                }
            }
            self.need(")")?;
            Expr::Cast(Box::new(e),ty.join(" "))
        }
        else{
            let t=self.peek().clone();
            self.p+=1;
            match t.kind{
                Kind::Str=>Expr::Lit(Value::Text(t.text)),Kind::Blob=>Expr::Lit(Value::Blob(unhex(&t.text).ok_or("invalid blob literal")?)),Kind::Num=>{
                    let n=t.text.replace('_',"");
                    Expr::Lit(if n.to_lowercase().starts_with("0x"){
                        Value::Integer(u64::from_str_radix(&n[2..],16).map_err(|_|"hex literal too big")? as i64)
                    }
                    else if let Ok(i)=n.parse::<i64>(){
                        Value::Integer(i)
                    }
                    else{
                        Value::Real(n.parse().map_err(|_|"invalid numeric literal")?)
                    }
                    )
                }
                ,Kind::Param=>Expr::Lit(Value::Null),Kind::Word|Kind::Quoted=>{
                    if t.kind==Kind::Word&&t.text.eq_ignore_ascii_case("NULL"){
                        Expr::Lit(Value::Null)
                    }
                    else if self.eat("("){
                        let distinct=self.eat("DISTINCT");
                        let mut args=vec![];
                        let mut order=vec![];
                        if !self.eat(")"){
                            loop{
                                args.push(self.expr()?);
                                if self.at("ORDER"){
                                    order=self.order()?
                                }
                                if self.eat(")"){
                                    break
                                }
                                self.need(",")?;
                            }
                        }
                        let filter=if self.eat("FILTER"){
                            self.need("(")?;
                            self.need("WHERE")?;
                            let e=self.expr()?;
                            self.need(")")?;
                            Some(Box::new(e))
                        }
                        else{
                            None
                        }
                        ;
                        let over=if self.eat("OVER"){
                            Some(if self.eat("("){
                                self.window()?
                            }
                            else{
                                Window{
                                    name:Some(self.id()?),..Default::default()
                                }
                            }
                            )
                        }
                        else{
                            None
                        }
                        ;
                        Expr::Call{
                            name:t.text,args,distinct,filter,order,over
                        }
                    }
                    else{
                        let double_quoted=t.kind==Kind::Quoted&&self.sql.as_bytes().get(t.start)==Some(&b'"');
                        let mut ns=vec![t.text];
                        while self.eat("."){
                            if self.eat("*"){
                                return Ok(Expr::Star(ns.last().cloned()))
                            }
                            ns.push(self.id()?)
                        }
                        if double_quoted&&ns.len()==1 { Expr::Dqs(ns.remove(0)) } else { Expr::Col(ns) }
                    }
                }
                ,Kind::Sym if t.text=="*"=>Expr::Star(None),_=>return Err(format!("near \"{}\": syntax error",t.text))
            }
        }
        ;
        loop{
            if self.at("COLLATE")&&min<=13{
                self.p+=1;
                left=Expr::Collate(Box::new(left),self.id()?);
                continue
            }
            let op=self.peek().text.to_uppercase();
            let (prec,neg)=match op.as_str(){
                "OR"=>(1,false),"AND"=>(2,false),"="|"=="|"!="|"<>"|"IS"|"ISNULL"|"NOTNULL"|"BETWEEN"|"IN"|"LIKE"|"GLOB"|"MATCH"|"REGEXP"=>(4,false),"NOT"=>{
                    let n=self.ts.get(self.p+1).map(|t|t.text.to_uppercase()).unwrap_or_default();
                    if ["BETWEEN","IN","LIKE","GLOB","MATCH","REGEXP","NULL"].contains(&n.as_str()){
                        (4,true)
                    }
                    else{
                        break
                    }
                }
                ,"<"|">"|"<="|">="=>(5,false),"&"|"|"|"<<"|">>"=>(7,false),"+"|"-"=>(8,false),"*"|"/"|"%"=>(9,false),"||"|"->"|"->>"=>(10,false),_=>break
            }
            ;
            if prec<min{
                break
            }
            self.p+=1;
            let op=if neg{
                let x=self.peek().text.to_uppercase();
                self.p+=1;
                x
            }
            else{
                op
            }
            ;
            match op.as_str(){
                "ISNULL"|"NOTNULL"|"NULL"=>{
                    left=Expr::Is(Box::new(left),Box::new(Expr::Lit(Value::Null)),op!="ISNULL")
                }
                ,"IS"=>{
                    let not=self.eat("NOT");
                    let not=if self.eat("DISTINCT"){
                        self.need("FROM")?;
                        !not
                    }
                    else{
                        not
                    }
                    ;
                    left=Expr::Is(Box::new(left),Box::new(self.bp(prec+1)?),not)
                }
                ,"BETWEEN"=>{
                    let lo=self.bp(prec+1)?;
                    self.need("AND")?;
                    let hi=self.bp(prec+1)?;
                    left=Expr::Between(Box::new(left),Box::new(lo),Box::new(hi),neg)
                }
                ,"IN"=>{
                    let mut list=vec![];
                    let mut query=None;
                    if self.eat("("){
                        if self.at("SELECT")||self.at("WITH")||self.at("VALUES"){
                            query=Some(Box::new(self.query()?));
                            self.need(")")?
                        }
                        else{
                            list=self.exprlist_end()?
                        }
                    }
                    else{
                        let t=self.fullname()?;
                        query=Some(Box::new(Query{
                            cores:vec![Select{
                                items:vec![Item{
                                    expr:Expr::Star(None),name:"*".into(),alias:None
                                }
                                ],from:Some(Source::Table(t,None,vec![])),..Default::default()
                            }
                            ],..Default::default()
                        }
                        ))
                    }
                    left=Expr::In(Box::new(left),list,query,neg)
                }
                ,"LIKE"|"GLOB"|"MATCH"|"REGEXP"=>{
                    let right=self.bp(prec+1)?;
                    let mut args=vec![right,left];
                    if self.eat("ESCAPE"){
                        args.push(self.bp(prec+1)?)
                    }
                    left=Expr::Call{
                        name:op,args,distinct:false,filter:None,order:vec![],over:None
                    }
                    ;
                    if neg{
                        left=Expr::Unary("NOT".into(),Box::new(left))
                    }
                }
                ,_=>{
                    left=Expr::Binary(op,Box::new(left),Box::new(self.bp(prec+1)?))
                }
            }
        }
        Ok(left)
    }
}
fn is_reserved(s:&str)->bool{
    ["FROM","WHERE","GROUP","HAVING","ORDER","LIMIT","OFFSET","UNION","INTERSECT","EXCEPT","JOIN","LEFT","RIGHT","FULL","INNER","CROSS","NATURAL","ON","USING","SET","RETURNING","WINDOW","ASC","DESC","NULLS","WHEN","THEN","ELSE","END","AND","OR","NOT","IN","IS","BETWEEN","LIKE","GLOB","COLLATE","FILTER","OVER","DO","INDEXED","VALUES"].contains(&s.to_uppercase().as_str())
}

fn key_column_name(e:&Expr)->Option<&str> {
    match e {Expr::Col(n)=>n.last().map(String::as_str),Expr::Collate(e,_)=>key_column_name(e),_=>None}
}
