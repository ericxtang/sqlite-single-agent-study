use crate::{
    engine::Engine,ast::*,parser::Res,storage::key
}
;
impl Engine{
    pub fn route_attachment(&self,s:&mut Statement)->Res<Option<String>>{
        if let Statement::IndexGuard(s,_)=s{return self.route_attachment(s)}
        let (target,create)=match s{
            Statement::CreateTable(t,..)=>(&mut t.name,true),Statement::CreateView(n,..)|Statement::CreateIndex(n,..)=>(n,true),Statement::CreateTrigger(t,_)=>(&mut t.name,true),Statement::Insert{
                table,..
            }
            |Statement::Update{
                table,..
            }
            |Statement::Delete{
                table,..
            }
            =>(table,false),Statement::Drop(_,n,_)|Statement::Alter(n,..)=>(n,false),Statement::Pragma(n,..)=>(n,true),_=>return Ok(None)
        }
        ;
        if let Some((schema,name))=target.split_once('.') {
            let schema=key(schema);
            if schema=="main"||schema=="temp"{
                if schema=="temp"{
                    *target=format!("temp.{}",name);
                    if let Statement::CreateTable(d,..)=s{
                        d.temporary=true;
                    }
                }
                else{
                    *target=format!("main.{}",name);
                    if create&&!matches!(s,Statement::Pragma(..)){
                        match s{
                            Statement::CreateTable(d,..)=>d.name=d.name[5..].into(),Statement::CreateView(n,..)|Statement::CreateIndex(n,..)=>*n=n[5..].into(),Statement::CreateTrigger(t,..)=>t.name=t.name[5..].into(),_=>{
                            }
                        }
                    }
                    else if let Statement::Pragma(n,..)=s{
                        *n=n[5..].into();
                    }
                }
                return Ok(None)
            }
            if !self.attachments.contains_key(&schema){
                return Err(format!("unknown database {}",schema))
            }
            *target=name.into();
            return Ok(Some(schema))
        }
        if !create&&!self.db.tables.contains_key(&key(target))&&!self.db.views.contains_key(&key(target))&&!self.db.indexes.contains_key(&key(target)){
            for(n,a)in &self.attachments{
                if a.db.tables.contains_key(&key(target))||a.db.views.contains_key(&key(target))||a.db.indexes.contains_key(&key(target)){
                    return Ok(Some(n.clone()))
                }
            }
        }
        Ok(None)
    }
}
