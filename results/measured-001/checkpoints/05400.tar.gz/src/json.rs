use crate::{
    value::Value,parser::Res
}
;
pub use crate::json_value::{
    Json as J,Object
}
;
pub fn to_json(v:&Value)->J{
    match v{
        Value::Null=>J::Null,Value::Integer(i)=>J::from(*i),Value::Real(f)=>J::from(*f),Value::Text(s)=>J::String(s.clone()),Value::Blob(b)=>J::String(String::from_utf8_lossy(b).into_owned())
    }
}
fn sql(v:&J)->Value{
    match v{
        J::Null=>Value::Null,J::Bool(b)=>Value::Integer(*b as i64),J::Number(n)=>n.as_i64().map(Value::Integer).unwrap_or_else(||Value::Real(n.as_f64().unwrap_or_else(||n.to_string().parse().unwrap_or(0.0)))),J::String(s)=>Value::Text(s.clone()),_=>Value::Text(v.to_string())
    }
}
fn parse(v:&Value)->Res<J>{
    if let Value::Blob(b)=v{
        if crate::jsonb::looks(b){
            return crate::jsonb::decode(b).ok_or("malformed JSON".into())
        }
    }
    crate::json_value::parse(&v.text()).map_err(|_|"malformed JSON".into())
}
#[derive(Clone)]
enum Path{
    Key(String),Index(i64),Append
}
fn path(s:&str)->Res<Vec<Path>>{
    if !s.starts_with('$'){
        return Err(format!("bad JSON path: '{}'",s))
    }
    let cs=s.chars().collect::<Vec<_>>();
    let mut p=1;
    let mut out=vec![];
    while p<cs.len(){
        if cs[p]=='.'{
            p+=1;
            let mut k=String::new();
            if cs.get(p)==Some(&'"'){
                p+=1;
                while p<cs.len()&&cs[p]!='"'{
                    k.push(cs[p]);
                    p+=1
                }
                if p==cs.len(){
                    return Err("bad JSON path".into())
                }
                p+=1
            }
            else{
                while p<cs.len()&&cs[p]!='.'&&cs[p]!='['{
                    k.push(cs[p]);
                    p+=1
                }
            }
            out.push(Path::Key(k))
        }
        else if cs[p]=='['{
            p+=1;
            let mut n=String::new();
            while p<cs.len()&&cs[p]!=']'{
                n.push(cs[p]);
                p+=1
            }
            if p==cs.len(){
                return Err("bad JSON path".into())
            }
            p+=1;
            out.push(if n=="#"{
                Path::Append
            }
            else{
                Path::Index(n.trim_start_matches('#').parse().map_err(|_|"bad JSON path")?)
            }
            )
        }
        else{
            return Err("bad JSON path".into())
        }
    }
    Ok(out)
}
fn get<'a>(v:&'a J,p:&[Path])->Option<&'a J>{
    let mut v=v;
    for x in p{
        v=match x{
            Path::Key(k)=>v.get(k)?,Path::Index(i)=>{
                let a=v.as_array()?;
                let i=if *i<0{
                    a.len() as i64+i
                }
                else{
                    *i
                }
                ;
                a.get(i as usize)?
            }
            ,Path::Append=>return None
        }
    }
    Some(v)
}
fn set(v:&mut J,p:&[Path],new:Option<J>,mode:&str){
    if p.is_empty(){
        if mode!="insert"{
            *v=new.unwrap_or(J::Null)
        }
        return
    }
    match &p[0]{
        Path::Key(k)=>{
            if v.is_null(){
                *v=J::Object(Object::new())
            }
            if let Some(o)=v.as_object_mut(){
                if p.len()==1{
                    if new.is_none(){
                        o.remove(k);
                    }
                    else if mode=="set"||(mode=="insert"&&!o.contains_key(k))||(mode=="replace"&&o.contains_key(k)){
                        o.insert(k.clone(),new.unwrap());
                    }
                }
                else if o.contains_key(k)||mode!="replace"{
                    let entry=o.entry(k.clone()).or_insert(J::Null);
                    set(entry,&p[1..],new,mode)
                }
            }
        }
        ,Path::Index(_)|Path::Append=>{
            if v.is_null(){
                *v=J::Array(vec![])
            }
            if let Some(a)=v.as_array_mut(){
                let i=match p[0]{
                    Path::Index(i)=>if i<0{
                        a.len() as i64+i
                    }
                    else{
                        i
                    }
                    ,_=>a.len() as i64
                }
                ;
                if i<0||i>a.len() as i64{
                    return
                }
                let i=i as usize;
                if p.len()==1{
                    if let Some(n)=new{
                        if i==a.len()&&mode!="replace"{
                            a.push(n)
                        }
                        else if i<a.len()&&mode!="insert"{
                            a[i]=n
                        }
                    }
                    else if i<a.len(){
                        a.remove(i);
                    }
                }
                else{
                    if i==a.len()&&mode!="replace"{
                        a.push(J::Null)
                    }
                    if let Some(v)=a.get_mut(i){
                        set(v,&p[1..],new,mode)
                    }
                }
            }
        }
    }
}
pub fn arrow(a:&Value,b:&Value,extract:bool)->Res<Value>{
    if a.null()||b.null(){
        return Ok(Value::Null)
    }
    let p=match b{
        Value::Integer(i)=>format!("$[{}{}]",if *i<0{
            "#"
        }
        else{
            ""
        }
        ,i),_=>{
            let s=b.text();
            if s.starts_with('$'){
                s
            }
            else{
                format!("$.{}",s)
            }
        }
    }
    ;
    let j=parse(a)?;
    let p=path(&p)?;
    Ok(if let Some(v)=get(&j,&p){
        if extract{
            sql(v)
        }
        else{
            Value::Text(v.to_string())
        }
    }
    else{
        Value::Null
    }
    )
}
pub fn call_typed(n:&str,a:&[Value],typed:&[bool])->Res<Value>{
    let result=call_inner(n,a,typed)?;
    if n=="jsonb"||n.starts_with("jsonb_"){
        if let Value::Text(s)=&result{
            let object_result=if n=="jsonb_extract"&&a.len()==2{
                extract_is_container(&a[0],&a[1])
            }
            else{
                true
            }
            ;
            if object_result{
                if let Ok(j)=crate::json_value::parse(s){
                    return Ok(Value::Blob(crate::jsonb::encode(&j)))
                }
            }
        }
    }
    Ok(result)
}
pub fn call_inner(n:&str,a:&[Value],typed:&[bool])->Res<Value>{
    let value_indices:Vec<usize>=match n{
        "json_object"|"jsonb_object"=>(1..a.len()).step_by(2).collect(),"json_set"|"json_insert"|"json_replace"|"jsonb_set"|"jsonb_insert"|"jsonb_replace"=>(2..a.len()).step_by(2).collect(),"json_quote"=>(0..a.len()).collect(),_=>vec![]
    }
    ;
    if value_indices.iter().any(|i|matches!(&a[*i],Value::Blob(b) if crate::jsonb::decode(b).is_none())){
        return Err("JSON cannot hold BLOB values".into())
    }
    let need=|min,max|if a.len()<min||a.len()>max{
        Err(format!("wrong number of arguments to function {}()",n))
    }
    else{
        Ok(())
    }
    ;
    Ok(match n{
        "json_valid"=>{
            need(1,2)?;
            if a.iter().any(Value::null){
                Value::Null
            }
            else{
                let flags=a.get(1).map(Value::int).unwrap_or(1);
                if !(1..=15).contains(&flags){
                    return Err("FLAGS parameter to json_valid() must be between 1 and 15".into())
                }
                Value::boolean((flags&1!=0&&serde_json::from_str::<serde_json::Value>(&a[0].text()).is_ok())||(flags&2!=0&&parse(&a[0]).is_ok()&&!matches!(a[0],Value::Blob(_)))||matches!(&a[0],Value::Blob(b) if (flags&4!=0&&crate::jsonb::looks(b))||(flags&8!=0&&crate::jsonb::decode(b).is_some())))
            }
        }
        ,"json_error_position"=>{
            need(1,1)?;
            if a[0].null(){
                Value::Null
            }
            else{
                Value::Integer(crate::json_value::parse(&a[0].text()).err().map(|e|e as i64).unwrap_or(0))
            }
        }
        ,
        "json"|"jsonb"=>{
            need(1,1)?;
            if a[0].null(){
                Value::Null
            }
            else{
                Value::Text(parse(&a[0])?.to_string())
            }
        }
        ,"json_pretty"=>{
            need(1,2)?;
            if a[0].null(){
                Value::Null
            }
            else{
                Value::Text(serde_json::to_string_pretty(&parse(&a[0])?).unwrap())
            }
        }
        ,
        "json_quote"=>{
            need(1,1)?;
            Value::Text(to_json_typed(&a[0],typed.first().copied().unwrap_or(false)).to_string())
        }
        ,
        "json_array"|"jsonb_array"=>{
            if a.iter().any(|v|matches!(v,Value::Blob(b) if crate::jsonb::decode(b).is_none())){
                return Err("JSON cannot hold BLOB values".into())
            }
            Value::Text(J::Array(a.iter().enumerate().map(|(i,v)|to_json_typed(v,typed.get(i).copied().unwrap_or(false))).collect()).to_string())
        }
        ,
        "json_object"|"jsonb_object"=>{
            if a.len()%2!=0{
                return Err("json_object() requires an even number of arguments".into())
            }
            let mut o=Object::new();
            for (i,pair) in a.chunks(2).enumerate(){
                let Value::Text(k)=&pair[0]else{
                    return Err("json_object() labels must be TEXT".into())
                }
                ;
                o.insert(k.clone(),to_json_typed(&pair[1],typed.get(i*2+1).copied().unwrap_or(false)));
            }
            Value::Text(J::Object(o).to_string())
        }
        ,
        "json_extract"|"jsonb_extract"=>{
            need(2,usize::MAX)?;
            if a[0].null(){
                Value::Null
            }
            else{
                let j=parse(&a[0])?;
                let mut out=vec![];
                for p in &a[1..]{
                    if p.null(){
                        out.push(J::Null)
                    }
                    else{
                        out.push(get(&j,&path(&p.text())?).cloned().unwrap_or(J::Null))
                    }
                }
                if out.len()==1{
                    sql(&out[0])
                }
                else{
                    Value::Text(J::Array(out).to_string())
                }
            }
        }
        ,
        "json_type"|"json_array_length"=>{
            need(1,2)?;
            if a[0].null()||a.get(1).is_some_and(Value::null){
                Value::Null
            }
            else{
                let j=parse(&a[0])?;
                let p=if a.len()==2{
                    path(&a[1].text())?
                }
                else{
                    vec![]
                }
                ;
                if let Some(v)=get(&j,&p){
                    if n=="json_array_length"{
                        Value::Integer(v.as_array().map(|a|a.len()).unwrap_or(0) as i64)
                    }
                    else{
                        Value::Text(match v{
                            J::Null=>"null",J::Bool(true)=>"true",J::Bool(false)=>"false",J::Number(n)=>if n.is_i64()||n.is_u64(){
                                "integer"
                            }
                            else{
                                "real"
                            }
                            ,J::String(_)=>"text",J::Array(_)=>"array",J::Object(_)=>"object"
                        }
                        .into())
                    }
                }
                else{
                    Value::Null
                }
            }
        }
        ,
        "json_set"|"json_insert"|"json_replace"|"jsonb_set"|"jsonb_insert"|"jsonb_replace"=>{
            need(1,usize::MAX)?;
            if a.len()%2!=1{
                return Err("json_set() needs an odd number of arguments".into())
            }
            if a[0].null(){
                Value::Null
            }
            else{
                let mut j=parse(&a[0])?;
                let mode=n.split('_').nth(1).unwrap();
                for (i,pair) in a[1..].chunks(2).enumerate(){
                    if pair[0].null(){
                        continue
                    }
                    set(&mut j,&path(&pair[0].text())?,Some(to_json_typed(&pair[1],typed.get(i*2+2).copied().unwrap_or(false))),mode)
                }
                Value::Text(j.to_string())
            }
        }
        ,
        "json_remove"|"jsonb_remove"=>{
            need(1,usize::MAX)?;
            if a.iter().any(Value::null){
                Value::Null
            }
            else{
                let mut j=parse(&a[0])?;
                for p in &a[1..]{
                    let p=path(&p.text())?;
                    if p.is_empty(){
                        return Ok(Value::Null)
                    }
                    set(&mut j,&p,None,"replace")
                }
                Value::Text(j.to_string())
            }
        }
        ,
        "json_patch"|"jsonb_patch"=>{
            need(2,2)?;
            if a.iter().any(Value::null){
                Value::Null
            }
            else{
                let mut j=parse(&a[0])?;
                patch(&mut j,parse(&a[1])?);
                Value::Text(j.to_string())
            }
        }
        ,_=>return Err(format!("no such function: {}",n))
    }
    )
}
fn patch(v:&mut J,p:J){
    if let J::Object(o)=p{
        if !v.is_object(){
            *v=J::Object(Object::new())
        }
        let target=v.as_object_mut().unwrap();
        for(k,p)in o{
            if p.is_null(){
                target.remove(&k);
            }
            else{
                patch(target.entry(k).or_insert(J::Null),p)
            }
        }
    }
    else{
        *v=p
    }
}
pub fn to_json_typed(v:&Value,typed:bool)->J{
    if let Value::Blob(b)=v{
        if let Some(j)=crate::jsonb::decode(b){
            return j
        }
    }
    if typed{
        parse(v).unwrap_or_else(|_|to_json(v))
    }
    else{
        to_json(v)
    }
}
pub fn is_json_expr(e:&crate::ast::Expr,v:&Value)->bool{
    use crate::ast::Expr;
    match e{
        Expr::Call{
            name,..
        }
        =>{
            let n=name.to_ascii_lowercase();
            if ["json_extract","jsonb_extract"].contains(&n.as_str()){
                matches!(v,Value::Text(s) if s.starts_with('[')||s.starts_with('{'))
            }
            else{
                n.starts_with("json")&&!["json_valid","json_type","json_array_length","json_error_position"].contains(&n.as_str())
            }
        }
        ,Expr::Binary(op,_,_)=>op=="->",_=>false
    }
}
pub fn table(name:&str,args:&[Value])->Res<crate::engine::Relation>{
    use crate::engine::{
        Relation,Field
    }
    ;
    if args.is_empty()||args.len()>2{
        return Err("wrong number of arguments to json_each()".into())
    }
    let mut r=Relation::simple(&["key","value","type","atom","id","parent","fullkey","path"],vec![]);
    for n in ["json","root"]{
        let mut f=Field::new(n);
        f.hidden=true;
        r.fields.push(f);
    }
    if args[0].null(){
        return Ok(r)
    }
    let j=parse(&args[0])?;
    let root=args.get(1).map(Value::text).unwrap_or("$".into());
    let p=path(&root)?;
    let Some(j)=get(&j,&p)else{
        return Ok(r)
    }
    ;
    let tree=name.ends_with("tree");
    let mut id=0;
    fn add(v:&J,k:Value,parent:Option<i64>,full:&str,path:&str,tree:bool,id:&mut i64,rows:&mut Vec<Vec<Value>>){
        let my=*id;
        *id+=1;
        let typ=match v{
            J::Null=>"null",J::Bool(true)=>"true",J::Bool(false)=>"false",J::Number(n)=>if n.is_i64()||n.is_u64(){
                "integer"
            }
            else{
                "real"
            }
            ,J::String(_)=>"text",J::Array(_)=>"array",J::Object(_)=>"object"
        }
        ;
        rows.push(vec![k,sql(v),Value::Text(typ.into()),if v.is_object()||v.is_array(){
            Value::Null
        }
        else{
            sql(v)
        }
        ,Value::Integer(my),parent.map(Value::Integer).unwrap_or(Value::Null),Value::Text(full.into()),Value::Text(path.into())]);
        if tree{
            match v{
                J::Array(a)=>for(i,v)in a.iter().enumerate(){
                    add(v,Value::Integer(i as i64),Some(my),&format!("{}[{}]",full,i),full,true,id,rows)
                }
                ,J::Object(o)=>for(k,v)in o{
                    add(v,Value::Text(k.clone()),Some(my),&format!("{}.{}",full,k),full,true,id,rows)
                }
                ,_=>{
                }
            }
        }
    }
    if tree{
        add(j,Value::Null,None,&root,&root,true,&mut id,&mut r.rows)
    }
    else{
        match j{
            J::Array(a)=>for(i,v)in a.iter().enumerate(){
                add(v,Value::Integer(i as i64),None,&format!("{}[{}]",root,i),&root,false,&mut id,&mut r.rows)
            }
            ,J::Object(o)=>for(k,v)in o{
                add(v,Value::Text(k.clone()),None,&format!("{}.{}",root,k),&root,false,&mut id,&mut r.rows)
            }
            ,_=>add(j,Value::Null,None,&root,&root,false,&mut id,&mut r.rows)
        }
    }
    for(n,v)in [("json",args[0].clone()),("root",Value::Text(root))]{
        let _=n;
        for row in &mut r.rows{
            row.push(v.clone())
        }
    }
    if name.starts_with("jsonb_"){
        for row in &mut r.rows{
            if row[2].text()=="array"||row[2].text()=="object"{
                row[1]=Value::Blob(crate::jsonb::encode(&parse(&row[1])?));
            }
        }
    }
    Ok(r)
}
pub fn extract_is_container(value:&Value,path_value:&Value)->bool{
    let Ok(j)=parse(value)else{
        return false
    }
    ;
    let Ok(p)=path(&path_value.text())else{
        return false
    }
    ;
    get(&j,&p).is_some_and(|v|v.is_array()||v.is_object())
}
