use std::{
    collections::BTreeMap,path::PathBuf,cmp::Ordering
}
;
use crate::{
    ast::*,storage::*,value::{
        Value,Affinity,affinity,compare,real
    }
    ,parser::{
        Parser,Res
    }
    ,functions
}
;
#[derive(Clone,Debug)]
pub struct Field{
    pub name:String,pub table:String,pub affinity:Affinity,pub collate:String,pub hidden:bool
}
#[derive(Clone,Debug,Default)]
pub struct Relation{
    pub fields:Vec<Field>,pub rows:Vec<Vec<Value>>
}
impl Relation{
    pub fn simple(names:&[&str],rows:Vec<Vec<Value>>)->Self{
        Self{
            fields:names.iter().map(|n|Field::new(n)).collect(),rows
        }
    }
    pub fn json(&self)->serde_json::Value{
        serde_json::json!({
            "ok":true,"columns":self.fields.iter().map(|f|f.name.clone()).collect::<Vec<_>>(),"rows":self.rows.iter().map(|r|r.iter().map(Value::json).collect::<Vec<_>>()).collect::<Vec<_>>()
        }
        )
    }
}
impl Field{
    pub fn new(n:&str)->Self{
        Self{
            name:n.into(),table:String::new(),affinity:Affinity::None,collate:"BINARY".into(),hidden:false
        }
    }
}
#[derive(Clone,Debug,Default)]
pub struct Env{
    pub fields:Vec<Field>,pub values:Vec<Value>,pub outer:Option<Box<Env>>
}
impl Env{
    pub fn find(&self,n:&[String])->Res<Option<usize>>{
        let name=n.last().unwrap();
        let qualifier=if n.len()>1{
            Some(&n[n.len()-2])
        }
        else{
            None
        }
        ;
        let mut ids:Vec<usize>=self.fields.iter().enumerate().filter(|(_,f)|f.name.eq_ignore_ascii_case(name)&&qualifier.is_none_or(|q|q.eq_ignore_ascii_case(&f.table)||f.table.rsplit('.').next().is_some_and(|t|q.eq_ignore_ascii_case(t)))).map(|(i,_)|i).collect();
        if qualifier.is_none()&&ids.iter().any(|i|!self.fields[*i].hidden){
            ids.retain(|i|!self.fields[*i].hidden)
        }
        if ids.len()>1{
            return Err(format!("ambiguous column name: {}",n.join(".")))
        }
        Ok(ids.first().copied())
    }
    pub fn get(&self,n:&[String])->Res<Option<(Value,Field)>>{
        if let Some(i)=self.find(n)?{
            return Ok(Some((self.values.get(i).cloned().unwrap_or(Value::Null),self.fields[i].clone())))
        }
        if let Some(o)=&self.outer{
            o.get(n)
        }
        else{
            Ok(None)
        }
    }
}
#[derive(Clone,Debug)]
pub struct WindowInput{
    pub env:Env,pub group:Option<Vec<Env>>
}
pub type Ctes=BTreeMap<String,Relation>;
pub struct Engine{
    pub active_change_values:Vec<(usize,i64)>,pub trigger_change_values:Vec<i64>,
    pub foreign_baseline:std::collections::BTreeSet<String>,pub data_version:i64,pub attachments:BTreeMap<String,Box<Engine>>,pub attachment_order:Vec<String>,pub snapshot_active:bool,pub writer:Option<WriteLock>,pub scoped_ctes:Ctes,pub trigger_env:Option<Env>,pub active_triggers:Vec<String>,pub db:Database,pub path:Option<PathBuf>,pub tx:Option<Database>,pub savepoints:Vec<(String,Database)>,pub explicit:bool,pub changes:i64,pub total_changes:i64,pub last_id:i64,pub foreign_keys:bool,pub defer_foreign:bool,pub case_like:bool,pub journal:String,pub pragmas:BTreeMap<String,Value>
}
impl Engine{
    pub fn open(s:&str)->Res<Self>{
        let path=if s==":memory:"||s.is_empty(){
            None
        }
        else{
            Some(confined(s)?)
        }
        ;
        let db=if let Some(p)=&path{
            open(p)?
        }
        else{
            Database::default()
        }
        ;
        Ok(Self{
            active_change_values:vec![],trigger_change_values:vec![],foreign_baseline:std::collections::BTreeSet::new(),data_version:1,attachments:BTreeMap::new(),attachment_order:vec![],snapshot_active:false,writer:None,scoped_ctes:Ctes::new(),trigger_env:None,active_triggers:vec![],db,path,tx:None,savepoints:vec![],explicit:false,changes:0,total_changes:0,last_id:0,foreign_keys:false,defer_foreign:false,case_like:false,journal:"delete".into(),pragmas:BTreeMap::new()
        }
        )
    }
    pub fn persist(&mut self)->Res<()>{
        if let Some(p)=&self.path{
            let previous=self.db.revision;
            let committed=open(p)?;
            let mut image=self.db.persistent();image.revision=committed.revision;
            if serde_json::to_vec(&image).map_err(|e|e.to_string())?==serde_json::to_vec(&committed).map_err(|e|e.to_string())? {self.db.revision=committed.revision;return Ok(())}
            self.db.revision=committed.revision.wrapping_add(1);
            if let Err(e)=save(p,&self.db){
                self.db.revision=previous;
                return Err(e)
            }
        }
        Ok(())
    }
    fn refresh(&mut self)->Res<()>{
        if let Some(p)=&self.path{
            let mut db=open(p)?;
            if db.revision!=self.db.revision{
                self.data_version+=1
            }
            db.temp_sequence_exists=self.db.temp_sequence_exists;
            db.temp_schema_version=self.db.temp_schema_version;db.temp_user_version=self.db.temp_user_version;db.temp_application_id=self.db.temp_application_id;
            for(k,t)in &self.db.tables{
                if t.def.temporary{
                    db.tables.insert(k.clone(),t.clone());
                    for(i,x)in &self.db.indexes{
                        if x.table.eq_ignore_ascii_case(&t.def.name){
                            db.indexes.insert(i.clone(),x.clone());
                        }
                    }
                }
            }
            for(k,v)in &self.db.views{
                if k.starts_with("temp."){
                    db.views.insert(k.clone(),v.clone());
                }
            }
            for(k,t)in &self.db.triggers{
                if t.temporary{
                    db.triggers.insert(k.clone(),t.clone());
                }
            }
            self.db=db;
        }
        for a in self.attachments.values_mut(){
            if a.tx.is_none(){
                a.refresh()?;
            }
        }
        Ok(())
    }
    pub fn execute(&mut self,sql:&str)->Res<Relation>{
        crate::datetime::begin_statement();
        let stmt=Parser::new(sql)?.parse()?;
        self.execute_statement(stmt)
    }
    pub fn execute_statement(&mut self,stmt:Statement)->Res<Relation>{
        self.execute_statement_raw(stmt).map_err(|e|e.trim_start_matches("ROLLBACK:").trim_start_matches("FAIL:").to_string())
    }
    pub(crate) fn execute_statement_raw(&mut self,stmt:Statement)->Res<Relation>{
        match &stmt{
            Statement::Vacuum(..) if self.tx.is_some()=>return Err("cannot VACUUM from within a transaction".into()),
            Statement::Begin(_) if self.tx.is_some()=>return Err("cannot start a transaction within a transaction".into()),Statement::Release(n)|Statement::Rollback(Some(n)) if !self.savepoints.iter().any(|(s,_)|s.eq_ignore_ascii_case(n))=>return Err(format!("no such savepoint: {}",n)),_=>{
            }
        }
        let control=matches!(stmt,Statement::Begin(_)|Statement::Commit|Statement::Rollback(_)|Statement::Savepoint(_)|Statement::Release(_));
        let write=statement_writes(&stmt);
        let main_write=write&&self.writes_main(&stmt,0);
        if !control{
            for a in self.attachments.values_mut(){
                if a.tx.is_some()&&!a.snapshot_active{
                    a.refresh()?;
                    a.tx=Some(a.db.clone());
                    for(_,db)in &mut a.savepoints{
                        *db=a.db.clone()
                    }
                    a.snapshot_active=true;
                }
            }
        }
        if self.tx.is_some()&&!self.snapshot_active&&!control{
            self.refresh()?;
            self.tx=Some(self.db.clone());
            for(_,db)in &mut self.savepoints{
                *db=self.db.clone()
            }
            self.snapshot_active=true;
        }
        if write&&self.pragmas.get("query_only").is_some_and(|v|v.truth()==Some(true)||v.text().eq_ignore_ascii_case("on")){
            return Err("attempt to write a readonly database".into())
        }
        if main_write&&self.writer.is_none(){
            if let Some(p)=&self.path{
                let lock=WriteLock::acquire_timeout(p,self.pragmas.get("busy_timeout").map(Value::int).unwrap_or(0))?;
                if let Some(tx)=&self.tx{
                    if open(p)?.revision!=tx.revision{
                        return Err("database is locked".into())
                    }
                }
                self.writer=Some(lock);
            }
        }
        if self.tx.is_none(){
            if let Err(e)=self.refresh(){
                self.writer=None;
                return Err(e)
            }
        }
        let before=self.db.clone();
        self.foreign_baseline=crate::foreign::violations(&before);
        let child_before=if write&&!control{self.attachments.iter().map(|(name,a)|(name.clone(),a.db.clone())).collect::<BTreeMap<_,_>>()}else{BTreeMap::new()};
        let mut transient_children=vec![];
        if write&&!control&&self.tx.is_none() {
            for (name,a) in &mut self.attachments {
                if a.tx.is_none(){a.tx=Some(a.db.clone());a.snapshot_active=true;a.explicit=false;transient_children.push(name.clone());}
            }
        }
        let old_changes=self.changes;
        let mut r=self.run(stmt);
        if r.is_ok()||r.as_ref().is_err_and(|e|e.starts_with("FAIL:")) {
            for name in &transient_children {
                if let Err(error)=self.attachments[name].check_foreign(true){r=Err(error);break}
            }
        }
        let mut result=match r {
            Ok(relation)=>{
                if self.tx.is_none()&&!control&&main_write {
                    if let Err(error)=self.persist(){self.db=before.clone();Err(error)}else{Ok(relation)}
                }else{Ok(relation)}
            },
            Err(error)=>{
                if !control {
                    if error.starts_with("ROLLBACK:") {
                        self.db=self.tx.take().unwrap_or_else(||before.clone());
                        self.savepoints.clear();self.explicit=false;self.defer_foreign=false;
                    }else if !error.starts_with("FAIL:") {
                        self.db=before.clone();self.changes=old_changes;
                    }else if self.tx.is_none()&&main_write {
                        if let Err(io_error)=self.persist(){self.db=before.clone();return Err(io_error)}
                    }
                }
                Err(error)
            }
        };
        let rollback_all=result.as_ref().is_err_and(|e|e.starts_with("ROLLBACK:"));
        let keep=result.is_ok()||result.as_ref().is_err_and(|e|e.starts_with("FAIL:"));
        for (name,snapshot) in child_before {
            let Some(a)=self.attachments.get_mut(&name)else{continue};
            if rollback_all {
                if a.tx.is_some(){a.execute_statement_raw(Statement::Rollback(None))?;}
            }else if transient_children.contains(&name) {
                if a.tx.is_some() {
                    let control=if keep{Statement::Commit}else{Statement::Rollback(None)};
                    if let Err(error)=a.execute_statement_raw(control){result=Err(error);}
                }
            }else if !keep {a.db=snapshot;}
        }
        if self.tx.is_none(){self.writer=None;}
        result
    }
    pub fn query(&self,q:&Query,outer:&Env,ctes:&Ctes,depth:usize)->Res<Relation>{
        if depth>100{
            return Err("query recursion limit exceeded".into())
        }
        let mut locals=self.scoped_ctes.clone();
        locals.extend(ctes.clone());
        for c in &q.ctes{
            let recursive=c.query.cores.len()>1&&c.query.cores.iter().any(|s|select_references(s,&c.name));
            let anchors=c.query.cores.iter().position(|s|select_references(s,&c.name)).unwrap_or(c.query.cores.len());
            let mut r=if recursive{
                let mut anchor=c.query.clone();
                anchor.cores.truncate(anchors);
                anchor.ops.truncate(anchors.saturating_sub(1));
                anchor.order.clear();
                anchor.limit=None;
                self.query(&anchor,outer,&locals,depth+1)?
            }
            else{
                self.query(&c.query,outer,&locals,depth+1)?
            }
            ;
            rename_cte(&mut r,&c.cols)?;
            if recursive{
                let mut all=Relation{
                    fields:r.fields.clone(),rows:vec![]
                }
                ;
                let mut step=c.query.clone();
                step.cores=step.cores.into_iter().skip(anchors).collect();
                let union_all=c.query.ops.get(anchors.saturating_sub(1)).is_some_and(|o|o=="UNION ALL");
                step.ops=step.ops.into_iter().skip(anchors).collect();
                step.ctes.clear();
                step.order.clear();
                step.limit=None;
                step.offset=None;
                if step.cores.iter().any(|s|!s.group.is_empty()||s.items.iter().any(|i|has_aggregate(&i.expr))){
                    return Err("recursive aggregate queries not supported".into())
                }
                if crate::validate::binding() {
                    locals.insert(key(&c.name),r.clone());
                    let next=self.query(&step,outer,&locals,depth+1)?;
                    if next.fields.len()!=r.fields.len(){return Err("SELECTs have different number of result columns".into())}
                    locals.insert(key(&c.name),r);continue;
                }
                let limit=c.query.limit.as_ref().map(|e|self.eval(e,outer,None,&locals,depth).and_then(|v|integer_limit(&v))).transpose()?.unwrap_or(-1);
                let mut offset=c.query.offset.as_ref().map(|e|self.eval(e,outer,None,&locals,depth).and_then(|v|integer_limit(&v))).transpose()?.unwrap_or(0).max(0);
                let mut queue=r.rows;
                let mut seen=if union_all{
                    vec![]
                }
                else{
                    queue.clone()
                }
                ;
                let mut iter=0;
                while !queue.is_empty()&&(limit<0||all.rows.len()<limit as usize){
                    iter+=1;
                    if iter>1000000{
                        return Err("recursive query limit exceeded".into())
                    }
                    if !c.query.order.is_empty(){
                        let mut decorated=vec![];
                        for row in queue{
                            let env=Env{
                                fields:all.fields.clone(),values:row.clone(),outer:Some(Box::new(outer.clone()))
                            }
                            ;
                            let keys=self.order_keys(&c.query.order,&all.fields,&row,&env,None,&locals,depth)?;
                            decorated.push((row,keys));
                        }
                        sort_decorated(&mut decorated,&c.query.order,&all.fields);
                        queue=decorated.into_iter().map(|x|x.0).collect();
                    }
                    let row=queue.remove(0);
                    if offset>0{
                        offset-=1
                    }
                    else{
                        all.rows.push(row.clone());
                        if limit>=0&&all.rows.len()>=limit as usize{
                            break
                        }
                    }
                    locals.insert(key(&c.name),Relation{
                        fields:all.fields.clone(),rows:vec![row]
                    }
                    );
                    let mut next=self.query(&step,outer,&locals,depth+1)?;
                    rename_cte(&mut next,&c.cols)?;
                    for row in next.rows{
                        if !union_all{
                            if seen.iter().any(|r|rows_equal(r,&row,&all.fields)){
                                continue
                            }
                            seen.push(row.clone())
                        }
                        queue.push(row);
                    }
                }
                r=all;
            }
            locals.insert(key(&c.name),r);
        }
        let mut r=self.core(&q.cores[0],if q.cores.len()==1{
            &q.order
        }
        else{
            &[]
        }
        ,outer,&locals,depth+1)?;
        for (op,s) in q.ops.iter().zip(q.cores.iter().skip(1)){
            let x=self.core(s,&[],outer,&locals,depth+1)?;
            if x.fields.len()!=r.fields.len(){
                return Err("SELECTs have different number of result columns".into())
            }
            match op.as_str(){
                "UNION ALL"=>r.rows.extend(x.rows),"UNION"=>{
                    r.rows.extend(x.rows);
                    dedup(&mut r)
                }
                ,"INTERSECT"=>{
                    r.rows.retain(|a|x.rows.iter().any(|b|rows_equal(a,b,&r.fields)));
                    dedup(&mut r)
                }
                ,"EXCEPT"=>{
                    r.rows.retain(|a|!x.rows.iter().any(|b|rows_equal(a,b,&r.fields)));
                    dedup(&mut r)
                }
                ,_=>return Err("invalid compound operator".into())
            }
        }
        if q.cores.len()>1&&!q.order.is_empty(){
            let mut decorated=vec![];
            for row in &r.rows{
                let env=Env{
                    fields:r.fields.clone(),values:row.clone(),outer:Some(Box::new(outer.clone()))
                }
                ;
                let keys=self.order_keys(&q.order,&r.fields,row,&env,None,&locals,depth)?;
                decorated.push((row.clone(),keys))
            }
            sort_decorated(&mut decorated,&q.order,&r.fields);
            r.rows=decorated.into_iter().map(|x|x.0).collect();
        }
        for e in q.limit.iter().chain(q.offset.iter()) {self.validate_row_expr(e,outer)?;}
        if crate::validate::binding(){r.rows.clear();return Ok(r)}
        if let Some(e)=&q.limit{
            let v=self.eval(e,outer,None,&locals,depth)?;
            let n=integer_limit(&v)?;
            let offset=if let Some(e)=&q.offset{
                integer_limit(&self.eval(e,outer,None,&locals,depth)?)?.max(0) as usize
            }
            else{
                0
            }
            ;
            r.rows=r.rows.into_iter().skip(offset).take(if n<0{
                usize::MAX
            }
            else{
                n as usize
            }
            ).collect();
        }
        for row in &mut r.rows {for v in row {if v.is_json() {*v=v.clone().into_plain();}}}
        Ok(r)
    }
    fn core(&self,s:&Select,order:&[Order],outer:&Env,ctes:&Ctes,depth:usize)->Res<Relation>{
        if let Some(vs)=&s.values{
            let mut r=Relation::default();
            if let Some(row)=vs.first(){
                r.fields=(0..row.len()).map(|i|Field::new(&format!("column{}",i+1))).collect()
            }
            if crate::validate::binding() {
                for row in vs {
                    if row.len()!=r.fields.len(){return Err("all VALUES must have the same number of terms".into())}
                    for e in row {self.validate_expr(e,outer,ctes,depth)?;}
                }
                return Ok(r);
            }
            for row in vs{
                if row.len()!=r.fields.len(){
                    return Err("all VALUES must have the same number of terms".into())
                }
                r.rows.push(row.iter().map(|e|self.eval(e,outer,None,ctes,depth)).collect::<Res<_>>()?)
            }
            return Ok(r)
        }
        let input=if let Some(f)=&s.from{
            self.source(f,outer,ctes,depth)?
        }
        else{
            Relation{
                fields:vec![],rows:vec![vec![]]
            }
        }
        ;
        let mut items=expand_items(&s.items,&input.fields)?;
        for item in &mut items {crate::window::resolve_expression(&mut item.expr,&s.windows)?;}
        let mut resolved_order=order.to_vec();
        for term in &mut resolved_order {crate::window::resolve_expression(&mut term.expr,&s.windows)?;}
        let order=resolved_order.as_slice();
        let template=Env{
            fields:input.fields.clone(),values:vec![Value::Null;
            input.fields.len()],outer:Some(Box::new(outer.clone()))
        }
        ;
        for item in &mut items { if item.alias.is_none() { if let Expr::Dqs(n)=&item.expr { if let Some(f)=input.fields.iter().find(|f|f.name.eq_ignore_ascii_case(n)) { item.name=f.name.clone(); } } } }
        let fields=items.iter().map(|i|{
            let (a,c)=self.meta(&i.expr,&template);
            Field{
                name:i.name.clone(),table:String::new(),affinity:a,collate:c,hidden:false
            }
        }
        ).collect::<Vec<_>>();
        if s.filter.as_ref().is_some_and(|e|has_aggregate(e)||has_window(e))||s.group.iter().any(|e|has_aggregate(e)||has_window(e)){
            return Err("misuse of aggregate function".into())
        }
        let mut bind=template.clone();
        for i in &items{
            self.validate_expr(&i.expr,&template,ctes,depth)?;
            if let Some(n)=&i.alias{
                if !bind.fields.iter().any(|f|f.name.eq_ignore_ascii_case(n)){
                    bind.fields.push(Field::new(n));
                    bind.values.push(Value::Null)
                }
            }
        }
        for e in s.filter.iter().chain(s.having.iter()).chain(s.group.iter()).chain(order.iter().map(|o|&o.expr)){
            self.validate_expr(e,&bind,ctes,depth)?;
        }
        for e in s.group.iter().chain(order.iter().map(|o|&o.expr)) {
            if let Expr::Lit(Value::Integer(n))=e {if *n<1||*n as usize>items.len(){return Err("ORDER BY or GROUP BY term out of range".into())}}
        }
        let aggregate=!s.group.is_empty()||s.items.iter().any(|i|has_aggregate(&i.expr))||s.having.as_ref().is_some_and(has_aggregate)||order.iter().any(|o|has_aggregate(&o.expr));
        if s.having.is_some()&&!aggregate{return Err("HAVING clause on a non-aggregate query".into())}
        if crate::validate::binding(){return Ok(Relation{fields,rows:vec![]})}
        let mut envs=vec![];
        for values in input.rows{
            let mut env=Env{
                fields:input.fields.clone(),values,outer:Some(Box::new(outer.clone()))
            }
            ;
            self.add_aliases(&items,&mut env,None,ctes,depth)?;
            if s.filter.as_ref().map(|e|self.eval(e,&env,None,ctes,depth).map(|v|v.truth()==Some(true))).transpose()?.unwrap_or(true){
                envs.push(env)
            }
        }
        let aggregate=!s.group.is_empty()||s.items.iter().any(|i|has_aggregate(&i.expr))||s.having.as_ref().is_some_and(has_aggregate)||order.iter().any(|o|has_aggregate(&o.expr));
        if s.having.is_some()&&!aggregate{
            return Err("HAVING clause on a non-aggregate query".into())
        }
        let mut groups:Vec<Vec<Env>>=vec![];
        if aggregate{
            if s.group.is_empty(){
                groups.push(envs.clone())
            }
            else{
                let mut keys:Vec<Vec<Value>>=vec![];
                for env in &envs{
                    let vals=s.group.iter().map(|e|{
                        if let Expr::Lit(Value::Integer(i))=e{
                            if *i>0&&(*i as usize)<=items.len(){
                                return self.eval(&items[*i as usize-1].expr,env,None,ctes,depth)
                            }
                        }
                        self.eval(e,env,None,ctes,depth)
                    }
                    ).collect::<Res<Vec<_>>>()?;
                    let ix=keys.iter().position(|k|k.iter().zip(&vals).zip(&s.group).all(|((a,b),e)|compare(a,b,&self.meta(e,env).1)==Ordering::Equal));
                    if let Some(i)=ix{
                        groups[i].push(env.clone())
                    }
                    else{
                        keys.push(vals);
                        groups.push(vec![env.clone()])
                    }
                }
            }
        }
        else{
            groups=envs.iter().map(|e|vec![e.clone()]).collect()
        }
        let mut prepared=vec![];
        for g in &groups{
            let mut env=g.first().cloned().unwrap_or(template.clone());
            if aggregate {
                if let Some((arg,ismax))=single_minmax(&items){
                    let mut best:Option<Value>=None;
                    for e in g{
                        let v=self.eval(&arg,e,None,ctes,depth)?;
                        if v.null(){
                            continue
                        }
                        if best.as_ref().is_none_or(|b|(compare(&v,b,&self.meta(&arg,e).1)==Ordering::Greater)==ismax){
                            best=Some(v);
                            env=e.clone()
                        }
                    }
                }
            }
            let group=if aggregate{
                Some(g.as_slice())
            }
            else{
                None
            }
            ;
            self.add_aliases(&items,&mut env,group,ctes,depth)?;
            if let Some(h)=&s.having{
                if self.eval(h,&env,group,ctes,depth)?.truth()!=Some(true){
                    continue
                }
            }
            prepared.push(WindowInput{
                env,group:if aggregate{
                    Some(g.clone())
                }
                else{
                    None
                }
            }
            );
        }
        let mut out=vec![];
        for (position,input)in prepared.iter().enumerate(){
            let env=&input.env;
            let group=input.group.as_deref();
            let row=items.iter().map(|i|self.eval_window_expr(&i.expr,env,group,ctes,depth,&prepared,position,&s.windows)).collect::<Res<Vec<_>>>()?;
            let mut evaluated_order=order.to_vec();
            for o in &mut evaluated_order{
                let positional=matches!(o.expr,Expr::Lit(Value::Integer(_)));
                o.expr=self.replace_windows(&o.expr,env,group,ctes,depth,&prepared,position,&s.windows)?;
                if !positional&&matches!(o.expr,Expr::Lit(Value::Integer(_))){
                    o.expr=Expr::Unary("+".into(),Box::new(o.expr.clone()));
                }
            }
            let keys=self.order_keys(&evaluated_order,&fields,&row,&env,group,ctes,depth)?;
            out.push((row,keys));
        }
        if s.distinct{
            let mut seen:Vec<Vec<Value>>=vec![];
            out.retain(|(r,_)|if seen.iter().any(|x|rows_equal(x,r,&fields)){
                false
            }
            else{
                seen.push(r.clone());
                true
            }
            )
        }
        let mut sort_order=order.to_vec();
        for o in &mut sort_order{
            if explicit_collate(&o.expr).is_none(){
                let coll=if let Expr::Lit(Value::Integer(i))=&o.expr{
                    fields.get(i.saturating_sub(1) as usize).map(|f|f.collate.clone()).unwrap_or("BINARY".into())
                }
                else if let Expr::Col(n)=&o.expr{
                    fields.iter().find(|f|n.len()==1&&f.name.eq_ignore_ascii_case(&n[0])).map(|f|f.collate.clone()).unwrap_or_else(||self.meta(&o.expr,&template).1)
                }
                else{
                    self.meta(&o.expr,&template).1
                }
                ;
                o.expr=Expr::Collate(Box::new(o.expr.clone()),coll)
            }
        }
        sort_decorated(&mut out,&sort_order,&fields);
        Ok(Relation{
            fields,rows:out.into_iter().map(|r|r.0).collect()
        }
        )
    }
    fn add_aliases(&self,items:&[Item],env:&mut Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize)->Res<()>{
        for i in items{
            if let Some(n)=&i.alias{
                if env.fields.iter().any(|f|f.name.eq_ignore_ascii_case(n)){
                    continue
                }
                if has_window(&i.expr)||has_aggregate(&i.expr)&&group.is_none(){
                    continue
                }
                let v=self.eval(&i.expr,env,group,ctes,depth)?;
                let (a,c)=self.meta(&i.expr,env);
                env.fields.push(Field{
                    name:n.clone(),table:String::new(),affinity:a,collate:c,hidden:true
                }
                );
                env.values.push(v)
            }
        }
        Ok(())
    }
    fn order_keys(&self,order:&[Order],fields:&[Field],row:&[Value],env:&Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize)->Res<Vec<Value>>{
        order.iter().map(|o|{
            if let Expr::Lit(Value::Integer(i))=&o.expr{
                if *i<1||*i as usize>row.len(){
                    return Err("ORDER BY term out of range".into())
                }
                return Ok(row[*i as usize-1].clone())
            }
            if let Expr::Dqs(n)=&o.expr { if let Some(i)=fields.iter().position(|f|f.name.eq_ignore_ascii_case(n)) { return Ok(row[i].clone()); } }
            if let Expr::Col(n)=&o.expr{
                if n.len()==1{
                    if let Some(i)=fields.iter().position(|f|f.name.eq_ignore_ascii_case(&n[0])){
                        return Ok(row[i].clone())
                    }
                }
            }
            self.eval(&o.expr,env,group,ctes,depth)
        }
        ).collect()
    }
    pub fn table_relation(&self,t:&Table,alias:&str)->Relation{
        let mut fields=t.def.cols.iter().map(|c|Field{
            name:c.name.clone(),table:alias.into(),affinity:if t.def.strict&&c.typ.eq_ignore_ascii_case("ANY"){
                Affinity::Blob
            }
            else{
                affinity(&c.typ)
            }
            ,collate:c.collate.clone(),hidden:false
        }
        ).collect::<Vec<_>>();
        let mut hidden=vec![];
        if !t.def.without_rowid{
            for n in ["rowid","_rowid_","oid"]{
                if !fields.iter().any(|f|f.name.eq_ignore_ascii_case(n)){
                    let mut f=Field::new(n);
                    f.table=alias.into();
                    f.affinity=Affinity::Integer;
                    f.hidden=true;
                    fields.push(f);
                    hidden.push(n);
                }
            }
        }
        let mut rows=t.rows.clone();
        if !t.def.without_rowid{
            rows.sort_by_key(|r|r.id)
        }
        else{
            rows.sort_by(|a,b|{
                if let Some(pk)=t.def.keys.iter().find(|k|k.primary) {
                    for order in &pk.cols {
                        if let Some(i)=crate::schema::column_name(&order.expr).and_then(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n))) {
                            let coll=explicit_collate(&order.expr).unwrap_or(t.def.cols[i].collate.clone());
                            let cmp=compare(&a.values[i],&b.values[i],&coll);
                            if cmp!=Ordering::Equal{return if order.desc{cmp.reverse()}else{cmp}}
                        }
                    }
                } else {
                    for c in 1..=t.def.cols.len(){
                        if let Some(i)=t.def.cols.iter().position(|x|x.primary==c){
                            let o=compare(&a.values[i],&b.values[i],&t.def.cols[i].collate);
                            if o!=Ordering::Equal{return o}
                        }
                    }
                }
                Ordering::Equal
            }
            )
        }
        Relation{
            fields,rows:rows.into_iter().map(|r|{
                let mut v=r.values.into_iter().map(Value::into_plain).collect::<Vec<_>>();
                v.extend(hidden.iter().map(|_|Value::Integer(r.id)));
                v
            }
            ).collect()
        }
    }
    pub fn source(&self,s:&Source,outer:&Env,ctes:&Ctes,depth:usize)->Res<Relation>{
        let mut result=self.source_impl(s,outer,ctes,depth)?;
        if crate::validate::binding(){result.rows.clear();}
        Ok(result)
    }
    fn source_impl(&self,s:&Source,outer:&Env,ctes:&Ctes,depth:usize)->Res<Relation>{
        match s{
            Source::Indexed(source,index)=>{
                if let Source::Table(n,..)=source.as_ref(){self.check_index(n,index)?;}
                self.source(source,outer,ctes,depth)
            },
            Source::Table(n,alias,args)=>{
                for arg in args {self.validate_expr(arg,outer,ctes,depth)?;} 
                let k=if ctes.contains_key(&key(n)){
                    key(n)
                }
                else{
                    self.resolve_relation_key(n)
                }
                ;
                if let Some((schema,name))=n.split_once('.') {
                    if schema.eq_ignore_ascii_case("main")||schema.eq_ignore_ascii_case("temp"){
                        let temp=schema.eq_ignore_ascii_case("temp");
                        if ["sqlite_master","sqlite_schema"].contains(&key(name).as_str()){
                            return Ok(self.schema_relation(temp))
                        }
                        if name.eq_ignore_ascii_case("sqlite_sequence"){
                            return self.sequence_relation(temp)
                        }
                        let stored=if temp{
                            format!("temp.{}",key(name))
                        }
                        else{
                            key(name)
                        }
                        ;
                        let mut r=if let Some(t)=self.db.tables.get(&stored){
                            self.table_relation(t,alias.as_deref().unwrap_or(name))
                        }
                        else if let Some(v)=self.db.views.get(&stored){
                            let mut query=v.query.clone();
                            if !v.name.starts_with("temp."){
                                crate::schema::qualify_main_view(&mut query);
                            }
                            let mut r=self.query(&query,outer,ctes,depth+1)?;
                            rename_cte(&mut r,&v.cols)?;
                            r
                        }
                        else{
                            return Err(format!("no such table: {}",n))
                        }
                        ;
                        for f in &mut r.fields{
                            f.table=alias.clone().unwrap_or(name.into())
                        }
                        return Ok(r)
                    }
                    if let Some(a)=self.attachments.get(&key(schema)){
                        let mut r=a.source(&Source::Table(name.into(),alias.clone(),args.clone()),outer,ctes,depth+1)?;
                        for f in &mut r.fields{
                            f.table=alias.clone().unwrap_or(name.into())
                        }
                        return Ok(r)
                    }
                }
                if !ctes.contains_key(&k)&&!self.scoped_ctes.contains_key(&k)&&!self.db.tables.contains_key(&k)&&!self.db.views.contains_key(&k){
                    for name in &self.attachment_order{
                        let a=&self.attachments[name];
                        if a.db.tables.contains_key(&k)||a.db.views.contains_key(&k){
                            return a.source(s,outer,ctes,depth+1)
                        }
                    }
                }
                let mut r=if let Some(r)=ctes.get(&k){
                    r.clone()
                }
                else if let Some(t)=self.db.tables.get(&k){
                    self.table_relation(t,n)
                }
                else if let Some(v)=self.db.views.get(&k){
                    let mut query=v.query.clone();
                    if !v.name.starts_with("temp."){
                        crate::schema::qualify_main_view(&mut query);
                    }
                    let mut r=self.query(&query,outer,ctes,depth+1)?;
                    rename_cte(&mut r,&v.cols)?;
                    unique_fields(&mut r.fields);
                    r
                }
                else if ["sqlite_master","sqlite_schema","sqlite_temp_master","sqlite_temp_schema"].contains(&k.as_str()){
                    self.schema_relation(k.starts_with("sqlite_temp_"))
                }
                else if k=="sqlite_sequence"{
                    self.sequence_relation(self.db.temp_sequence_exists)?
                }
                else if ["json_each","json_tree","jsonb_each","jsonb_tree"].contains(&k.as_str()){
                    let a=args.iter().map(|e|self.eval(e,outer,None,ctes,depth)).collect::<Res<Vec<_>>>()?;
                    crate::json::table(&k,&a)?
                }
                else if k=="generate_series"{
                    if crate::validate::binding(){for arg in args{self.validate_expr(arg,outer,ctes,depth)?;}return Ok(Relation::simple(&["value"],vec![]))}
                    let a=args.iter().map(|e|self.eval(e,outer,None,ctes,depth)).collect::<Res<Vec<_>>>()?;
                    let start=a.first().map(Value::int).unwrap_or(0);
                    let stop=a.get(1).map(Value::int).unwrap_or(4294967295);
                    let step=a.get(2).map(Value::int).unwrap_or(1);
                    let step=if step==0{
                        1
                    }
                    else{
                        step
                    }
                    ;
                    let mut rows=vec![];
                    let mut x=start;
                    while (step>0&&x<=stop)||(step<0&&x>=stop){
                        if rows.len()>100000{
                            return Err("series too large".into())
                        }
                        rows.push(vec![Value::Integer(x)]);
                        if let Some(v)=x.checked_add(step){
                            x=v
                        }
                        else{
                            break
                        }
                    }
                    Relation::simple(&["value"],rows)
                }
                else if k.starts_with("pragma_"){
                    let a=args.first().map(|e|self.eval(e,outer,None,ctes,depth)).transpose()?;
                    self.pragma_read(&k[7..],a.as_ref())?
                }
                else{
                    return Err(format!("no such table: {}",n))
                }
                ;
                for f in &mut r.fields{
                    f.table=alias.clone().unwrap_or_else(||n.clone())
                }
                Ok(r)
            }
            ,Source::Query(q,alias)=>{
                let mut r=self.query(q,outer,ctes,depth+1)?;
                unique_fields(&mut r.fields);
                for f in &mut r.fields{
                    f.table=alias.clone().unwrap_or_default()
                }
                Ok(r)
            }
            ,Source::Join(a,b,kind,on,using,natural)=>{
                let l=self.source(a,outer,ctes,depth)?;
                if let Source::Table(_,_,args)=b.as_ref(){
                    if !args.is_empty(){
                        let template=Env{
                            fields:l.fields.clone(),values:vec![Value::Null;
                            l.fields.len()],outer:Some(Box::new(outer.clone()))
                        }
                        ;
                        let rr=self.bind_source(b,&template,ctes,depth)?;
                        let mut fields=l.fields.clone();
                        fields.extend(rr.fields);
                        let on_env=Env{fields:fields.clone(),values:vec![Value::Null;fields.len()],outer:Some(Box::new(outer.clone()))};
                        if let Some(on)=on {self.validate_row_expr(on,&on_env)?;}
                        let mut rows=vec![];
                        for lv in &l.rows{
                            let left=Env{
                                fields:l.fields.clone(),values:lv.clone(),outer:Some(Box::new(outer.clone()))
                            }
                            ;
                            let r=self.source(b,&left,ctes,depth)?;
                            let mut matched=false;
                            for rv in r.rows{
                                let mut values=lv.clone();
                                values.extend(rv);
                                let env=Env{
                                    fields:fields.clone(),values:values.clone(),outer:Some(Box::new(outer.clone()))
                                }
                                ;
                                if on.as_ref().map(|e|self.eval(e,&env,None,ctes,depth).map(|v|v.truth()==Some(true))).transpose()?.unwrap_or(true){
                                    matched=true;
                                    rows.push(values)
                                }
                            }
                            if !matched&&kind=="LEFT"{
                                let mut values=lv.clone();
                                values.extend(vec![Value::Null;
                                fields.len()-l.fields.len()]);
                                rows.push(values)
                            }
                        }
                        return Ok(Relation{
                            fields,rows
                        }
                        )
                    }
                }
                let r=self.source(b,outer,ctes,depth)?;
                let mut names=using.clone();
                if *natural{
                    names=l.fields.iter().filter(|f|!f.hidden&&r.fields.iter().any(|g|!g.hidden&&f.name.eq_ignore_ascii_case(&g.name))).map(|f|f.name.clone()).collect()
                }
                let mut pairs=vec![];
                for n in names{
                    let i=l.fields.iter().position(|f|f.name.eq_ignore_ascii_case(&n)).ok_or(format!("cannot join using column {}",n))?;
                    let j=r.fields.iter().position(|f|f.name.eq_ignore_ascii_case(&n)).ok_or(format!("cannot join using column {}",n))?;
                    pairs.push((i,j));
                }
                let mut fields=l.fields.clone();
                fields.extend(r.fields.clone());
                for(_,j)in &pairs{
                    fields[l.fields.len()+j].hidden=true;
                }
                let on_env=Env{fields:fields.clone(),values:vec![Value::Null;fields.len()],outer:Some(Box::new(outer.clone()))};
                if let Some(on)=on {self.validate_expr(on,&on_env,ctes,depth)?;if has_aggregate(on)||has_window(on){return Err("misuse of aggregate in JOIN".into())}}
                let mut rows=vec![];
                let mut matched=vec![false;
                r.rows.len()];
                for lv in &l.rows{
                    let mut any=false;
                    for (j,rv)in r.rows.iter().enumerate(){
                        let mut vals=lv.clone();
                        vals.extend(rv.clone());
                        let env=Env{
                            fields:fields.clone(),values:vals.clone(),outer:Some(Box::new(outer.clone()))
                        }
                        ;
                        let mut pass=true;
                        for(i,k)in &pairs{
                            let a=&lv[*i];
                            let b=&rv[*k];
                            if a.null()||b.null()||compare(a,&b.apply(l.fields[*i].affinity),&l.fields[*i].collate)!=Ordering::Equal{
                                pass=false;
                                break
                            }
                        }
                        if pass{
                            if let Some(e)=on{
                                pass=self.eval(e,&env,None,ctes,depth)?.truth()==Some(true)
                            }
                        }
                        if pass{
                            any=true;
                            matched[j]=true;
                            rows.push(vals)
                        }
                    }
                    if !any&&(kind=="LEFT"||kind=="FULL"){
                        let mut vals=lv.clone();
                        vals.extend(vec![Value::Null;
                        r.fields.len()]);
                        rows.push(vals)
                    }
                }
                if kind=="RIGHT"||kind=="FULL"{
                    for(j,rv)in r.rows.iter().enumerate(){
                        if !matched[j]{
                            let mut vals=vec![Value::Null;
                            l.fields.len()];
                            vals.extend(rv.clone());
                            rows.push(vals)
                        }
                    }
                }
                if kind=="RIGHT"||kind=="FULL"{
                    let mut pairs=pairs.clone();
                    pairs.sort_by_key(|p|std::cmp::Reverse(p.0));
                    let original=fields.clone();
                    for(i,_)in &pairs{
                        fields[*i].hidden=true;
                    }
                    for row in &mut rows{
                        let additions=pairs.iter().map(|(i,j)|(*i,if row[*i].null(){
                            row[l.fields.len()+j].clone()
                        }
                        else{
                            row[*i].clone()
                        }
                        )).collect::<Vec<_>>();
                        for(i,v)in additions{
                            row.insert(i,v);
                        }
                    }
                    for(i,_)in pairs{
                        let mut f=original[i].clone();
                        f.table=String::new();
                        f.hidden=false;
                        fields.insert(i,f);
                    }
                }
                Ok(Relation{
                    fields,rows
                }
                )
            }
        }
    }
    pub fn meta(&self,e:&Expr,env:&Env)->(Affinity,String){
        match e{
            Expr::Dqs(n)=>self.meta(&Expr::Col(vec![n.clone()]),env),Expr::Col(n)=>env.get(n).ok().flatten().map(|(_,f)|(f.affinity,f.collate)).unwrap_or((Affinity::None,"BINARY".into())),Expr::Cast(e,t)=>(affinity(t),self.meta(e,env).1),Expr::Unary(op,e) if op=="+"=>(Affinity::None,self.meta(e,env).1),Expr::Collate(e,c)=>(self.meta(e,env).0,c.clone()),_ =>(Affinity::None,"BINARY".into())
        }
    }
    fn comparison(&self,a:&Expr,b:&Expr,va:&Value,vb:&Value,env:&Env)->Ordering{
        let (aa,_)=self.meta(a,env);
        let (ba,_)=self.meta(b,env);
        let coll=explicit_collate(a).or_else(||explicit_collate(b)).or_else(||self.column_collation(a,env)).or_else(||self.column_collation(b,env)).unwrap_or("BINARY".into());
        let mut x=va.clone();
        let mut y=vb.clone();
        if matches!(aa,Affinity::Integer|Affinity::Real|Affinity::Numeric)&&!matches!(ba,Affinity::Integer|Affinity::Real|Affinity::Numeric){
            y=y.apply(Affinity::Numeric)
        }
        else if matches!(ba,Affinity::Integer|Affinity::Real|Affinity::Numeric)&&!matches!(aa,Affinity::Integer|Affinity::Real|Affinity::Numeric){
            x=x.apply(Affinity::Numeric)
        }
        else if aa==Affinity::Text&&ba==Affinity::None{
            y=y.apply(Affinity::Text)
        }
        else if ba==Affinity::Text&&aa==Affinity::None{
            x=x.apply(Affinity::Text)
        }
        compare(&x,&y,&coll)
    }
    pub fn eval(&self,e:&Expr,env:&Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize)->Res<Value>{
        if crate::validate::binding(){return Ok(Value::Null)}
        if depth>150{
            return Err("expression recursion limit exceeded".into())
        }
        use Expr::*;
        match e{
            Dqs(n)=>Ok(env.get(&[n.clone()])?.map(|(v,_)|v).unwrap_or_else(||Value::Text(n.clone()))),Tuple(_)=>Err("row value misused".into()),RowAccess(e,i)=>{
                let r=self.eval_row(e,env,group,ctes,depth+1)?;
                r.get(*i).cloned().ok_or("row value column count mismatch".into())
            }
            ,Lit(v)=>Ok(v.clone()),Col(n)=>{
                if let Some((v,_))=env.get(n)?{
                    return Ok(v)
                }
                if let Some(t)=&self.trigger_env{
                    if let Some((v,_))=t.get(n)?{
                        return Ok(v)
                    }
                }
                if n.len()==1{
                    if n[0].eq_ignore_ascii_case("TRUE"){
                        return Ok(Value::Integer(1))
                    }
                    if n[0].eq_ignore_ascii_case("FALSE"){
                        return Ok(Value::Integer(0))
                    }
                    if ["CURRENT_TIMESTAMP","CURRENT_DATE","CURRENT_TIME"].iter().any(|x|n[0].eq_ignore_ascii_case(x)){
                        return crate::datetime::current(&n[0])
                    }
                }
                Err(format!("no such column: {}",n.join(".")))
            }
            ,Star(_)=>Err("misuse of *".into()),Collate(e,_)=>self.eval(e,env,group,ctes,depth+1),Cast(e,t)=>Ok(self.eval(e,env,group,ctes,depth+1)?.cast(t)),
            Unary(op,e)=>{
                let v=self.eval(e,env,group,ctes,depth+1)?;
                Ok(match op.as_str(){
                    "+"=>v,"NOT"=>v.truth().map(|b|Value::boolean(!b)).unwrap_or(Value::Null),"~"=>if v.null(){
                        Value::Null
                    }
                    else{
                        Value::Integer(!v.int())
                    }
                    ,"-"=>match v.number(){
                        Value::Null=>Value::Null,Value::Integer(i)=>i.checked_neg().map(Value::Integer).unwrap_or(Value::Real(-(i as f64))),n=>real(-n.float())
                    }
                    ,_=>Value::Null
                }
                )
            }
            ,
            Binary(op,a,b)=>{
                if ["=","==","!=","<>","<",">","<=",">="].contains(&op.as_str())&&(matches!(a.as_ref(),Tuple(_)|Subquery(_))||matches!(b.as_ref(),Tuple(_)|Subquery(_))){
                    return self.row_comparison(op,a,b,env,group,ctes,depth+1)
                }
                let va=self.eval(a,env,group,ctes,depth+1)?;
                let vb=self.eval(b,env,group,ctes,depth+1)?;
                if op=="AND"||op=="OR"{
                    let(a,b)=(va.truth(),vb.truth());
                    return Ok(if op=="AND"{
                        if a==Some(false)||b==Some(false){
                            Value::Integer(0)
                        }
                        else if a.is_none()||b.is_none(){
                            Value::Null
                        }
                        else{
                            Value::Integer(1)
                        }
                    }
                    else if a==Some(true)||b==Some(true){
                        Value::Integer(1)
                    }
                    else if a.is_none()||b.is_none(){
                        Value::Null
                    }
                    else{
                        Value::Integer(0)
                    }
                    )
                }
                if va.null()||vb.null(){
                    return Ok(Value::Null)
                }
                if ["=","==","!=","<>","<",">","<=",">="].contains(&op.as_str()){
                    let c=self.comparison(a,b,&va,&vb,env);
                    return Ok(Value::boolean(match op.as_str(){
                        "="|"=="=>c==Ordering::Equal,"!="|"<>"=>c!=Ordering::Equal,"<"=>c==Ordering::Less,">"=>c==Ordering::Greater,"<="=>c!=Ordering::Greater,_=>c!=Ordering::Less
                    }
                    ))
                }
                if op=="||"{
                    return Ok(Value::Text(va.text()+&vb.text()))
                }
                if op=="->"||op=="->>"{
                    return crate::json::arrow(&va,&vb,op=="->>")
                }
                Ok(arithmetic(op,&va,&vb))
            }
            ,
            Is(a,b,not)=>{
                if matches!(a.as_ref(),Tuple(_)|Subquery(_))||matches!(b.as_ref(),Tuple(_)|Subquery(_)){
                    return self.row_comparison(if *not{
                        "IS NOT"
                    }
                    else{
                        "IS"
                    }
                    ,a,b,env,group,ctes,depth+1)
                }
                let va=self.eval(a,env,group,ctes,depth+1)?;
                let vb=self.eval(b,env,group,ctes,depth+1)?;
                let yes=if let Expr::Col(n)=b.as_ref(){
                    if n.len()==1&&n[0].eq_ignore_ascii_case("TRUE")&&env.get(n)?.is_none(){
                        va.truth()==Some(true)
                    }
                    else if n.len()==1&&n[0].eq_ignore_ascii_case("FALSE")&&env.get(n)?.is_none(){
                        va.truth()==Some(false)
                    }
                    else{
                        self.comparison(a,b,&va,&vb,env)==Ordering::Equal
                    }
                }
                else{
                    self.comparison(a,b,&va,&vb,env)==Ordering::Equal
                }
                ;
                Ok(Value::boolean(yes!=*not))
            }
            ,
            Between(a,b,c,not)=>{
                let mut meta_env=Env{outer:Some(Box::new(env.clone())),..Default::default()};
                let(x,ax)=self.annotated_row(a,env,group,ctes,depth+1,&mut meta_env)?;
                let(y,bx)=self.annotated_row(b,env,group,ctes,depth+1,&mut meta_env)?;
                let(z,cx)=self.annotated_row(c,env,group,ctes,depth+1,&mut meta_env)?;
                let lo=self.compare_row_values(">=",&x,&y,&ax,&bx,&meta_env)?.truth();
                let hi=self.compare_row_values("<=",&x,&z,&ax,&cx,&meta_env)?.truth();
                let result=if lo==Some(false)||hi==Some(false){Some(false)}else if lo.is_none()||hi.is_none(){None}else{Some(true)};
                Ok(result.map(|b|Value::boolean(b!=*not)).unwrap_or(Value::Null))
            }
            ,
            In(e,es,q,not)=>{
                if matches!(e.as_ref(),Tuple(_)|Subquery(_))&&q.is_some(){
                    let mut meta_env=Env{outer:Some(Box::new(env.clone())),..Default::default()};
                    let(left,ax)=self.annotated_row(e,env,group,ctes,depth+1,&mut meta_env)?;
                    let right=self.query(q.as_ref().unwrap(),env,ctes,depth+1)?;
                    if left.len()!=right.fields.len(){return Err("row value column count mismatch".into())}
                    let bx=append_row_fields(&mut meta_env,&right.fields);
                    let mut null=false;
                    for row in right.rows {
                        let value=self.compare_row_values("=",&left,&row,&ax,&bx,&meta_env)?;
                        if value.truth()==Some(true){return Ok(Value::boolean(!*not))}
                        null|=value.null();
                    }
                    return Ok(if null{Value::Null}else{Value::boolean(*not)})
                }
                let v=self.eval(e,env,group,ctes,depth+1)?;
                let mut rightmeta=None;
                let vals=if let Some(q)=q{
                    let r=self.query(q,env,ctes,depth+1)?;
                    if r.fields.len()!=1{
                        return Err("sub-select returns more than one column".into())
                    }
                    rightmeta=r.fields.first().cloned();
                    r.rows.into_iter().map(|r|r[0].clone()).collect()
                }
                else{
                    es.iter().map(|x|self.eval(x,env,group,ctes,depth+1)).collect::<Res<Vec<_>>>()?
                }
                ;
                if vals.is_empty(){
                    return Ok(Value::boolean(*not))
                }
                let mut null=v.null();
                for x in vals{
                    if x.null(){
                        null=true
                    }
                    else if !v.null()&&{
                        if let Some(f)=&rightmeta{
                            let mut env=env.clone();
                            let mut f=f.clone();
                            f.name="__in_rhs".into();
                            f.table="__internal".into();
                            env.fields.push(f);
                            env.values.push(x.clone());
                            self.comparison(e,&Expr::Col(vec!["__internal".into(),"__in_rhs".into()]),&v,&x,&env)
                        }
                        else{
                            self.comparison(e,&Expr::Lit(x.clone()),&v,&x,env)
                        }
                    }
                    ==Ordering::Equal{
                        return Ok(Value::boolean(!*not))
                    }
                }
                Ok(if null{
                    Value::Null
                }
                else{
                    Value::boolean(*not)
                }
                )
            }
            ,
            Case(base,arms,other)=>{
                if base.as_ref().is_some_and(|e|matches!(e.as_ref(),Expr::Tuple(_))){
                    let e=base.as_ref().unwrap();
                    for(w,t)in arms{
                        if self.row_comparison("=",e,w,env,group,ctes,depth+1)?.truth()==Some(true){
                            return self.eval(t,env,group,ctes,depth+1)
                        }
                    }
                    return other.as_ref().map(|e|self.eval(e,env,group,ctes,depth+1)).unwrap_or(Ok(Value::Null))
                }
                let value=base.as_ref().map(|b|self.eval(b,env,group,ctes,depth+1)).transpose()?;
                for(w,t)in arms{
                    let v=self.eval(w,env,group,ctes,depth+1)?;
                    let matched=if let Some(b)=&value{
                        !b.null()&&!v.null()&&self.comparison(base.as_ref().unwrap(),w,b,&v,env)==Ordering::Equal
                    }
                    else{
                        v.truth()==Some(true)
                    }
                    ;
                    if matched{
                        return self.eval(t,env,group,ctes,depth+1)
                    }
                }
                other.as_ref().map(|e|self.eval(e,env,group,ctes,depth+1)).unwrap_or(Ok(Value::Null))
            }
            ,
            Subquery(q)=>{
                let r=self.query(q,env,ctes,depth+1)?;
                if r.fields.len()!=1{
                    return Err("sub-select returns more than one column".into())
                }
                Ok(r.rows.first().and_then(|r|r.first()).cloned().unwrap_or(Value::Null))
            }
            ,Exists(q)=>Ok(Value::boolean(!self.query(q,env,ctes,depth+1)?.rows.is_empty())),
            Call{
                name,args,distinct,filter,order,over
            }
            =>{
                if over.is_some(){
                    return Err("misuse of window function".into())
                }
                let n=key(name);
                if n=="raise"{
                    if self.trigger_env.is_none(){
                        return Err("RAISE() may only be used within a trigger-program".into())
                    }
                    let action=match args.first(){
                        Some(Expr::Col(n))=>n[0].to_uppercase(),_=>return Err("invalid RAISE action".into())
                    }
                    ;
                    if action=="IGNORE"{
                        return Err("TRIGGER_IGNORE".into())
                    }
                    let msg=args.get(1).map(|e|self.eval(e,env,group,ctes,depth+1).map(|v|v.text())).transpose()?.unwrap_or_default();
                    return Err(if action=="ROLLBACK"||action=="FAIL"{
                        format!("{}:{}",action,msg)
                    }
                    else{
                        msg
                    }
                    )
                }
                if is_aggregate(name,args.len()){
                    return self.aggregate(name,args,*distinct,filter.as_deref(),order,group.ok_or("misuse of aggregate function")?,ctes,depth+1)
                }
                if n=="coalesce"||n=="ifnull"{
                    if args.len()<2||(n=="ifnull"&&args.len()!=2){
                        return Err("wrong number of arguments".into())
                    }
                    for a in args{
                        let v=self.eval(a,env,group,ctes,depth+1)?;
                        if !v.null(){
                            return Ok(v)
                        }
                    }
                    return Ok(Value::Null)
                }
                if n=="iif"||n=="if"{
                    if args.len()<2{
                        return Err("wrong number of arguments".into())
                    }
                    for pair in args.chunks(2){
                        if pair.len()==1{
                            return self.eval(&pair[0],env,group,ctes,depth+1)
                        }
                        if self.eval(&pair[0],env,group,ctes,depth+1)?.truth()==Some(true){
                            return self.eval(&pair[1],env,group,ctes,depth+1)
                        }
                    }
                    return Ok(Value::Null)
                }
                let vals=args.iter().map(|e|self.eval(e,env,group,ctes,depth+1)).collect::<Res<Vec<_>>>()?;
                if n=="nullif"&&vals.len()==2{
                    let coll=args.iter().find_map(|e|explicit_collate(e).or_else(||self.column_collation(e,env))).unwrap_or("BINARY".into());
                    return Ok(if compare(&vals[0],&vals[1],&coll)==Ordering::Equal{
                        Value::Null
                    }
                    else{
                        vals[0].clone()
                    }
                    )
                }
                if (n=="min"||n=="max")&&args.len()>1{
                    if vals.iter().any(Value::null){
                        return Ok(Value::Null)
                    }
                    let coll=args.iter().find_map(|e|explicit_collate(e).or_else(||self.column_collation(e,env))).unwrap_or("BINARY".into());
                    return Ok(vals.into_iter().reduce(|a,b|if (compare(&b,&a,&coll)==Ordering::Less)==(n=="min"){
                        b
                    }
                    else{
                        a
                    }
                    ).unwrap())
                }
                match n.as_str(){
                    "changes"=>Ok(Value::Integer(self.visible_changes())),"total_changes"=>Ok(Value::Integer(self.total_changes)),"last_insert_rowid"=>Ok(Value::Integer(self.last_id)),"date"|"time"|"datetime"|"julianday"|"unixepoch"|"strftime"|"timediff"=>{crate::schema::check_datetime_args(&n,&vals)?;crate::datetime::call(&n,&vals)},_ if n.starts_with("json")=>crate::json::call_typed(&n,&vals,&vals.iter().map(Value::is_json).collect::<Vec<_>>()),_=>functions::scalar(name,&vals,self.case_like)
                }
            }
        }
    }
    fn aggregate(&self,name:&str,args:&[Expr],distinct:bool,filter:Option<&Expr>,order:&[Order],group:&[Env],ctes:&Ctes,depth:usize)->Res<Value>{
        let n=key(name);
        let mut rows=vec![];
        for env in group{
            if let Some(f)=filter{
                if self.eval(f,env,None,ctes,depth)?.truth()!=Some(true){
                    continue
                }
            }
            let vals=args.iter().map(|e|if matches!(e,Expr::Star(_)){
                Ok(Value::Integer(1))
            }
            else{
                self.eval(e,env,None,ctes,depth)
            }
            ).collect::<Res<Vec<_>>>()?;
            let keys=order.iter().map(|o|self.eval(&o.expr,env,None,ctes,depth)).collect::<Res<Vec<_>>>()?;
            rows.push((vals,keys));
        }
        sort_decorated(&mut rows,order,&[]);
        let coll=args.first().map(|a|self.meta(a,group.first().unwrap_or(&Env::default())).1).unwrap_or("BINARY".into());
        if distinct{
            if args.len()!=1{
                return Err("DISTINCT aggregates must have exactly one argument".into())
            }
            let mut seen=vec![];
            rows.retain(|(r,_)|if seen.iter().any(|x|compare(x,&r[0],&coll)==Ordering::Equal){
                false
            }
            else{
                seen.push(r[0].clone());
                true
            }
            )
        }
        let values:Vec<Value>=rows.iter().filter_map(|(r,_)|r.first().filter(|v|!v.null()).cloned()).collect();
        match n.as_str(){
            "median"|"percentile"|"percentile_cont"|"percentile_disc"=>{
                if args.len()!=if n=="median"{
                    1
                }
                else{
                    2
                }
                {
                    return Err("wrong number of arguments".into())
                }
                let mut pct=None;
                let mut nums=vec![];
                for(row,_)in &rows{
                    let p=if n=="median"{
                        0.5
                    }
                    else{
                        let v=row[1].apply(Affinity::Numeric);
                        if !matches!(v,Value::Integer(_)|Value::Real(_)){
                            return Err("percentile argument must be numeric".into())
                        }
                        v.float()/if n=="percentile"{
                            100.0
                        }
                        else{
                            1.0
                        }
                    }
                    ;
                    if !(0.0..=1.0).contains(&p){
                        return Err("percentile argument out of range".into())
                    }
                    if pct.is_some_and(|x:f64|(x-p).abs()>0.001){
                        return Err("percentile argument must be the same for all input rows".into())
                    }
                    pct=Some(p);
                    if !row[0].null(){
                        if !matches!(row[0],Value::Integer(_)|Value::Real(_))||!row[0].float().is_finite(){
                            return Err("non-numeric input to percentile()".into())
                        }
                        nums.push(row[0].float())
                    }
                }
                if nums.is_empty(){
                    return Ok(Value::Null)
                }
                nums.sort_by(|a,b|a.partial_cmp(b).unwrap());
                let rank=pct.unwrap_or(0.5)*(nums.len()-1) as f64;
                let lo=rank.floor() as usize;
                let hi=rank.ceil() as usize;
                Ok(real(if n=="percentile_disc"{
                    nums[lo]
                }
                else{
                    nums[lo]+(nums[hi]-nums[lo])*rank.fract()
                }
                ))
            }
            ,"count"=>{
                if args.len()!=1{
                    return Err("wrong number of arguments to function count()".into())
                }
                Ok(Value::Integer(values.len() as i64))
            }
            ,"min"|"max"=>Ok(values.into_iter().reduce(|a,b|if (compare(&b,&a,&coll)==Ordering::Less)==(n=="min"){
                b
            }
            else{
                a
            }
            ).unwrap_or(Value::Null)),"sum"|"total"|"avg"=>{
                if args.len()!=1{
                    return Err("wrong number of arguments".into())
                }
                if values.is_empty(){
                    return Ok(if n=="total"{
                        Value::Real(0.0)
                    }
                    else{
                        Value::Null
                    }
                    )
                }
                let mut integer=0i64;
                let mut float=0.0;
                let mut allint=true;
                let mut overflow=false;
                for v in &values{
                    if matches!(v,Value::Blob(_))||matches!(v.apply(Affinity::Numeric),Value::Text(_)|Value::JsonText(_)){
                        allint=false
                    }
                    let x=v.number();
                    float+=x.float();
                    if let Value::Integer(i)=x{
                        if let Some(s)=integer.checked_add(i){
                            integer=s
                        }
                        else{
                            overflow=true
                        }
                    }
                    else{
                        allint=false
                    }
                }
                if n=="avg"{
                    Ok(real(float/values.len() as f64))
                }
                else if n=="total"||!allint{
                    Ok(real(float))
                }
                else if overflow{
                    Err("integer overflow".into())
                }
                else{
                    Ok(Value::Integer(integer))
                }
            }
            ,"group_concat"|"string_agg"=>{
                if args.is_empty()||args.len()>2||(n=="string_agg"&&args.len()!=2){
                    return Err("wrong number of arguments".into())
                }
                let mut out=None;
                for(r,_)in rows{
                    if r[0].null(){
                        continue
                    }
                    let sep=if r.len()==2{
                        r[1].text()
                    }
                    else{
                        ",".into()
                    }
                    ;
                    if let Some(s)=&mut out{
                        let s:&mut String=s;
                        s.push_str(&sep);
                        s.push_str(&r[0].text())
                    }
                    else{
                        out=Some(r[0].text())
                    }
                }
                Ok(out.map(Value::Text).unwrap_or(Value::Null))
            }
            ,"json_group_array"|"jsonb_group_array"=>{
                let a:Vec<_>=rows.iter().map(|(r,_)|crate::json::to_json_typed(&r[0],r[0].is_json())).collect();
                Ok(if n=="jsonb_group_array"{
                    Value::Blob(crate::jsonb::encode(&crate::json::J::Array(a)))
                }
                else{
                    Value::JsonText(serde_json::to_string(&a).unwrap())
                }
                )
            }
            ,"json_group_object"|"jsonb_group_object"=>{
                let mut obj=crate::json::Object::new();
                for(r,_)in rows{
                    if r.len()!=2{
                        return Err("wrong number of arguments".into())
                    }
                    obj.insert(r[0].text(),crate::json::to_json_typed(&r[1],r[1].is_json()));
                }
                Ok(if n=="jsonb_group_object"{
                    Value::Blob(crate::jsonb::encode(&crate::json::J::Object(obj)))
                }
                else{
                    Value::JsonText(crate::json::J::Object(obj).to_string())
                }
                )
            }
            ,_=>Err(format!("no such aggregate: {}",name))
        }
    }
}
pub fn expand_items(items:&[Item],fields:&[Field])->Res<Vec<Item>>{
    let mut out=vec![];
    for i in items{
        if let Expr::Star(t)=&i.expr{
            let matched:Vec<_>=fields.iter().filter(|f|(!f.hidden||(t.is_some()&&!["rowid","_rowid_","oid"].contains(&key(&f.name).as_str())))&&t.as_ref().is_none_or(|t|t.eq_ignore_ascii_case(&f.table))).collect();
            if matched.is_empty(){
                return Err("no tables specified or no such table for *".into())
            }
            for f in matched{
                out.push(Item{
                    expr:Expr::Col(if f.table.is_empty(){
                        vec![f.name.clone()]
                    }
                    else{
                        vec![f.table.clone(),f.name.clone()]
                    }
                    ),name:f.name.clone(),alias:None
                }
                )
            }
        }
        else{
            out.push(i.clone())
        }
    }
    Ok(out)
}
pub fn is_aggregate(n:&str,argc:usize)->bool{
    match key(n).as_str(){
        "count"|"sum"|"total"|"avg"|"group_concat"|"string_agg"|"json_group_array"|"json_group_object"|"jsonb_group_array"|"jsonb_group_object"|"median"|"percentile"|"percentile_cont"|"percentile_disc"=>true,"min"|"max"=>argc==1,_=>false
    }
}
pub fn has_aggregate(e:&Expr)->bool{
    match e{
        Expr::Call{
            name,args,over,..
        }
        =>(over.is_none()&&is_aggregate(name,args.len()))||args.iter().any(has_aggregate)||over.as_ref().is_some_and(|w|w.partition.iter().any(has_aggregate)||w.order.iter().any(|o|has_aggregate(&o.expr))),Expr::Unary(_,e)|Expr::Cast(e,_)|Expr::Collate(e,_)=>has_aggregate(e),Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>has_aggregate(a)||has_aggregate(b),Expr::Between(a,b,c,_)=>has_aggregate(a)||has_aggregate(b)||has_aggregate(c),Expr::Case(b,arms,o)=>b.as_ref().is_some_and(|e|has_aggregate(e))||arms.iter().any(|(a,b)|has_aggregate(a)||has_aggregate(b))||o.as_ref().is_some_and(|e|has_aggregate(e)),_=>false
    }
}
pub(crate) fn has_window(e:&Expr)->bool {
    match e {
        Expr::Call{over,args,..}=>over.is_some()||args.iter().any(has_window),
        Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>has_window(a)||has_window(b),
        Expr::Unary(_,e)|Expr::Cast(e,_)|Expr::Collate(e,_)|Expr::RowAccess(e,_)=>has_window(e),
        Expr::Case(b,arms,o)=>b.as_ref().is_some_and(|e|has_window(e))||arms.iter().any(|(a,b)|has_window(a)||has_window(b))||o.as_ref().is_some_and(|e|has_window(e)),
        Expr::Between(a,b,c,_)=>has_window(a)||has_window(b)||has_window(c),
        Expr::Tuple(es)=>es.iter().any(has_window),
        Expr::In(e,es,_,_)=>has_window(e)||es.iter().any(has_window),
        _=>false
    }
}

fn single_minmax(items:&[Item])->Option<(Expr,bool)>{
    let a:Vec<_>=items.iter().filter_map(|i|if let Expr::Call{
        name,args,over:None,..
    }
    =&i.expr{
        if args.len()==1&&(key(name)=="min"||key(name)=="max"){
            Some((args[0].clone(),key(name)=="max"))
        }
        else{
            None
        }
    }
    else{
        None
    }
    ).collect();
    if a.len()==1{
        Some(a[0].clone())
    }
    else{
        None
    }
}
pub(crate) fn explicit_collate(e:&Expr)->Option<String>{
    match e{
        Expr::Collate(_,c)=>Some(c.clone()),Expr::Unary(_,e)|Expr::Cast(e,_)=>explicit_collate(e),Expr::Binary(_,a,b)=>explicit_collate(a).or_else(||explicit_collate(b)),_=>None
    }
}
fn rename_cte(r:&mut Relation,cols:&[String])->Res<()>{
    if !cols.is_empty(){
        if cols.len()!=r.fields.len(){
            return Err("column count mismatch".into())
        }
        for(f,n)in r.fields.iter_mut().zip(cols){
            f.name=n.clone()
        }
    }
    Ok(())
}
pub fn rows_equal(a:&[Value],b:&[Value],fields:&[Field])->bool{
    a.len()==b.len()&&a.iter().zip(b).enumerate().all(|(i,(a,b))|compare(a,b,fields.get(i).map(|f|f.collate.as_str()).unwrap_or("BINARY"))==Ordering::Equal)
}
fn dedup(r:&mut Relation){
    let mut rows=vec![];
    for row in r.rows.drain(..){
        if !rows.iter().any(|x:&Vec<Value>|rows_equal(x,&row,&r.fields)){
            rows.push(row)
        }
    }
    r.rows=rows;
}
fn sort_decorated(rows:&mut [(Vec<Value>,Vec<Value>)],order:&[Order],fields:&[Field]){
    if order.is_empty(){
        return
    }
    rows.sort_by(|a,b|{
        for (i,o)in order.iter().enumerate(){
            let av=&a.1[i];
            let bv=&b.1[i];
            let coll=explicit_collate(&o.expr).unwrap_or_else(||if let Expr::Col(n)=&o.expr{
                fields.iter().find(|f|f.name.eq_ignore_ascii_case(n.last().unwrap())).map(|f|f.collate.clone()).unwrap_or("BINARY".into())
            }
            else{
                "BINARY".into()
            }
            );
            let c=if av.null()!=bv.null(){
                let first=o.nulls.unwrap_or(!o.desc);
                if av.null()==first{
                    Ordering::Less
                }
                else{
                    Ordering::Greater
                }
            }
            else{
                let c=compare(av,bv,&coll);
                if o.desc{
                    c.reverse()
                }
                else{
                    c
                }
            }
            ;
            if c!=Ordering::Equal{
                return c
            }
        }
        Ordering::Equal
    }
    )
}
pub(crate) fn integer_limit(v:&Value)->Res<i64>{
    match v.apply(Affinity::Numeric){
        Value::Integer(i)=>Ok(i),Value::Real(f)if f.trunc()==f=>Ok(f as i64),_=>Err("datatype mismatch".into())
    }
}
pub fn arithmetic(op:&str,a:&Value,b:&Value)->Value{
    use Value::*;
    let (x,y)=(a.number(),b.number());
    if op=="&"{
        return Integer(x.int()&y.int())
    }
    if op=="|"{
        return Integer(x.int()|y.int())
    }
    if op=="<<"||op==">>"{
        let shift=y.int();
        let left=(op=="<<")!=(shift<0);
        let shift=shift.unsigned_abs();
        return Integer(if shift>=64{
            if left||x.int()>=0{
                0
            }
            else{
                -1
            }
        }
        else if left{
            x.int().wrapping_shl(shift as u32)
        }
        else{
            x.int()>>(shift as u32)
        }
        )
    }
    if op=="%"{
        if y.int()==0{
            return Null
        }
        let v=x.int().checked_rem(y.int()).unwrap_or(0);
        return if matches!(x,Real(_))||matches!(y,Real(_)){
            Real(v as f64)
        }
        else{
            Integer(v)
        }
    }
    if op=="/"&&y.float()==0.0{
        return Null
    }
    if let (Integer(x),Integer(y))=(&x,&y){
        let r=match op{
            "+"=>x.checked_add(*y),"-"=>x.checked_sub(*y),"*"=>x.checked_mul(*y),"/"=>x.checked_div(*y),_=>None
        }
        ;
        if let Some(r)=r{
            return Integer(r)
        }
    }
    real(match op{
        "+"=>x.float()+y.float(),"-"=>x.float()-y.float(),"*"=>x.float()*y.float(),"/"=>x.float()/y.float(),_=>0.0
    }
    )
}
impl Engine{
    pub fn eval_row(&self,e:&Expr,env:&Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize)->Res<Vec<Value>>{
        match e{
            Expr::Tuple(es)=>es.iter().map(|e|self.eval(e,env,group,ctes,depth)).collect(),Expr::Subquery(q)=>{
                let r=self.query(q,env,ctes,depth)?;
                Ok(r.rows.first().cloned().unwrap_or(vec![Value::Null;
                r.fields.len()]))
            }
            ,_=>Ok(vec![self.eval(e,env,group,ctes,depth)?])
        }
    }
    fn annotated_row(&self,e:&Expr,env:&Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize,meta_env:&mut Env)->Res<(Vec<Value>,Vec<Expr>)> {
        match e {
            Expr::Subquery(q)=>{
                let r=self.query(q,env,ctes,depth)?;
                let values=r.rows.first().cloned().unwrap_or(vec![Value::Null;r.fields.len()]);
                let expressions=append_row_fields(meta_env,&r.fields);
                Ok((values,expressions))
            },
            Expr::Tuple(es)=>{
                let mut values=vec![];let mut expressions=vec![];
                for e in es {let(v,x)=self.annotated_row(e,env,group,ctes,depth+1,meta_env)?;if v.len()!=1{return Err("row value misused".into())}values.extend(v);expressions.extend(x);}
                Ok((values,expressions))
            },
            _=>Ok((vec![self.eval(e,env,group,ctes,depth)?],vec![e.clone()]))
        }
    }
    fn row_comparison(&self,op:&str,a:&Expr,b:&Expr,env:&Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize)->Res<Value>{
        let mut meta_env=Env{outer:Some(Box::new(env.clone())),..Default::default()};
        let(x,ax)=self.annotated_row(a,env,group,ctes,depth,&mut meta_env)?;
        let(y,bx)=self.annotated_row(b,env,group,ctes,depth,&mut meta_env)?;
        if ["IS","IS NOT"].contains(&op)&&x.len()==1&&y.len()==1 {
            if let Expr::Col(names)=b {
                if names.len()==1&&env.get(names)?.is_none()&&["true","false"].contains(&names[0].to_ascii_lowercase().as_str()) {
                    let expected=names[0].eq_ignore_ascii_case("true");
                    return Ok(Value::boolean((x[0].truth()==Some(expected))!=(op=="IS NOT")))
                }
            }
        }
        self.compare_row_values(op,&x,&y,&ax,&bx,&meta_env)
    }
    fn compare_row_values(&self,op:&str,x:&[Value],y:&[Value],ax:&[Expr],bx:&[Expr],env:&Env)->Res<Value> {
        if x.len()!=y.len(){return Err("row value column count mismatch".into())}
        let equality=["=","==","!=","<>","IS","IS NOT"].contains(&op);
        let is=op=="IS"||op=="IS NOT";
        let invert=["!=","<>","IS NOT"].contains(&op);
        let mut null=false;
        for i in 0..x.len(){
            if !is&&(x[i].null()||y[i].null()){
                if !equality{
                    return Ok(Value::Null)
                }
                null=true;
                continue
            }
            let c=self.comparison(&ax[i],&bx[i],&x[i],&y[i],env);
            if c!=Ordering::Equal{
                return Ok(Value::boolean(if equality{
                    invert
                }
                else if op=="<"||op=="<="{
                    c==Ordering::Less
                }
                else{
                    c==Ordering::Greater
                }
                ))
            }
        }
        Ok(if null{
            Value::Null
        }
        else{
            Value::boolean(if equality{
                !invert
            }
            else{
                op=="<="||op==">="
            }
            )
        }
        )
    }
}
fn append_row_fields(env:&mut Env,fields:&[Field])->Vec<Expr> {
    fields.iter().map(|f|{
        let mut f=f.clone();f.name=format!("field{}",env.fields.len());f.table="\0comparison".into();
        let expr=Expr::Col(vec![f.table.clone(),f.name.clone()]);env.fields.push(f);env.values.push(Value::Null);expr
    }).collect()
}

fn statement_writes(s:&Statement)->bool{
    match s{
        Statement::Vacuum(_,Some(_))|Statement::Attach(_,_)|Statement::Detach(_)|Statement::Query(_)|Statement::Explain(_,_)|Statement::Noop|Statement::Savepoint(_)|Statement::Commit|Statement::Rollback(_)|Statement::Release(_)=>false,Statement::Begin(m)=>m!="DEFERRED",Statement::Pragma(n,v)=>v.is_some()&&["user_version","application_id","schema_version"].contains(&n.rsplit('.').next().unwrap_or(n).to_ascii_lowercase().as_str()),Statement::IndexGuard(s,_)|Statement::With(_,_,s)=>statement_writes(s),_=>true
    }
}
fn unique_fields(fields:&mut [Field]){
    let mut names=vec![];
    for f in fields{
        let base=f.name.clone();
        let mut n=0;
        while names.iter().any(|s:&String|s.eq_ignore_ascii_case(&f.name)){
            n+=1;
            f.name=format!("{}:{}",base,n)
        }
        names.push(f.name.clone())
    }
}
fn select_references(s:&Select,name:&str)->bool{
    fn source(s:&Source,n:&str)->bool{
        match s{
            Source::Indexed(s,_)=>source(s,n),Source::Table(t,..)=>t.eq_ignore_ascii_case(n),Source::Join(a,b,..)=>source(a,n)||source(b,n),Source::Query(q,_)=>q.cores.iter().any(|s|select_references(s,n))
        }
    }
    s.from.as_ref().is_some_and(|s|source(s,name))
}
impl Engine{
    pub fn resolve_relation_key(&self,n:&str)->String{
        if let Some((schema,name))=n.split_once('.') {
            if schema.eq_ignore_ascii_case("main"){
                return key(name)
            }
            return key(n)
        }
        let temp=format!("temp.{}",key(n));
        if self.db.tables.contains_key(&temp)||self.db.views.contains_key(&temp){
            temp
        }
        else{
            key(n)
        }
    }
    pub fn resolve_object_key(&self,n:&str,kind:&str)->String {
        let exists=|k:&str|match kind {"trigger"=>self.db.triggers.contains_key(k),"index"=>self.db.indexes.contains_key(k),"table"=>self.db.tables.contains_key(k),"view"=>self.db.views.contains_key(k),_=>self.db.tables.contains_key(k)||self.db.views.contains_key(k)};
        if let Some((schema,name))=n.split_once('.') {return if schema.eq_ignore_ascii_case("main") {key(name)}else{key(n)}}
        let temp=format!("temp.{}",key(n));
        if exists(&temp){temp}else{key(n)}
    }
    pub fn resolve_index_key(&self,n:&str)->String{
        if let Some((schema,name))=n.split_once('.') {
            if schema.eq_ignore_ascii_case("main"){
                return key(name)
            }
            return key(n)
        }
        let temp=format!("temp.{}",key(n));
        if self.db.indexes.contains_key(&temp){
            temp
        }
        else{
            key(n)
        }
    }
}

impl Engine {
    pub fn visible_changes(&self)->i64 {
        if let Some((depth,value))=self.active_change_values.last() {
            if *depth==self.trigger_change_values.len() { return *value; }
        }
        self.trigger_change_values.last().copied().unwrap_or(self.changes)
    }
}

impl Engine {
    fn column_collation(&self,e:&Expr,env:&Env)->Option<String>{
        match e {
            Expr::Col(n)=>env.get(n).ok().flatten().map(|(_,f)|f.collate),
            Expr::Dqs(n)=>env.get(&[n.clone()]).ok().flatten().map(|(_,f)|f.collate),
            Expr::Cast(e,_)=>self.column_collation(e,env),
            Expr::Unary(op,e) if op=="+"=>self.column_collation(e,env),
            _=>None
        }
    }
}

impl Engine {
    pub fn check_index(&self,table:&str,index:&str)->Res<()> {
        if index.is_empty(){return Ok(())}
        if let Some((schema,name))=table.split_once('.') { if let Some(a)=self.attachments.get(&key(schema)){return a.check_index(name,index)} }
        let target=self.resolve_relation_key(table);
        let idx=self.db.indexes.get(&self.resolve_index_key(index)).ok_or(format!("no such index: {}",index))?;
        if !idx.table.eq_ignore_ascii_case(&target){return Err(format!("no such index: {}",index))}
        Ok(())
    }
}

impl Engine {
    pub fn schema_changed(&mut self,temp:bool) {if temp{self.db.temp_schema_version+=1;}else{self.db.schema_version+=1;}}
    fn writes_main(&self,stmt:&Statement,depth:usize)->bool {
        if depth>50{return true}
        if !statement_writes(stmt){return false}
        if let Some(temp)=self.sequence_target(stmt){return !temp}
        let mut routed=stmt.clone();
        if self.route_attachment(&mut routed).ok().flatten().is_some(){return false}
        match stmt {
            Statement::IndexGuard(s,_)|Statement::With(_,_,s)=>self.writes_main(s,depth+1),
            Statement::CreateTable(t,..)=>!t.temporary&&!key(&t.name).starts_with("temp."),
            Statement::CreateView(n,..)=>!key(n).starts_with("temp."),
            Statement::CreateIndex(n,t,..)=>!key(n).starts_with("temp.")&&!self.resolve_relation_key(t).starts_with("temp."),
            Statement::CreateTrigger(t,_)=>!t.temporary&&!key(&t.name).starts_with("temp.")&&!self.resolve_relation_key(&t.table).starts_with("temp."),
            Statement::Drop(kind,n,_)=>!self.resolve_object_key(n,&key(kind)).starts_with("temp."),
            Statement::Alter(n,..)=>!self.resolve_relation_key(n).starts_with("temp."),
            Statement::Pragma(n,_)=>!key(n).starts_with("temp."),
            Statement::Reindex(Some(n)) if n.to_ascii_lowercase().starts_with("temp.")=>false,
            Statement::Analyze(Some(n))=>!n.eq_ignore_ascii_case("temp")&&!self.resolve_relation_key(n).starts_with("temp."),
            Statement::Insert{table,..}|Statement::Update{table,..}|Statement::Delete{table,..}=>{
                let table=self.resolve_relation_key(table);
                if !table.starts_with("temp."){return true}
                self.db.triggers.values().filter(|t|t.table.eq_ignore_ascii_case(&table)).any(|t|t.body.iter().any(|s|self.writes_main(s,depth+1)))
            },
            _=>true
        }
    }
}
