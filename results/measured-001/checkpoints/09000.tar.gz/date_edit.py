from pathlib import Path
p=Path('src/datetime.rs');s=p.read_text()
a=s.index('    let mut sub=false;');b=s.index('    sec=(sec*1000.0).round()/1000.0;',a)
s=s[:a]+'''    let mut sub=false;
    let mut overflow_days=0;
    for (position,v) in modifiers.iter().enumerate(){
        let m=v.text().to_ascii_lowercase();
        let previous_overflow=overflow_days;
        overflow_days=0;
        match m.as_str(){
            "unixepoch"|"julianday"=>{
                if position!=0||subfirst||numeric.is_none(){return Ok(Value::Null)}
            }
            "auto"=>if position!=0||subfirst{return Ok(Value::Null)},
            "utc"|"localtime"=>{},
            "subsec"|"subsecond"=>sub=true,
            "ceiling"=>{},
            "floor"=>sec-=previous_overflow as f64*86400.0,
            "start of day"=>sec=(sec/86400.0).floor()*86400.0,
            "start of month"|"start of year"=>{
                let(y,mo,_)=civil((sec/86400.0).floor() as i64);
                sec=days(y,if m=="start of year"{1}else{mo},1) as f64*86400.0;
            }
            _=>{
                if let Some(s)=m.strip_prefix("weekday "){
                    let Some(d)=s.parse::<f64>().ok().filter(|d|d.fract()==0.0&&(0.0..=6.0).contains(d)) else{return Ok(Value::Null)};
                    let current=((sec/86400.0).floor() as i64+4).rem_euclid(7);
                    sec+=(d as i64-current).rem_euclid(7) as f64*86400.0;
                }else{
                    let parts=m.split_whitespace().collect::<Vec<_>>();
                    let amount=parts.first().and_then(|s|s.parse::<f64>().ok());
                    if let Some(x)=amount{
                        if parts.len()!=2||!x.is_finite(){return Ok(Value::Null)}
                        let unit=parts[1].strip_suffix('s').unwrap_or(parts[1]);
                        match unit{
                            "day"=>sec+=x*86400.0,
                            "hour"=>sec+=x*3600.0,
                            "minute"=>sec+=x*60.0,
                            "second"=>sec+=x,
                            "month"|"year"=>{
                                // Bound conversion before doing signed calendar arithmetic.
                                if x.abs()>120000.0{return Ok(Value::Null)}
                                let whole=x.trunc() as i64;
                                let months=if unit=="year"{whole*12}else{whole};
                                let (shifted,overflow)=calendar_shift(sec,months);
                                overflow_days=overflow;
                                sec=shifted+x.fract()*if unit=="year"{365.0*86400.0}else{30.0*86400.0};
                            }
                            _=>return Ok(Value::Null)
                        }
                    }else{
                        let sign=if m.starts_with('-'){-1.0}else{1.0};
                        let signed=m.starts_with(['+','-']);
                        let shift=if signed{&m[1..]}else{&m};
                        let bytes=shift.as_bytes();
                        if signed&&bytes.len()>=10&&bytes[4]==b'-'&&bytes[7]==b'-'{
                            let Some(yy)=digits(bytes,0,4) else{return Ok(Value::Null)};
                            let Some(mm)=digits(bytes,5,2).filter(|x|*x<12) else{return Ok(Value::Null)};
                            let Some(dd)=digits(bytes,8,2).filter(|x|*x<31) else{return Ok(Value::Null)};
                            let (shifted,overflow)=calendar_shift(sec,sign as i64*(yy*12+mm));
                            sec=shifted+sign*dd as f64*86400.0;
                            overflow_days=overflow;
                            if bytes.len()>10{
                                if !bytes[10].is_ascii_whitespace(){return Ok(Value::Null)}
                                let Some(time)=parse_clock(shift[10..].trim(),false) else{return Ok(Value::Null)};
                                sec+=sign*time;
                            }
                        }else if let Some(d)=parse_clock(shift,false){
                            sec+=sign*d;
                        }else{return Ok(Value::Null)}
                    }
                }
            }
        }
        if !valid_seconds(sec){return Ok(Value::Null)}
        sec=(sec*1000.0).round()/1000.0;
    }
    if !valid_seconds(sec){return Ok(Value::Null)}
''' + s[b:]
s=s.replace("'%'=>\"%\".into(),'Y'", "'%'=>\"%\".into(),'G'=>format!(\"{:04}\",iso_week(day).0),'g'=>format!(\"{:02}\",iso_week(day).0.rem_euclid(100)),'V'=>format!(\"{:02}\",iso_week(day).1),'Y'")
a=s.index('fn parse(v:&Value,unix:bool)');b=s.index('pub fn days(',a)
s=s[:a]+'''fn valid_seconds(sec:f64)->bool{
    (-210866760000.0..253402300800.0).contains(&sec)
}
fn digits(bytes:&[u8],start:usize,count:usize)->Option<i64>{
    let part=bytes.get(start..start+count)?;
    if !part.iter().all(u8::is_ascii_digit){return None}
    Some(part.iter().fold(0,|n,b|n*10+(b-b'0') as i64))
}
fn parse(v:&Value,unix:bool)->Option<f64>{
    let s=v.text();
    let s=s.trim();
    let sec=if s.eq_ignore_ascii_case("now"){
        now()
    }else if let Ok(n)=s.parse::<f64>(){
        if unix{n}else{
            if !(0.0..5373484.5).contains(&n){return None}
            (n-2440587.5)*86400.0
        }
    }else{
        let b=s.as_bytes();
        if b.len()>=10&&b[4]==b'-'&&b[7]==b'-'{
            let y=digits(b,0,4)?;
            let m=digits(b,5,2).filter(|n|(1..=12).contains(n))?;
            let d=digits(b,8,2).filter(|n|(1..=31).contains(n))?;
            let base=days(y,m,d) as f64*86400.0;
            if b.len()==10{base}else{
                if b[10]!=b'T'&&!b[10].is_ascii_whitespace(){return None}
                let time=s[10..].trim_start_matches(|c:char|c=='T'||c.is_ascii_whitespace());
                base+parse_clock(time,true)?
            }
        }else{
            days(2000,1,1) as f64*86400.0+parse_clock(s,true)?
        }
    };
    let sec=(sec*1000.0).round()/1000.0;
    valid_seconds(sec).then_some(sec)
}
fn parse_clock(s:&str,allow_zone:bool)->Option<f64>{
    let s=s.trim();
    let b=s.as_bytes();
    let h=digits(b,0,2).filter(|n|*n<=24)?;
    if b.get(2)!=Some(&b':'){return None}
    let m=digits(b,3,2).filter(|n|*n<60)?;
    let mut pos=5;
    let mut seconds=0.0;
    if b.get(pos)==Some(&b':'){
        seconds=digits(b,pos+1,2).filter(|n|*n<60)? as f64;
        pos+=3;
        if b.get(pos)==Some(&b'.'){
            let start=pos;
            pos+=1;
            while b.get(pos).is_some_and(u8::is_ascii_digit){pos+=1}
            if pos==start+1{return None}
            seconds+=s[start..pos].parse::<f64>().ok()?;
        }
    }
    let tail=s.get(pos..)?.trim();
    let zone=if tail.is_empty(){0.0}else if !allow_zone{return None}else if tail.eq_ignore_ascii_case("z"){0.0}else{
        let z=tail.as_bytes();
        if z.len()!=6||!matches!(z[0],b'+'|b'-')||z[3]!=b':'{return None}
        let zh=digits(z,1,2).filter(|n|*n<=14)?;
        let zm=digits(z,4,2).filter(|n|*n<60)?;
        (zh*3600+zm*60) as f64*if z[0]==b'+'{1.0}else{-1.0}
    };
    Some(h as f64*3600.0+m as f64*60.0+seconds-zone)
}
fn iso_week(day:i64)->(i64,i64){
    // ISO weeks belong to the year containing their Thursday.
    let thursday=day+3-(day+3).rem_euclid(7);
    let year=civil(thursday).0;
    (year,(thursday-days(year,1,1))/7+1)
}
fn calendar_shift(sec:f64,months:i64)->(f64,i64){
    let(y,m,d)=civil((sec/86400.0).floor() as i64);
    let total=y*12+m-1+months;
    let ny=total.div_euclid(12);
    let nm=total.rem_euclid(12)+1;
    let following=total+1;
    let maxday=days(following.div_euclid(12),following.rem_euclid(12)+1,1)-days(ny,nm,1);
    (days(ny,nm,d) as f64*86400.0+sec.rem_euclid(86400.0),(d-maxday).max(0))
}
''' + s[b:]
p.write_text(s)
