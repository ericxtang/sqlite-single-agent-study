use crate::{
    engine::Engine,ast::*,parser::Res,storage::key
}
;
impl Engine{
    pub fn route_attachment(&self,s:&mut Statement)->Res<Option<String>>{
        if let Statement::IndexGuard(s,_)=s{return self.route_attachment(s)}
        if let Statement::Pragma(name,_)=s {
            if let Some((_,base))=name.split_once('.') {
                if crate::pragma::connection_pragma(&key(base)){*name=base.into();return Ok(None)}
            }
        }
        let (target,create)=match s{
            Statement::CreateTable(t,..)=>(&mut t.name,true),Statement::CreateView(n,..)|Statement::CreateIndex(n,..)=>(n,true),Statement::CreateTrigger(t,_)=>(&mut t.name,true),Statement::Insert{
                table,..
            }
            |Statement::Update{
                table,..
            }
            |Statement::Delete{
                table,..
            }
            =>(table,false),Statement::Drop(_,n,_)|Statement::Alter(n,..)=>(n,false),Statement::Pragma(n,..)=>(n,true),_=>return Ok(None)
        }
        ;
        if let Some((schema,name))=target.split_once('.') {
            let schema=key(schema);
            if schema=="main"||schema=="temp"{
                if schema=="temp"{
                    *target=format!("temp.{}",name);
                    if let Statement::CreateTable(d,..)=s{
                        d.temporary=true;
                    }
                }
                else{
                    *target=format!("main.{}",name);
                    if create&&!matches!(s,Statement::Pragma(..)){
                        match s{
                            Statement::CreateTable(d,..)=>d.name=d.name[5..].into(),Statement::CreateView(n,..)|Statement::CreateIndex(n,..)=>*n=n[5..].into(),Statement::CreateTrigger(t,..)=>t.name=t.name[5..].into(),_=>{
                            }
                        }
                    }

                }
                return Ok(None)
            }
            if !self.attachments.contains_key(&schema){
                return Err(format!("unknown database {}",schema))
            }
            *target=name.into();
            return Ok(Some(schema))
        }
        if !create {
            let kind=match s {Statement::Drop(kind,..)=>key(kind),_=>"relation".into()};
            let name=match s {Statement::Drop(_,n,_)|Statement::Alter(n,..)=>n,Statement::Insert{table,..}|Statement::Update{table,..}|Statement::Delete{table,..}=>table,_=>return Ok(None)};
            let exists=|engine:&Engine| {let k=engine.resolve_object_key(name,&kind);match kind.as_str(){"table"=>engine.db.tables.contains_key(&k),"view"=>engine.db.views.contains_key(&k),"index"=>engine.db.indexes.contains_key(&k),"trigger"=>engine.db.triggers.contains_key(&k),_=>engine.db.tables.contains_key(&k)||engine.db.views.contains_key(&k)}};
            if !exists(self) {
                for n in &self.attachment_order {if exists(&self.attachments[n]) {return Ok(Some(n.clone()))}}
            }
        }
        Ok(None)
    }
}
