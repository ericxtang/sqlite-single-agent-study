use crate::{
    engine::*,storage::*,ast::*,value::Value,parser::Res
}
;
impl Engine{
    pub fn schema_relation(&self,temp:bool)->Relation{
        let mut rows=vec![];
        let mut page=2;
        for t in self.db.tables.values().filter(|t|t.def.temporary==temp){
            rows.push(vec![Value::Text("table".into()),Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Integer(page),Value::Text(t.def.sql.clone())]);
            page+=1;
        }
        if if temp{
            self.db.temp_sequence_exists
        }
        else{
            self.db.sequence_exists
        }
        {
            rows.push(vec![Value::Text("table".into()),Value::Text("sqlite_sequence".into()),Value::Text("sqlite_sequence".into()),Value::Integer(page),Value::Text("CREATE TABLE sqlite_sequence(name,seq)".into())]);
            page+=1;
        }
        for v in self.db.views.values().filter(|v|v.name.starts_with("temp.")==temp){
            rows.push(vec![Value::Text("view".into()),Value::Text(v.name.trim_start_matches("temp.").into()),Value::Text(v.name.trim_start_matches("temp.").into()),Value::Integer(0),Value::Text(v.sql.clone())]);
        }
        for i in self.db.indexes.values().filter(|i|i.table.starts_with("temp.")==temp){
            if i.origin=="pk"&&self.db.tables.get(&key(&i.table)).is_some_and(|t|t.def.without_rowid){continue}
            rows.push(vec![Value::Text("index".into()),Value::Text(i.name.trim_start_matches("temp.").into()),Value::Text(i.table.trim_start_matches("temp.").into()),Value::Integer(page),if i.sql.is_empty(){
                Value::Null
            }
            else{
                Value::Text(i.sql.clone())
            }
            ]);
            page+=1;
        }
        for t in self.db.triggers.values().filter(|t|(t.temporary||t.table.starts_with("temp."))==temp){
            rows.push(vec![Value::Text("trigger".into()),Value::Text(t.name.trim_start_matches("temp.").into()),Value::Text(t.table.trim_start_matches("temp.").into()),Value::Integer(0),Value::Text(t.sql.clone())]);
        }
        Relation::simple(&["type","name","tbl_name","rootpage","sql"],rows)
    }
    pub fn pragma(&mut self,name:&str,e:Option<&Expr>)->Res<Relation>{
        if let Some((schema,base))=name.split_once('.') {
            if connection_pragma(&key(base)){return self.pragma(base,e)}
            if schema.eq_ignore_ascii_case("temp") {
                if base.eq_ignore_ascii_case("synchronous")&&e.is_some(){return Ok(Relation::default())}
                if base.eq_ignore_ascii_case("cache_size"){
                    if let Some(e)=e{let value=self.eval(e,&Env::default(),None,&Ctes::new(),0)?.int();self.pragmas.insert("temp.cache_size".into(),Value::Integer(value));return Ok(Relation::default())}
                    return self.pragma_read(name,None)
                }
                if base.eq_ignore_ascii_case("journal_mode"){
                    if self.tx.is_none(){if let Some(e)=e{
                        let value=match e{Expr::Col(n)=>Value::Text(n.join(".")),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)?};
                        let mode=key(&value.text());if ["memory","off"].contains(&mode.as_str()){self.pragmas.insert("temp.journal_mode".into(),Value::Text(mode));}
                    }}
                    return self.pragma_read(name,None)
                }
                if ["schema_version","user_version","application_id"].contains(&key(base).as_str()) {
                    if let Some(e)=e {let v=self.eval(e,&Env::default(),None,&Ctes::new(),0)?.int();match key(base).as_str(){"schema_version"=>self.db.temp_schema_version=v,"user_version"=>self.db.temp_user_version=v,_=>self.db.temp_application_id=v}return Ok(Relation::default())}
                }
                let val=e.map(|e|match e{Expr::Col(n)=>Ok(Value::Text(n.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)}).transpose()?;
                return self.pragma_read(name,val.as_ref());
            }
            if schema.eq_ignore_ascii_case("main") {
                if base.eq_ignore_ascii_case("journal_mode"){
                    if let Some(e)=e{let value=match e{Expr::Col(n)=>Value::Text(n.join(".")),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)?};self.set_journal_mode(&value);}
                    return self.pragma_read(base,None)
                }
                if ["table_info","table_xinfo","index_list","index_info","index_xinfo","foreign_key_list","foreign_key_check","table_list"].contains(&key(base).as_str()) {
                    let val=e.map(|e|match e{Expr::Col(n)=>Ok(Value::Text(n.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)}).transpose()?;
                    return self.pragma_read(name,val.as_ref());
                }
                return self.pragma(base,e);
            }
        }
        let n=key(name);
        let val=e.map(|e|match e{
            Expr::Col(ns)=>Ok(Value::Text(ns.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)
        }
        ).transpose()?;
        if let Some(v)=&val{
            let boolean=if let Value::Text(s)=v{
                ["on","yes","true","1"].contains(&key(s).as_str())
            }
            else{
                v.truth()==Some(true)
            }
            ;
            match n.as_str(){
                "foreign_keys"=>{
                    if self.tx.is_none(){
                        self.foreign_keys=boolean;
                        for a in self.attachments.values_mut(){
                            a.foreign_keys=boolean;
                        }
                    }
                    return Ok(Relation::default())
                }
                ,"defer_foreign_keys"=>{
                    self.defer_foreign=boolean;
                    for a in self.attachments.values_mut(){a.defer_foreign=boolean;}
                    return Ok(Relation::default())
                }
                ,"case_sensitive_like"=>{
                    self.case_like=boolean;
                    for a in self.attachments.values_mut(){a.case_like=boolean;}
                    return Ok(Relation::default())
                }
                ,"user_version"=>{
                    self.db.user_version=v.int();
                    return Ok(Relation::default())
                }
                ,"application_id"=>{
                    self.db.application_id=v.int();
                    return Ok(Relation::default())
                }
                ,"schema_version"=>{
                    self.db.schema_version=v.int();
                    return Ok(Relation::default())
                }
                ,"journal_mode"=>{
                    self.set_journal_mode(v);
                    for a in self.attachments.values_mut(){a.set_journal_mode(v);}
                    return self.pragma_read(&n,None)
                }
                ,"synchronous"=>{
                    if self.tx.is_some(){return Err("Safety level may not be changed inside a transaction".into())}
                    let level=match key(&v.text()).as_str(){"off"=>Some(0),"normal"=>Some(1),"full"=>Some(2),"extra"=>Some(3),_=>v.text().parse::<i64>().ok().filter(|n|(0..=3).contains(n))};
                    if let Some(level)=level{self.pragmas.insert(n,Value::Integer(level));}
                    return Ok(Relation::default())
                }
                ,"busy_timeout"=>{
                    let value=Value::Integer(v.int().max(0));
                    self.pragmas.insert(n.clone(),value.clone());
                    for a in self.attachments.values_mut(){a.pragmas.insert(n.clone(),value.clone());}
                    return self.pragma_read(&n,None)
                }
                ,"table_info"|"table_xinfo"|"index_list"|"index_info"|"index_xinfo"|"foreign_key_list"|"foreign_key_check"|"integrity_check"|"quick_check"=>{
                }
                ,_=>{
                    let v=if ["recursive_triggers","read_uncommitted","query_only","count_changes","ignore_check_constraints","legacy_alter_table","writable_schema"].contains(&n.as_str()){Value::Integer(boolean as i64)}else{v.clone()};
                    self.pragmas.insert(n.clone(),v.clone());
                    if connection_pragma(&n){for a in self.attachments.values_mut(){a.pragmas.insert(n.clone(),v.clone());}}
                    return Ok(Relation::default())
                }
            }
        }
        self.pragma_read(&n,val.as_ref())
    }
    fn set_journal_mode(&mut self,value:&Value){
        if self.tx.is_some(){return}
        let mode=key(&value.text());
        let allowed=if self.path.is_none(){["memory","off"].contains(&mode.as_str())}else{["delete","truncate","persist","memory","wal","off"].contains(&mode.as_str())};
        if allowed{self.journal=mode;}
    }
    pub fn pragma_read(&self,name:&str,val:Option<&Value>)->Res<Relation>{
        if let Some((schema,base))=name.split_once('.') {
            if connection_pragma(&key(base)){return self.pragma_read(base,val)}
            let temp=schema.eq_ignore_ascii_case("temp");
            if temp||schema.eq_ignore_ascii_case("main") {
                let simple=|v|Relation::simple(&[base],vec![vec![Value::Integer(v)]]);
                if ["integrity_check","quick_check"].contains(&key(base).as_str()){return self.integrity_relation(base,temp,val)}
                if temp {match key(base).as_str(){"cache_size"=>return Ok(simple(self.pragmas.get("temp.cache_size").map(Value::int).unwrap_or(0))),"synchronous"=>return Ok(simple(0)),"data_version"=>return Ok(simple(1)),"schema_version"=>return Ok(simple(self.db.temp_schema_version)),"user_version"=>return Ok(simple(self.db.temp_user_version)),"application_id"=>return Ok(simple(self.db.temp_application_id)),"journal_mode"=>return Ok(Relation::simple(&[base],vec![vec![self.pragmas.get("temp.journal_mode").cloned().unwrap_or(Value::Text("memory".into()))]])),_=>{}}}
                if ["table_info","table_xinfo","index_list","index_info","index_xinfo","foreign_key_list","foreign_key_check"].contains(&key(base).as_str()) {
                    let value=val.map(|v|Value::Text(format!("{}.{}",if temp{"temp"}else{"main"},v.text())));
                    return self.pragma_read(base,value.as_ref());
                }
                let mut result=self.pragma_read(base,val)?;
                if base.eq_ignore_ascii_case("table_list"){result.rows.retain(|r|r.first().is_some_and(|v|v.text().eq_ignore_ascii_case(schema)));}
                return Ok(result);
            }
            if let Some(db)=self.attachments.get(&key(schema)){return db.pragma_read(base,val)}
            return Err(format!("unknown database {}",schema));
        }
        let n=key(name);
        let arg=val.map(Value::text).unwrap_or_default();
        let integer=|x|Relation::simple(&[name],vec![vec![Value::Integer(x)]]);
        Ok(match n.as_str(){
            "data_version"=>integer(self.data_version),"foreign_keys"=>integer(self.foreign_keys as i64),"defer_foreign_keys"=>integer(self.defer_foreign as i64),"user_version"=>integer(self.db.user_version),"application_id"=>integer(self.db.application_id),"schema_version"=>integer(self.db.schema_version),"journal_mode"=>Relation::simple(&["journal_mode"],vec![vec![Value::Text(if self.path.is_none()&&self.journal=="delete"{
                "memory".into()
            }
            else{
                self.journal.clone()
            }
            )]]),"encoding"=>Relation::simple(&["encoding"],vec![vec![Value::Text("UTF-8".into())]]),"page_size"=>integer(4096),"page_count"=>integer((self.db.tables.len()+self.db.indexes.len()+1) as i64),"freelist_count"=>integer(0),"auto_vacuum"=>integer(0),"synchronous"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(2)),"cache_size"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(-2000)),"busy_timeout"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(0)),"recursive_triggers"|"read_uncommitted"|"query_only"|"count_changes"|"ignore_check_constraints"|"legacy_alter_table"|"writable_schema"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(0)),
            "database_list"=>{
                let mut rows=vec![vec![Value::Integer(0),Value::Text("main".into()),Value::Text(self.path.as_ref().map(|p|p.to_string_lossy().to_string()).unwrap_or_default())]];
                if self.db.tables.values().any(|t|t.def.temporary)||self.db.views.keys().any(|k|k.starts_with("temp.")){
                    rows.push(vec![Value::Integer(1),Value::Text("temp".into()),Value::Text(String::new())]);
                }
                for(i,n)in self.attachment_order.iter().enumerate(){
                    let a=&self.attachments[n];
                    rows.push(vec![Value::Integer(i as i64+2),Value::Text(n.clone()),Value::Text(a.path.as_ref().map(|p|p.to_string_lossy().to_string()).unwrap_or_default())])
                }
                Relation::simple(&["seq","name","file"],rows)
            }
            ,
            "table_info"|"table_xinfo"=>{
                let mut rows=vec![];
                if (arg.eq_ignore_ascii_case("sqlite_sequence")||arg.to_ascii_lowercase().ends_with(".sqlite_sequence"))&&(self.db.sequence_exists||self.db.temp_sequence_exists){
                    for(i,nm)in ["name","seq"].iter().enumerate(){
                        let mut row=vec![Value::Integer(i as i64),Value::Text((*nm).into()),Value::Text(String::new()),Value::Integer(0),Value::Null,Value::Integer(0)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(0))
                        }
                        rows.push(row)
                    }
                }
                if let Some(t)=self.db.tables.get(&self.resolve_relation_key(&arg)){
                    let mut cid=0;
                    for c in &t.def.cols{
                        if n=="table_info"&&c.generated.is_some(){
                            continue
                        }
                        let mut row=vec![Value::Integer(cid),Value::Text(c.name.clone()),Value::Text(c.typ.clone()),Value::Integer(c.not_null as i64),c.default_sql.as_ref().map(|s|Value::Text(s.clone())).unwrap_or(Value::Null),Value::Integer(c.primary as i64)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(if c.generated.is_some(){
                                if c.stored{
                                    3
                                }
                                else{
                                    2
                                }
                            }
                            else{
                                0
                            }
                            ))
                        }
                        rows.push(row);
                        cid+=1
                    }
                }
                else if let Some(v)=self.db.views.get(&self.resolve_relation_key(&arg)){
                    let r=self.query(&v.query,&Env::default(),&Ctes::new(),0)?;
                    for(i,c)in r.fields.iter().enumerate(){
                        let mut row=vec![Value::Integer(i as i64),Value::Text(v.cols.get(i).unwrap_or(&c.name).clone()),Value::Text(String::new()),Value::Integer(0),Value::Null,Value::Integer(0)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(0))
                        }
                        rows.push(row)
                    }
                }
                Relation::simple(if n=="table_info"{
                    &["cid","name","type","notnull","dflt_value","pk"]
                }
                else{
                    &["cid","name","type","notnull","dflt_value","pk","hidden"]
                }
                ,rows)
            }
            ,
            "table_list"=>{
                let mut rows=self.db.tables.values().filter(|t|arg.is_empty()||t.def.name.eq_ignore_ascii_case(&arg)).map(|t|vec![Value::Text(if t.def.temporary{
                    "temp"
                }
                else{
                    "main"
                }
                .into()),Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Text("table".into()),Value::Integer(t.def.cols.len() as i64),Value::Integer(t.def.without_rowid as i64),Value::Integer(t.def.strict as i64)]).collect::<Vec<_>>();
                for v in self.db.views.values(){
                    rows.push(vec![Value::Text(if v.name.starts_with("temp."){"temp"}else{"main"}.into()),Value::Text(v.name.trim_start_matches("temp.").into()),Value::Text("view".into()),Value::Integer(v.cols.len() as i64),Value::Integer(0),Value::Integer(0)])
                }
                Relation::simple(&["schema","name","type","ncol","wr","strict"],rows)
            }
            ,
            "index_list"=>Relation::simple(&["seq","name","unique","origin","partial"],self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&self.resolve_relation_key(&arg))).enumerate().map(|(j,i)|vec![Value::Integer(j as i64),Value::Text(i.name.trim_start_matches("temp.").into()),Value::Integer(i.unique as i64),Value::Text(i.origin.clone()),Value::Integer(i.filter.is_some() as i64)]).collect()),
            "index_info"|"index_xinfo"=>{
                let mut rows=vec![];
                let index=self.db.indexes.get(&self.resolve_index_key(&arg)).or_else(|| {
                    let table=self.db.tables.get(&self.resolve_relation_key(&arg))?;
                    if !table.def.without_rowid{return None}
                    self.db.indexes.values().find(|i|i.table.eq_ignore_ascii_case(&table.def.name)&&i.origin=="pk")
                });
                if let Some(idx)=index {
                    if let Some(t)=self.db.tables.get(&key(&idx.table)) {
                        let env=self.row_env(t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},None);
                        let mut entries=idx.cols.iter().map(|o|(o.clone(),true)).collect::<Vec<_>>();
                        if n=="index_xinfo" {
                            if t.def.without_rowid {
                                if idx.origin=="pk" {
                                    for c in &t.def.cols {if !entries.iter().any(|(o,_)|crate::schema::column_name(&o.expr).is_some_and(|n|n.eq_ignore_ascii_case(&c.name))) {entries.push((Order{expr:Expr::Col(vec![c.name.clone()]),desc:false,nulls:None},false));}}
                                } else if let Some(pk)=self.db.indexes.values().find(|i|i.table.eq_ignore_ascii_case(&t.def.name)&&i.origin=="pk") {
                                    for o in &pk.cols {if !entries.iter().any(|(e,_)|crate::schema::column_name(&e.expr)==crate::schema::column_name(&o.expr)&&self.meta(&e.expr,&env).1.eq_ignore_ascii_case(&self.meta(&o.expr,&env).1)) {entries.push((o.clone(),false));}}
                                }
                            }
                        }
                        for (o,is_key) in entries {
                            let(ci,nm)=if let Some(name)=crate::schema::column_name(&o.expr) {(t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(name)).map(|i|i as i64).unwrap_or(-1),Value::Text(name.into()))}else{(-2,Value::Null)};
                            let mut row=vec![Value::Integer(rows.len() as i64),Value::Integer(ci),nm];
                            if n=="index_xinfo" {row.extend([Value::Integer(o.desc as i64),Value::Text(self.meta(&o.expr,&env).1),Value::Integer(is_key as i64)]);}
                            rows.push(row);
                        }
                        if n=="index_xinfo"&&!t.def.without_rowid {rows.push(vec![Value::Integer(rows.len() as i64),Value::Integer(-1),Value::Null,Value::Integer(0),Value::Text("BINARY".into()),Value::Integer(0)]);}
                    }
                }
                Relation::simple(if n=="index_info"{
                    &["seqno","cid","name"]
                }
                else{
                    &["seqno","cid","name","desc","coll","key"]
                }
                ,rows)
            }
            ,
            "foreign_key_list"=>{
                let mut rows=vec![];
                if let Some(t)=self.db.tables.get(&self.resolve_relation_key(&arg)){
                    for(i,f)in t.def.foreign.iter().rev().enumerate(){
                        for(j,n)in f.cols.iter().enumerate(){
                            rows.push(vec![Value::Integer(i as i64),Value::Integer(j as i64),Value::Text(f.table.clone()),Value::Text(n.clone()),f.target.get(j).map(|s|Value::Text(s.clone())).unwrap_or(Value::Null),Value::Text(f.update.clone()),Value::Text(f.delete.clone()),Value::Text("NONE".into())])
                        }
                    }
                }
                Relation::simple(&["id","seq","table","from","to","on_update","on_delete","match"],rows)
            }
            ,
            "foreign_key_check"=>self.foreign_check_relation(&arg)?,"integrity_check"|"quick_check"=>self.integrity_relation(name,false,val)?,"collation_list"=>Relation::simple(&["seq","name"],vec![vec![Value::Integer(0),Value::Text("RTRIM".into())],vec![Value::Integer(1),Value::Text("NOCASE".into())],vec![Value::Integer(2),Value::Text("BINARY".into())]]),"compile_options"=>Relation::simple(&["compile_options"],vec![]),"wal_checkpoint"=>Relation::simple(&["busy","log","checkpointed"],vec![vec![Value::Integer(0),Value::Integer(-1),Value::Integer(-1)]]),_=>if let Some(v)=self.pragmas.get(&n){
                Relation::simple(&[name],vec![vec![v.clone()]])
            }
            else{
                Relation::default()
            }
        }
        )
    }
}
impl Engine{
    fn foreign_check_relation(&self,name:&str)->Res<Relation>{
        use crate::value::{
            affinity,compare
        }
        ;
        use std::cmp::Ordering;
        let mut rows=vec![];
        for t in self.db.tables.values(){
            if !name.is_empty()&&!t.def.name.eq_ignore_ascii_case(&self.resolve_relation_key(name)){
                continue
            }
            for (fk,f) in t.def.foreign.iter().rev().enumerate(){
                let child=f.cols.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch".to_string())).collect::<Res<Vec<_>>>()?;
                let parent=self.db.tables.get(&if t.def.temporary{
                    format!("temp.{}",key(&f.table))
                }
                else{
                    key(&f.table)
                }
                );
                let names=if let Some(parent)=parent{
                    if f.target.is_empty(){
                        let mut cols=parent.def.cols.iter().filter(|c|c.primary>0).collect::<Vec<_>>();
                        cols.sort_by_key(|c|c.primary);
                        cols.iter().map(|c|c.name.clone()).collect()
                    }
                    else{
                        f.target.clone()
                    }
                }
                else{
                    f.target.clone()
                }
                ;
                let target=parent.map(|p|names.iter().map(|n|p.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch".to_string())).collect::<Res<Vec<_>>>()).transpose()?;
                for r in &t.rows{
                    if child.iter().any(|i|r.values[*i].null()){
                        continue
                    }
                    let found=if let (Some(p),Some(target))=(parent,&target){
                        if child.len()!=target.len(){
                            return Err("foreign key mismatch".into())
                        }
                        p.rows.iter().any(|pr|child.iter().zip(target).all(|(i,j)|compare(&r.values[*i].apply(affinity(&p.def.cols[*j].typ)),&pr.values[*j],&p.def.cols[*j].collate)==Ordering::Equal))
                    }
                    else{
                        false
                    }
                    ;
                    if !found{
                        rows.push(vec![Value::Text(t.def.name.clone()),if t.def.without_rowid{
                            Value::Null
                        }
                        else{
                            Value::Integer(r.id)
                        }
                        ,Value::Text(f.table.clone()),Value::Integer(fk as i64)]);
                    }
                }
            }
        }
        Ok(Relation::simple(&["table","rowid","parent","fkid"],rows))
    }
}

impl Engine {
    pub fn pragma_enabled(&self,name:&str)->bool {self.pragmas.get(name).is_some_and(|v|v.truth()==Some(true)||["on","yes","true"].contains(&v.text().to_ascii_lowercase().as_str()))}
    pub fn count_output(&self,result:&mut Relation,name:&str,count:i64) {
        if result.fields.is_empty()&&self.pragma_enabled("count_changes"){*result=Relation::simple(&[name],vec![vec![Value::Integer(count)]]);}
    }
}

impl Engine {
    fn integrity_relation(&self,name:&str,temp:bool,value:Option<&Value>)->Res<Relation> {
        let table=value.filter(|v|matches!(v,Value::Text(_))).map(Value::text);
        let limit=value.filter(|v|matches!(v,Value::Integer(_))).map(Value::int).unwrap_or(100).max(1) as usize;
        let mut errors=vec![];
        for t in self.db.tables.values().filter(|t|t.def.temporary==temp&&table.as_ref().is_none_or(|n|t.def.name.trim_start_matches("temp.").eq_ignore_ascii_case(n))) {
            for (i,row) in t.rows.iter().enumerate() {
                match self.validate_row(t,row,Some(i)) {
                    Ok(conflicts) if !conflicts.is_empty()&&name.eq_ignore_ascii_case("integrity_check")=>errors.push(vec![Value::Text(format!("UNIQUE constraint failed in {}",t.def.name))]),
                    Err(error)=>errors.push(vec![Value::Text(error)]),_=>{}
                }
                if errors.len()>=limit{return Ok(Relation::simple(&[name],errors))}
            }
        }
        if errors.is_empty(){errors.push(vec![Value::Text("ok".into())]);}
        Ok(Relation::simple(&[name],errors))
    }
}

pub(crate) fn connection_pragma(name:&str)->bool{
    ["foreign_keys","defer_foreign_keys","case_sensitive_like","recursive_triggers","read_uncommitted","query_only","count_changes","ignore_check_constraints","legacy_alter_table","writable_schema","busy_timeout","temp_store","threads","analysis_limit"].contains(&name)
}
