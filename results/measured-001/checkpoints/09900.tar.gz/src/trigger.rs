use crate::{
    engine::*,storage::*,parser::Res
}
;
impl Engine{
    pub fn fire_triggers(&mut self,t:&Table,timing:&str,event:&str,old:Option<&Row>,new:Option<&Row>,columns:&[String])->Res<bool>{
        let ts=self.db.triggers.values().filter(|tr|tr.table.eq_ignore_ascii_case(&t.def.name)&&tr.timing==timing&&tr.event==event&&(tr.columns.is_empty()||columns.iter().any(|c|tr.columns.iter().any(|n|n.eq_ignore_ascii_case(c))))).cloned().collect::<Vec<_>>();
        let recursive=self.pragmas.get("recursive_triggers").is_some_and(|v|v.truth()==Some(true)||v.text().eq_ignore_ascii_case("on"));
        for mut tr in ts.into_iter().rev(){
            if !tr.temporary {
                if let Some(e)=&mut tr.when{crate::schema::qualify_trigger_expr(e);}
                for stmt in &mut tr.body{crate::schema::qualify_trigger_statement(stmt);}
            }
            if !recursive&&self.active_triggers.contains(&tr.name){
                continue
            }
            if self.active_triggers.len()>50{
                return Err("too many levels of trigger recursion".into())
            }
            let mut env=Env::default();
            if let Some(r)=old{
                let e=self.row_env(t,r,Some("old"));
                env.fields.extend(e.fields);
                env.values.extend(e.values)
            }
            if let Some(r)=new{
                let e=self.row_env(t,r,Some("new"));
                env.fields.extend(e.fields);
                env.values.extend(e.values)
            }
            let prev=self.trigger_env.replace(env.clone());
            self.active_triggers.push(tr.name);
            let changes=self.changes;
            self.trigger_change_values.push(self.visible_changes());
            let last=self.last_id;
            let res=(||{
                if let Some(w)=&tr.when{
                    if self.eval(w,&env,None,&Ctes::new(),0)?.truth()!=Some(true){
                        return Ok(())
                    }
                }
                for s in tr.body{
                    self.run(s)?;
                }
                Ok::<_,String>(())
            }
            )();
            self.trigger_change_values.pop();
            self.changes=changes;
            self.last_id=last;
            self.active_triggers.pop();
            self.trigger_env=prev;
            if let Err(e)=res{
                if e=="TRIGGER_IGNORE"{
                    return Ok(false)
                }
                return Err(e)
            }
        }
        Ok(true)
    }
}
use crate::{
    ast::*,value::Value
}
;
impl Engine{
    fn view_table(&self,name:&str,event:&str)->Res<Table>{
        let canonical=self.resolve_relation_key(name);
        let name=canonical.as_str();
        if !self.db.triggers.values().any(|t|t.table.eq_ignore_ascii_case(name)&&t.event==event&&t.timing=="INSTEAD OF"){
            return Err(format!("cannot modify {} because it is a view",name))
        }
        let v=&self.db.views[&key(name)];
        let r=self.query(&v.query,&Env::default(),&Ctes::new(),0)?;
        let cols=r.fields.iter().enumerate().map(|(i,f)|Column{
            name:v.cols.get(i).cloned().unwrap_or(f.name.clone()),collate:f.collate.clone(),..Default::default()
        }
        ).collect();
        Ok(Table{
            def:TableDef{
                name:name.into(),cols,without_rowid:true,..Default::default()
            }
            ,rows:r.rows.into_iter().enumerate().map(|(i,values)|Row{
                id:i as i64,values
            }
            ).collect(),sequence:0,sequence_written:false
        }
        )
    }
    pub fn insert_view(&mut self,name:&str,cols:&[String],q:Option<&Query>,default:bool,returning:&[Item])->Res<Relation>{
        let t=self.view_table(name,"INSERT")?;
        let (inputs,input_width)=if default{
            let width=if cols.is_empty(){t.def.cols.len()}else{cols.len()};
            (vec![vec![Value::Null;width]],width)
        }else{
            let input=self.query(q.ok_or("missing query")?,&Env::default(),&Ctes::new(),0)?;
            (input.rows,input.fields.len())
        }
        ;
        let positions=if cols.is_empty(){
            (0..t.def.cols.len()).collect::<Vec<_>>()
        }
        else{
            cols.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or(format!("no such column: {}",n))).collect::<Res<Vec<_>>>()?
        }
        ;
        if input_width!=positions.len(){return Err("column count mismatch".into())}
        let(items,mut out)=self.output_template(&t,returning)?;
        self.changes=0;
        let mut affected=0;
        for vals in inputs{
            if vals.len()!=positions.len(){
                return Err("column count mismatch".into())
            }
            let mut row=Row{
                id:0,values:vec![Value::Null;
                t.def.cols.len()]
            }
            ;
            for(i,v)in positions.iter().zip(vals){
                row.values[*i]=v
            }
            affected+=1;
            if self.fire_triggers(&t,"INSTEAD OF","INSERT",None,Some(&row),&[])?&&!items.is_empty(){
                out.rows.push(self.output_row(&t,&row,&items)?);
            }
        }
        self.check_foreign(false)?;
        self.count_output(&mut out,"rows inserted",affected);
        Ok(out)
    }
    pub fn change_view(&mut self,name:&str,alias:Option<&str>,assignments:&[(String,Expr)],filter:Option<&Expr>,returning:&[Item],delete:bool)->Res<Relation>{
        let event=if delete{
            "DELETE"
        }
        else{
            "UPDATE"
        }
        ;
        let t=self.view_table(name,event)?;
        let(items,mut out)=self.output_template(&t,returning)?;
        let bind=self.row_env(&t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},alias);
        for(n,e)in assignments {if !t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(n)){return Err(format!("no such column: {}",n))}self.validate_row_expr(e,&bind)?;}
        if let Some(e)=filter{self.validate_row_expr(e,&bind)?;}
        self.changes=0;
        let mut affected=0;
        for old in &t.rows{
            let env=self.row_env(&t,old,alias);
            if filter.map(|e|self.eval(e,&env,None,&Ctes::new(),0).map(|v|v.truth()==Some(true))).transpose()?.unwrap_or(true){
                affected+=1;
                let mut new=old.clone();
                for((n,_),v)in assignments.iter().zip(self.assignment_values(assignments,&env)?){
                    let Some(v)=v else{continue};
                    let i=t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or(format!("no such column: {}",n))?;
                    new.values[i]=v;
                }
                if self.fire_triggers(&t,"INSTEAD OF",event,Some(old),if delete{
                    None
                }
                else{
                    Some(&new)
                }
                ,&assignments.iter().map(|(n,_)|n.clone()).collect::<Vec<_>>())?&&!items.is_empty(){
                    out.rows.push(self.output_row(&t,if delete{
                        old
                    }
                    else{
                        &new
                    }
                    ,&items)?);
                }
            }
        }
        self.check_foreign(false)?;
        self.count_output(&mut out,if delete{"rows deleted"}else{"rows updated"},affected);
        Ok(out)
    }
}
