# Rust SQLite implementation state

## Build and interface

`cargo build --release --offline --bin sqlite-agent`
produces `target/release/sqlite-agent`. JSON-lines process interface follows
IO_CONTRACT.md. Only serde and serde_json (including arbitrary_precision) are used.
All development/tests ran through the offline workspace tool. No reference engine,
external parser/source/tests/network, or other agents were used.

## Architecture

- lexer/parser/ast: SQL syntax and serializable schema/programs.
- value: five storage classes, integer overflow, numeric conversion, affinity,
  collation, exact IEEE-754 snapshot representation.
- engine: relational execution, binding, expressions, aggregates, correlated
  subqueries, compound queries, ordinary/recursive CTEs, recursive work queue.
- mutate/schema: DDL/DML, constraints, schema rewrites, conflict policies,
  generated columns, foreign-key checks/actions.
- trigger/attach: row triggers (including RAISE and INSTEAD OF view writes),
  attached databases, transaction control propagation.
- window/functions/datetime/json/json_value/jsonb: window frames/exclusions,
  scalar/aggregate functions, calendar arithmetic, ordered JSON/JSON5 parser,
  JSON table functions and opaque binary JSON representation.
- storage/pragma: persistence, writer locks, schema metadata and pragmas.

## Storage and transaction design

Custom versioned snapshots, fsync + atomic rename. Snapshot serialization preserves
all integer/blob/text/real values, including infinities. Explicit transactions and
savepoints retain snapshots; durable writes happen on commit; close rolls back.
Paths are confined to /work with canonicalization. Readers refresh committed state;
transactions preserve read snapshots. Writer sidecar locks prevent lost writes and
stale transaction upgrades. Operating-system advisory file locks release automatically after process death.
The sidecar inode remains stable across connections to avoid unlink/recreate races.

These are custom database and JSONB formats, not native SQLite binary formats.
Index definitions enforce constraints, but query execution primarily scans rows.
ATTACH commits files individually: cross-file crash atomicity is not implemented.
Reader/writer concurrency resembles snapshot/WAL behavior; full rollback-journal
reader locks and EXCLUSIVE mode semantics remain incomplete.

## Current verification

All passing at last integrated release build:
- `python3 tests/smoke.py`: 51 assertions.
- `python3 tests/regression.py`: 780 assertions.
- `python3 tests/properties.py`: 533 deterministic arithmetic/calendar/NULL/conflict/error
  recovery checks.
- `python3 tests/persistence.py`: concurrent processes, committed-read isolation,
  stale writers, writer locking, kill/reopen recovery, temporary table lifetime,
  and exact typed persistence (including large integer/blob/Unicode/infinity).

Tests are based on supplied docs and directly derived properties. cargo-fmt is not
installed in the supplied toolchain; no network installation was attempted.

## Remaining priorities/limits

Keep making useful progress and keep builds integrated. Next useful areas:
- Schema catalog order/metadata details, temporary-schema ALTER behavior, and
  more complete sqlite_sequence mutation edge cases.
- JSON subtype behavior now follows runtime values; advanced propagation and
  subquery boundaries still warrant review. JSONB is not SQLite byte-compatible.
- Advanced window validation and tuple/subquery collation/affinity edge cases.
- Foreign-key trigger ordering/self-referential cascades and deferred errors
  across attachments.
- ALTER dependency rewriting for deeply nested/correlated/ambiguous references;
  DROP COLUMN dependency coverage and exact schema text rewriting.
- Scalar/date formatting edge cases, timezone and strftime handling.
- Real query indexes/optimization and resource limits for large/deep inputs.
- Virtual-table extensions (FTS/RTREE etc), comprehensive EXPLAIN, native SQLite
  page/WAL formats and locking compatibility remain unimplemented.

## Latest integrated review

Temporary tables/views now have a separate namespace, shadow main objects, and
appear in sqlite_temp_schema. Explicit main/temp access is supported. Main views
bind their sources to main so temp shadowing does not redirect them. sqlite_sequence
can be updated/deleted for AUTOINCREMENT control; data_version reflects external
commits. Current-time functions share a statement timestamp. LIKE/GLOB use iterative
matching to avoid deep recursive calls on long strings.

Grouped windows now run after grouping/HAVING, support aggregates inside window
arguments/ordering, and work within CASE expressions. Recursive CTEs use a queue,
respect LIMIT/OFFSET and recursive ordering, and support multiple anchor terms.
Foreign-key enforcement distinguishes pre-existing violations from new violations.
UPSERT supports target aliases and selects the row associated with the matching
conflict target. UPDATE OR REPLACE no longer uses a rowid sentinel, preserving the
full signed 64-bit rowid domain.

Sources received a whitespace-only layout pass with a token-text invariant check;
the release build remains clean. tests/run.sh provides a single verification entry.
Most recent semantic checks: 51 smoke + 780 regression + 533 properties = 1364 checks,
plus the multi-process persistence suite. A 1,000-row recursive insert/aggregate
check completed in roughly 0.4 seconds in this workspace.

Latest additions: VACUUM INTO writes reopenable snapshots; ANALYZE populates
sqlite_stat1; INDEXED BY validates named indexes. Index schema expressions bind
on empty tables and reject subqueries/aggregates/non-deterministic functions.
Every applicable index is evaluated on writes, including nonunique indexes.
Date/time schema expressions reject current-time/localtime/utc at evaluation.
JSON path editing preserves existing null/scalar nodes and avoids incomplete
container creation. Runtime JsonText subtype replaces expression-shape guessing.
Namespaces respect temp shadowing and attachment insertion order; schema SQL is
normalized; temporary autoindex names and table renames preserve their schema.
ALTER DROP COLUMN updates SQL text and dependency checks; SET/DROP NOT NULL is
implemented with existing-row validation. Per-constraint conflict policies and
collation/sort metadata for table-defined unique/primary-key indexes are now
implemented, including UPDATE REPLACE delete triggers and index_xinfo details.
A binding-only mode checks subqueries without running unused expressions.
DML/RETURNING/JOIN/function validation works on empty input. Tuple/subquery
comparisons retain affinity/collation; BETWEEN evaluates its left input once.
Window partition collation, NULLS ordering, named chaining, and frame structure
checks were added. Parser nesting/expression depth is limited to roughly 100;
function arguments (1000), compound terms (500), result columns (2000), join
sources (64), and JSON path depth (1000) have explicit limits. Deep schema
snapshots use serde_json's unbounded_depth option behind a 1024-level input guard.
Temporary schema versions are separate; temporary writes avoid main-file locks
and commits; unchanged snapshots are not rewritten. Qualified metadata PRAGMAs
now select main/temp explicitly. Persistence tests cover these cases.

Attached writes now remain pending until the outer statement succeeds. ABORT,
FAIL, and ROLLBACK propagate across attached DBs and TEMP-trigger writes, and
NEW/OLD environments travel with routed trigger statements. Outermost RELEASE
preflights deferred foreign keys before committing any attachment; failed BEGIN
unwinds already-acquired child locks. Attachments created inside savepoints get
matching rollback snapshots. This improves SQL atomicity; multi-file crash/I/O
atomic commit is still a limitation. Busy timeouts wait/retry writer locks; new
file initialization uses the writer lock to prevent concurrent overwrite.
REINDEX now validates/recomputes selected index expressions and uniqueness,
including EXPRESSIONS/collation/all-attached targets. ANALYZE handles one index
without replacing other statistics and visits attached schemas. CHECK suppression
and count_changes (including view/UPSERT distinctions) are implemented. Integrity
checks validate constraints instead of always returning ok. Permanent trigger
programs resolve their unqualified tables within their owning database.


Calendar/formatting review: ISO week/year strftime conversions, strict ASCII
clock/timezone parsing, numeric range guards, complete modifier syntax, immediate
julianday/auto placement, unsigned clock shifts, and floor/ceiling lifetime are
implemented. Calendar tests include 150 independent Python Gregorian/ISO cases
and 100 documented timediff round trips. Localtime/utc remain UTC no-ops.

formatting.rs now handles missing/NULL format, dynamic width/precision, integer
signs/prefixes/precision, unsigned 64-bit values, exponential/general formatting,
comma grouping, character widths, repeated characters, SQL quote escaping and
unistr control-code escapes. Output/field size guards reject huge allocations.
Floating-point decimal rounding and very high precision still differ from native
SQLite's custom formatter. Byte precision cutting a UTF-8 sequence is represented
with replacement characters because protocol text uses valid Rust UTF-8 strings.

Binding checks row-value widths in scalar/comparison/CASE/IN contexts, including
empty inputs and lazy expressions. CASE evaluates its base once. UPDATE tuple
subqueries evaluate once per row and require exact assignment width. RowAccess's
serialized width field has a default for earlier snapshots. INSERT/view inputs
validate column counts even when no rows are selected. UPSERT assignment names,
generated targets, expressions and filters bind before conflict execution; rowid
updates work. Rightmost duplicate assignment wins without evaluating overwritten
expressions. VALUES expressions now receive static validation too.

Window bounds parse complete expressions and split clauses outside quoted strings,
parentheses and CASE expressions. They require constant, finite, nonnegative
numeric values (integral for ROWS/GROUPS), including during static binding.
Lag/lead use checked integer offsets; nth_value and LIMIT/OFFSET reject fractional
or out-of-domain integer values. All 1364 SQL/property checks and the multiprocess
persistence suite pass after these changes.


UPSERT now uses indexed expressions, partial-index predicates, collation matching,
reordered composite terms, actual index collisions, and first matching clause
precedence. Target metadata is serialized and visited by schema renames. Invalid
DO NOTHING WHERE, nonfinal targetless clauses, DEFAULT VALUES UPSERT and NULLS
ordering targets are rejected. Persistent trigger tests cover tuple assignments,
expression/partial targets, reopen, and column rename.

Writer locking now uses Rust standard-library File::try_lock rather than PID
sidecars. Stable .agent-lock files remain after closing; the OS releases their
locks even after SIGKILL. Six simultaneous writers performing 180 increments
preserve all updates. Injected temp-file failures during OR FAIL verify root lock
release and transient attached transaction rollback. Existing persistence limits
still apply: attached file commits are serial and not yet crash-atomic.

Next storage review: follow atomiccommit.txt multi-file rollback journals and
super-journal commit point to make attached snapshots recover together. Current
code remains integrated/passing; no group-journal implementation exists yet.
