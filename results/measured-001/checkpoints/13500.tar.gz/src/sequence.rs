use crate::{engine::*,ast::*,storage::*,value::Value,parser::Res};
impl Engine{
    fn stored_sequence_rows(&self,temp:bool)->Vec<Row>{
        let stored=if temp{&self.db.temp_sequence_rows}else{&self.db.sequence_rows};
        if let Some(rows)=stored{return rows.clone()}
        // Earlier snapshot versions stored just the per-table high-water marks.
        self.db.tables.values().filter(|t|t.def.temporary==temp&&t.def.cols.iter().any(|c|c.auto)&&t.sequence_written).enumerate().map(|(i,t)|Row{
            id:i as i64+1,values:vec![Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Integer(t.sequence)]
        }).collect()
    }
    fn sequence_rows_mut(&mut self,temp:bool)->&mut Vec<Row>{
        if (if temp{&self.db.temp_sequence_rows}else{&self.db.sequence_rows}).is_none(){
            let rows=self.stored_sequence_rows(temp);
            if temp{self.db.temp_sequence_rows=Some(rows)}else{self.db.sequence_rows=Some(rows)}
        }
        if temp{self.db.temp_sequence_rows.as_mut().unwrap()}else{self.db.sequence_rows.as_mut().unwrap()}
    }
    fn sequence_table(&self,temp:bool)->Res<Table>{
        if !(if temp{self.db.temp_sequence_exists}else{self.db.sequence_exists}){return Err("no such table: sqlite_sequence".into())}
        Ok(Table{
            def:TableDef{name:if temp{"temp.sqlite_sequence"}else{"sqlite_sequence"}.into(),cols:["name","seq"].iter().map(|name|Column{name:(*name).into(),collate:"BINARY".into(),..Default::default()}).collect(),temporary:temp,sql:"CREATE TABLE sqlite_sequence(name,seq)".into(),..Default::default()},
            rows:self.stored_sequence_rows(temp),sequence:0,sequence_written:false
        })
    }
    pub fn sequence_relation(&self,temp:bool)->Res<Relation>{
        let t=self.sequence_table(temp)?;Ok(self.table_relation(&t,&t.def.name))
    }
    pub(crate) fn record_sequence(&mut self,t:&Table)->Res<()>{
        let name=t.def.name.trim_start_matches("temp.");
        let rows=self.sequence_rows_mut(t.def.temporary);
        if let Some(row)=rows.iter_mut().find(|r|matches!(&r.values[0],Value::Text(n) if n==name)){
            row.values[1]=Value::Integer(t.sequence);
        }else{
            let maximum=rows.iter().map(|r|r.id).max().unwrap_or(0);
            let id=if let Some(id)=maximum.checked_add(1){id}else{
                let mut chosen=None;
                for _ in 0..100{
                    let id=crate::functions::scalar("random",&[],false)?.int().unsigned_abs().min(i64::MAX as u64) as i64;
                    if id>0&&!rows.iter().any(|r|r.id==id){chosen=Some(id);break}
                }
                chosen.ok_or("database or disk is full")?
            };
            rows.push(Row{id,values:vec![Value::Text(name.into()),Value::Integer(t.sequence)]});
        }
        Ok(())
    }
    pub(crate) fn remove_sequence(&mut self,t:&Table){
        if t.def.cols.iter().any(|c|c.auto){
            let name=t.def.name.trim_start_matches("temp.");
            self.sequence_rows_mut(t.def.temporary).retain(|r|!matches!(&r.values[0],Value::Text(n) if n==name));
        }
    }
    pub(crate) fn rename_sequence(&mut self,t:&Table,new:&str){
        if t.def.cols.iter().any(|c|c.auto){
            let name=t.def.name.trim_start_matches("temp.");
            for row in self.sequence_rows_mut(t.def.temporary){
                if matches!(&row.values[0],Value::Text(n) if n==name){row.values[0]=Value::Text(new.trim_start_matches("temp.").into());}
            }
        }
    }
    pub fn sequence_target(&self,s:&Statement)->Option<bool>{
        let name=match s{Statement::Insert{table,..}|Statement::Update{table,..}|Statement::Delete{table,..}=>table,_=>return None};
        let temp=if name.eq_ignore_ascii_case("temp.sqlite_sequence"){true}
            else if name.eq_ignore_ascii_case("main.sqlite_sequence"){false}
            else if name.eq_ignore_ascii_case("sqlite_sequence"){self.db.temp_sequence_exists}
            else{return None};
        let name=if temp{"temp.sqlite_sequence"}else{"sqlite_sequence"};
        if self.db.tables.contains_key(name){None}else{Some(temp)}
    }
    pub fn modify_sequence(&mut self,s:Statement,temp:bool)->Res<Relation>{
        let table=self.sequence_table(temp)?;
        let name=table.def.name.clone();
        self.db.tables.insert(name.clone(),table);
        let result=self.run(s);
        let system=self.db.tables.remove(&name).unwrap();
        for t in self.db.tables.values_mut().filter(|t|t.def.temporary==temp&&t.def.cols.iter().any(|c|c.auto)){
            let name=t.def.name.trim_start_matches("temp.");
            if let Some(row)=system.rows.iter().find(|r|matches!(&r.values[0],Value::Text(n) if n==name)){
                t.sequence=row.values[1].int();t.sequence_written=true;
            }else{t.sequence=0;t.sequence_written=false;}
        }
        if temp{self.db.temp_sequence_rows=Some(system.rows)}else{self.db.sequence_rows=Some(system.rows)}
        result
    }
}
