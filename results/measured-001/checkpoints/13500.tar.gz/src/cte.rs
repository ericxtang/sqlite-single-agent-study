use crate::{ast::*,parser::Res,storage::key};
use std::collections::BTreeMap;

fn expression(e:&Expr,out:&mut Vec<String>)->Res<()>{
    match e{
        Expr::Subquery(q)|Expr::Exists(q)=>out.extend(query_references(q)?),
        Expr::Tuple(es)=>for e in es{expression(e,out)?;},
        Expr::RowAccess(e,..)|Expr::Unary(_,e)|Expr::Cast(e,_)|Expr::Collate(e,_)=>expression(e,out)?,
        Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>{expression(a,out)?;expression(b,out)?;}
        Expr::Between(a,b,c,_)=>{expression(a,out)?;expression(b,out)?;expression(c,out)?;}
        Expr::In(e,es,q,_)=>{expression(e,out)?;for e in es{expression(e,out)?;}if let Some(q)=q{out.extend(query_references(q)?);}}
        Expr::Case(base,arms,other)=>{if let Some(e)=base{expression(e,out)?;}for(a,b)in arms{expression(a,out)?;expression(b,out)?;}if let Some(e)=other{expression(e,out)?;}}
        Expr::Call{args,filter,order,over,..}=>{
            for e in args{expression(e,out)?;}if let Some(e)=filter{expression(e,out)?;}
            for o in order{expression(&o.expr,out)?;}
            if let Some(w)=over{for e in &w.partition{expression(e,out)?;}for o in &w.order{expression(&o.expr,out)?;}}
        }
        _=>{}
    }
    Ok(())
}
fn source(s:&Source,out:&mut Vec<String>)->Res<()>{
    match s{
        Source::Table(name,_,args)=>{out.push(key(name));for e in args{expression(e,out)?;}}
        Source::Indexed(s,_)=>source(s,out)?,
        Source::Query(q,_)=>out.extend(query_references(q)?),
        Source::Join(a,b,_,on,_,_)=>{source(a,out)?;source(b,out)?;if let Some(e)=on{expression(e,out)?;}}
    }
    Ok(())
}
pub(crate) fn select_references(s:&Select)->Res<Vec<String>>{
    let mut out=vec![];
    if let Some(s)=&s.from{source(s,&mut out)?;}
    for item in &s.items{expression(&item.expr,&mut out)?;}
    for e in s.filter.iter().chain(s.having.iter()).chain(s.group.iter()){expression(e,&mut out)?;}
    if let Some(rows)=&s.values{for row in rows{for e in row{expression(e,&mut out)?;}}}
    for(_,w)in &s.windows{for e in &w.partition{expression(e,&mut out)?;}for o in &w.order{expression(&o.expr,&mut out)?;}}
    Ok(out)
}
fn roots(q:&Query)->Res<Vec<String>>{
    let mut out=vec![];
    for s in &q.cores{out.extend(select_references(s)?);}
    for o in &q.order{expression(&o.expr,&mut out)?;}
    for e in q.limit.iter().chain(q.offset.iter()){expression(e,&mut out)?;}
    Ok(out)
}
fn resolve(ctes:&[Cte],roots:Vec<String>)->Res<(Vec<usize>,Vec<String>)>{
    let mut names=BTreeMap::new();
    for(i,c)in ctes.iter().enumerate(){if names.insert(key(&c.name),i).is_some(){return Err(format!("duplicate WITH table name: {}",c.name))}}
    fn visit(i:usize,ctes:&[Cte],names:&BTreeMap<String,usize>,state:&mut [u8],order:&mut Vec<usize>,external:&mut Vec<String>)->Res<()>{
        if state[i]==2{return Ok(())}
        if state[i]==1{return Err(format!("circular reference: {}",ctes[i].name))}
        if state.iter().filter(|s|**s==1).count()>=100{return Err("CTE dependency depth limit exceeded".into())}
        state[i]=1;
        for name in query_references(&ctes[i].query)?{
            if let Some(&j)=names.get(&name){if i!=j{visit(j,ctes,names,state,order,external)?;}}
            else{external.push(name)}
        }
        state[i]=2;order.push(i);Ok(())
    }
    let mut state=vec![0;ctes.len()];let mut order=vec![];let mut external=vec![];
    for name in roots{
        if let Some(&i)=names.get(&name){visit(i,ctes,&names,&mut state,&mut order,&mut external)?;}
        else{external.push(name)}
    }
    Ok((order,external))
}
fn query_references(q:&Query)->Res<Vec<String>>{Ok(resolve(&q.ctes,roots(q)?)?.1)}
pub(crate) fn query_order(q:&Query)->Res<Vec<usize>>{Ok(resolve(&q.ctes,roots(q)?)?.0)}
pub(crate) fn statement_order(ctes:&[Cte],stmt:&Statement)->Res<Vec<usize>>{
    let mut out=vec![];
    match stmt{
        Statement::Query(q)=>out.extend(query_references(q)?),
        Statement::IndexGuard(s,_)=>return statement_order(ctes,s),
        Statement::Insert{query,upsert,returning,..}=>{
            if let Some(q)=query{out.extend(query_references(q)?);}
            for u in upsert{for(_,e)in &u.assignments{expression(e,&mut out)?;}if let Some(e)=&u.filter{expression(e,&mut out)?;}}
            for item in returning{expression(&item.expr,&mut out)?;}
        }
        Statement::Update{assignments,filter,from,order,limit,returning,..}=>{
            if let Some(s)=from{source(s,&mut out)?;}
            for(_,e)in assignments{expression(e,&mut out)?;}
            for e in filter.iter().chain(limit.iter()){expression(e,&mut out)?;}
            for o in order{expression(&o.expr,&mut out)?;}
            for item in returning{expression(&item.expr,&mut out)?;}
        }
        Statement::Delete{filter,order,limit,returning,..}=>{
            for e in filter.iter().chain(limit.iter()){expression(e,&mut out)?;}
            for o in order{expression(&o.expr,&mut out)?;}
            for item in returning{expression(&item.expr,&mut out)?;}
        }
        _=>{}
    }
    Ok(resolve(ctes,out)?.0)
}
fn direct_count(s:&Source,name:&str)->usize{
    match s{
        Source::Table(n,_,_)=>usize::from(n.eq_ignore_ascii_case(name)),
        Source::Indexed(s,_)=>direct_count(s,name),
        Source::Join(a,b,..)=>direct_count(a,name)+direct_count(b,name),
        Source::Query(..)=>0
    }
}
pub(crate) fn recursive_anchor(c:&Cte)->Res<Option<usize>>{
    let references=c.query.cores.iter().map(|s|{
        if c.query.ctes.is_empty(){select_references(s)}else{
            query_references(&Query{ctes:c.query.ctes.clone(),cores:vec![s.clone()],..Default::default()})
        }
    }).collect::<Res<Vec<_>>>()?;
    let Some(anchor)=references.iter().position(|names|names.iter().any(|n|n.eq_ignore_ascii_case(&c.name)))else{return Ok(None)};
    if anchor==0{return Err(format!("circular reference: {}",c.name))}
    let operator=&c.query.ops[anchor-1];
    if !["UNION","UNION ALL"].contains(&operator.as_str())||c.query.ops[anchor-1..].iter().any(|o|o!=operator){return Err("recursive terms must use the same UNION operator".into())}
    for(s,names)in c.query.cores[anchor..].iter().zip(&references[anchor..]){
        if s.from.as_ref().map(|s|direct_count(s,&c.name)).unwrap_or(0)!=1||names.iter().filter(|n|n.eq_ignore_ascii_case(&c.name)).count()!=1{
            return Err(format!("invalid recursive reference: {}",c.name))
        }
        if !s.group.is_empty()||s.items.iter().map(|i|&i.expr).chain(s.having.iter()).any(|e|crate::engine::has_aggregate(e)||crate::engine::has_window(e)){
            return Err("aggregate and window functions are not permitted in recursive queries".into())
        }
    }
    Ok(Some(anchor))
}
