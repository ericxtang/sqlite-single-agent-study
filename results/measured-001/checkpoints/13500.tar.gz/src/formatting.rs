use crate::value::Value;

const MAX_OUTPUT:usize=16*1024*1024;
const MAX_FIELD:usize=1_000_000;

fn argument<'a>(args:&'a [Value],index:&mut usize)->&'a Value{
    let value=args.get(*index).unwrap_or(&Value::Null);
    *index+=1;
    value
}
fn field(chars:&[char],pos:&mut usize)->Result<usize,String>{
    let mut value=0usize;
    while let Some(d)=chars.get(*pos).and_then(|c|c.to_digit(10)){
        value=value.saturating_mul(10).saturating_add(d as usize);
        if value>MAX_FIELD{return Err("string or blob too big".into())}
        *pos+=1;
    }
    Ok(value)
}
fn group_digits(s:&str)->String{
    let end=s.bytes().take_while(u8::is_ascii_digit).count();
    let mut out=String::new();
    for (i,c) in s[..end].chars().enumerate(){
        if i>0&&(end-i)%3==0{out.push(',')}
        out.push(c);
    }
    out.push_str(&s[end..]);
    out
}
fn decimal_point(s:&mut String,one:bool){
    if !s.contains('.') {s.push('.')}
    if one&&s.ends_with('.') {s.push('0')}
}
fn float_body(value:f64,spec:char,precision:Option<usize>,alt:bool,wide:bool,zero:bool)->String{
    if value.is_infinite(){return if zero{"9.0e+999"}else{"Inf"}.into()}
    if value.is_nan(){return if zero{"null"}else{"NaN"}.into()}
    let prec=precision.unwrap_or(6).min(1000);
    let kind=spec.to_ascii_lowercase();
    let force=alt||wide;
    if kind=='f'{
        let mut s=format!("{:.*}",prec,value);
        if force{decimal_point(&mut s,wide)}
        return s
    }
    let significant=prec.max(1);
    let exponential=format!("{:.*e}",if kind=='g'{significant-1}else{prec},value);
    let (mantissa,exponent)=exponential.split_once('e').unwrap();
    let exp=exponent.parse::<i32>().unwrap_or(0);
    let scientific=kind=='e'||exp < -4||exp>=significant as i32;
    let mut body=if scientific{mantissa.to_string()}else{
        format!("{:.*}",(significant as i32-exp-1).max(0) as usize,value)
    };
    if kind=='g'&&body.contains('.'){
        while body.ends_with('0'){body.pop();}
        if body.ends_with('.') {body.pop();}
    }
    if force{decimal_point(&mut body,wide)}
    if scientific{
        body.push(if spec.is_ascii_uppercase(){'E'}else{'e'});
        body.push(if exp<0{'-'}else{'+'});
        body.push_str(&format!("{:02}",exp.unsigned_abs()));
    }
    body
}
fn string_input(v:&Value,precision:Option<usize>,characters:bool)->String{
    let s=v.text();
    let s=s.split('\0').next().unwrap_or("");
    match precision{
        None=>s.to_string(),
        Some(n) if characters=>s.chars().take(n).collect(),
        Some(n)=>String::from_utf8_lossy(&s.as_bytes()[..n.min(s.len())]).into_owned()
    }
}
pub fn format_sql(fmt:&str,args:&[Value])->Result<String,String>{
    let chars=fmt.split('\0').next().unwrap_or("").chars().collect::<Vec<_>>();
    let mut out=String::new();
    let(mut pos,mut index)=(0,0);
    while pos<chars.len(){
        if chars[pos]!='%'{out.push(chars[pos]);pos+=1;continue}
        pos+=1;
        if chars.get(pos)==Some(&'%'){out.push('%');pos+=1;continue}
        let mut flags=String::new();
        while chars.get(pos).is_some_and(|c|"-+ #!0,".contains(*c)){
            flags.push(chars[pos]);pos+=1;
        }
        let mut left=flags.contains('-');
        let width=if chars.get(pos)==Some(&'*'){
            pos+=1;
            let w=argument(args,&mut index).int();
            left|=w<0;
            let w=w.unsigned_abs();
            if w>MAX_FIELD as u64{return Err("string or blob too big".into())}
            w as usize
        }else{field(&chars,&mut pos)?};
        let precision=if chars.get(pos)==Some(&'.'){
            pos+=1;
            Some(if chars.get(pos)==Some(&'*'){
                pos+=1;
                let p=argument(args,&mut index).int().unsigned_abs();
                if p>MAX_FIELD as u64{return Err("string or blob too big".into())}
                p as usize
            }else{field(&chars,&mut pos)?})
        }else{None};
        if chars.get(pos)==Some(&'l'){
            pos+=1;
            if chars.get(pos)==Some(&'l'){pos+=1}
        }
        let Some(&spec)=chars.get(pos) else{break};pos+=1;
        if spec=='n'{continue}
        let value=argument(args,&mut index);
        let (alt,wide,zero)=(flags.contains('#'),flags.contains('!'),flags.contains('0')&&!left);
        let mut prefix=String::new();
        let numeric="diuxXopfFeEgG".contains(spec);
        let mut body=match spec{
            'd'|'i'|'u'|'x'|'X'|'o'|'p'=>{
                let signed=matches!(spec,'d'|'i');
                let number=if signed{value.int().unsigned_abs()}else{value.int() as u64};
                if signed{
                    if value.int()<0{prefix.push('-')}
                    else if flags.contains('+'){prefix.push('+')}
                    else if flags.contains(' '){prefix.push(' ')}
                }
                let mut digits=match spec{'x'=>format!("{:x}",number),'X'|'p'=>format!("{:X}",number),'o'=>format!("{:o}",number),_=>number.to_string()};
                if let Some(p)=precision{
                    if digits.len()<p{digits="0".repeat(p-digits.len())+&digits}
                }
                if alt&&number!=0{
                    match spec{'x'=>prefix.push_str("0x"),'X'|'p'=>prefix.push_str("0X"),'o'=>if !digits.starts_with('0'){prefix.push('0')},_=>{}}
                }
                digits
            }
            'f'|'e'|'E'|'g'|'G'=>{
                let f=value.float();
                let body=float_body(f.abs(),spec,precision,alt,wide,zero);
                let rounded_zero=body.chars().all(|c|c=='0'||c=='.');
                if f<0.0&&!(spec=='f'&&alt&&!flags.contains('+')&&rounded_zero){prefix.push('-')}
                else if flags.contains('+'){prefix.push('+')}
                else if flags.contains(' '){prefix.push(' ')}
                body
            }
            's'|'z'|'q'|'Q'|'w'=>{
                if spec=='Q'&&value.null(){"NULL".into()}else{
                    let input=string_input(value,precision,wide);
                    let controls=input.chars().any(|c|('\u{1}'..='\u{1f}').contains(&c));
                    let escape=alt&&(spec=='q'||(spec=='Q'&&controls));
                    let mut escaped=String::new();
                    for c in input.chars(){
                        if (matches!(spec,'q'|'Q')&&c=='\'')||(spec=='w'&&c=='"'){escaped.push(c);escaped.push(c)}
                        else if escape&&c=='\\'{escaped.push_str("\\\\")}
                        else if escape&&('\u{1}'..='\u{1f}').contains(&c){escaped.push_str(&format!("\\u{:04x}",c as u32))}
                        else{escaped.push(c)}
                    }
                    if spec=='Q'{
                        if escape{format!("unistr('{}')",escaped)}else{format!("'{}'",escaped)}
                    }else{escaped}
                }
            }
            'c'=>value.text().chars().next().unwrap_or('\0').to_string().repeat(precision.unwrap_or(1).max(1)),
            _=>break
        };
        if numeric&&flags.contains(','){body=group_digits(&body)}
        let length=prefix.len()+if wide{body.chars().count()}else{body.len()};
        let padding=width.saturating_sub(length);
        if out.len().saturating_add(prefix.len()+body.len()+padding)>MAX_OUTPUT{return Err("string or blob too big".into())}
        if left{
            out.push_str(&prefix);out.push_str(&body);out.push_str(&" ".repeat(padding));
        }else if numeric&&zero{
            out.push_str(&prefix);out.push_str(&"0".repeat(padding));out.push_str(&body);
        }else{
            out.push_str(&" ".repeat(padding));out.push_str(&prefix);out.push_str(&body);
        }
    }
    Ok(out)
}
