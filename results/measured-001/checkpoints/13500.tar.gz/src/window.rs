use crate::{
    engine::*,ast::*,value::{
        Value,compare
    }
    ,parser::Res
}
;
use std::cmp::Ordering;
impl Engine{
    pub fn eval_window_expr(&self,e:&Expr,env:&Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize,all:&[WindowInput],pos:usize,windows:&[(String,Window)])->Res<Value>{
        let transformed=self.replace_windows(e,env,group,ctes,depth,all,pos,windows)?;
        self.eval(&transformed,env,group,ctes,depth)
    }
    pub fn replace_windows(&self,e:&Expr,env:&Env,group:Option<&[Env]>,ctes:&Ctes,depth:usize,all:&[WindowInput],pos:usize,windows:&[(String,Window)])->Res<Expr>{
        let sub=|e:&Expr|self.replace_windows(e,env,group,ctes,depth,all,pos,windows);
        Ok(match e{
            Expr::Call{
                name,args,distinct,filter,order,over:Some(w)
            }
            =>{
                let w=resolve_window(w,windows,&mut vec![])?;
                frame_spec(&w)?;
                let keys=w.partition.iter().map(|e|self.eval(e,env,group,ctes,depth)).collect::<Res<Vec<_>>>()?;
                let mut members=vec![];
                for(i,e)in all.iter().enumerate(){
                    let k=w.partition.iter().map(|x|self.eval(x,&e.env,e.group.as_deref(),ctes,depth)).collect::<Res<Vec<_>>>()?;
                    if k.iter().zip(&keys).zip(&w.partition).all(|((a,b),expr)|compare(a,b,&self.meta(expr,env).1)==Ordering::Equal){
                        let sort=w.order.iter().map(|o|self.eval(&o.expr,&e.env,e.group.as_deref(),ctes,depth)).collect::<Res<Vec<_>>>()?;
                        members.push((i,e.clone(),sort))
                    }
                }
                members.sort_by(|a,b|{
                    for(i,o)in w.order.iter().enumerate(){
                        let x=&a.2[i];let y=&b.2[i];
                        let c=if x.null()!=y.null() {let first=o.nulls.unwrap_or(!o.desc);if x.null()==first{Ordering::Less}else{Ordering::Greater}}else{let c=compare(x,y,&self.meta(&o.expr,&a.1.env).1);if o.desc{c.reverse()}else{c}};
                        if c!=Ordering::Equal{return c}
                    }
                    Ordering::Equal
                }
                );
                let p=members.iter().position(|(i,_,_)|*i==pos).unwrap_or(0);
                let len=members.len();
                if len==0{
                    return Ok(Expr::Lit(Value::Null))
                }
                let peers=|i:usize,j:usize|members[i].2.iter().zip(&members[j].2).zip(&w.order).all(|((a,b),o)|compare(a,b,&self.meta(&o.expr,&members[i].1.env).1)==Ordering::Equal);
                let first=(0..=p).find(|i|peers(*i,p)).unwrap_or(p);
                let last=(p..len).rev().find(|i|peers(*i,p)).unwrap_or(p);
                let n=name.to_ascii_lowercase();
                let value=match n.as_str(){
                    "row_number"=>Value::Integer(p as i64+1),"rank"=>Value::Integer(first as i64+1),"dense_rank"=>{
                        let count=(1..=p).filter(|i|!peers(*i,*i-1)).count();
                        Value::Integer(count as i64+1)
                    }
                    ,"percent_rank"=>Value::Real(if len<=1{
                        0.0
                    }
                    else{
                        first as f64/(len-1) as f64
                    }
                    ),"cume_dist"=>Value::Real((last+1) as f64/len as f64),"ntile"=>{
                        let n=self.eval(args.first().ok_or("wrong number of arguments")?,env,group,ctes,depth)?.int();
                        if n<=0{
                            return Err("argument of ntile must be a positive integer".into())
                        }
                        let n=n as usize;
                        let small=len/n;
                        let extra=len%n;
                        let cutoff=(small+1)*extra;
                        let bucket=if p<cutoff{
                            p/(small+1)
                        }
                        else{
                            extra+(p-cutoff)/small.max(1)
                        }
                        ;
                        Value::Integer(bucket as i64+1)
                    }
                    ,"lag"|"lead"=>{
                        if args.is_empty()||args.len()>3{
                            return Err("wrong number of arguments".into())
                        }
                        let offset=args.get(1).map(|e|self.eval(e,env,group,ctes,depth).and_then(|v|integer_limit(&v))).transpose()?.unwrap_or(1);
                        if offset<0{return Err("offset must be a non-negative integer".into())}
                        let idx=if n=="lead"{(p as i64).checked_add(offset)}else{(p as i64).checked_sub(offset)};
                        if let Some(idx)=idx.filter(|i|*i>=0&&(*i as usize)<len){
                            self.eval(&args[0],&members[idx as usize].1.env,members[idx as usize].1.group.as_deref(),ctes,depth)?
                        }
                        else{
                            args.get(2).map(|e|self.eval(e,env,group,ctes,depth)).unwrap_or(Ok(Value::Null))?
                        }
                    }
                    ,_=>{
                        let frame=self.window_frame(&w,&members,p,first,last,ctes,depth)?.into_iter().map(|i|members[i].1.clone()).collect::<Vec<_>>();
                        if n=="first_value"||n=="last_value"||n=="nth_value"{
                            let idx=if n=="first_value"{
                                0
                            }
                            else if n=="last_value"{
                                frame.len().saturating_sub(1)
                            }
                            else{
                                let n=integer_limit(&self.eval(args.get(1).ok_or("wrong number of arguments")?,env,group,ctes,depth)?)?;
                                if n<1{
                                    return Err("second argument to nth_value must be a positive integer".into())
                                }
                                n as usize-1
                            }
                            ;
                            if let Some(e)=frame.get(idx){
                                self.eval(args.first().ok_or("wrong number of arguments")?,&e.env,e.group.as_deref(),ctes,depth)?
                            }
                            else{
                                Value::Null
                            }
                        }
                        else{
                            let mut bound_args=vec![];
                            for(i,arg)in args.iter().enumerate(){
                                bound_args.push(if matches!(arg,Expr::Star(_)){
                                    arg.clone()
                                }
                                else{
                                    Expr::Col(vec!["__window".into(),format!("arg{}",i)])
                                }
                                )
                            }
                            let bound_filter=filter.as_ref().map(|_|Box::new(Expr::Col(vec!["__window".into(),"filter".into()])));
                            let mut bound_frame=vec![];
                            for input in &frame{
                                let mut row=input.env.clone();
                                for(i,arg)in args.iter().enumerate(){
                                    if matches!(arg,Expr::Star(_)){
                                        continue
                                    }
                                    let value=self.eval(arg,&input.env,input.group.as_deref(),ctes,depth)?;
                                    let mut field=Field::new(&format!("arg{}",i));
                                    field.table="__window".into();
                                    let(a,c)=self.meta(arg,&input.env);
                                    field.affinity=a;
                                    field.collate=c;
                                    row.fields.push(field);
                                    row.values.push(value);
                                }
                                if let Some(f)=filter{
                                    let value=self.eval(f,&input.env,input.group.as_deref(),ctes,depth)?;
                                    let mut field=Field::new("filter");
                                    field.table="__window".into();
                                    row.fields.push(field);
                                    row.values.push(value);
                                }
                                bound_frame.push(row);
                            }
                            let call=Expr::Call{
                                name:name.clone(),args:bound_args,distinct:*distinct,filter:bound_filter,order:order.clone(),over:None
                            }
                            ;
                            self.eval(&call,env,Some(&bound_frame),ctes,depth)?
                        }
                    }
                }
                ;
                Expr::Lit(value)
            }
            ,Expr::Case(b,arms,o)=>Expr::Case(b.as_ref().map(|e|sub(e).map(Box::new)).transpose()?,arms.iter().map(|(a,b)|Ok((sub(a)?,sub(b)?))).collect::<Res<_>>()?,o.as_ref().map(|e|sub(e).map(Box::new)).transpose()?),Expr::Is(a,b,n)=>Expr::Is(Box::new(sub(a)?),Box::new(sub(b)?),*n),Expr::Between(a,b,c,n)=>Expr::Between(Box::new(sub(a)?),Box::new(sub(b)?),Box::new(sub(c)?),*n),Expr::Binary(o,a,b)=>Expr::Binary(o.clone(),Box::new(sub(a)?),Box::new(sub(b)?)),Expr::Unary(o,e)=>Expr::Unary(o.clone(),Box::new(sub(e)?)),Expr::Cast(e,t)=>Expr::Cast(Box::new(sub(e)?),t.clone()),Expr::Collate(e,c)=>Expr::Collate(Box::new(sub(e)?),c.clone()),Expr::Call{
                name,args,distinct,filter,order,over
            }
            =>Expr::Call{
                name:name.clone(),args:args.iter().map(sub).collect::<Res<_>>()?,distinct:*distinct,filter:filter.clone(),order:order.clone(),over:over.clone()
            }
            ,Expr::Tuple(es)=>Expr::Tuple(es.iter().map(sub).collect::<Res<_>>()?),
            Expr::RowAccess(e,i,width)=>Expr::RowAccess(Box::new(sub(e)?),*i,*width),
            Expr::In(e,es,q,not)=>Expr::In(Box::new(sub(e)?),es.iter().map(sub).collect::<Res<_>>()?,q.clone(),*not),
            _=>e.clone()
        }
        )
    }
}
#[derive(Clone,Copy)]enum Bound{
    BeforeAll,AfterAll,Current,Offset(f64,bool)
}
impl Engine{
    fn frame_offset(&self,e:&Expr,kind:&str)->Res<f64>{
        self.validate_schema_expression(e,&Env::default(),"window frame bounds",true)?;
        let value=crate::validate::evaluate_constant(||self.eval_schema(e,&Env::default()))?;
        let value=value.apply(crate::value::Affinity::Numeric);
        if !matches!(value,Value::Integer(_)|Value::Real(_))||!value.float().is_finite()||value.float()<0.0{
            return Err("frame offset must be a non-negative number".into())
        }
        if kind!="RANGE"{integer_limit(&value).map_err(|_|"frame offset must be a non-negative integer".to_string())?;}
        Ok(value.float())
    }
    pub(crate) fn validate_window_frame(&self,w:&Window)->Res<()>{
        let(kind,start,end,_)=frame_spec(w)?;
        for bound in [start,end]{
            if bound.starts_with("UNBOUNDED ")||bound=="CURRENT ROW"{continue}
            let expr=bound.strip_suffix(" PRECEDING").or_else(||bound.strip_suffix(" FOLLOWING")).ok_or("invalid window frame")?;
            self.frame_offset(&parse_frame_expression(expr)?,&kind)?;
        }
        Ok(())
    }
    fn window_frame(&self,w:&Window,m:&[(usize,WindowInput,Vec<Value>)],p:usize,first:usize,last:usize,_ctes:&Ctes,_depth:usize)->Res<Vec<usize>>{
        let(kind,a,b,exclude)=frame_spec(w)?;
        let parse=|s:&str|->Res<Bound>{
            match s{
                "UNBOUNDED PRECEDING"=>Ok(Bound::BeforeAll),"UNBOUNDED FOLLOWING"=>Ok(Bound::AfterAll),"CURRENT ROW"=>Ok(Bound::Current),_=>{
                    let (expr,pre)=if let Some(e)=s.strip_suffix(" PRECEDING"){
                        (e,true)
                    }
                    else if let Some(e)=s.strip_suffix(" FOLLOWING"){
                        (e,false)
                    }
                    else{
                        return Err("invalid window frame".into())
                    }
                    ;
                    let e=parse_frame_expression(expr)?;
                    let offset=self.frame_offset(&e,&kind)?;
                    Ok(Bound::Offset(offset,pre))
                }
            }
        }
        ;
        let lo=parse(&a)?;
        let hi=parse(&b)?;
        if matches!(lo,Bound::AfterAll)||matches!(hi,Bound::BeforeAll){
            return Err("unsupported frame specification".into())
        }
        let mut groups=vec![0usize;
        m.len()];
        for i in 1..m.len(){
            let same=m[i].2.iter().zip(&m[i-1].2).zip(&w.order).all(|((x,y),o)|compare(x,y,&self.meta(&o.expr,&m[i].1.env).1)==Ordering::Equal);
            groups[i]=groups[i-1]+usize::from(!same)
        }
        let peer=|i:usize|groups[i]==groups[p];
        let raw=|bound:Bound,current:i64|->i64{
            match bound{
                Bound::BeforeAll=>i64::MIN,Bound::AfterAll=>i64::MAX,Bound::Current=>current,Bound::Offset(n,pre)=>if pre{
                    current.saturating_sub(n as i64)
                }
                else{
                    current.saturating_add(n as i64)
                }
            }
        }
        ;
        let mut out=vec![];
        if kind=="RANGE"&&(matches!(lo,Bound::Offset(..))||matches!(hi,Bound::Offset(..)))&&w.order.len()!=1{
            return Err("RANGE with offset requires one ORDER BY expression".into())
        }
        for i in 0..m.len(){
            let inside=if kind=="ROWS"{
                let i=i as i64;
                i>=raw(lo,p as i64)&&i<=raw(hi,p as i64)
            }
            else if kind=="GROUPS"{
                let g=groups[i] as i64;
                g>=raw(lo,groups[p] as i64)&&g<=raw(hi,groups[p] as i64)
            }
            else{
                let test=|bound:Bound,start:bool|->bool{
                    match bound{
                        Bound::BeforeAll=>true,Bound::AfterAll=>true,Bound::Current=>if start{
                            i>=first
                        }
                        else{
                            i<=last
                        }
                        ,Bound::Offset(n,pre)=>{
                            let x=&m[i].2[0];
                            let c=&m[p].2[0];
                            if !matches!(x,Value::Integer(_)|Value::Real(_))||!matches!(c,Value::Integer(_)|Value::Real(_)){
                                return if start{
                                    i>=first
                                }
                                else{
                                    i<=last
                                }
                            }
                            let direction=if w.order[0].desc{
                                -1.0
                            }
                            else{
                                1.0
                            }
                            ;
                            let boundary=c.float()*direction+if pre{
                                -n
                            }
                            else{
                                n
                            }
                            ;
                            if start{
                                x.float()*direction>=boundary
                            }
                            else{
                                x.float()*direction<=boundary
                            }
                        }
                    }
                }
                ;
                test(lo,true)&&test(hi,false)
            }
            ;
            if inside&&match exclude.as_str(){
                "CURRENT ROW"=>i!=p,"GROUP"=>!peer(i),"TIES"=>i==p||!peer(i),_=>true
            }
            {
                out.push(i)
            }
        }
        Ok(out)
    }
}

pub fn resolve_expression(e:&mut Expr,windows:&[(String,Window)])->Res<()> {
    let sub=|e:&mut Expr|resolve_expression(e,windows);
    match e {
        Expr::Call{args,filter,order,over,..}=>{
            for arg in args{sub(arg)?;}if let Some(f)=filter{sub(f)?;}for o in order{sub(&mut o.expr)?;}
            if let Some(w)=over{let resolved=resolve_window(w,windows,&mut vec![])?;frame_spec(&resolved)?;*w=resolved;}
        },
        Expr::Tuple(es)=>for e in es{sub(e)?;},
        Expr::RowAccess(e,_,_)|Expr::Unary(_,e)|Expr::Cast(e,_)|Expr::Collate(e,_)=>sub(e)?,
        Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>{sub(a)?;sub(b)?;},
        Expr::Between(a,b,c,_)=>{sub(a)?;sub(b)?;sub(c)?;},
        Expr::In(e,es,_,_)=>{sub(e)?;for e in es{sub(e)?;}},
        Expr::Case(e,arms,other)=>{if let Some(e)=e{sub(e)?;}for(a,b)in arms{sub(a)?;sub(b)?;}if let Some(e)=other{sub(e)?;}},
        _=>{}
    }
    Ok(())
}
fn resolve_window(w:&Window,windows:&[(String,Window)],stack:&mut Vec<String>)->Res<Window> {
    let Some(name)=&w.name else{return Ok(w.clone())};
    if stack.iter().any(|n|n.eq_ignore_ascii_case(name)){return Err("circular window definition".into())}
    let base=windows.iter().find(|(n,_)|n.eq_ignore_ascii_case(name)).ok_or(format!("no such window: {}",name))?;
    stack.push(name.clone());let base=resolve_window(&base.1,windows,stack)?;stack.pop();
    if w.direct{return Ok(base)}
    if !w.partition.is_empty(){return Err("cannot override PARTITION clause of window".into())}
    if !w.order.is_empty()&&!base.order.is_empty(){return Err("cannot override ORDER BY clause of window".into())}
    if !base.frame.is_empty(){return Err("cannot override frame specification of window".into())}
    let mut result=w.clone();result.name=None;result.partition=base.partition;
    if result.order.is_empty(){result.order=base.order;}
    Ok(result)
}
fn frame_spec(w:&Window)->Res<(String,String,String,String)> {
    if w.frame.is_empty(){return Ok(("RANGE".into(),"UNBOUNDED PRECEDING".into(),"CURRENT ROW".into(),"NO OTHERS".into()))}
    let kind=&w.frame[0];if !["RANGE","ROWS","GROUPS"].contains(&kind.as_str()){return Err("invalid window frame".into())}
    let text=w.frame[1..].join(" ");let(rest,exclude)=split_frame_clause(&text,"EXCLUDE")?.unwrap_or((&text,"NO OTHERS"));
    if !["NO OTHERS","CURRENT ROW","GROUP","TIES"].contains(&exclude){return Err("invalid EXCLUDE clause".into())}
    let(start,end)=if let Some(rest)=rest.strip_prefix("BETWEEN "){split_frame_clause(rest,"AND")?.ok_or("invalid window frame")?}else{(rest,"CURRENT ROW")};
    let category=|s:&str|->Res<u8>{Ok(match s {"UNBOUNDED PRECEDING"=>0,"CURRENT ROW"=>2,"UNBOUNDED FOLLOWING"=>4,_=>{
        if let Some(expr)=s.strip_suffix(" PRECEDING"){parse_frame_expression(expr)?;1}
        else if let Some(expr)=s.strip_suffix(" FOLLOWING"){parse_frame_expression(expr)?;3}
        else{return Err("invalid window frame".into())}
    }})};
    let a=category(start)?;let b=category(end)?;
    if a>b||a==4||b==0{return Err("unsupported frame specification".into())}
    if kind=="RANGE"&&[a,b].iter().any(|n|*n==1||*n==3)&&w.order.len()!=1{return Err("RANGE with offset requires one ORDER BY expression".into())}
    Ok((kind.clone(),start.into(),end.into(),exclude.into()))
}

fn parse_frame_expression(text:&str)->Res<Expr>{
    let mut parser=crate::parser::Parser::new(text)?;
    let expression=parser.expr()?;
    if parser.peek().kind!=crate::lexer::Kind::Eof{return Err("invalid window frame expression".into())}
    Ok(expression)
}
fn split_frame_clause<'a>(text:&'a str,keyword:&str)->Res<Option<(&'a str,&'a str)>>{
    let mut nesting=0usize;
    for token in crate::lexer::lex(text)?{
        if matches!(token.kind,crate::lexer::Kind::Str|crate::lexer::Kind::Quoted){continue}
        let word=token.text.to_ascii_uppercase();
        if word=="("||word=="CASE"{nesting+=1}
        else if word==")"||word=="END"{nesting=nesting.saturating_sub(1)}
        else if nesting==0&&word==keyword{return Ok(Some((text[..token.start].trim(),text[token.end..].trim())))}
    }
    Ok(None)
}
