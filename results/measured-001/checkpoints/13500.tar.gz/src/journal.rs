// The snapshot format uses the multi-file protocol described in atomiccommit.txt:
// durable before-images, a durable super-journal, then database publication;
// deleting the super-journal is the commit point.
use crate::storage::{self,Database,WriteLock};
use std::{fs,io::Write,path::{Path,PathBuf},sync::atomic::{AtomicU64,Ordering}};
const HEADER:&[u8]=b"RustSQLite rollback 1\n";
fn journal_path(database:&Path)->PathBuf{
    let mut name=database.as_os_str().to_os_string();name.push(".agent-journal");PathBuf::from(name)
}
fn read_journal(database:&Path)->Result<Option<(PathBuf,Vec<u8>)>,String>{
    let bytes=match fs::read(journal_path(database)){
        Ok(bytes)=>bytes,Err(e) if e.kind()==std::io::ErrorKind::NotFound=>return Ok(None),Err(e)=>return Err(format!("disk I/O error: {}",e))
    };
    let body=bytes.strip_prefix(HEADER).ok_or("malformed rollback journal")?;
    let end=body.iter().position(|b|*b==b'\n').ok_or("malformed rollback journal")?;
    let master:String=serde_json::from_slice(&body[..end]).map_err(|_|"malformed rollback journal")?;
    let master=storage::confined(&master)?;
    let before=body[end+1..].to_vec();
    storage::decode(&before)?;
    Ok(Some((master,before)))
}
fn cleanup_master(master:&Path){
    let Ok(bytes)=fs::read(master)else{return};
    let Ok(paths)=serde_json::from_slice::<Vec<String>>(&bytes)else{return};
    if paths.iter().all(|p|storage::confined(p).is_ok_and(|p|!journal_path(&p).exists())){
        let _=fs::remove_file(master);let _=storage::sync_parent(master);
    }
}
pub(crate) fn recover_locked(database:&Path)->Result<(),String>{
    let Some((master,before))=read_journal(database)?else{return Ok(())};
    if master.exists(){storage::write_atomic(database,&before)?;}
    fs::remove_file(journal_path(database)).map_err(|e|format!("disk I/O error: {}",e))?;
    storage::sync_parent(database)?;
    cleanup_master(&master);
    Ok(())
}
pub(crate) fn read_committed(database:&Path)->Result<Option<Vec<u8>>,String>{
    let Some((master,before))=read_journal(database)?else{return Ok(None)};
    match WriteLock::acquire(database){
        Ok(_lock)=>{recover_locked(database)?;Ok(None)}
        Err(error) if error=="database is locked"=>{
            // A live writer can publish only after every before-image is durable.
            // Readers keep seeing the before-image until the commit point.
            if master.exists(){Ok(Some(before))}else{Ok(None)}
        }
        Err(error)=>Err(error)
    }
}
fn new_master(paths:&[PathBuf])->Result<PathBuf,String>{
    static NEXT:AtomicU64=AtomicU64::new(0);
    let time=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
    let path=PathBuf::from(format!("/work/.agent-master-{}-{}-{}",std::process::id(),time,NEXT.fetch_add(1,Ordering::Relaxed)));
    let bytes=serde_json::to_vec(paths).map_err(|e|e.to_string())?;
    let mut file=fs::OpenOptions::new().write(true).create_new(true).open(&path).map_err(|e|format!("disk I/O error: {}",e))?;
    if let Err(error)=file.write_all(&bytes).and_then(|_|file.sync_all()){
        let _=fs::remove_file(&path);return Err(format!("disk I/O error: {}",error))
    }
    storage::sync_parent(&path)?;
    Ok(path)
}
pub(crate) fn save_group(databases:&[(PathBuf,Database)],milliseconds:i64)->Result<(),String>{
    if databases.is_empty(){return Ok(())}
    let _publication=storage::VisibilityLock::write(milliseconds)?;
    if databases.len()==1{return storage::save(&databases[0].0,&databases[0].1)}
    let mut staged=vec![];
    let mut originals=vec![];
    // Prepare all new snapshots before changing any committed file.
    for(path,db)in databases{
        originals.push(fs::read(path).map_err(|e|format!("disk I/O error: {}",e))?);
        staged.push(storage::stage_bytes(path,&storage::encode(db)?)?);
    }
    let master=new_master(&databases.iter().map(|(p,_)|p.clone()).collect::<Vec<_>>())?;
    let mut journals=vec![];
    let result=(||{
        for((path,_),before)in databases.iter().zip(&originals){
            let journal=journal_path(path);
            let mut bytes=HEADER.to_vec();
            bytes.extend(serde_json::to_vec(&master).map_err(|e|e.to_string())?);bytes.push(b'\n');bytes.extend(before);
            storage::write_atomic(&journal,&bytes)?;
            journals.push(path.clone());
        }
        for stage in &mut staged{stage.publish()?;}
        fs::remove_file(&master).map_err(|e|format!("disk I/O error: {}",e))?;
        storage::sync_parent(&master)?;
        Ok(())
    })();
    // New-image temp files must be dropped before recovery creates its temp file.
    drop(staged);
    if result.is_err()&&master.exists(){
        for path in &journals{let _=recover_locked(path);}
    }else{
        for path in &journals{let _=fs::remove_file(journal_path(path));let _=storage::sync_parent(path);}
    }
    cleanup_master(&master);
    result
}
