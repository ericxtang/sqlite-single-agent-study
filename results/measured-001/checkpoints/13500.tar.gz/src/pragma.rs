use crate::{
    engine::*,storage::*,ast::*,value::Value,parser::Res
}
;
impl Engine{
    pub fn schema_relation(&self,temp:bool)->Relation{
        let mut rows=vec![];
        let mut page=2;
        for t in self.db.tables.values().filter(|t|t.def.temporary==temp){
            rows.push(vec![Value::Text("table".into()),Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Text(t.def.name.trim_start_matches("temp.").into()),Value::Integer(page),Value::Text(t.def.sql.clone())]);
            page+=1;
        }
        if if temp{
            self.db.temp_sequence_exists
        }
        else{
            self.db.sequence_exists
        }
        {
            rows.push(vec![Value::Text("table".into()),Value::Text("sqlite_sequence".into()),Value::Text("sqlite_sequence".into()),Value::Integer(page),Value::Text("CREATE TABLE sqlite_sequence(name,seq)".into())]);
            page+=1;
        }
        for v in self.db.views.values().filter(|v|v.name.starts_with("temp.")==temp){
            rows.push(vec![Value::Text("view".into()),Value::Text(v.name.trim_start_matches("temp.").into()),Value::Text(v.name.trim_start_matches("temp.").into()),Value::Integer(0),Value::Text(v.sql.clone())]);
        }
        for i in self.db.indexes.values().filter(|i|i.table.starts_with("temp.")==temp){
            if i.origin=="pk"&&self.db.tables.get(&key(&i.table)).is_some_and(|t|t.def.without_rowid){continue}
            rows.push(vec![Value::Text("index".into()),Value::Text(i.name.trim_start_matches("temp.").into()),Value::Text(i.table.trim_start_matches("temp.").into()),Value::Integer(page),if i.sql.is_empty(){
                Value::Null
            }
            else{
                Value::Text(i.sql.clone())
            }
            ]);
            page+=1;
        }
        for t in self.db.triggers.values().filter(|t|(t.temporary||t.table.starts_with("temp."))==temp){
            rows.push(vec![Value::Text("trigger".into()),Value::Text(t.name.trim_start_matches("temp.").into()),Value::Text(t.table.trim_start_matches("temp.").into()),Value::Integer(0),Value::Text(t.sql.clone())]);
        }
        let mut relation=Relation::simple(&["type","name","tbl_name","rootpage","sql"],rows);
        for (field,typ) in relation.fields.iter_mut().zip(["TEXT","TEXT","TEXT","INTEGER","TEXT"]){field.declared_type=typ.into();field.affinity=crate::value::affinity(typ);}
        relation
    }
    pub fn pragma(&mut self,name:&str,e:Option<&Expr>)->Res<Relation>{
        if name.rsplit('.').next().is_some_and(|n|n.eq_ignore_ascii_case("table_list")){
            let value=e.map(|e|match e{Expr::Col(n)=>Ok(Value::Text(n.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)}).transpose()?;
            return self.pragma_read(name,value.as_ref())
        }
        if let Some((schema,base))=name.split_once('.') {
            if connection_pragma(&key(base)){return self.pragma(base,e)}
            if schema.eq_ignore_ascii_case("temp") {
                if base.eq_ignore_ascii_case("synchronous")&&e.is_some(){return Ok(Relation::default())}
                if base.eq_ignore_ascii_case("cache_size"){
                    if let Some(e)=e{let value=self.eval(e,&Env::default(),None,&Ctes::new(),0)?.int();self.pragmas.insert("temp.cache_size".into(),Value::Integer(value));return Ok(Relation::default())}
                    return self.pragma_read(name,None)
                }
                if base.eq_ignore_ascii_case("journal_mode"){
                    if self.tx.is_none(){if let Some(e)=e{
                        let value=match e{Expr::Col(n)=>Value::Text(n.join(".")),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)?};
                        let mode=key(&value.text());if ["memory","off"].contains(&mode.as_str()){self.pragmas.insert("temp.journal_mode".into(),Value::Text(mode));}
                    }}
                    return self.pragma_read(name,None)
                }
                if ["schema_version","user_version","application_id"].contains(&key(base).as_str()) {
                    if let Some(e)=e {let v=self.eval(e,&Env::default(),None,&Ctes::new(),0)?.int();match key(base).as_str(){"schema_version"=>self.db.temp_schema_version=v,"user_version"=>self.db.temp_user_version=v,_=>self.db.temp_application_id=v}return Ok(Relation::default())}
                }
                let val=e.map(|e|match e{Expr::Col(n)=>Ok(Value::Text(n.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)}).transpose()?;
                return self.pragma_read(name,val.as_ref());
            }
            if schema.eq_ignore_ascii_case("main") {
                if base.eq_ignore_ascii_case("journal_mode"){
                    if let Some(e)=e{let value=match e{Expr::Col(n)=>Value::Text(n.join(".")),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)?};self.set_journal_mode(&value);}
                    return self.pragma_read(base,None)
                }
                if ["table_info","table_xinfo","index_list","index_info","index_xinfo","foreign_key_list","foreign_key_check","table_list"].contains(&key(base).as_str()) {
                    let val=e.map(|e|match e{Expr::Col(n)=>Ok(Value::Text(n.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)}).transpose()?;
                    return self.pragma_read(name,val.as_ref());
                }
                return self.pragma(base,e);
            }
        }
        let n=key(name);
        let val=e.map(|e|match e{
            Expr::Col(ns)=>Ok(Value::Text(ns.join("."))),_=>self.eval(e,&Env::default(),None,&Ctes::new(),0)
        }
        ).transpose()?;
        if let Some(v)=&val{
            let boolean=if let Value::Text(s)=v{
                ["on","yes","true","1"].contains(&key(s).as_str())
            }
            else{
                v.truth()==Some(true)
            }
            ;
            match n.as_str(){
                "foreign_keys"=>{
                    if self.tx.is_none(){
                        self.foreign_keys=boolean;
                        for a in self.attachments.values_mut(){
                            a.foreign_keys=boolean;
                        }
                    }
                    return Ok(Relation::default())
                }
                ,"defer_foreign_keys"=>{
                    self.defer_foreign=boolean;
                    for a in self.attachments.values_mut(){a.defer_foreign=boolean;}
                    return Ok(Relation::default())
                }
                ,"case_sensitive_like"=>{
                    self.case_like=boolean;
                    for a in self.attachments.values_mut(){a.case_like=boolean;}
                    return Ok(Relation::default())
                }
                ,"user_version"=>{
                    self.db.user_version=v.int();
                    return Ok(Relation::default())
                }
                ,"application_id"=>{
                    self.db.application_id=v.int();
                    return Ok(Relation::default())
                }
                ,"schema_version"=>{
                    self.db.schema_version=v.int();
                    return Ok(Relation::default())
                }
                ,"journal_mode"=>{
                    self.set_journal_mode(v);
                    for a in self.attachments.values_mut(){a.set_journal_mode(v);}
                    return self.pragma_read(&n,None)
                }
                ,"synchronous"=>{
                    if self.tx.is_some(){return Err("Safety level may not be changed inside a transaction".into())}
                    let level=match key(&v.text()).as_str(){"off"=>Some(0),"normal"=>Some(1),"full"=>Some(2),"extra"=>Some(3),_=>v.text().parse::<i64>().ok().filter(|n|(0..=3).contains(n))};
                    if let Some(level)=level{self.pragmas.insert(n,Value::Integer(level));}
                    return Ok(Relation::default())
                }
                ,"temp_store"=>{
                    let mode=match key(&v.text()).as_str(){"default"=>Some(0),"file"=>Some(1),"memory"=>Some(2),_=>v.text().parse::<i64>().ok().filter(|n|(0..=2).contains(n))};
                    if let Some(mode)=mode{
                        if mode!=self.pragmas.get("temp_store").map(Value::int).unwrap_or(0){
                            if self.tx.is_some(){return Err("temporary storage cannot be changed from within a transaction".into())}
                            self.reset_temporary_schema();
                            for a in self.attachments.values_mut(){a.reset_temporary_schema();}
                        }
                        self.pragmas.insert(n.clone(),Value::Integer(mode));
                        for a in self.attachments.values_mut(){a.pragmas.insert(n.clone(),Value::Integer(mode));}
                    }
                    return Ok(Relation::default())
                }
                ,"busy_timeout"=>{
                    let value=Value::Integer(v.int().max(0));
                    self.pragmas.insert(n.clone(),value.clone());
                    for a in self.attachments.values_mut(){a.pragmas.insert(n.clone(),value.clone());}
                    return self.pragma_read(&n,None)
                }
                ,"table_info"|"table_xinfo"|"index_list"|"index_info"|"index_xinfo"|"foreign_key_list"|"foreign_key_check"|"integrity_check"|"quick_check"|"table_list"=>{
                }
                ,_=>{
                    if !connection_pragma(&n)&&!["cache_size","journal_size_limit"].contains(&n.as_str()){return Ok(Relation::default())}
                    let v=if ["recursive_triggers","read_uncommitted","query_only","count_changes","ignore_check_constraints","legacy_alter_table","writable_schema"].contains(&n.as_str()){Value::Integer(boolean as i64)}else{v.clone()};
                    self.pragmas.insert(n.clone(),v.clone());
                    if connection_pragma(&n){for a in self.attachments.values_mut(){a.pragmas.insert(n.clone(),v.clone());}}
                    return Ok(Relation::default())
                }
            }
        }
        self.pragma_read(&n,val.as_ref())
    }
    fn set_journal_mode(&mut self,value:&Value){
        if self.tx.is_some(){return}
        let mode=key(&value.text());
        let allowed=if self.path.is_none(){["memory","off"].contains(&mode.as_str())}else{["delete","truncate","persist","memory","wal","off"].contains(&mode.as_str())};
        if allowed{self.journal=mode;}
    }
    pub fn pragma_read(&self,name:&str,val:Option<&Value>)->Res<Relation>{
        if name.rsplit('.').next().is_some_and(|n|n.eq_ignore_ascii_case("table_list")){
            return self.table_list_relation(name.split_once('.').map(|(schema,_)|schema),&val.map(Value::text).unwrap_or_default())
        }
        if let Some((schema,base))=name.split_once('.') {
            if connection_pragma(&key(base)){return self.pragma_read(base,val)}
            let temp=schema.eq_ignore_ascii_case("temp");
            if temp||schema.eq_ignore_ascii_case("main") {
                let simple=|v|Relation::simple(&[base],vec![vec![Value::Integer(v)]]);
                if ["integrity_check","quick_check"].contains(&key(base).as_str()){return self.integrity_relation(base,temp,val)}
                if temp {match key(base).as_str(){"cache_size"=>return Ok(simple(self.pragmas.get("temp.cache_size").map(Value::int).unwrap_or(0))),"synchronous"=>return Ok(simple(0)),"data_version"=>return Ok(simple(1)),"schema_version"=>return Ok(simple(self.db.temp_schema_version)),"user_version"=>return Ok(simple(self.db.temp_user_version)),"application_id"=>return Ok(simple(self.db.temp_application_id)),"journal_mode"=>return Ok(Relation::simple(&[base],vec![vec![self.pragmas.get("temp.journal_mode").cloned().unwrap_or(Value::Text("memory".into()))]])),_=>{}}}
                if base.eq_ignore_ascii_case("foreign_key_check"){return self.foreign_check_relation(&val.map(Value::text).unwrap_or_default(),temp)}
                if ["table_info","table_xinfo","index_list","index_info","index_xinfo","foreign_key_list"].contains(&key(base).as_str()) {
                    let value=val.map(|v|Value::Text(format!("{}.{}",if temp{"temp"}else{"main"},v.text())));
                    return self.pragma_read(base,value.as_ref());
                }
                let mut result=self.pragma_read(base,val)?;
                if base.eq_ignore_ascii_case("table_list"){result.rows.retain(|r|r.first().is_some_and(|v|v.text().eq_ignore_ascii_case(schema)));}
                return Ok(result);
            }
            if let Some(db)=self.attachments.get(&key(schema)){return db.pragma_read(base,val)}
            return Err(format!("unknown database {}",schema));
        }
        let n=key(name);
        let arg=val.map(Value::text).unwrap_or_default();
        let integer=|x|Relation::simple(&[name],vec![vec![Value::Integer(x)]]);
        Ok(match n.as_str(){
            "data_version"=>integer(self.data_version),"foreign_keys"=>integer(self.foreign_keys as i64),"defer_foreign_keys"=>integer(self.defer_foreign as i64),"user_version"=>integer(self.db.user_version),"application_id"=>integer(self.db.application_id),"schema_version"=>integer(self.db.schema_version),"journal_mode"=>Relation::simple(&["journal_mode"],vec![vec![Value::Text(if self.path.is_none()&&self.journal=="delete"{
                "memory".into()
            }
            else{
                self.journal.clone()
            }
            )]]),"encoding"=>Relation::simple(&["encoding"],vec![vec![Value::Text("UTF-8".into())]]),"page_size"=>integer(4096),"page_count"=>integer((self.db.tables.len()+self.db.indexes.len()+1) as i64),"freelist_count"=>integer(0),"auto_vacuum"=>integer(0),"synchronous"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(2)),"cache_size"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(-2000)),"temp_store"|"threads"|"analysis_limit"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(0)),"journal_size_limit"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(-1)),"busy_timeout"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(0)),"recursive_triggers"|"read_uncommitted"|"query_only"|"count_changes"|"ignore_check_constraints"|"legacy_alter_table"|"writable_schema"=>integer(self.pragmas.get(&n).map(Value::int).unwrap_or(0)),
            "database_list"=>{
                let mut rows=vec![vec![Value::Integer(0),Value::Text("main".into()),Value::Text(self.path.as_ref().map(|p|p.to_string_lossy().to_string()).unwrap_or_default())]];
                if self.db.tables.values().any(|t|t.def.temporary)||self.db.views.keys().any(|k|k.starts_with("temp.")){
                    rows.push(vec![Value::Integer(1),Value::Text("temp".into()),Value::Text(String::new())]);
                }
                for(i,n)in self.attachment_order.iter().enumerate(){
                    let a=&self.attachments[n];
                    rows.push(vec![Value::Integer(i as i64+2),Value::Text(n.clone()),Value::Text(a.path.as_ref().map(|p|p.to_string_lossy().to_string()).unwrap_or_default())])
                }
                Relation::simple(&["seq","name","file"],rows)
            }
            ,
            "table_info"|"table_xinfo"=>{
                let mut rows=vec![];
                let short=arg.rsplit('.').next().unwrap_or(&arg);
                let temp=arg.split_once('.').map(|(s,_)|s.eq_ignore_ascii_case("temp")).unwrap_or(self.db.temp_sequence_exists);
                if short.eq_ignore_ascii_case("sqlite_sequence")&&(if temp{self.db.temp_sequence_exists}else{self.db.sequence_exists}){
                    for(i,nm)in ["name","seq"].iter().enumerate(){
                        let mut row=vec![Value::Integer(i as i64),Value::Text((*nm).into()),Value::Text(String::new()),Value::Integer(0),Value::Null,Value::Integer(0)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(0))
                        }
                        rows.push(row)
                    }
                }
                if ["sqlite_schema","sqlite_master","sqlite_temp_schema","sqlite_temp_master"].contains(&key(short).as_str()){
                    for (i,(name,typ)) in ["type","name","tbl_name","rootpage","sql"].into_iter().zip(["TEXT","TEXT","TEXT","INTEGER","TEXT"]).enumerate(){
                        let mut row=vec![Value::Integer(i as i64),Value::Text(name.into()),Value::Text(typ.into()),Value::Integer(0),Value::Null,Value::Integer(0)];
                        if n=="table_xinfo"{row.push(Value::Integer(0));}rows.push(row);
                    }
                }
                if let Some(t)=self.db.tables.get(&self.resolve_relation_key(&arg)){
                    let mut cid=0;
                    for c in &t.def.cols{
                        if n=="table_info"&&c.generated.is_some(){
                            continue
                        }
                        let mut row=vec![Value::Integer(cid),Value::Text(c.name.clone()),Value::Text(c.typ.clone()),Value::Integer(c.not_null as i64),c.default_sql.as_ref().map(|s|Value::Text(s.clone())).unwrap_or(Value::Null),Value::Integer(c.primary as i64)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(if c.generated.is_some(){
                                if c.stored{
                                    3
                                }
                                else{
                                    2
                                }
                            }
                            else{
                                0
                            }
                            ))
                        }
                        rows.push(row);
                        cid+=1
                    }
                }
                else if let Some(v)=self.db.views.get(&self.resolve_relation_key(&arg)){
                    let r=self.view_metadata(v)?;
                    for(i,c)in r.fields.iter().enumerate(){
                        let mut row=vec![Value::Integer(i as i64),Value::Text(c.name.clone()),Value::Text(c.declared_type.clone()),Value::Integer(0),Value::Null,Value::Integer(0)];
                        if n=="table_xinfo"{
                            row.push(Value::Integer(0))
                        }
                        rows.push(row)
                    }
                }
                Relation::simple(if n=="table_info"{
                    &["cid","name","type","notnull","dflt_value","pk"]
                }
                else{
                    &["cid","name","type","notnull","dflt_value","pk","hidden"]
                }
                ,rows)
            }
            ,
            "index_list"=>Relation::simple(&["seq","name","unique","origin","partial"],self.db.indexes.values().filter(|i|i.table.eq_ignore_ascii_case(&self.resolve_relation_key(&arg))).enumerate().map(|(j,i)|vec![Value::Integer(j as i64),Value::Text(i.name.trim_start_matches("temp.").into()),Value::Integer(i.unique as i64),Value::Text(i.origin.clone()),Value::Integer(i.filter.is_some() as i64)]).collect()),
            "index_info"|"index_xinfo"=>{
                let mut rows=vec![];
                let index=self.db.indexes.get(&self.resolve_index_key(&arg)).or_else(|| {
                    let table=self.db.tables.get(&self.resolve_relation_key(&arg))?;
                    if !table.def.without_rowid{return None}
                    self.db.indexes.values().find(|i|i.table.eq_ignore_ascii_case(&table.def.name)&&i.origin=="pk")
                });
                if let Some(idx)=index {
                    if let Some(t)=self.db.tables.get(&key(&idx.table)) {
                        let env=self.row_env(t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},None);
                        let mut entries=idx.cols.iter().map(|o|(o.clone(),true)).collect::<Vec<_>>();
                        if n=="index_xinfo" {
                            if t.def.without_rowid {
                                if idx.origin=="pk" {
                                    for c in &t.def.cols {if !entries.iter().any(|(o,_)|crate::schema::column_name(&o.expr).is_some_and(|n|n.eq_ignore_ascii_case(&c.name))) {entries.push((Order{expr:Expr::Col(vec![c.name.clone()]),desc:false,nulls:None},false));}}
                                } else if let Some(pk)=self.db.indexes.values().find(|i|i.table.eq_ignore_ascii_case(&t.def.name)&&i.origin=="pk") {
                                    for o in &pk.cols {if !entries.iter().any(|(e,_)|crate::schema::column_name(&e.expr)==crate::schema::column_name(&o.expr)&&self.meta(&e.expr,&env).1.eq_ignore_ascii_case(&self.meta(&o.expr,&env).1)) {entries.push((o.clone(),false));}}
                                }
                            }
                        }
                        for (o,is_key) in entries {
                            let(ci,nm)=if let Some(name)=crate::schema::column_name(&o.expr) {(t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(name)).map(|i|i as i64).unwrap_or(-1),Value::Text(name.into()))}else{(-2,Value::Null)};
                            let mut row=vec![Value::Integer(rows.len() as i64),Value::Integer(ci),nm];
                            if n=="index_xinfo" {row.extend([Value::Integer(o.desc as i64),Value::Text(self.meta(&o.expr,&env).1),Value::Integer(is_key as i64)]);}
                            rows.push(row);
                        }
                        if n=="index_xinfo"&&!t.def.without_rowid {rows.push(vec![Value::Integer(rows.len() as i64),Value::Integer(-1),Value::Null,Value::Integer(0),Value::Text("BINARY".into()),Value::Integer(0)]);}
                    }
                }
                Relation::simple(if n=="index_info"{
                    &["seqno","cid","name"]
                }
                else{
                    &["seqno","cid","name","desc","coll","key"]
                }
                ,rows)
            }
            ,
            "foreign_key_list"=>{
                let mut rows=vec![];
                if let Some(t)=self.db.tables.get(&self.resolve_relation_key(&arg)){
                    for(i,f)in t.def.foreign.iter().rev().enumerate(){
                        for(j,n)in f.cols.iter().enumerate(){
                            rows.push(vec![Value::Integer(i as i64),Value::Integer(j as i64),Value::Text(f.table.clone()),Value::Text(n.clone()),f.target.get(j).map(|s|Value::Text(s.clone())).unwrap_or(Value::Null),Value::Text(f.update.clone()),Value::Text(f.delete.clone()),Value::Text("NONE".into())])
                        }
                    }
                }
                Relation::simple(&["id","seq","table","from","to","on_update","on_delete","match"],rows)
            }
            ,
            "foreign_key_check"=>self.foreign_check_relation(&arg,false)?,"integrity_check"|"quick_check"=>self.integrity_relation(name,false,val)?,"collation_list"=>Relation::simple(&["seq","name"],vec![vec![Value::Integer(0),Value::Text("RTRIM".into())],vec![Value::Integer(1),Value::Text("NOCASE".into())],vec![Value::Integer(2),Value::Text("BINARY".into())]]),"compile_options"=>Relation::simple(&["compile_options"],vec![]),"wal_checkpoint"=>Relation::simple(&["busy","log","checkpointed"],vec![vec![Value::Integer(0),Value::Integer(-1),Value::Integer(-1)]]),_=>if let Some(v)=self.pragmas.get(&n){
                Relation::simple(&[name],vec![vec![v.clone()]])
            }
            else{
                Relation::default()
            }
        }
        )
    }
}
impl Engine{
    fn foreign_check_relation(&self,name:&str,temp:bool)->Res<Relation>{
        use crate::value::{
            affinity,compare
        }
        ;
        use std::cmp::Ordering;
        let mut rows=vec![];
        let table=if name.is_empty(){None}else{Some(if temp{format!("temp.{}",key(name))}else{key(name)})};
        if table.as_ref().is_some_and(|name|!self.db.tables.contains_key(name)){return Err(format!("no such table: {}",name))}
        for t in self.db.tables.values(){
            if t.def.temporary!=temp||table.as_ref().is_some_and(|name|!t.def.name.eq_ignore_ascii_case(name)){continue}
            for (fk,f) in t.def.foreign.iter().rev().enumerate(){
                let child=f.cols.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or("foreign key mismatch".to_string())).collect::<Res<Vec<_>>>()?;
                let parent=self.db.tables.get(&if t.def.temporary{
                    format!("temp.{}",key(&f.table))
                }
                else{
                    key(&f.table)
                }
                );
                let target=if parent.is_some(){Some(crate::foreign::parent_key(&self.db,t,f)?.2)}else{None};
                for r in &t.rows{
                    if child.iter().any(|i|r.values[*i].null()){
                        continue
                    }
                    let found=if let (Some(p),Some(target))=(parent,&target){
                        if child.len()!=target.len(){
                            return Err("foreign key mismatch".into())
                        }
                        p.rows.iter().any(|pr|child.iter().zip(target).all(|(i,j)|compare(&r.values[*i].apply(affinity(&p.def.cols[*j].typ)),&pr.values[*j],&p.def.cols[*j].collate)==Ordering::Equal))
                    }
                    else{
                        false
                    }
                    ;
                    if !found{
                        rows.push(vec![Value::Text(t.def.name.trim_start_matches("temp.").into()),if t.def.without_rowid{
                            Value::Null
                        }
                        else{
                            Value::Integer(r.id)
                        }
                        ,Value::Text(f.table.clone()),Value::Integer(fk as i64)]);
                    }
                }
            }
        }
        Ok(Relation::simple(&["table","rowid","parent","fkid"],rows))
    }
}

impl Engine {
    pub fn pragma_enabled(&self,name:&str)->bool {self.pragmas.get(name).is_some_and(|v|v.truth()==Some(true)||["on","yes","true"].contains(&v.text().to_ascii_lowercase().as_str()))}
    pub fn count_output(&self,result:&mut Relation,name:&str,count:i64) {
        if result.fields.is_empty()&&self.pragma_enabled("count_changes"){*result=Relation::simple(&[name],vec![vec![Value::Integer(count)]]);}
    }
}

impl Engine {
    fn integrity_relation(&self,name:&str,temp:bool,value:Option<&Value>)->Res<Relation> {
        let table=value.filter(|v|matches!(v,Value::Text(_))).map(Value::text);
        let limit=value.filter(|v|matches!(v,Value::Integer(_))).map(Value::int).unwrap_or(100).max(1) as usize;
        let mut errors=vec![];
        for t in self.db.tables.values().filter(|t|t.def.temporary==temp&&table.as_ref().is_none_or(|n|t.def.name.trim_start_matches("temp.").eq_ignore_ascii_case(n))) {
            for (i,row) in t.rows.iter().enumerate() {
                match self.validate_row(t,row,Some(i)) {
                    Ok(conflicts) if !conflicts.is_empty()&&name.eq_ignore_ascii_case("integrity_check")=>errors.push(vec![Value::Text(format!("UNIQUE constraint failed in {}",t.def.name))]),
                    Err(error)=>errors.push(vec![Value::Text(error)]),_=>{}
                }
                if errors.len()>=limit{return Ok(Relation::simple(&[name],errors))}
            }
        }
        if errors.is_empty(){errors.push(vec![Value::Text("ok".into())]);}
        Ok(Relation::simple(&[name],errors))
    }
}

pub(crate) fn connection_pragma(name:&str)->bool{
    ["foreign_keys","defer_foreign_keys","case_sensitive_like","recursive_triggers","read_uncommitted","query_only","count_changes","ignore_check_constraints","legacy_alter_table","writable_schema","busy_timeout","temp_store","threads","analysis_limit"].contains(&name)
}

impl Engine{
    fn reset_temporary_schema(&mut self){
        self.db.tables.retain(|_,t|!t.def.temporary);
        self.db.views.retain(|name,_|!name.starts_with("temp."));
        self.db.indexes.retain(|_,i|!i.table.starts_with("temp."));
        self.db.triggers.retain(|_,t|!t.temporary&&!t.table.starts_with("temp."));
        self.db.temp_sequence_exists=false;self.db.temp_sequence_rows=None;
        self.db.temp_schema_version=0;self.db.temp_user_version=0;self.db.temp_application_id=0;
        self.pragmas.retain(|name,_|!name.starts_with("temp."));
    }
    fn view_metadata(&self,v:&View)->Res<Relation>{
        let name=if v.name.starts_with("temp."){v.name.clone()}else{format!("main.{}",v.name)};
        self.bind_source(&Source::Table(name,None,vec![]),&Env::default(),&Ctes::new(),0)
    }
    fn table_list_relation(&self,schema:Option<&str>,argument:&str)->Res<Relation>{
        let mut rows=vec![];
        let wanted=|name:&str|argument.is_empty()||name.eq_ignore_ascii_case(argument);
        let include=|temp:bool|schema.is_none_or(|s|s.eq_ignore_ascii_case(if temp{"temp"}else{"main"}));
        for t in self.db.tables.values(){
            let name=t.def.name.trim_start_matches("temp.");
            if include(t.def.temporary)&&wanted(name){rows.push(vec![Value::Text(if t.def.temporary{"temp"}else{"main"}.into()),Value::Text(name.into()),Value::Text("table".into()),Value::Integer(t.def.cols.len() as i64),Value::Integer(t.def.without_rowid as i64),Value::Integer(t.def.strict as i64)]);}
        }
        for v in self.db.views.values(){
            let temp=v.name.starts_with("temp.");let name=v.name.trim_start_matches("temp.");
            if include(temp)&&wanted(name){
                let count=self.view_metadata(v)?.fields.len();
                rows.push(vec![Value::Text(if temp{"temp"}else{"main"}.into()),Value::Text(name.into()),Value::Text("view".into()),Value::Integer(count as i64),Value::Integer(0),Value::Integer(0)]);
            }
        }
        for temp in [false,true]{
            if !include(temp){continue}
            let schema=if temp{"temp"}else{"main"};
            let catalog=if temp{"sqlite_temp_schema"}else{"sqlite_schema"};
            if wanted(catalog){rows.push(vec![Value::Text(schema.into()),Value::Text(catalog.into()),Value::Text("table".into()),Value::Integer(5),Value::Integer(0),Value::Integer(0)]);}
            if wanted("sqlite_sequence")&&(if temp{self.db.temp_sequence_exists}else{self.db.sequence_exists}){rows.push(vec![Value::Text(schema.into()),Value::Text("sqlite_sequence".into()),Value::Text("table".into()),Value::Integer(2),Value::Integer(0),Value::Integer(0)]);}
        }
        if let Some(schema)=schema{
            if !["main","temp"].contains(&key(schema).as_str())&&!self.attachments.contains_key(&key(schema)){return Err(format!("unknown database {}",schema))}
        }
        for name in &self.attachment_order{
            if schema.is_some_and(|s|!s.eq_ignore_ascii_case(name)){continue}
            let mut result=self.attachments[name].table_list_relation(Some("main"),argument)?;
            for row in &mut result.rows{row[0]=Value::Text(name.clone());}
            rows.extend(result.rows);
        }
        Ok(Relation::simple(&["schema","name","type","ncol","wr","strict"],rows))
    }
    pub(crate) fn pragma_function(&self,name:&str,args:&[Value])->Res<Relation>{
        let argument=["table_info","table_xinfo","index_info","index_xinfo","index_list","foreign_key_list","foreign_key_check","integrity_check","quick_check","table_list"].contains(&name);
        let scoped=["table_info","table_xinfo","index_info","index_xinfo","index_list","foreign_key_list","foreign_key_check","integrity_check","quick_check","table_list","journal_mode","synchronous","cache_size","schema_version","user_version","application_id","data_version","page_size","page_count","freelist_count","auto_vacuum"].contains(&name);
        let maximum=argument as usize+scoped as usize;
        if args.len()>maximum{return Err(format!("too many arguments on pragma_{}()",name))}
        let schema=if scoped{args.get(argument as usize).filter(|v|!v.null()).map(Value::text)}else{None};
        let full=schema.map(|s|format!("{}.{}",s,name)).unwrap_or_else(||name.into());
        let result=self.pragma_read(&full,if argument{args.first()}else{None})?;
        if result.fields.is_empty(){return Err(format!("no such table: pragma_{}",name))}
        Ok(result)
    }
}
