use crate::value::Value;
use crate::parser::Res;
thread_local!{
    static STATEMENT_NOW:std::cell::Cell<Option<f64>>=const{
        std::cell::Cell::new(None)
    }
    ;
}
fn clock_now()->f64{
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d|d.as_secs_f64()).unwrap_or(0.0)
}
pub fn begin_statement(){
    STATEMENT_NOW.with(|t|t.set(Some(clock_now())))
}
fn now()->f64{
    STATEMENT_NOW.with(|t|t.get()).unwrap_or_else(clock_now)
}
pub fn current(n:&str)->Res<Value>{
    call(match n.to_ascii_uppercase().as_str(){
        "CURRENT_DATE"=>"date","CURRENT_TIME"=>"time",_=>"datetime"
    }
    ,&[])
}
pub fn call(n:&str,a:&[Value])->Res<Value>{
    if a.iter().any(Value::null){
        return Ok(Value::Null)
    }
    let off=usize::from(n=="strftime");
    if off==1&&a.is_empty(){
        return Ok(Value::Null)
    }
    if n=="timediff"{
        if a.len()!=2{
            return Err("wrong number of arguments to function timediff()".into())
        }
        let(x,y)=(parse(&a[0],false),parse(&a[1],false));
        if let(Some(x),Some(y))=(x,y){
            return Ok(Value::Text(timedifference(x,y)))
        }
        return Ok(Value::Null)
    }
    let subfirst=a.get(off).is_some_and(|v|["subsec","subsecond"].contains(&v.text().to_lowercase().as_str()));
    let modifiers=&a[(off+usize::from(a.len()>off&&!subfirst)).min(a.len())..];
    let unix=modifiers.first().is_some_and(|v|v.text().eq_ignore_ascii_case("unixepoch"));
    let auto=modifiers.first().is_some_and(|v|v.text().eq_ignore_ascii_case("auto"));
    let v=a.get(off).cloned().unwrap_or(Value::Text("now".into()));
    let numeric=v.text().parse::<f64>().ok();
    let mut sec=if subfirst{
        now()
    }
    else if let Some(x)=parse(&v,unix||(auto&&numeric.is_some_and(|v|!(0.0..=5373484.499999).contains(&v)))){
        x
    }
    else{
        return Ok(Value::Null)
    }
    ;
    let mut sub=false;
    let mut overflow_days=0;
    for (position,v) in modifiers.iter().enumerate(){
        let m=v.text().to_ascii_lowercase();
        let previous_overflow=overflow_days;
        overflow_days=0;
        match m.as_str(){
            "unixepoch"|"julianday"=>{
                if position!=0||subfirst||numeric.is_none(){return Ok(Value::Null)}
            }
            "auto"=>if position!=0||subfirst{return Ok(Value::Null)},
            "utc"|"localtime"=>{},
            "subsec"|"subsecond"=>sub=true,
            "ceiling"=>{},
            "floor"=>sec-=previous_overflow as f64*86400.0,
            "start of day"=>sec=(sec/86400.0).floor()*86400.0,
            "start of month"|"start of year"=>{
                let(y,mo,_)=civil((sec/86400.0).floor() as i64);
                sec=days(y,if m=="start of year"{1}else{mo},1) as f64*86400.0;
            }
            _=>{
                if let Some(s)=m.strip_prefix("weekday "){
                    let Some(d)=s.parse::<f64>().ok().filter(|d|d.fract()==0.0&&(0.0..=6.0).contains(d)) else{return Ok(Value::Null)};
                    let current=((sec/86400.0).floor() as i64+4).rem_euclid(7);
                    sec+=(d as i64-current).rem_euclid(7) as f64*86400.0;
                }else{
                    let parts=m.split_whitespace().collect::<Vec<_>>();
                    let amount=parts.first().and_then(|s|s.parse::<f64>().ok());
                    if let Some(x)=amount{
                        if parts.len()!=2||!x.is_finite(){return Ok(Value::Null)}
                        let unit=parts[1].strip_suffix('s').unwrap_or(parts[1]);
                        match unit{
                            "day"=>sec+=x*86400.0,
                            "hour"=>sec+=x*3600.0,
                            "minute"=>sec+=x*60.0,
                            "second"=>sec+=x,
                            "month"|"year"=>{
                                // Bound conversion before doing signed calendar arithmetic.
                                if x.abs()>120000.0{return Ok(Value::Null)}
                                let whole=x.trunc() as i64;
                                let months=if unit=="year"{whole*12}else{whole};
                                let (shifted,overflow)=calendar_shift(sec,months);
                                overflow_days=overflow;
                                sec=shifted+x.fract()*if unit=="year"{365.0*86400.0}else{30.0*86400.0};
                            }
                            _=>return Ok(Value::Null)
                        }
                    }else{
                        let sign=if m.starts_with('-'){-1.0}else{1.0};
                        let signed=m.starts_with(['+','-']);
                        let shift=if signed{&m[1..]}else{&m};
                        let bytes=shift.as_bytes();
                        if signed&&bytes.len()>=10&&bytes[4]==b'-'&&bytes[7]==b'-'{
                            let Some(yy)=digits(bytes,0,4) else{return Ok(Value::Null)};
                            let Some(mm)=digits(bytes,5,2).filter(|x|*x<12) else{return Ok(Value::Null)};
                            let Some(dd)=digits(bytes,8,2).filter(|x|*x<31) else{return Ok(Value::Null)};
                            let (shifted,overflow)=calendar_shift(sec,sign as i64*(yy*12+mm));
                            sec=shifted+sign*dd as f64*86400.0;
                            overflow_days=overflow;
                            if bytes.len()>10{
                                if !bytes[10].is_ascii_whitespace(){return Ok(Value::Null)}
                                let Some(time)=parse_clock(shift[10..].trim(),false) else{return Ok(Value::Null)};
                                sec+=sign*time;
                            }
                        }else if let Some(d)=parse_clock(shift,false){
                            sec+=sign*d;
                        }else{return Ok(Value::Null)}
                    }
                }
            }
        }
        if !valid_seconds(sec){return Ok(Value::Null)}
        sec=(sec*1000.0).round()/1000.0;
    }
    if !valid_seconds(sec){return Ok(Value::Null)}
    sec=(sec*1000.0).round()/1000.0;
    let day=(sec/86400.0).floor() as i64;
    let(y,m,d)=civil(day);
    let sod=sec.rem_euclid(86400.0);
    let h=(sod/3600.0).floor() as i64;
    let mi=((sod%3600.0)/60.0).floor() as i64;
    let ss=sod%60.0;
    let date=format!("{:04}-{:02}-{:02}",y,m,d);
    let time=if sub{
        format!("{:02}:{:02}:{:06.3}",h,mi,ss)
    }
    else{
        format!("{:02}:{:02}:{:02}",h,mi,ss as i64)
    }
    ;
    Ok(match n{
        "date"=>Value::Text(date),"time"=>Value::Text(time),"datetime"=>Value::Text(format!("{} {}",date,time)),"julianday"=>Value::Real(sec/86400.0+2440587.5),"unixepoch"=>if sub{
            Value::Real(sec)
        }
        else{
            Value::Integer(sec.floor() as i64)
        }
        ,"strftime"=>{
            let fmt=a[0].text();
            let mut cs=fmt.chars();
            let mut out=String::new();
            while let Some(c)=cs.next(){
                if c!='%'{
                    out.push(c);
                    continue
                }
                let Some(c)=cs.next()else{
                    return Ok(Value::Null)
                }
                ;
                let s=match c{
                    '%'=>"%".into(),'G'=>format!("{:04}",iso_week(day).0),'g'=>format!("{:02}",iso_week(day).0.rem_euclid(100)),'V'=>format!("{:02}",iso_week(day).1),'Y'=>format!("{:04}",y),'m'=>format!("{:02}",m),'d'=>format!("{:02}",d),'e'=>format!("{:2}",d),'H'=>format!("{:02}",h),'k'=>format!("{:2}",h),'I'=>format!("{:02}",(h+11)%12+1),'l'=>format!("{:2}",(h+11)%12+1),'M'=>format!("{:02}",mi),'S'=>format!("{:02}",ss as i64),'f'=>format!("{:06.3}",ss),'F'=>date.clone(),'T'=>format!("{:02}:{:02}:{:02}",h,mi,ss as i64),'R'=>format!("{:02}:{:02}",h,mi),'j'=>format!("{:03}",day-days(y,1,1)+1),'w'=>((day+4).rem_euclid(7)).to_string(),'u'=>((day+3).rem_euclid(7)+1).to_string(),'s'=>if sub{
                        format!("{:.3}",sec)
                    }
                    else{
                        (sec.floor() as i64).to_string()
                    }
                    ,'J'=>(sec/86400.0+2440587.5).to_string(),'p'=>if h<12{
                        "AM"
                    }
                    else{
                        "PM"
                    }
                    .into(),'P'=>if h<12{
                        "am"
                    }
                    else{
                        "pm"
                    }
                    .into(),'W'=>format!("{:02}",(day-days(y,1,1)+7-(day+3).rem_euclid(7))/7),'U'=>format!("{:02}",(day-days(y,1,1)+7-(day+4).rem_euclid(7))/7),_=>return Ok(Value::Null)
                }
                ;
                out.push_str(&s)
            }
            Value::Text(out)
        }
        ,_=>Value::Null
    }
    )
}
fn valid_seconds(sec:f64)->bool{
    (-210866760000.0..253402300800.0).contains(&sec)
}
fn digits(bytes:&[u8],start:usize,count:usize)->Option<i64>{
    let part=bytes.get(start..start+count)?;
    if !part.iter().all(u8::is_ascii_digit){return None}
    Some(part.iter().fold(0,|n,b|n*10+(b-b'0') as i64))
}
fn parse(v:&Value,unix:bool)->Option<f64>{
    let s=v.text();
    let s=s.trim();
    let sec=if s.eq_ignore_ascii_case("now"){
        now()
    }else if let Ok(n)=s.parse::<f64>(){
        if unix{n}else{
            if !(0.0..5373484.5).contains(&n){return None}
            (n-2440587.5)*86400.0
        }
    }else{
        let b=s.as_bytes();
        if b.len()>=10&&b[4]==b'-'&&b[7]==b'-'{
            let y=digits(b,0,4)?;
            let m=digits(b,5,2).filter(|n|(1..=12).contains(n))?;
            let d=digits(b,8,2).filter(|n|(1..=31).contains(n))?;
            let base=days(y,m,d) as f64*86400.0;
            if b.len()==10{base}else{
                if b[10]!=b'T'&&!b[10].is_ascii_whitespace(){return None}
                let time=s[10..].trim_start_matches(|c:char|c=='T'||c.is_ascii_whitespace());
                base+parse_clock(time,true)?
            }
        }else{
            days(2000,1,1) as f64*86400.0+parse_clock(s,true)?
        }
    };
    let sec=(sec*1000.0).round()/1000.0;
    valid_seconds(sec).then_some(sec)
}
fn parse_clock(s:&str,allow_zone:bool)->Option<f64>{
    let s=s.trim();
    let b=s.as_bytes();
    let h=digits(b,0,2).filter(|n|*n<=24)?;
    if b.get(2)!=Some(&b':'){return None}
    let m=digits(b,3,2).filter(|n|*n<60)?;
    let mut pos=5;
    let mut seconds=0.0;
    if b.get(pos)==Some(&b':'){
        seconds=digits(b,pos+1,2).filter(|n|*n<60)? as f64;
        pos+=3;
        if b.get(pos)==Some(&b'.'){
            let start=pos;
            pos+=1;
            while b.get(pos).is_some_and(u8::is_ascii_digit){pos+=1}
            if pos==start+1{return None}
            seconds+=s[start..pos].parse::<f64>().ok()?;
        }
    }
    let tail=s.get(pos..)?.trim();
    let zone=if tail.is_empty(){0.0}else if !allow_zone{return None}else if tail.eq_ignore_ascii_case("z"){0.0}else{
        let z=tail.as_bytes();
        if z.len()!=6||!matches!(z[0],b'+'|b'-')||z[3]!=b':'{return None}
        let zh=digits(z,1,2).filter(|n|*n<=14)?;
        let zm=digits(z,4,2).filter(|n|*n<60)?;
        (zh*3600+zm*60) as f64*if z[0]==b'+'{1.0}else{-1.0}
    };
    Some(h as f64*3600.0+m as f64*60.0+seconds-zone)
}
fn iso_week(day:i64)->(i64,i64){
    // ISO weeks belong to the year containing their Thursday.
    let thursday=day+3-(day+3).rem_euclid(7);
    let year=civil(thursday).0;
    (year,(thursday-days(year,1,1))/7+1)
}
fn calendar_shift(sec:f64,months:i64)->(f64,i64){
    let(y,m,d)=civil((sec/86400.0).floor() as i64);
    let total=y*12+m-1+months;
    let ny=total.div_euclid(12);
    let nm=total.rem_euclid(12)+1;
    let following=total+1;
    let maxday=days(following.div_euclid(12),following.rem_euclid(12)+1,1)-days(ny,nm,1);
    (days(ny,nm,d) as f64*86400.0+sec.rem_euclid(86400.0),(d-maxday).max(0))
}
pub fn days(y:i64,m:i64,d:i64)->i64{
    let y=y-i64::from(m<=2);
    let era=y.div_euclid(400);
    let yo=y-era*400;
    let mp=m+if m>2{
        -3
    }
    else{
        9
    }
    ;
    let doy=(153*mp+2)/5+d-1;
    era*146097+yo*365+yo/4-yo/100+doy-719468
}
pub fn civil(z:i64)->(i64,i64,i64){
    let z=z+719468;
    let era=z.div_euclid(146097);
    let doe=z-era*146097;
    let yo=(doe-doe/1460+doe/36524-doe/146096)/365;
    let y=yo+era*400;
    let doy=doe-(365*yo+yo/4-yo/100);
    let mp=(5*doy+2)/153;
    let d=doy-(153*mp+2)/5+1;
    let m=mp+if mp<10{
        3
    }
    else{
        -9
    }
    ;
    (y+i64::from(m<=2),m,d)
}
fn shift_months(sec:f64,months:i64)->f64{
    let(y,m,d)=civil((sec/86400.0).floor() as i64);
    let total=y*12+m-1+months;
    days(total.div_euclid(12),total.rem_euclid(12)+1,d) as f64*86400.0+sec.rem_euclid(86400.0)
}
fn timedifference(a:f64,b:f64)->String{
    let sign=if a<b{
        -1
    }
    else{
        1
    }
    ;
    let(ay,am,_)=civil((a/86400.0).floor() as i64);
    let(by,bm,_)=civil((b/86400.0).floor() as i64);
    let mut months=((ay-by)*12+am-bm).abs();
    let mut shifted=shift_months(b,sign*months);
    while months>0&&((sign>0&&shifted>a)||(sign<0&&shifted<a)){
        months-=1;
        shifted=shift_months(b,sign*months);
    }
    let delta=(((a-shifted).abs())*1000.0).round()/1000.0;
    format!("{}{:04}-{:02}-{:02} {:02}:{:02}:{:06.3}",if sign<0{
        '-'
    }
    else{
        '+'
    }
    ,months/12,months%12,(delta/86400.0) as i64,((delta%86400.0)/3600.0) as i64,((delta%3600.0)/60.0) as i64,delta%60.0)
}
