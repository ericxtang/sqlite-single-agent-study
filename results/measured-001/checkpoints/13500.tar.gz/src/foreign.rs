use crate::{
    storage::{
        Database,Table,Row,key
    }
    ,ast::Foreign,value::{
        Value,affinity,compare
    }
}
;
use std::{
    collections::BTreeSet,cmp::Ordering
}
;
pub fn violation_key(t:&Table,fk:usize,f:&Foreign,r:&Row)->String{
    let values=f.cols.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).map(|i|r.values[i].clone()).unwrap_or(Value::Null)).collect::<Vec<_>>();
    serde_json::to_string(&(key(&t.def.name),fk,r.id,values)).unwrap()
}
pub fn violations(db:&Database)->BTreeSet<String>{
    let mut result=BTreeSet::new();
    for t in db.tables.values(){
        for(fk,f)in t.def.foreign.iter().enumerate(){
            let cols=f.cols.iter().filter_map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n))).collect::<Vec<_>>();
            let parent=db.tables.get(&if t.def.temporary{
                format!("temp.{}",key(&f.table))
            }
            else{
                key(&f.table)
            }
            );
            let targets=parent.map(|p|{
                if f.target.is_empty(){
                    let mut cs=p.def.cols.iter().enumerate().filter(|(_,c)|c.primary>0).collect::<Vec<_>>();
                    cs.sort_by_key(|(_,c)|c.primary);
                    cs.into_iter().map(|(i,_)|i).collect::<Vec<_>>()
                }
                else{
                    f.target.iter().filter_map(|n|p.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n))).collect()
                }
            }
            );
            for r in &t.rows{
                if cols.iter().any(|i|r.values[*i].null()){
                    continue
                }
                let found=if let(Some(p),Some(target))=(parent,&targets){
                    cols.len()==target.len()&&p.rows.iter().any(|pr|cols.iter().zip(target).all(|(i,j)|compare(&r.values[*i].apply(affinity(&p.def.cols[*j].typ)),&pr.values[*j],&p.def.cols[*j].collate)==Ordering::Equal))
                }
                else{
                    false
                }
                ;
                if !found{
                    result.insert(violation_key(t,fk,f,r));
                }
            }
        }
    }
    result
}

// Resolve a named parent key against a complete UNIQUE index using the column's
// declared collation. Partial/expression indexes and hidden rowids are not keys.
pub(crate) fn parent_key<'a>(db:&'a Database,t:&Table,f:&Foreign)->Result<(&'a Table,Vec<usize>,Vec<usize>),String>{
    let name=if t.def.temporary{format!("temp.{}",key(&f.table))}else{key(&f.table)};
    let parent=db.tables.get(&name).ok_or_else(||format!("no such table: {}",name))?;
    let mut targets=if f.target.is_empty(){
        let mut cols=parent.def.cols.iter().enumerate().filter(|(_,c)|c.primary>0).collect::<Vec<_>>();
        cols.sort_by_key(|(_,c)|c.primary);cols.into_iter().map(|(i,_)|i).collect::<Vec<_>>()
    }else{
        f.target.iter().map(|n|parent.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or_else(||"foreign key mismatch".to_string())).collect::<Result<Vec<_>,_>>()?
    };
    let child=f.cols.iter().map(|n|t.def.cols.iter().position(|c|c.name.eq_ignore_ascii_case(n)).ok_or_else(||"foreign key mismatch".to_string())).collect::<Result<Vec<_>,_>>()?;
    if targets.is_empty()||child.len()!=targets.len(){return Err("foreign key mismatch".into())}
    let valid=parent.ipk().is_some_and(|i|targets==[i])||db.indexes.values().any(|idx|{
        if !idx.unique||idx.filter.is_some()||!idx.table.eq_ignore_ascii_case(&parent.def.name)||idx.cols.len()!=targets.len(){return false}
        let mut unmatched=targets.clone();
        for order in &idx.cols{
            let Some(name)=crate::schema::column_name(&order.expr)else{return false};
            let Some(at)=unmatched.iter().position(|i|parent.def.cols[*i].name.eq_ignore_ascii_case(name))else{return false};
            let c=&parent.def.cols[unmatched.remove(at)];
            if !crate::engine::explicit_collate(&order.expr).unwrap_or_else(||c.collate.clone()).eq_ignore_ascii_case(&c.collate){return false}
        }
        unmatched.is_empty()
    });
    if !valid{return Err("foreign key mismatch".into())}
    Ok((parent,child,std::mem::take(&mut targets)))
}
impl crate::engine::Engine{
    pub(crate) fn validate_foreign_change(&self,t:&Table,event:&str,changed:&[String])->Result<(),String>{
        if !self.foreign_keys{return Ok(())}
        let changes=|names:&[String]|event!="UPDATE"||names.iter().any(|n|changed.iter().any(|c|c.eq_ignore_ascii_case(n)||(!t.def.without_rowid&&["rowid","oid","_rowid_"].contains(&key(c).as_str())&&t.ipk().is_some_and(|i|t.def.cols[i].name.eq_ignore_ascii_case(n)))));
        for f in &t.def.foreign{if changes(&f.cols){parent_key(&self.db,t,f)?;}}
        if event!="INSERT"{
            for child in self.db.tables.values(){
                for f in &child.def.foreign{
                    let parent=if child.def.temporary{format!("temp.{}",f.table)}else{f.table.clone()};
                    if !parent.eq_ignore_ascii_case(&t.def.name){continue}
                    let names=if f.target.is_empty(){t.def.cols.iter().filter(|c|c.primary>0).map(|c|c.name.clone()).collect()}else{f.target.clone()};
                    if changes(&names){parent_key(&self.db,child,f)?;}
                }
            }
        }
        Ok(())
    }
}
