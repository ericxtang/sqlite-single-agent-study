use crate::{ast::*,engine::*,parser::Res,storage::{Index,Table,Row},value::{Value,compare}};
use std::cmp::Ordering;

pub(crate) enum ConflictTarget{Any,Rowid,Index(Index)}

fn uncollated(e:&Expr)->&Expr{
    if let Expr::Collate(e,_)=e{uncollated(e)}else{e}
}
fn expression_key(e:&Expr,t:&Table)->serde_json::Value{
    let mut e=e.clone();
    crate::schema::visit_expr(&mut e,&mut |e|match e{
        Expr::Dqs(name)=>{
            *e=if t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(name)){
                Expr::Col(vec![name.to_ascii_lowercase()])
            }else{Expr::Lit(Value::Text(name.clone()))};
        }
        Expr::Col(names)=>{if let Some(name)=names.last(){*names=vec![name.to_ascii_lowercase()];}}
        Expr::Call{name,..}=>*name=name.to_ascii_lowercase(),
        Expr::Collate(_,name)=>*name=name.to_ascii_lowercase(),
        Expr::Cast(_,name)=>*name=name.to_ascii_uppercase(),
        _=>{}
    });
    serde_json::to_value(&e).unwrap_or(serde_json::Value::Null)
}
impl Engine{
    pub(crate) fn resolve_upsert_target(&self,t:&Table,u:&Upsert)->Res<ConflictTarget>{
        let terms=if u.target_exprs.is_empty(){
            u.target.iter().map(|name|Order{expr:Expr::Col(vec![name.clone()]),desc:false,nulls:None}).collect::<Vec<_>>()
        }else{u.target_exprs.clone()};
        if terms.is_empty(){return Ok(ConflictTarget::Any)}
        let env=self.row_env(t,&Row{id:0,values:vec![Value::Null;t.def.cols.len()]},None);
        for term in &terms{self.validate_schema_expression(&term.expr,&env,"conflict targets",true)?;}
        if let Some(filter)=&u.target_where{self.validate_schema_expression(filter,&env,"conflict targets",true)?;}
        if terms.len()==1&&!t.def.without_rowid{
            let name=match uncollated(&terms[0].expr){Expr::Dqs(n)=>Some(n.as_str()),e=>crate::schema::column_name(e)};
            if let Some(name)=name{
                let ipk=t.ipk().is_some_and(|i|t.def.cols[i].name.eq_ignore_ascii_case(name));
                let rowid=["rowid","_rowid_","oid"].contains(&name.to_ascii_lowercase().as_str())&&!t.def.cols.iter().any(|c|c.name.eq_ignore_ascii_case(name));
                if ipk||rowid{return Ok(ConflictTarget::Rowid)}
            }
        }
        for index in self.db.indexes.values().filter(|i|i.unique&&i.table.eq_ignore_ascii_case(&t.def.name)&&i.cols.len()==terms.len()){
            if let Some(filter)=&index.filter{
                if !u.target_where.as_ref().is_some_and(|f|expression_key(f,t)==expression_key(filter,t)){continue}
            }
            let mut used=vec![false;terms.len()];
            let matches=index.cols.iter().all(|column|{
                let key=expression_key(uncollated(&column.expr),t);
                let collate=self.meta(&column.expr,&env).1;
                for(i,term)in terms.iter().enumerate(){
                    if !used[i]&&expression_key(uncollated(&term.expr),t)==key&&explicit_collate(&term.expr).is_none_or(|c|c.eq_ignore_ascii_case(&collate)){
                        used[i]=true;return true
                    }
                }
                false
            });
            if matches{return Ok(ConflictTarget::Index(index.clone()))}
        }
        Err("ON CONFLICT clause does not match any PRIMARY KEY or UNIQUE constraint".into())
    }
    pub(crate) fn upsert_conflict(&self,t:&Table,new:&Row,old:&Row,target:&ConflictTarget)->Res<bool>{
        match target{
            ConflictTarget::Any=>Ok(true),
            ConflictTarget::Rowid=>Ok(new.id==old.id),
            ConflictTarget::Index(index)=>{
                let new_env=self.row_env(t,new,None);
                let old_env=self.row_env(t,old,None);
                if !self.index_applies(index,&new_env)?||!self.index_applies(index,&old_env)?{return Ok(false)}
                let new=self.index_values(index,&new_env)?;
                let old=self.index_values(index,&old_env)?;
                Ok(!new.iter().any(Value::null)&&new.iter().zip(&old).zip(&index.cols).all(|((a,b),o)|compare(a,b,&self.meta(&o.expr,&new_env).1)==Ordering::Equal))
            }
        }
    }
}
