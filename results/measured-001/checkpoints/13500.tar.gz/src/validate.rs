use crate::{
    engine::*,ast::*,value::Value,parser::Res,functions
}
;
impl Engine{
    pub fn bind_source(&self,s:&Source,env:&Env,ctes:&Ctes,depth:usize)->Res<Relation> {
        let _scope=BindingScope::enter();self.source(s,env,ctes,depth)
    }
    pub fn bind_query(&self,q:&Query,env:&Env,ctes:&Ctes,depth:usize)->Res<Relation> {
        let _scope=BindingScope::enter();
        self.query(q,env,ctes,depth)
    }
    pub fn validate_row_expr(&self,e:&Expr,env:&Env)->Res<()> {
        if has_aggregate(e)||has_window(e){return Err("misuse of aggregate or window function".into())}
        self.validate_expr(e,env,&Ctes::new(),0)
    }
    fn row_width(&self,e:&Expr,env:&Env,ctes:&Ctes,depth:usize)->Res<usize>{
        if depth>100{return Err("expression tree too large".into())}
        match e{
            Expr::Tuple(es)=>{
                for e in es{self.validate_expr(e,env,ctes,depth+1)?;}
                Ok(es.len())
            }
            Expr::Subquery(q)=>Ok(self.bind_query(q,env,ctes,depth+1)?.fields.len()),
            _=>{self.validate_expr(e,env,ctes,depth+1)?;Ok(1)}
        }
    }
    pub fn validate_expr(&self,e:&Expr,env:&Env,ctes:&Ctes,depth:usize)->Res<()>{
        if depth>100{
            return Err("expression tree too large".into())
        }
        let sub=|e:&Expr|self.validate_expr(e,env,ctes,depth+1);
        match e{
            Expr::Tuple(_)=>return Err("row value misused".into()),
            Expr::RowAccess(e,i,width)=>{
                let actual=self.row_width(e,env,ctes,depth+1)?;
                if actual<=*i||(*width!=0&&actual!=*width){return Err("row value column count mismatch".into())}
            },Expr::Dqs(n)=>{env.get(&[n.clone()])?;},Expr::Lit(_)=>{
            }
            ,Expr::Col(n)=>{
                if env.get(n)?.is_none()&&self.trigger_env.as_ref().map(|e|e.get(n)).transpose()?.flatten().is_none()&&!(n.len()==1&&["TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP"].contains(&n[0].to_ascii_uppercase().as_str())){
                    return Err(format!("no such column: {}",n.join(".")))
                }
            }
            ,Expr::Star(_)=>{
            }
            ,Expr::Collate(e,c)=>{
                if !["binary","nocase","rtrim"].contains(&c.to_ascii_lowercase().as_str()){
                    return Err(format!("no such collation sequence: {}",c))
                }
                sub(e)?
            }
            ,Expr::Unary(_,e)|Expr::Cast(e,_)=>sub(e)?,
            Expr::Binary(op,a,b) if !["=","==","!=","<>","<",">","<=",">="].contains(&op.as_str())=>{sub(a)?;sub(b)?;}
            Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>{
                if self.row_width(a,env,ctes,depth+1)?!=self.row_width(b,env,ctes,depth+1)?{
                    return Err("row value column count mismatch".into())
                }
            }
            Expr::Between(a,b,c,_)=>{
                let width=self.row_width(a,env,ctes,depth+1)?;
                if width!=self.row_width(b,env,ctes,depth+1)?||width!=self.row_width(c,env,ctes,depth+1)?{
                    return Err("row value column count mismatch".into())
                }
            }
            Expr::In(e,es,q,_)=>{
                if let Some(q)=q{
                    if self.row_width(e,env,ctes,depth+1)?!=self.bind_query(q,env,ctes,depth+1)?.fields.len(){
                        return Err("row value column count mismatch".into())
                    }
                }else{
                    sub(e)?;
                    for x in es{sub(x)?;}
                }
            }
            Expr::Case(base,arms,other)=>{
                let width=base.as_ref().map(|e|self.row_width(e,env,ctes,depth+1)).transpose()?;
                for(a,b)in arms{
                    if let Some(width)=width{
                        if width!=self.row_width(a,env,ctes,depth+1)?{return Err("row value column count mismatch".into())}
                    }else{sub(a)?;}
                    sub(b)?;
                }
                if let Some(e)=other{sub(e)?;}
            }
            Expr::Subquery(q)=>{
                if self.bind_query(q,env,ctes,depth+1)?.fields.len()!=1{return Err("sub-select returns more than one column".into())}
            }
            Expr::Exists(q)=>{self.bind_query(q,env,ctes,depth+1)?;}
            ,Expr::Call{
                name,args,filter,order,over,distinct
            }
            =>{
                let n=name.to_ascii_lowercase();
                if n=="raise"{
                    if self.trigger_env.is_none(){
                        return Err("RAISE() may only be used within a trigger-program".into())
                    }
                    if let Some(e)=args.get(1){
                        sub(e)?
                    }
                    return Ok(())
                }
                if n.starts_with("json") {crate::json::validate_call(&n,args.len())?;}
                if ["changes","total_changes","last_insert_rowid"].contains(&n.as_str())&&!args.is_empty(){return Err("wrong number of arguments".into())}
                if (n=="strftime"&&args.is_empty())||(n=="timediff"&&args.len()!=2){return Err("wrong number of arguments".into())}
                if ["row_number","rank","dense_rank","percent_rank","cume_dist","ntile","lag","lead","first_value","last_value","nth_value"].contains(&n.as_str())&&over.is_none(){return Err("misuse of window function".into())}
                let agg=is_aggregate(name,args.len());
                if args.iter().any(|e|matches!(e,Expr::Star(_)))&&!(n=="count"&&args.len()==1&&matches!(&args[0],Expr::Star(None))&&!*distinct){return Err("misuse of *".into())}
                if agg&&*distinct&&args.len()!=1{return Err("DISTINCT aggregates must have exactly one argument".into())}
                let arguments=args.iter().chain(filter.iter().map(|e|e.as_ref())).chain(order.iter().map(|o|&o.expr));
                if agg&&over.is_none()&&arguments.clone().any(|e|has_aggregate(e)||has_window(e)){return Err("misuse of aggregate function".into())}
                if let Some(w)=over{
                    if arguments.chain(w.partition.iter()).chain(w.order.iter().map(|o|&o.expr)).any(has_window){return Err("misuse of window function".into())}
                }
                let valid_arity=match n.as_str(){
                    "row_number"|"rank"|"dense_rank"|"percent_rank"|"cume_dist"=>args.is_empty(),"ntile"|"first_value"|"last_value"|"sum"|"total"|"avg"|"count"|"median"|"json_group_array"|"jsonb_group_array"=>args.len()==1,"nth_value"|"percentile"|"percentile_cont"|"percentile_disc"|"json_group_object"|"jsonb_group_object"|"string_agg"=>args.len()==2,"lag"|"lead"=>(1..=3).contains(&args.len()),"group_concat"=>(1..=2).contains(&args.len()),_=>true
                }
                ;
                if !valid_arity{
                    return Err(format!("wrong number of arguments to function {}()",name))
                }
                if over.is_some(){
                    if *distinct{
                        return Err("DISTINCT is not supported for window functions".into())
                    }
                    if !agg&&!["row_number","rank","dense_rank","percent_rank","cume_dist","ntile","lag","lead","first_value","last_value","nth_value"].contains(&n.as_str()){
                        return Err(format!("{}() may not be used as a window function",name))
                    }
                }
                if !agg&&filter.is_some(){
                    return Err("FILTER may only be used with aggregate functions".into())
                }
                if !agg&&!order.is_empty(){
                    return Err("ORDER BY may only be used with aggregate functions".into())
                }
                for e in args{
                    sub(e)?
                }
                if let Some(f)=filter{
                    sub(f)?
                }
                for o in order{
                    sub(&o.expr)?
                }
                if let Some(w)=over{
                    self.validate_window_frame(w)?;
                    for e in &w.partition{
                        sub(e)?
                    }
                    for o in &w.order{
                        sub(&o.expr)?
                    }
                }
                if !is_aggregate(name,args.len())&&!n.starts_with("json")&&!matches!(n.as_str(),"changes"|"total_changes"|"last_insert_rowid"|"date"|"time"|"datetime"|"julianday"|"unixepoch"|"strftime"|"timediff"|"row_number"|"rank"|"dense_rank"|"percent_rank"|"cume_dist"|"ntile"|"lag"|"lead"|"first_value"|"last_value"|"nth_value"){
                    functions::scalar(name,&vec![Value::Null;
                    args.len()],self.case_like)?;
                }
            }
        }
        Ok(())
    }
}

thread_local! {static BINDING_DEPTH:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
pub fn binding()->bool {BINDING_DEPTH.with(|d|d.get()>0)}
struct BindingScope;
impl BindingScope {fn enter()->Self{BINDING_DEPTH.with(|d|d.set(d.get()+1));Self}}
impl Drop for BindingScope {fn drop(&mut self){BINDING_DEPTH.with(|d|d.set(d.get()-1));}}

// Only statically checked constant expressions may temporarily leave binding mode.
pub(crate) fn evaluate_constant<T>(f:impl FnOnce()->T)->T{
    struct Restore(usize);
    impl Drop for Restore{fn drop(&mut self){BINDING_DEPTH.with(|d|d.set(self.0));}}
    let _restore=Restore(BINDING_DEPTH.with(|d|{let old=d.get();d.set(0);old}));
    f()
}
