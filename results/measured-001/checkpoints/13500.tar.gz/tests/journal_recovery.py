"""Interrupted multi-file commit states derived from atomiccommit.txt.

Before/after snapshots come only from this implementation. Filesystem edits
reproduce interruption points without relying on timing or a reference engine.
"""
import json,pathlib,subprocess
root=pathlib.Path('/work/journal-main.db');child=pathlib.Path('/work/journal-child.db')
master=pathlib.Path('/work/journal-recovery-master')
paths=[root,child]
def journal(path):return pathlib.Path(str(path)+'.agent-journal')
def cleanup():
 for path in paths:
  for file in [path,journal(path),pathlib.Path(str(path)+'.agent-lock')]:file.unlink(missing_ok=True)
 master.unlink(missing_ok=True)
class DB:
 def __init__(self,path):
  self.p=subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
  assert self.send({'op':'open','path':str(path)})['ok']
 def send(self,request):
  self.p.stdin.write(json.dumps(request)+'\n');self.p.stdin.flush();return json.loads(self.p.stdout.readline())
 def q(self,sql,want=None,err=False):
  result=self.send({'op':'execute','sql':sql})
  if err:assert not result['ok'],(sql,result);return
  assert result['ok'],(sql,result)
  if want is not None:assert [[v.get('value')for v in row]for row in result['rows']]==want,(sql,result,want)
 def stop(self):
  self.send({'op':'close'});self.p.terminate();self.p.wait()
cleanup()
a=DB(root);a.q('CREATE TABLE t(v)');a.q('INSERT INTO t VALUES(1)');a.q("ATTACH '/work/journal-child.db' AS aux")
a.q('CREATE TABLE aux.t(v)');a.q('INSERT INTO aux.t VALUES(1)');a.stop()
before=[path.read_bytes() for path in paths]
a=DB(root);a.q("ATTACH '/work/journal-child.db' AS aux");a.q('BEGIN');a.q('UPDATE t SET v=2');a.q('UPDATE aux.t SET v=2');a.q('COMMIT');a.stop()
after=[path.read_bytes() for path in paths]
def interrupted(published,journal_count=2,committed=False):
 master.write_text(json.dumps([str(path)for path in paths]))
 for i,path in enumerate(paths):
  path.write_bytes(after[i] if i<published else before[i])
  journal(path).unlink(missing_ok=True)
  if i<journal_count:journal(path).write_bytes(b'RustSQLite rollback 1\n'+json.dumps(str(master)).encode()+b'\n'+before[i])
 if committed:master.unlink()
for published,journal_count,committed,want in [(0,1,False,'1'),(0,2,False,'1'),(1,2,False,'1'),(2,2,False,'1'),(2,2,True,'2')]:
 interrupted(published,journal_count,committed)
 for path in paths:
  db=DB(path);db.q('SELECT * FROM t',[[want]]);db.stop()
 assert not master.exists();assert all(not journal(path).exists()for path in paths)
# A live writer owns the recovery lock; readers must use committed before-images.
for path,bytes_ in zip(paths,before):path.write_bytes(bytes_)
a=DB(root);a.q("ATTACH '/work/journal-child.db' AS aux");a.q('BEGIN IMMEDIATE')
interrupted(2)
b=DB(root);b.q('SELECT * FROM t',[['1']]);c=DB(child);c.q('SELECT * FROM t',[['1']])
master.unlink() # The documented commit point exposes every prepared new image.
b.q('SELECT * FROM t',[['2']]);c.q('SELECT * FROM t',[['2']]);b.stop();c.stop()
a.p.kill();a.p.wait() # Locks release even with leftover rollback journals.
for path in paths:
 db=DB(path);db.q('SELECT * FROM t',[['2']]);db.stop();assert not journal(path).exists()
# A child staging failure leaves every committed file unchanged, and COMMIT can
# be retried using the still-active transaction.
a=DB(root);a.q("ATTACH '/work/journal-child.db' AS aux")
a.q('BEGIN');a.q('UPDATE t SET v=3');a.q('UPDATE aux.t SET v=3')
blocker=pathlib.Path(str(child)+f'.agent-{a.p.pid}-tmp');blocker.write_text('injected failure')
a.q('COMMIT',err=True)
b=DB(root);b.q('SELECT * FROM t',[['2']]);b.stop();c=DB(child);c.q('SELECT * FROM t',[['2']]);c.stop()
blocker.unlink();a.q('COMMIT');a.q('SELECT * FROM t',[['3']]);a.q('SELECT * FROM aux.t',[['3']])
a.q('SAVEPOINT outer');a.q('UPDATE t SET v=4');a.q('UPDATE aux.t SET v=4')
blocker.write_text('injected failure');a.q('RELEASE outer',err=True)
b=DB(root);b.q('SELECT * FROM t',[['3']]);b.stop();blocker.unlink();a.q('ROLLBACK TO outer');a.q('RELEASE outer')
a.q('SELECT * FROM t',[['3']]);a.q('SELECT * FROM aux.t',[['3']]);a.stop()
assert all(not journal(path).exists()for path in paths)
# Autocommit statements spanning databases roll back together on staging errors.
a=DB(root);a.q("ATTACH '/work/journal-child.db' AS aux")
a.q('CREATE TABLE aux.mirror(v)');a.q('INSERT INTO aux.mirror VALUES(3)')
a.q('CREATE TEMP TRIGGER mirror_update AFTER UPDATE ON t BEGIN UPDATE mirror SET v=new.v; END')
blocker=pathlib.Path(str(child)+f'.agent-{a.p.pid}-tmp');blocker.write_text('injected failure')
a.q('UPDATE t SET v=77',err=True);blocker.unlink()
a.q('SELECT * FROM t',[['3']]);a.q('SELECT * FROM aux.mirror',[['3']]);a.q('BEGIN');a.q('ROLLBACK');a.stop()
# A SELECT spanning both databases must not mix halves of concurrent commits.
import threading,time
writer=DB(root);reader=DB(root)
for db in [writer,reader]:db.q("ATTACH '/work/journal-child.db' AS aux");db.q('PRAGMA busy_timeout=2000')
errors=[]
def commit_loop():
 try:
  for n in range(5,45):
   writer.q('BEGIN');writer.q(f'UPDATE t SET v={n}');writer.q(f'UPDATE aux.t SET v={n}');writer.q('COMMIT')
 except BaseException as error:errors.append(error)
thread=threading.Thread(target=commit_loop);thread.start();reads=0
while thread.is_alive():
 reader.q('SELECT m.v=c.v FROM main.t AS m,aux.t AS c',[['1']]);reads+=1
 time.sleep(0.0005)
thread.join();assert not errors,errors;assert reads>0
reader.q('SELECT m.v,c.v FROM main.t AS m,aux.t AS c',[['44','44']]);reader.stop();writer.stop()
cleanup();print('Multi-file commit, injected I/O failures, live-reader isolation and interrupted-commit recovery passed')
