# Implementation state

Rust-only SQL implementation; serde/serde_json are the only dependencies. Build:
`cargo build --release --offline --bin sqlite-agent`. Protocol is JSON lines per IO_CONTRACT.md.

Modules: lexer/parser/ast; value for storage classes and affinity; engine for relational/expression evaluation; mutate for DDL/DML/constraints/transactions; storage for durable snapshots; functions/datetime/json/window; pragma for schema metadata.

Integrated baseline passes tests/smoke.py (51 assertions). Test expected values come from supplied docs and manual semantic reasoning, never another engine.

Storage uses versioned JSON snapshots with fsync + atomic rename. Explicit transactions and savepoints keep snapshots, persist only on commit, roll back on close. This is a custom format, not binary SQLite file compatibility. Workspace confinement checks reject traversal/outside paths.

Implemented: select/values, sorting/distinct/compound selects, joins including outer joins, grouping/aggregates, correlated scalar/EXISTS/IN subqueries, CTEs/recursive CTEs, many scalar/date/JSON funcs, basic window funcs; create/drop table/view/index, alter table; CRUD/returning/upsert; affinity/strict/generation/default/check/not-null/unique/primary constraints; foreign keys/actions/deferred validation; transactions/savepoints; common pragmas/schema tables.

Next: deeper correctness tests, fix empty-query validation, join USING visibility, collation/affinity corner cases, trigger support, richer JSON table functions, CTE DML, row-value expressions. Audit conflict modes, cascading self-references, window frame edges, temp objects. Current limitations include no triggers/attach/virtual-table extensions yet, partial JSON subtype/JSON5 behavior, limited EXPLAIN, no concurrency locks or native SQLite page format. Keep implementation usable and extend according to supplied docs.
