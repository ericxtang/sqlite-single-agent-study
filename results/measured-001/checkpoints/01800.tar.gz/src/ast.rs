use serde::{Serialize,Deserialize};
use crate::value::Value;
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Expr { Tuple(Vec<Expr>),RowAccess(Box<Expr>,usize),Lit(Value), Col(Vec<String>), Star(Option<String>), Unary(String,Box<Expr>), Binary(String,Box<Expr>,Box<Expr>), Between(Box<Expr>,Box<Expr>,Box<Expr>,bool), In(Box<Expr>,Vec<Expr>,Option<Box<Query>>,bool), Is(Box<Expr>,Box<Expr>,bool), Case(Option<Box<Expr>>,Vec<(Expr,Expr)>,Option<Box<Expr>>), Cast(Box<Expr>,String), Collate(Box<Expr>,String), Call{name:String,args:Vec<Expr>,distinct:bool,filter:Option<Box<Expr>>,order:Vec<Order>,over:Option<Window>}, Subquery(Box<Query>), Exists(Box<Query>) }
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Window {pub name:Option<String>,pub partition:Vec<Expr>,pub order:Vec<Order>,pub frame:Vec<String>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Order{pub expr:Expr,pub desc:bool,pub nulls:Option<bool>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Item{pub expr:Expr,pub name:String,pub alias:Option<String>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Source {Table(String,Option<String>,Vec<Expr>),Query(Box<Query>,Option<String>),Join(Box<Source>,Box<Source>,String,Option<Expr>,Vec<String>,bool)}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Select {pub distinct:bool,pub items:Vec<Item>,pub from:Option<Source>,pub filter:Option<Expr>,pub group:Vec<Expr>,pub having:Option<Expr>,pub values:Option<Vec<Vec<Expr>>>,pub windows:Vec<(String,Window)>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Cte{pub name:String,pub cols:Vec<String>,pub query:Query}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Query{pub ctes:Vec<Cte>,pub recursive:bool,pub cores:Vec<Select>,pub ops:Vec<String>,pub order:Vec<Order>,pub limit:Option<Expr>,pub offset:Option<Expr>}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Column{pub name:String,pub typ:String,pub not_null:bool,pub primary:usize,pub unique:bool,pub default:Option<Expr>,pub default_sql:Option<String>,pub collate:String,pub generated:Option<Expr>,pub stored:bool,pub auto:bool,pub pk_desc:bool,pub conflict:String}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Foreign{pub cols:Vec<String>,pub table:String,pub target:Vec<String>,pub delete:String,pub update:String,pub deferred:bool}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct TableDef{pub name:String,pub cols:Vec<Column>,pub checks:Vec<Expr>,pub uniques:Vec<Vec<String>>,pub foreign:Vec<Foreign>,pub without_rowid:bool,pub strict:bool,pub sql:String,pub temporary:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Upsert{pub target:Vec<String>,pub assignments:Vec<(String,Expr)>,pub filter:Option<Expr>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Statement { Query(Query),CreateTrigger(Trigger,bool),CreateTable(TableDef,bool,Option<Query>),CreateView(String,Vec<String>,Query,bool,String),CreateIndex(String,String,Vec<Order>,bool,Option<Expr>,bool,String),Drop(String,String,bool),Insert{table:String,cols:Vec<String>,query:Option<Query>,default:bool,conflict:String,upsert:Vec<Upsert>,returning:Vec<Item>},Update{table:String,alias:Option<String>,assignments:Vec<(String,Expr)>,filter:Option<Expr>,conflict:String,returning:Vec<Item>,from:Option<Source>,order:Vec<Order>,limit:Option<Expr>},Delete{table:String,alias:Option<String>,filter:Option<Expr>,returning:Vec<Item>,order:Vec<Order>,limit:Option<Expr>},Begin,Commit,Rollback(Option<String>),Savepoint(String),Release(String),Pragma(String,Option<Expr>),Alter(String,String,Option<String>,Option<Column>),Explain(Box<Statement>,bool),Noop }

#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Trigger{pub name:String,pub table:String,pub timing:String,pub event:String,pub columns:Vec<String>,pub when:Option<Expr>,pub body:Vec<Statement>,pub sql:String,pub temporary:bool}
