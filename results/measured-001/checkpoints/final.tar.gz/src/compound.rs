use crate::{ast::*,engine::*,value::Value,parser::Res};

pub(crate) struct CompoundPlan{
    pub order:Vec<Order>,pub collations:Vec<(String,bool)>,pub inputs:Vec<Relation>
}
// ORDER BY permits signed integer column positions, including a COLLATE suffix.
pub(crate) fn integer_position(e:&Expr)->Option<i64>{
    match e{
        Expr::Lit(Value::Integer(i))=>Some(*i),Expr::Collate(e,_)=>integer_position(e),
        Expr::Unary(op,e) if op=="+"=>integer_position(e),
        Expr::Unary(op,e) if op=="-"=>integer_position(e)?.checked_neg(),_=>None
    }
}
fn uncollated(e:&Expr)->&Expr{if let Expr::Collate(e,_)=e{uncollated(e)}else{e}}
fn expression_key(e:&Expr,env:&Env)->serde_json::Value{
    let mut expression=e.clone();
    let mut query=false;
    crate::schema::visit_expr(&mut expression,&mut |e|{query|=matches!(e,Expr::Subquery(_)|Expr::Exists(_)|Expr::In(_,_,Some(_),_));});
    if !query{
        crate::schema::visit_expr(&mut expression,&mut |e|match e{
            Expr::Col(names)=>{
                if let Ok(Some(index))=env.find(names){*names=vec![format!("#{}",index)];}
                else{for name in names{name.make_ascii_lowercase();}}
            }
            Expr::Dqs(name)=>{
                *e=if let Ok(Some(index))=env.find(&[name.clone()]){Expr::Col(vec![format!("#{}",index)])}else{Expr::Lit(Value::Text(name.clone()))};
            }
            Expr::Call{name,..}|Expr::Collate(_,name)=>name.make_ascii_lowercase(),
            Expr::Cast(_,name)=>name.make_ascii_uppercase(),_=>{}
        });
    }
    serde_json::to_value(expression).unwrap_or(serde_json::Value::Null)
}
impl Engine{
    pub(crate) fn result_collation(&self,e:&Expr,env:&Env)->Option<String>{
        if let Some(collation)=explicit_collate(e){return Some(collation)}
        match e{
            Expr::Col(names)=>env.get(names).ok().flatten().and_then(|(_,field)|field.collation_defined.then_some(field.collate)),
            Expr::Dqs(name)=>self.result_collation(&Expr::Col(vec![name.clone()]),env),
            Expr::Cast(e,_)=>self.result_collation(e,env),
            Expr::Unary(op,e) if op=="+"=>self.result_collation(e,env),_=>None
        }
    }
    pub(crate) fn compound_plan(&self,q:&Query,outer:&Env,ctes:&Ctes,depth:usize)->Res<CompoundPlan>{
        let mut projections=vec![];
        let mut inputs=vec![];
        let mut collations:Vec<Option<String>>=vec![];
        for select in &q.cores{
            let input=select.from.as_ref().map(|s|self.bind_source(s,outer,ctes,depth+1)).transpose()?.unwrap_or_default();
            let env=Env{values:vec![Value::Null;input.fields.len()],fields:input.fields.clone(),outer:Some(Box::new(outer.clone()))};
            let items=if let Some(rows)=&select.values{
                rows.first().into_iter().flatten().enumerate().map(|(i,e)|Item{expr:e.clone(),name:format!("column{}",i+1),alias:None}).collect()
            }else{expand_items(&select.items,&env.fields)?};
            if projections.is_empty(){collations.resize(items.len(),None);}
            if items.len()!=collations.len(){return Err("SELECTs have different number of result columns".into())}
            for(i,item)in items.iter().enumerate(){if collations[i].is_none(){collations[i]=self.result_collation(&item.expr,&env);}}
            projections.push((items,env));inputs.push(input);
        }
        let mut orders=vec![];
        for term in &q.order{
            let (position,collation)=if let Some(position)=integer_position(&term.expr){
                if position<1||position as usize>collations.len(){return Err("ORDER BY term out of range".into())}
                (position as usize-1,collations[position as usize-1].clone())
            }else{
                let expression=uncollated(&term.expr);
                let alias=match expression{Expr::Col(names) if names.len()==1=>Some(&names[0]),Expr::Dqs(name)=>Some(name),_=>None};
                let mut found=None;
                for(items,env)in &projections{
                    let key=expression_key(expression,env);
                    if let Some(index)=items.iter().position(|item|alias.is_some_and(|name|item.alias.as_ref().unwrap_or(&item.name).eq_ignore_ascii_case(name))||expression_key(uncollated(&item.expr),env)==key){
                        found=Some((index,self.result_collation(&items[index].expr,env)));break
                    }
                }
                found.ok_or("ORDER BY term does not match any column in the result set")?
            };
            let collation=explicit_collate(&term.expr).or(collation).unwrap_or_else(||"BINARY".into());
            if !["binary","nocase","rtrim"].contains(&collation.to_ascii_lowercase().as_str()){return Err(format!("no such collation sequence: {}",collation))}
            orders.push(Order{expr:Expr::Collate(Box::new(Expr::Lit(Value::Integer(position as i64+1))),collation),desc:term.desc,nulls:term.nulls});
        }
        Ok(CompoundPlan{order:orders,collations:collations.into_iter().map(|c|(c.clone().unwrap_or_else(||"BINARY".into()),c.is_some())).collect(),inputs})
    }
}
