// Validate structural invariants before a deserialized snapshot can enter the
// evaluator. SQL constraint violations are left to integrity/FK checking.
use crate::{ast::*,storage::{Database,Table,key},value::Value};
use std::collections::HashSet;
type Res=Result<(),String>;
fn malformed(reason:&str)->String{format!("malformed database: {}",reason)}
fn value(value:&Value)->Res{
    if matches!(value,Value::Real(n) if n.is_nan()){return Err(malformed("NaN value"))}Ok(())
}
enum Node<'a>{Expr(&'a Expr),Query(&'a Query),Source(&'a Source),Statement(&'a Statement)}
fn definition<'a>(def:&'a TableDef,nodes:&mut Vec<Node<'a>>){
    for c in &def.cols{
        nodes.extend(c.default.iter().chain(c.generated.iter()).chain(c.checks.iter()).map(Node::Expr));
    }
    nodes.extend(def.checks.iter().map(Node::Expr));
    for k in &def.keys{nodes.extend(k.cols.iter().map(|o|Node::Expr(&o.expr)));}
}
fn table<'a>(t:&'a Table,nodes:&mut Vec<Node<'a>>)->Res{
    if t.def.cols.is_empty(){return Err(malformed("table has no columns"))}
    let mut ids=HashSet::new();
    for row in &t.rows{
        if row.values.len()!=t.def.cols.len(){return Err(malformed("row width differs from table definition"))}
        if !ids.insert(row.id){return Err(malformed("duplicate rowid"))}
        if t.ipk().is_some_and(|i|row.values[i]!=Value::Integer(row.id)){return Err(malformed("integer primary key differs from rowid"))}
        for v in &row.values{value(v)?;}
    }
    definition(&t.def,nodes);Ok(())
}
pub(crate) fn validate(db:&Database)->Res{
    let mut nodes=vec![];
    for (name,t) in &db.tables{
        if *name!=key(&t.def.name){return Err(malformed("table name differs from schema key"))}
        table(t,&mut nodes)?;
    }
    if let Some(rows)=&db.sequence_rows{
        let mut ids=HashSet::new();
        for row in rows{
            if row.values.len()!=2||!ids.insert(row.id){return Err(malformed("invalid sqlite_sequence row"))}
            for v in &row.values{value(v)?;}
        }
    }
    for (name,index) in &db.indexes{
        if *name!=key(&index.name)||!db.tables.contains_key(&key(&index.table))||index.cols.is_empty(){return Err(malformed("invalid index definition"))}
        nodes.extend(index.cols.iter().map(|o|Node::Expr(&o.expr)));
        nodes.extend(index.filter.iter().map(Node::Expr));
    }
    for (name,view) in &db.views{
        if *name!=key(&view.name){return Err(malformed("view name differs from schema key"))}
        nodes.push(Node::Query(&view.query));
    }
    for (name,trigger) in &db.triggers{
        if *name!=key(&trigger.name)||(!db.tables.contains_key(&key(&trigger.table))&&!db.views.contains_key(&key(&trigger.table))){return Err(malformed("invalid trigger definition"))}
        nodes.extend(trigger.when.iter().map(Node::Expr));nodes.extend(trigger.body.iter().map(Node::Statement));
    }
    while let Some(node)=nodes.pop(){
        match node{
            Node::Expr(expr)=>match expr{
                Expr::Col(names) if names.is_empty()=>return Err(malformed("empty column reference")),
                Expr::Lit(v)=>value(v)?,
                Expr::Unary(_,e)|Expr::Cast(e,_)|Expr::Collate(e,_)|Expr::RowAccess(e,..)=>nodes.push(Node::Expr(e)),
                Expr::Binary(_,a,b)|Expr::Is(a,b,_)=>{nodes.push(Node::Expr(a));nodes.push(Node::Expr(b));}
                Expr::Between(a,b,c,_)=>{nodes.push(Node::Expr(a));nodes.push(Node::Expr(b));nodes.push(Node::Expr(c));}
                Expr::Tuple(es)=>nodes.extend(es.iter().map(Node::Expr)),
                Expr::In(e,es,q,_)=>{nodes.push(Node::Expr(e));nodes.extend(es.iter().map(Node::Expr));if let Some(q)=q{nodes.push(Node::Query(q));}}
                Expr::Case(base,arms,other)=>{for e in base.iter().chain(other.iter()){nodes.push(Node::Expr(e));}for(a,b)in arms{nodes.push(Node::Expr(a));nodes.push(Node::Expr(b));}}
                Expr::Subquery(q)|Expr::Exists(q)=>nodes.push(Node::Query(q)),
                Expr::Call{args,filter,order,over,..}=>{
                    nodes.extend(args.iter().map(Node::Expr));if let Some(e)=filter{nodes.push(Node::Expr(e));}
                    nodes.extend(order.iter().map(|o|Node::Expr(&o.expr)));
                    if let Some(w)=over{nodes.extend(w.partition.iter().map(Node::Expr));nodes.extend(w.order.iter().map(|o|Node::Expr(&o.expr)));}
                }
                _=>{}
            },
            Node::Query(q)=>{
                if q.cores.is_empty()||q.ops.len()+1!=q.cores.len(){return Err(malformed("invalid compound query"))}
                nodes.extend(q.ctes.iter().map(|c|Node::Query(&c.query)));
                nodes.extend(q.order.iter().map(|o|Node::Expr(&o.expr)));nodes.extend(q.limit.iter().chain(q.offset.iter()).map(Node::Expr));
                for select in &q.cores{
                    if let Some(rows)=&select.values{
                        if rows.is_empty()||rows.iter().any(|r|r.len()!=rows[0].len()){return Err(malformed("invalid VALUES rows"))}
                        nodes.extend(rows.iter().flatten().map(Node::Expr));
                    }else if select.items.is_empty(){return Err(malformed("SELECT has no result columns"))}
                    nodes.extend(select.items.iter().map(|i|Node::Expr(&i.expr)));
                    nodes.extend(select.filter.iter().chain(select.having.iter()).chain(select.group.iter()).map(Node::Expr));
                    if let Some(s)=&select.from{nodes.push(Node::Source(s));}
                    for(_,w)in &select.windows{nodes.extend(w.partition.iter().map(Node::Expr));nodes.extend(w.order.iter().map(|o|Node::Expr(&o.expr)));}
                }
            },
            Node::Source(s)=>match s{
                Source::Table(_,_,args)=>nodes.extend(args.iter().map(Node::Expr)),
                Source::Query(q,_)=>nodes.push(Node::Query(q)),
                Source::Indexed(s,_)=>nodes.push(Node::Source(s)),
                Source::Join(a,b,_,on,_,_)=>{nodes.push(Node::Source(a));nodes.push(Node::Source(b));nodes.extend(on.iter().map(Node::Expr));}
            },
            Node::Statement(s)=>match s{
                Statement::Query(q)|Statement::CreateView(_,_,q,..)=>nodes.push(Node::Query(q)),
                Statement::With(ctes,_,s)=>{nodes.extend(ctes.iter().map(|c|Node::Query(&c.query)));nodes.push(Node::Statement(s));}
                Statement::IndexGuard(s,_)|Statement::Explain(s,_)=>nodes.push(Node::Statement(s)),
                Statement::CreateTable(d,_,q)=>{definition(d,&mut nodes);if let Some(q)=q{nodes.push(Node::Query(q));}}
                Statement::Insert{query,upsert,returning,..}=>{
                    if let Some(q)=query{nodes.push(Node::Query(q));}
                    for u in upsert{nodes.extend(u.target_exprs.iter().map(|o|Node::Expr(&o.expr)));nodes.extend(u.target_where.iter().chain(u.filter.iter()).map(Node::Expr));nodes.extend(u.assignments.iter().map(|(_,e)|Node::Expr(e)));}
                    nodes.extend(returning.iter().map(|i|Node::Expr(&i.expr)));
                }
                Statement::Update{assignments,filter,returning,from,order,limit,..}=>{
                    nodes.extend(assignments.iter().map(|(_,e)|Node::Expr(e)));nodes.extend(filter.iter().chain(limit.iter()).map(Node::Expr));nodes.extend(returning.iter().map(|i|Node::Expr(&i.expr)));nodes.extend(order.iter().map(|o|Node::Expr(&o.expr)));if let Some(s)=from{nodes.push(Node::Source(s));}
                }
                Statement::Delete{filter,returning,order,limit,..}=>{nodes.extend(filter.iter().chain(limit.iter()).map(Node::Expr));nodes.extend(returning.iter().map(|i|Node::Expr(&i.expr)));nodes.extend(order.iter().map(|o|Node::Expr(&o.expr)));}
                _=>{}
            }
        }
    }
    Ok(())
}
