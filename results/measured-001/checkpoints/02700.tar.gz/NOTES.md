# Implementation state

Rust-only SQL implementation; serde/serde_json are the only dependencies. Build:
`cargo build --release --offline --bin sqlite-agent`. Protocol is JSON lines per IO_CONTRACT.md.

Modules: lexer/parser/ast; value for storage classes and affinity; engine for relational/expression evaluation; mutate for DDL/DML/constraints/transactions; storage for durable snapshots; functions/datetime/json/window; pragma for schema metadata.

Integrated baseline passes tests/smoke.py (51 assertions). Test expected values come from supplied docs and manual semantic reasoning, never another engine.

Storage uses versioned JSON snapshots with fsync + atomic rename. Explicit transactions and savepoints keep snapshots, persist only on commit, roll back on close. This is a custom format, not binary SQLite file compatibility. Workspace confinement checks reject traversal/outside paths.

Implemented: select/values, sorting/distinct/compound selects, joins including outer joins, grouping/aggregates, correlated scalar/EXISTS/IN subqueries, CTEs/recursive CTEs, many scalar/date/JSON funcs, basic window funcs; create/drop table/view/index, alter table; CRUD/returning/upsert; affinity/strict/generation/default/check/not-null/unique/primary constraints; foreign keys/actions/deferred validation; transactions/savepoints; common pragmas/schema tables.

Next: deeper correctness tests, fix empty-query validation, join USING visibility, collation/affinity corner cases, trigger support, richer JSON table functions, CTE DML, row-value expressions. Audit conflict modes, cascading self-references, window frame edges, temp objects. Current limitations include no triggers/attach/virtual-table extensions yet, partial JSON subtype/JSON5 behavior, limited EXPLAIN, no concurrency locks or native SQLite page format. Keep implementation usable and extend according to supplied docs.

## Further integrated progress

Added triggers (BEFORE/AFTER, WHEN, UPDATE OF, RAISE actions, nested programs, INSTEAD OF view writes), row-value comparison/IN/UPDATE, CTE DML, JSON expression composition and json_each/json_tree with correlated table functions. Corrected USING visibility, NOCASE window peers, empty-result binding errors, signed minimum integer literal, column collation precedence, IN-subquery affinity, AUTOINCREMENT IGNORE gaps, rowid aliases and UPSERT target validation.

Writer lock files now prevent concurrent write loss; reads refresh committed snapshots; transactions retain snapshots and reject stale upgrades. Lock ownership survives process crashes via stale-PID detection. Persistence/isolation tests use only this implementation, including kill/reopen and temp-table checks. ATTACH/DETACH and schema-qualified CRUD/querying work; transaction controls propagate to attached connections. Multi-file commits currently persist files individually (not crash-atomic across all attachments). Rollback-journal reader blocking and full EXCLUSIVE lock semantics remain incomplete; ordinary concurrent reader/writer behavior resembles snapshot/WAL behavior.

Current tests: smoke.py 51, regression.py 135, persistence.py multiple process-level assertions, all passing at last build. `cargo fmt` unavailable in supplied toolchain; no attempted network install. Next improve JSON5/object ordering, window frame bounds/exclusion, conflict and foreign-key edge cases, and schema mutation validation. Maintain integrated builds.
