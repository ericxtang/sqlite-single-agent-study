import json,pathlib,subprocess,os,time,threading
path='/work/concurrency-test.db'
for n in [path,path+'.agent-lock']:
 pathlib.Path(n).unlink(missing_ok=True)
class DB:
 def __init__(self):
  self.p=subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
  assert self.send({'op':'open','path':path})['ok']
 def send(self,o):
  self.p.stdin.write(json.dumps(o)+'\n');self.p.stdin.flush();return json.loads(self.p.stdout.readline())
 def q(self,s,expect=None,err=False):
  r=self.send({'op':'execute','sql':s})
  if err:assert not r['ok'],(s,r)
  else:
   assert r['ok'],(s,r)
   if expect is not None:assert [[v.get('value')for v in row]for row in r['rows']]==expect,(s,r,expect)
 def stop(self):
  self.send({'op':'close'});self.p.terminate();self.p.wait()
a=DB();b=DB();a.q('CREATE TABLE t(id INTEGER PRIMARY KEY,v)');a.q("INSERT INTO t VALUES(1,'a')");b.q('SELECT * FROM t',[['1','a']])
version=lambda db:db.send({'op':'execute','sql':'PRAGMA data_version'})['rows'][0][0]['value']
before=version(b)
a.q('CREATE TEMP TABLE version_temp(x)');a.q('INSERT INTO version_temp VALUES(1)');a.q('DROP TABLE version_temp')
assert version(b)==before
# Temp writes neither require nor modify another connection's main writer lock.
a.q('BEGIN IMMEDIATE');b.q('CREATE TEMP TABLE unlocked_temp(x)');b.q('INSERT INTO unlocked_temp VALUES(2)');b.q('SELECT * FROM unlocked_temp',[['2']]);a.q('ROLLBACK')
b.q('PRAGMA main.user_version=88');a.q('PRAGMA main.user_version',[['88']])
a.q('PRAGMA temp.user_version=12');a.q('PRAGMA temp.user_version',[['12']]);b.q('PRAGMA temp.user_version',[['0']])
before=version(b);a.q('CREATE TABLE IF NOT EXISTS t(other)');a.q('UPDATE t SET v=0 WHERE 0');assert version(b)==before
# Busy handlers wait until a competing writer finishes, then retry the lock.
b.q('PRAGMA busy_timeout=1000');a.q('BEGIN IMMEDIATE')
timer=threading.Timer(0.08,lambda:a.q('ROLLBACK'));timer.start()
started=time.monotonic();b.q("INSERT INTO t VALUES(99,'waited')");assert time.monotonic()-started>=0.05;timer.join()
b.q('DELETE FROM t WHERE id=99');b.q('PRAGMA busy_timeout=30');a.q('BEGIN IMMEDIATE')
started=time.monotonic();b.q("INSERT INTO t VALUES(99,'timed-out')",err=True);assert time.monotonic()-started>=0.02
a.q('ROLLBACK');b.q('PRAGMA busy_timeout=0')
a.q('BEGIN');a.q("UPDATE t SET v='pending'");b.q('SELECT * FROM t',[['1','a']]);b.q("INSERT INTO t VALUES(2,'blocked')",err=True);a.q('COMMIT');b.q('SELECT * FROM t',[['1','pending']])
a.q('BEGIN');a.q('SELECT * FROM t',[['1','pending']]);b.q("UPDATE t SET v='committed'");a.q('SELECT * FROM t',[['1','pending']]);a.q("UPDATE t SET v='stale'",err=True);a.q('ROLLBACK');a.q('SELECT * FROM t',[['1','committed']])
a.q('BEGIN IMMEDIATE');b.q('BEGIN IMMEDIATE',err=True);a.q('ROLLBACK');b.q('BEGIN IMMEDIATE');b.q('ROLLBACK')
a.q('BEGIN');a.q("INSERT INTO t VALUES(2,'crash')");a.p.kill();a.p.wait();b.q('SELECT * FROM t',[['1','committed']]);b.q("INSERT INTO t VALUES(3,'after-crash')");b.stop()
c=DB();c.q('SELECT * FROM t',[['1','committed'],['3','after-crash']]);c.q('CREATE TEMP TABLE tmp(x)');c.q('INSERT INTO tmp VALUES(1)');c.q('SELECT * FROM tmp',[['1']]);c.stop();c=DB();c.q('SELECT * FROM tmp',err=True);c.stop()
c=DB();c.q('CREATE TABLE types(i,r,b,t)');c.q("INSERT INTO types VALUES(9223372036854775807,1e999,x'00FF','λ')");c.stop();c=DB();c.q('SELECT * FROM types',[['9223372036854775807','Inf','00FF','λ']]);c.stop()
# Deep schema expressions and per-constraint metadata survive serialization.
c=DB();expr='abs('*55+'a'+')'*55
c.q('CREATE TABLE nested_schema(a INT CHECK('+expr+'>=0),b TEXT,UNIQUE(b COLLATE NOCASE) ON CONFLICT IGNORE)')
c.q("INSERT INTO nested_schema VALUES(1,'A')");c.stop();c=DB()
c.q("INSERT INTO nested_schema VALUES(2,'a')");c.q('SELECT * FROM nested_schema',[['1','A']])
c.q('CREATE TABLE persisted_json(j)');c.q("INSERT INTO persisted_json VALUES(json('{a:[1,2]}'))");c.stop();c=DB()
c.q('SELECT json_array(j) FROM persisted_json', [[json.dumps(['{\"a\":[1,2]}'],separators=(',',':'))]]);c.stop()
# Persisted triggers retain exact tuple assignment widths and expression targets.
c=DB();c.q('CREATE TABLE persisted_pair(x,y)');c.q('INSERT INTO persisted_pair VALUES(1,2)')
c.q('CREATE TABLE persisted_fire(v)')
c.q('CREATE TRIGGER persisted_tuple AFTER INSERT ON persisted_fire BEGIN UPDATE persisted_pair SET(x,y)=(SELECT r,r FROM(SELECT random() AS r)); END')
c.q('CREATE TABLE persisted_up(name TEXT,live,hits)')
c.q('CREATE UNIQUE INDEX persisted_up_key ON persisted_up(lower(name)) WHERE live=1')
c.q("CREATE TRIGGER persisted_up_trigger AFTER INSERT ON persisted_fire BEGIN INSERT INTO persisted_up(name,live,hits) VALUES('Key',1,1) ON CONFLICT(lower(name)) WHERE live=1 DO UPDATE SET hits=hits+1; END")
c.stop();c=DB();c.q('INSERT INTO persisted_fire VALUES(1)');c.q('SELECT x=y FROM persisted_pair',[['1']])
c.q('ALTER TABLE persisted_up RENAME COLUMN name TO label');c.stop();c=DB()
c.q('INSERT INTO persisted_fire VALUES(2)');c.q('SELECT x=y FROM persisted_pair',[['1']]);c.q('SELECT * FROM persisted_up',[['Key','1','2']]);c.stop()
other='/work/attached-atomicity.db';pathlib.Path(other).unlink(missing_ok=True)
c=DB();c.q("ATTACH '/work/attached-atomicity.db' AS aux")
c.q('CREATE TABLE atomic_root(v)');c.q('CREATE TABLE aux.atomic_child(v)')
c.q("CREATE TEMP TRIGGER atomic_trigger AFTER INSERT ON atomic_root BEGIN INSERT INTO atomic_child VALUES(new.v); SELECT CASE WHEN new.v=2 THEN RAISE(ABORT,'stop') END; END")
c.q('INSERT INTO atomic_root VALUES(1),(2)',err=True);c.q('SELECT * FROM aux.atomic_child',[]);c.stop()
c=DB();c.q('SELECT * FROM atomic_root',[]);assert c.send({'op':'open','path':other})['ok'];c.q('SELECT * FROM atomic_child',[]);c.stop();pathlib.Path(other).unlink()
# Deferred violations prevent outer RELEASE from committing any attachment.
other='/work/release-atomicity.db';pathlib.Path(other).unlink(missing_ok=True)
c=DB();c.q("ATTACH '/work/release-atomicity.db' AS aux");c.q('CREATE TABLE aux.release_log(v)')
c.q('PRAGMA foreign_keys=ON');c.q('CREATE TABLE release_parent(id PRIMARY KEY)');c.q('CREATE TABLE release_child(id REFERENCES release_parent DEFERRABLE INITIALLY DEFERRED)')
c.q('SAVEPOINT release_outer');c.q('INSERT INTO release_child VALUES(1)');c.q('INSERT INTO aux.release_log VALUES(1)');c.q('RELEASE release_outer',err=True)
d=DB();assert d.send({'op':'open','path':other})['ok'];d.q('SELECT * FROM release_log',[]);d.stop();c.q('ROLLBACK');c.stop();pathlib.Path(other).unlink()
# A failed BEGIN across attachments releases locks already acquired.
first='/work/begin-first.db';second='/work/begin-second.db'
for filename in [first,second]:pathlib.Path(filename).unlink(missing_ok=True)
c=DB();c.q("ATTACH '/work/begin-first.db' AS first");c.q("ATTACH '/work/begin-second.db' AS second")
d=DB();assert d.send({'op':'open','path':second})['ok'];d.q('BEGIN IMMEDIATE');c.q('BEGIN IMMEDIATE',err=True)
e=DB();assert e.send({'op':'open','path':first})['ok'];e.q('BEGIN IMMEDIATE');e.q('ROLLBACK');e.stop()
d.q('ROLLBACK');d.stop();c.q('BEGIN IMMEDIATE');c.q('ROLLBACK');c.stop()
for filename in [first,second]:pathlib.Path(filename).unlink()
# Competing autocommit writers must refresh after locking, avoiding lost updates.
import concurrent.futures
c=DB();c.q('CREATE TABLE writer_counter(v)');c.q('INSERT INTO writer_counter VALUES(0)');c.stop()
barrier=threading.Barrier(6)
def increment_worker(_):
 db=DB();db.q('PRAGMA busy_timeout=5000');barrier.wait()
 for _ in range(30):db.q('UPDATE writer_counter SET v=v+1')
 db.stop()
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:list(pool.map(increment_worker,range(6)))
c=DB();c.q('SELECT v FROM writer_counter',[['180']]);c.stop()
# A failed persistence attempt during OR FAIL still releases locks and rolls back
# transient child transactions. A pre-existing temp path injects a disk error.
fault_child='/work/fault-child.db';pathlib.Path(fault_child).unlink(missing_ok=True)
c=DB();c.q("ATTACH '/work/fault-child.db' AS fault_child")
c.q('CREATE TABLE fault_root(v UNIQUE)');c.q('CREATE TABLE fault_child.fault_log(v)')
c.q('CREATE TEMP TRIGGER fault_after AFTER INSERT ON fault_root BEGIN INSERT INTO fault_log VALUES(new.v); END')
blocker=pathlib.Path(path+f'.agent-{c.p.pid}-tmp');blocker.write_text('injected I/O failure')
c.q('INSERT OR FAIL INTO fault_root VALUES(1),(1)',err=True);blocker.unlink()
c.q('SELECT * FROM fault_root',[]);c.q('SELECT * FROM fault_child.fault_log',[])
d=DB();d.q('BEGIN IMMEDIATE');d.q('ROLLBACK');d.stop()
c.q('BEGIN');c.q('INSERT INTO fault_root VALUES(2)');c.q('COMMIT');c.q('SELECT * FROM fault_child.fault_log',[['2']]);c.stop();pathlib.Path(fault_child).unlink()
# VACUUM INTO honors a writer lock on an existing empty destination.
empty_copy='/work/vacuum-locked.db';pathlib.Path(empty_copy).write_bytes(b'')
c=DB();d=DB();assert d.send({'op':'open','path':empty_copy})['ok'];d.q('BEGIN IMMEDIATE')
c.q("VACUUM INTO '/work/vacuum-locked.db'",err=True);d.q('ROLLBACK');d.stop()
c.q("VACUUM INTO '/work/vacuum-locked.db'");c.stop();pathlib.Path(empty_copy).unlink()
copy='/work/vacuum-copy.db';pathlib.Path(copy).unlink(missing_ok=True)
c=DB();c.q("VACUUM INTO '/work/' || 'vacuum-copy.db'");c.q("VACUUM INTO '/work/vacuum-copy.db'",err=True);c.stop()
c=DB();assert c.send({'op':'open','path':copy})['ok'];c.q('SELECT * FROM types',[['9223372036854775807','Inf','00FF','λ']]);c.q('SELECT * FROM t',[['1','committed'],['3','after-crash']]);c.stop();pathlib.Path(copy).unlink()
pathlib.Path(path).unlink();pathlib.Path(path+'.agent-lock').unlink(missing_ok=True);print('Persistence, isolation, writer locking, crash recovery, and temporary table checks passed')
