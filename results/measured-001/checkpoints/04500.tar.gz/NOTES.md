# Rust SQLite implementation state

## Build and interface

`cargo build --release --offline --bin sqlite-agent`
produces `target/release/sqlite-agent`. JSON-lines process interface follows
IO_CONTRACT.md. Only serde and serde_json (including arbitrary_precision) are used.
All development/tests ran through the offline workspace tool. No reference engine,
external parser/source/tests/network, or other agents were used.

## Architecture

- lexer/parser/ast: SQL syntax and serializable schema/programs.
- value: five storage classes, integer overflow, numeric conversion, affinity,
  collation, exact IEEE-754 snapshot representation.
- engine: relational execution, binding, expressions, aggregates, correlated
  subqueries, compound queries, ordinary/recursive CTEs, recursive work queue.
- mutate/schema: DDL/DML, constraints, schema rewrites, conflict policies,
  generated columns, foreign-key checks/actions.
- trigger/attach: row triggers (including RAISE and INSTEAD OF view writes),
  attached databases, transaction control propagation.
- window/functions/datetime/json/json_value/jsonb: window frames/exclusions,
  scalar/aggregate functions, calendar arithmetic, ordered JSON/JSON5 parser,
  JSON table functions and opaque binary JSON representation.
- storage/pragma: persistence, writer locks, schema metadata and pragmas.

## Storage and transaction design

Custom versioned snapshots, fsync + atomic rename. Snapshot serialization preserves
all integer/blob/text/real values, including infinities. Explicit transactions and
savepoints retain snapshots; durable writes happen on commit; close rolls back.
Paths are confined to /work with canonicalization. Readers refresh committed state;
transactions preserve read snapshots. Writer sidecar locks prevent lost writes and
stale transaction upgrades. Stale PID locks can be recovered after process death.

These are custom database and JSONB formats, not native SQLite binary formats.
Index definitions enforce constraints, but query execution primarily scans rows.
ATTACH commits files individually: cross-file crash atomicity is not implemented.
Reader/writer concurrency resembles snapshot/WAL behavior; full rollback-journal
reader locks and EXCLUSIVE mode semantics remain incomplete.

## Current verification

All passing at last integrated release build:
- `python3 tests/smoke.py`: 51 assertions.
- `python3 tests/regression.py`: 223 assertions.
- `python3 tests/properties.py`: 275 deterministic arithmetic/NULL/conflict/error
  recovery checks.
- `python3 tests/persistence.py`: concurrent processes, committed-read isolation,
  stale writers, writer locking, kill/reopen recovery, temporary table lifetime,
  and exact typed persistence (including large integer/blob/Unicode/infinity).

Tests are based on supplied docs and directly derived properties. cargo-fmt is not
installed in the supplied toolchain; no network installation was attempted.

## Remaining priorities/limits

Keep making useful progress and keep builds integrated. Next useful areas:
- More accurate temporary-schema namespace/shadowing, sqlite_sequence mutation,
  and schema catalog order/metadata details.
- JSON subtype propagation through arbitrary expressions; JSONB is intentionally
  opaque but not SQLite byte-compatible.
- Grouped aggregate windows, advanced window validation, tuple collation/affinity.
- Foreign-key edge cases: existing violations when enabling enforcement, trigger
  ordering/self-referential cascades, deferred errors across attachments.
- ALTER dependency rewriting for deeply nested/correlated/ambiguous references;
  DROP COLUMN dependency coverage and exact schema text rewriting.
- Scalar/date formatting edge cases, double-quoted string compatibility,
  statement-consistent current time.
- Real query indexes/optimization and resource limits for large/deep inputs.
- Virtual-table extensions (FTS/RTREE etc), comprehensive EXPLAIN, native SQLite
  page/WAL formats and locking compatibility remain unimplemented.
