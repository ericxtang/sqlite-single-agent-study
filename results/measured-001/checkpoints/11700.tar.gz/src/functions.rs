use crate::value::{
    Value,real,hex,unhex,compare
}
;
use std::cmp::Ordering;
pub fn scalar(name:&str,a:&[Value],case_like:bool)->Result<Value,String>{
    use Value::*;
    let normalized;
    let a=if a.iter().any(Value::is_json) {normalized=a.iter().cloned().map(Value::into_plain).collect::<Vec<_>>();normalized.as_slice()} else {a};
    let n=name.to_ascii_lowercase();
    let arity=|min,max|if a.len()<min||a.len()>max{
        Err(format!("wrong number of arguments to function {}()",name))
    }
    else{
        Ok(())
    }
    ;
    let nul=||a.iter().any(Value::null);
    let s=|i:usize|a.get(i).map(Value::text).unwrap_or_default();
    let i=|i:usize|a.get(i).map(Value::int).unwrap_or(0);
    let f=|i:usize|a.get(i).map(Value::float).unwrap_or(0.0);
    Ok(match n.as_str(){
        "typeof"=>{
            arity(1,1)?;
            Text(a[0].typ().into())
        }
        ,
        "length"|"octet_length"=>{
            arity(1,1)?;
            if nul(){
                Null
            }
            else{
                Integer(match &a[0]{
                    Blob(b)=>b.len() as i64,_=>if n=="octet_length"{
                        s(0).len() as i64
                    }
                    else{
                        s(0).split('\0').next().unwrap_or("").chars().count() as i64
                    }
                }
                )
            }
        }
        ,
        "abs"=>{
            arity(1,1)?;
            match &a[0]{
                Integer(x)=>Integer(x.checked_abs().ok_or("integer overflow")?),Null=>Null,x=>real(x.float().abs())
            }
        }
        ,
        "lower"|"upper"=>{
            arity(1,1)?;
            if nul(){
                Null
            }
            else{
                Text(if n=="lower"{
                    s(0).to_ascii_lowercase()
                }
                else{
                    s(0).to_ascii_uppercase()
                }
                )
            }
        }
        ,
        "hex"=>{
            arity(1,1)?;
            Text(hex(&match &a[0]{
                Blob(b)=>b.clone(),_=>s(0).into_bytes()
            }
            ))
        }
        ,
        "unhex"=>{
            arity(1,2)?;
            if a[0].null(){
                Null
            }
            else{
                let mut t=s(0);
                if a.len()==2{
                    t.retain(|c|c.is_ascii_hexdigit()||!s(1).contains(c))
                }
                unhex(&t).map(Blob).unwrap_or(Null)
            }
        }
        ,
        "quote"=>{
            arity(1,1)?;
            Text(match &a[0]{
                Null=>"NULL".into(),Text(t)=>format!("'{}'",t.split('\0').next().unwrap_or("").replace('\'',"''")),Blob(b)=>format!("X'{}'",hex(b)),_=>s(0)
            }
            )
        }
        ,
        "unistr"=>{
            arity(1,1)?;
            if nul(){
                Null
            }
            else{
                Text(unistr(&s(0))?)
            }
        }
        ,
        "unistr_quote"=>{
            arity(1,1)?;
            if let Text(t)=&a[0]{
                if t.chars().any(|c|c>'\0'&&c<' '){
                    let mut out=String::new();
                    for c in t.split('\0').next().unwrap_or("").chars(){
                        if c=='\\'{
                            out.push_str("\\\\")
                        }
                        else if c=='\''{
                            out.push_str("''")
                        }
                        else if c<' '{
                            out.push_str(&format!("\\u{:04x}",c as u32))
                        }
                        else{
                            out.push(c)
                        }
                    }
                    Text(format!("unistr('{}')",out))
                }
                else{
                    scalar("quote",a,case_like)?
                }
            }
            else{
                scalar("quote",a,case_like)?
            }
        }
        ,
        "soundex"=>{
            arity(1,1)?;
            Text(soundex(&s(0)))
        }
        ,
        "unicode"=>{
            arity(1,1)?;
            s(0).chars().next().map(|x|Integer(x as i64)).unwrap_or(Null)
        }
        ,
        "char"=>Text(a.iter().map(|v|char::from_u32(v.int() as u32).unwrap_or('\u{fffd}')).collect()),
        "substr"|"substring"=>{
            arity(2,3)?;
            if nul(){
                Null
            }
            else{
                let blob=matches!(a[0],Blob(_));
                let cs:Vec<u32>=if let Blob(b)=&a[0]{
                    b.iter().map(|x|*x as u32).collect()
                }
                else{
                    s(0).chars().map(|x|x as u32).collect()
                }
                ;
                let len=cs.len() as i64;
                let start=i(1);
                let mut pos=if start>0{
                    start-1
                }
                else if start<0{
                    len+start
                }
                else{
                    0
                }
                ;
                let mut count=if a.len()==3{
                    i(2)
                }
                else{
                    len
                }
                ;
                if start==0&&count>0{
                    count-=1
                }
                if count<0{
                    pos+=count;
                    count= -count
                }
                if pos<0{
                    count=(count+pos).max(0);
                    pos=0
                }
                let end=(pos.saturating_add(count)).max(0).min(len);
                pos=pos.min(len);
                let sl=&cs[pos as usize..end.max(pos) as usize];
                if blob{
                    Blob(sl.iter().map(|x|*x as u8).collect())
                }
                else{
                    Text(sl.iter().filter_map(|x|char::from_u32(*x)).collect())
                }
            }
        }
        ,
        "instr"=>{
            arity(2,2)?;
            if nul(){
                Null
            }
            else if let (Blob(h),Blob(n))=(&a[0],&a[1]){
                Integer(if n.is_empty(){
                    1
                }
                else{
                    h.windows(n.len()).position(|w|w==n).map(|p|p+1).unwrap_or(0) as i64
                }
                )
            }
            else{
                let h=s(0);
                Integer(h.find(&s(1)).map(|p|h[..p].chars().count()+1).unwrap_or(0) as i64)
            }
        }
        ,
        "replace"=>{
            arity(3,3)?;
            if nul(){
                Null
            }
            else if s(1).is_empty(){
                Text(s(0))
            }
            else{
                Text(s(0).replace(&s(1),&s(2)))
            }
        }
        ,
        "trim"|"ltrim"|"rtrim"=>{
            arity(1,2)?;
            if nul(){
                Null
            }
            else{
                let ch=if a.len()==2{
                    s(1)
                }
                else{
                    " ".into()
                }
                ;
                let t=s(0);
                Text(match n.as_str(){
                    "ltrim"=>t.trim_start_matches(|c|ch.contains(c)),"rtrim"=>t.trim_end_matches(|c|ch.contains(c)),_=>t.trim_matches(|c|ch.contains(c))
                }
                .into())
            }
        }
        ,
        "round"=>{
            arity(1,2)?;
            if nul(){
                Null
            }
            else{
                let p=10f64.powi(i(1).clamp(0,30) as i32);
                real(if f(0).abs()>=4503599627370496.0{
                    f(0)
                }
                else{
                    (f(0)*p).round()/p
                }
                )
            }
        }
        ,
        "sign"=>{
            arity(1,1)?;
            if a[0].null(){
                Null
            }
            else{
                let x=a[0].apply(crate::value::Affinity::Numeric);
                if matches!(x,Integer(_)|Real(_)){
                    Integer(if f(0)>0.0{
                        1
                    }
                    else if f(0)<0.0{
                        -1
                    }
                    else{
                        0
                    }
                    )
                }
                else{
                    Null
                }
            }
        }
        ,
        "coalesce"|"ifnull"|"nvl"=>{
            arity(2,if n=="coalesce"{
                usize::MAX
            }
            else{
                2
            }
            )?;
            a.iter().find(|v|!v.null()).cloned().unwrap_or(Null)
        }
        ,
        "nullif"=>{
            arity(2,2)?;
            if compare(&a[0],&a[1],"BINARY")==Ordering::Equal{
                Null
            }
            else{
                a[0].clone()
            }
        }
        ,
        "iif"|"if"=>{
            arity(2,usize::MAX)?;
            let mut res=Null;
            for pair in a.chunks(2){
                if pair.len()==1{
                    res=pair[0].clone()
                }
                else if pair[0].truth()==Some(true){
                    res=pair[1].clone();
                    break
                }
            }
            res
        }
        ,
        "min"|"max"=>{
            arity(2,usize::MAX)?;
            if nul(){
                Null
            }
            else{
                a.iter().cloned().reduce(|v,w|if (compare(&w,&v,"BINARY")==Ordering::Less)==(n=="min"){
                    w
                }
                else{
                    v
                }
                ).unwrap()
            }
        }
        ,
        "like"|"glob"=>{
            arity(2,if n=="like"{
                3
            }
            else{
                2
            }
            )?;
            if nul(){
                Null
            }
            else{
                if s(0).len()>50000{
                    return Err("LIKE or GLOB pattern too complex".into())
                }
                let esc=if a.len()==3{
                    let x=s(2);
                    let mut c=x.chars();
                    let e=c.next().ok_or("ESCAPE expression must be a single character")?;
                    if c.next().is_some(){
                        return Err("ESCAPE expression must be a single character".into())
                    }
                    Some(e)
                }
                else{
                    None
                }
                ;
                Value::boolean(pattern(&s(0),&s(1),n=="glob",esc,case_like))
            }
        }
        ,
        "zeroblob"=>{
            arity(1,1)?;
            let len=i(0).max(0) as usize;
            if len>16*1024*1024{
                return Err("string or blob too big".into())
            }
            Blob(vec![0;
            len])
        }
        ,
        "random"=>{
            arity(0,0)?;
            Integer(match random_u64() as i64{
                i64::MIN=>0,x=>x
            }
            )
        }
        ,
        "randomblob"=>{
            arity(1,1)?;
            let len=i(0).max(1) as usize;
            if len>16*1024*1024{
                return Err("string or blob too big".into())
            }
            Blob((0..len).map(|_|random_u64() as u8).collect())
        }
        ,
        "likely"|"unlikely"=>{
            arity(1,1)?;
            a[0].clone()
        }
        ,"likelihood"=>{
            arity(2,2)?;
            a[0].clone()
        }
        ,
        "sqlite_version"=>{
            arity(0,0)?;
            Text("3.53.4".into())
        }
        ,"sqlite_source_id"=>Text("rust-sqlite-agent".into()),
        "sqlite_compileoption_used"=>Integer(0),"sqlite_compileoption_get"=>Null,
        "concat"=>{
            arity(1,usize::MAX)?;
            Text(a.iter().filter(|v|!v.null()).map(Value::text).collect())
        }
        ,
        "concat_ws"=>{
            arity(2,usize::MAX)?;
            if a[0].null(){
                Null
            }
            else{
                Text(a[1..].iter().filter(|v|!v.null()).map(Value::text).collect::<Vec<_>>().join(&s(0)))
            }
        }
        ,
        "printf"|"format"=>{
            if a.is_empty()||a[0].null(){Null}else{
                Text(crate::formatting::format_sql(&s(0),&a[1..])?)
            }
        }
        ,
        "pi"=>{
            arity(0,0)?;
            real(std::f64::consts::PI)
        }
        ,
        "sqrt"|"exp"|"ln"|"log10"|"log2"|"sin"|"cos"|"tan"|"asin"|"acos"|"atan"|"sinh"|"cosh"|"tanh"|"ceil"|"ceiling"|"floor"|"trunc"|"degrees"|"radians"=>{
            arity(1,1)?;
            if nul(){
                Null
            }
            else{
                if !math_numeric(&a[0]){
                    return Ok(Null)
                }
                let x=f(0);
                real(match n.as_str(){
                    "sqrt"=>x.sqrt(),"exp"=>x.exp(),"ln"=>x.ln(),"log10"=>x.log10(),"log2"=>x.log2(),"sin"=>x.sin(),"cos"=>x.cos(),"tan"=>x.tan(),"asin"=>x.asin(),"acos"=>x.acos(),"atan"=>x.atan(),"sinh"=>x.sinh(),"cosh"=>x.cosh(),"tanh"=>x.tanh(),"ceil"|"ceiling"=>x.ceil(),"floor"=>x.floor(),"trunc"=>x.trunc(),"degrees"=>x.to_degrees(),_=>x.to_radians()
                }
                )
            }
        }
        ,
        "pow"|"power"|"mod"|"atan2"=>{
            arity(2,2)?;
            if nul(){
                Null
            }
            else{
                if !a.iter().all(math_numeric){
                    return Ok(Null)
                }
                real(match n.as_str(){
                    "mod"=>f(0)%f(1),"atan2"=>f(0).atan2(f(1)),_=>f(0).powf(f(1))
                }
                )
            }
        }
        ,
        "log"=>{
            arity(1,2)?;
            if nul(){
                Null
            }
            else{
                if !a.iter().all(math_numeric){
                    return Ok(Null)
                }
                real(if a.len()==1{
                    f(0).log10()
                }
                else{
                    f(1).log(f(0))
                }
                )
            }
        }
        ,
        _=>return Err(format!("no such function: {}",name))
    }
    )
}
fn random_u64()->u64{
    use std::sync::atomic::{
        AtomicU64,Ordering
    }
    ;
    static STATE:AtomicU64=AtomicU64::new(0);
    let mut n=STATE.load(Ordering::Relaxed);
    if n==0{
        n=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|x|x.as_nanos() as u64).unwrap_or(1)
    }
    n^=n<<13;
    n^=n>>7;
    n^=n<<17;
    STATE.store(n,Ordering::Relaxed);
    n
}
pub fn pattern(p:&str,s:&str,glob:bool,esc:Option<char>,case:bool)->bool{
    enum Token{
        Many,One,Char(char),Class(Vec<(char,char)>,bool)
    }
    let pattern=p.chars().collect::<Vec<_>>();
    let text=s.chars().collect::<Vec<_>>();
    let mut tokens=vec![];
    let mut i=0;
    while i<pattern.len(){
        let c=pattern[i];
        i+=1;
        if Some(c)==esc{
            let Some(c)=pattern.get(i)else{
                return false
            }
            ;
            tokens.push(Token::Char(*c));
            i+=1;
        }
        else if c==if glob{
            '*'
        }
        else{
            '%'
        }
        {
            if !matches!(tokens.last(),Some(Token::Many)){
                tokens.push(Token::Many)
            }
        }
        else if c==if glob{
            '?'
        }
        else{
            '_'
        }
        {
            tokens.push(Token::One)
        }
        else if glob&&c=='['{
            let neg=pattern.get(i)==Some(&'^');
            if neg{
                i+=1
            }
            let mut ranges=vec![];
            if pattern.get(i)==Some(&']'){
                ranges.push((']',']'));
                i+=1
            }
            while i<pattern.len()&&pattern[i]!=']'{
                let a=pattern[i];
                i+=1;
                if pattern.get(i)==Some(&'-')&&pattern.get(i+1).is_some_and(|c|*c!=']'){
                    ranges.push((a,pattern[i+1]));
                    i+=2
                }
                else{
                    ranges.push((a,a))
                }
            }
            if pattern.get(i)!=Some(&']'){
                return false
            }
            i+=1;
            tokens.push(Token::Class(ranges,neg));
        }
        else{
            tokens.push(Token::Char(c));
        }
    }
    let mut prev=vec![false;
    text.len()+1];
    prev[0]=true;
    for token in tokens{
        let mut next=vec![false;
        text.len()+1];
        if matches!(token,Token::Many){
            next[0]=prev[0];
            for j in 1..next.len(){
                next[j]=prev[j]||next[j-1]
            }
        }
        else{
            for(j,c)in text.iter().enumerate(){
                let matched=match &token{
                    Token::One=>true,Token::Char(x)=>if glob||case{
                        c==x
                    }
                    else{
                        c.eq_ignore_ascii_case(x)
                    }
                    ,Token::Class(ranges,neg)=>ranges.iter().any(|(a,b)|c>=a&&c<=b)!=*neg,_=>false
                }
                ;
                next[j+1]=prev[j]&&matched
            }
        }
        prev=next
    }
    prev[text.len()]
}
fn unistr(s:&str)->Result<String,String>{
    let chars=s.chars().collect::<Vec<_>>();
    let mut p=0;
    let mut out=String::new();
    while p<chars.len(){
        let c=chars[p];
        p+=1;
        if c!='\\'{
            out.push(c);
            continue
        }
        if chars.get(p)==Some(&'\\'){
            out.push('\\');
            p+=1;
            continue
        }
        let n=match chars.get(p){
            Some('u')=>{
                p+=1;
                4
            }
            ,Some('U')=>{
                p+=1;
                8
            }
            ,Some('+')=>{
                p+=1;
                6
            }
            ,_=>4
        }
        ;
        let mut code=0u32;
        for _ in 0..n{
            let x=chars.get(p).and_then(|c|c.to_digit(16)).ok_or("invalid Unicode escape")?;
            p+=1;
            code=code.checked_mul(16).and_then(|c|c.checked_add(x)).ok_or("invalid Unicode escape")?;
        }
        if (0xd800..=0xdbff).contains(&code)&&chars.get(p)==Some(&'\\'){
            p+=1;
            if chars.get(p)==Some(&'u'){
                p+=1
            }
            let mut low=0u32;
            for _ in 0..4{
                low=low*16+chars.get(p).and_then(|c|c.to_digit(16)).ok_or("invalid Unicode escape")?;
                p+=1
            }
            if !(0xdc00..=0xdfff).contains(&low){
                return Err("invalid Unicode escape".into())
            }
            code=0x10000+(code-0xd800)*1024+low-0xdc00;
        }
        out.push(char::from_u32(code).ok_or("invalid Unicode escape")?);
    }
    Ok(out)
}
fn soundex(s:&str)->String{
    fn code(c:char)->char{
        match c{
            'B'|'F'|'P'|'V'=>'1','C'|'G'|'J'|'K'|'Q'|'S'|'X'|'Z'=>'2','D'|'T'=>'3','L'=>'4','M'|'N'=>'5','R'=>'6',_=>'0'
        }
    }
    let cs=s.chars().filter(char::is_ascii_alphabetic).map(|c|c.to_ascii_uppercase()).collect::<Vec<_>>();
    let Some(first)=cs.first()else{
        return "?000".into()
    }
    ;
    let mut out=first.to_string();
    let mut prev=code(*first);
    for c in &cs[1..]{
        let next=code(*c);
        if next!='0'&&next!=prev{
            out.push(next);
            if out.len()==4{
                break
            }
        }
        if *c!='H'&&*c!='W'{
            prev=next
        }
    }
    while out.len()<4{
        out.push('0')
    }
    out
}
fn math_numeric(v:&Value)->bool{
    match v{
        Value::Integer(_)|Value::Real(_)=>true,Value::Text(_)|Value::Blob(_)=>v.text().trim().parse::<f64>().is_ok(),_=>false
    }
}
