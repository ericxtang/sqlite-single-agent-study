use crate::{ast::Query,engine::{Engine,Env,Relation,Ctes},parser::Res};
use std::{cell::{Cell,RefCell},collections::BTreeMap};
#[derive(Clone)]
enum Cached{Correlated,Result(Relation)}
thread_local!{
    static NEXT:Cell<u64>=const{Cell::new(1)};
    static QUERIES:RefCell<Vec<BTreeMap<u64,Cached>>>=const{RefCell::new(Vec::new())};
    static OBSERVERS:RefCell<Vec<(u64,bool)>>=const{RefCell::new(Vec::new())};
}
fn next_id()->u64{NEXT.with(|next|{let id=next.get();next.set(id.wrapping_add(1).max(1));id})}
pub(crate) fn query_id(query:&Query)->u64{
    if query.memo_id.get()==0{query.memo_id.set(next_id());}
    query.memo_id.get()
}
pub(crate) struct QueryScope;
impl QueryScope{pub(crate) fn enter()->Self{QUERIES.with(|q|q.borrow_mut().push(BTreeMap::new()));Self}}
impl Drop for QueryScope{fn drop(&mut self){QUERIES.with(|q|{q.borrow_mut().pop();});}}
struct Observer{scope:u64}
impl Observer{
    fn enter()->Self{let scope=next_id();OBSERVERS.with(|o|o.borrow_mut().push((scope,false)));Self{scope}}
    fn used(&self)->bool{OBSERVERS.with(|o|o.borrow().iter().find(|(id,_)|*id==self.scope).is_some_and(|(_,used)|*used))}
}
impl Drop for Observer{fn drop(&mut self){OBSERVERS.with(|o|{o.borrow_mut().pop();});}}
pub(crate) fn observe(scope:u64){
    if scope!=0{OBSERVERS.with(|observers|{for(id,used)in observers.borrow_mut().iter_mut(){if *id==scope{*used=true;}}});}
}
fn mark(env:&mut Env,scope:u64){
    for field in &mut env.fields{field.scope=scope;}
    if let Some(outer)=&mut env.outer{mark(outer,scope);}
}
impl Engine{
    pub(crate) fn subquery(&self,q:&Query,env:&Env,ctes:&Ctes,depth:usize)->Res<Relation>{
        let id=query_id(q);
        let cached=QUERIES.with(|queries|queries.borrow().last().and_then(|cache|cache.get(&id).cloned()));
        if let Some(Cached::Result(result))=cached{return Ok(result)}
        if matches!(cached,Some(Cached::Correlated)){return self.query(q,env,ctes,depth)}
        let observer=Observer::enter();
        let mut marked=env.clone();mark(&mut marked,observer.scope);
        self.bind_query(q,&marked,ctes,depth)?;
        let correlated=observer.used();drop(observer);
        let result=self.query(q,env,ctes,depth)?;
        QUERIES.with(|queries|{if let Some(cache)=queries.borrow_mut().last_mut(){cache.insert(id,if correlated{Cached::Correlated}else{Cached::Result(result.clone())});}});
        Ok(result)
    }
}
