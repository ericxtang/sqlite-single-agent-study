import json,pathlib,subprocess,os
path='/work/concurrency-test.db'
for n in [path,path+'.agent-lock']:
 pathlib.Path(n).unlink(missing_ok=True)
class DB:
 def __init__(self):
  self.p=subprocess.Popen(['/work/target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
  assert self.send({'op':'open','path':path})['ok']
 def send(self,o):
  self.p.stdin.write(json.dumps(o)+'\n');self.p.stdin.flush();return json.loads(self.p.stdout.readline())
 def q(self,s,expect=None,err=False):
  r=self.send({'op':'execute','sql':s})
  if err:assert not r['ok'],(s,r)
  else:
   assert r['ok'],(s,r)
   if expect is not None:assert [[v.get('value')for v in row]for row in r['rows']]==expect,(s,r,expect)
 def stop(self):
  self.send({'op':'close'});self.p.terminate();self.p.wait()
a=DB();b=DB();a.q('CREATE TABLE t(id INTEGER PRIMARY KEY,v)');a.q("INSERT INTO t VALUES(1,'a')");b.q('SELECT * FROM t',[['1','a']])
a.q('BEGIN');a.q("UPDATE t SET v='pending'");b.q('SELECT * FROM t',[['1','a']]);b.q("INSERT INTO t VALUES(2,'blocked')",err=True);a.q('COMMIT');b.q('SELECT * FROM t',[['1','pending']])
a.q('BEGIN');a.q('SELECT * FROM t',[['1','pending']]);b.q("UPDATE t SET v='committed'");a.q('SELECT * FROM t',[['1','pending']]);a.q("UPDATE t SET v='stale'",err=True);a.q('ROLLBACK');a.q('SELECT * FROM t',[['1','committed']])
a.q('BEGIN IMMEDIATE');b.q('BEGIN IMMEDIATE',err=True);a.q('ROLLBACK');b.q('BEGIN IMMEDIATE');b.q('ROLLBACK')
a.q('BEGIN');a.q("INSERT INTO t VALUES(2,'crash')");a.p.kill();a.p.wait();b.q('SELECT * FROM t',[['1','committed']]);b.q("INSERT INTO t VALUES(3,'after-crash')");b.stop()
c=DB();c.q('SELECT * FROM t',[['1','committed'],['3','after-crash']]);c.q('CREATE TEMP TABLE tmp(x)');c.q('INSERT INTO tmp VALUES(1)');c.q('SELECT * FROM tmp',[['1']]);c.stop();c=DB();c.q('SELECT * FROM tmp',err=True);c.stop()
c=DB();c.q('CREATE TABLE types(i,r,b,t)');c.q("INSERT INTO types VALUES(9223372036854775807,1e999,x'00FF','λ')");c.stop();c=DB();c.q('SELECT * FROM types',[['9223372036854775807','Inf','00FF','λ']]);c.stop()
pathlib.Path(path).unlink();assert not pathlib.Path(path+'.agent-lock').exists();print('Persistence, isolation, writer locking, crash recovery, and temporary table checks passed')
