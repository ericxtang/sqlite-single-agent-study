use serde::{Serialize,Deserialize};
use std::{collections::BTreeMap,path::{Path,PathBuf},fs,io::Write};
use crate::{ast::*,value::Value};
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Row{pub id:i64,pub values:Vec<Value>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Table{pub def:TableDef,pub rows:Vec<Row>,pub sequence:i64}
impl Table{pub fn ipk(&self)->Option<usize>{if self.def.without_rowid{return None}let pk:Vec<_>=self.def.cols.iter().enumerate().filter(|(_,c)|c.primary>0).collect();if pk.len()==1&&pk[0].1.typ.eq_ignore_ascii_case("INTEGER")&&!pk[0].1.pk_desc{Some(pk[0].0)}else{None}}}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct View{pub name:String,pub cols:Vec<String>,pub query:Query,pub sql:String}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Index{pub name:String,pub table:String,pub cols:Vec<Order>,pub unique:bool,pub filter:Option<Expr>,pub sql:String,pub origin:String}
#[derive(Clone,Debug,Serialize,Deserialize,Default)]
pub struct Database{#[serde(default)] pub revision:u64,#[serde(default)] pub triggers:BTreeMap<String,Trigger>,pub tables:BTreeMap<String,Table>,pub views:BTreeMap<String,View>,pub indexes:BTreeMap<String,Index>,pub user_version:i64,pub application_id:i64,pub schema_version:i64}
pub fn key(s:&str)->String{s.to_ascii_lowercase()}
pub fn confined(s:&str)->Result<PathBuf,String>{let p=Path::new(s);let p=if p.is_absolute(){p.to_path_buf()}else{Path::new("/work").join(p)};if p.components().any(|c|matches!(c,std::path::Component::ParentDir)){return Err("database path must be within /work".into())}let parent=p.parent().ok_or("invalid database path")?.canonicalize().map_err(|e|format!("unable to open database file: {}",e))?;if !parent.starts_with("/work"){return Err("database path must be within /work".into())}let p=parent.join(p.file_name().ok_or("invalid database path")?);if p.exists(){let canonical=p.canonicalize().map_err(|e|e.to_string())?;if !canonical.starts_with("/work"){return Err("database path must be within /work".into())}return Ok(canonical)}Ok(p)}
pub fn open(path:&Path)->Result<Database,String>{if !path.exists(){let d=Database::default();save(path,&d)?;return Ok(d)}let b=fs::read(path).map_err(|e|e.to_string())?;if b.is_empty(){return Ok(Database::default())}if !b.starts_with(b"RustSQLite snapshot 1\n"){return Err("file is not a database".into())}serde_json::from_slice(&b[22..]).map_err(|e|format!("malformed database: {}",e))}
pub fn save(path:&Path,db:&Database)->Result<(),String>{let mut db=db.clone();let temp=db.tables.iter().filter(|(_,t)|t.def.temporary).map(|(k,_)|k.clone()).collect::<Vec<_>>();db.tables.retain(|_,t|!t.def.temporary);db.indexes.retain(|_,i|!temp.contains(&key(&i.table)));db.triggers.retain(|_,t|!t.temporary);let mut bytes=b"RustSQLite snapshot 1\n".to_vec();bytes.extend(serde_json::to_vec(&db).map_err(|e|e.to_string())?);let temp=path.with_extension(format!("agent-{}-tmp",std::process::id()));let mut f=fs::OpenOptions::new().write(true).create_new(true).open(&temp).map_err(|e|format!("disk I/O error: {}",e))?;let result=(||{f.write_all(&bytes)?;f.sync_all()?;fs::rename(&temp,path)?;if let Some(p)=path.parent(){fs::File::open(p)?.sync_all()?}Ok::<_,std::io::Error>(())})();if result.is_err(){let _=fs::remove_file(&temp);}result.map_err(|e|format!("disk I/O error: {}",e))}

// A writer owns this lock until its statement or explicit transaction ends.
// Atomic rename provides readers with complete committed snapshots.
pub struct WriteLock{path:PathBuf}
impl WriteLock{pub fn acquire(db:&Path)->Result<Self,String>{let mut name=db.as_os_str().to_os_string();name.push(".agent-lock");let path=PathBuf::from(name);for _ in 0..2{match fs::OpenOptions::new().write(true).create_new(true).open(&path){Ok(mut f)=>{write!(f,"{}",std::process::id()).map_err(|e|e.to_string())?;return Ok(Self{path})},Err(e)if e.kind()==std::io::ErrorKind::AlreadyExists=>{let pid=fs::read_to_string(&path).ok().and_then(|s|s.parse::<u32>().ok());if pid.is_some_and(|p|!Path::new(&format!("/proc/{}",p)).exists()){let _=fs::remove_file(&path);continue}return Err("database is locked".into())},Err(e)=>return Err(format!("disk I/O error: {}",e))}}Err("database is locked".into())}}
impl Drop for WriteLock{fn drop(&mut self){let _=fs::remove_file(&self.path);}}
