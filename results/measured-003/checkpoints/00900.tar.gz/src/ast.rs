use serde::{Serialize,Deserialize};
use crate::value::V;
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum E {Val(V),Col(Vec<String>),Star(Option<String>),Unary(String,Box<E>),Binary(String,Box<E>,Box<E>),Call(String,Vec<E>,bool,Option<Box<E>>),Case(Option<Box<E>>,Vec<(E,E)>,Option<Box<E>>),Cast(Box<E>,String),Collate(Box<E>,String),Between(Box<E>,Box<E>,Box<E>,bool),In(Box<E>,Vec<E>,Option<Box<Query>>,bool),Sub(Box<Query>),Exists(Box<Query>),Tuple(Vec<E>)}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Item {pub e:E,pub alias:Option<String>,pub label:String}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Order {pub e:E,pub desc:bool,pub nulls:Option<bool>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub enum Source {Table(String,Option<String>),Query(Box<Query>,Option<String>)}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Join {pub source:Source,pub kind:String,pub on:Option<E>,pub using:Vec<String>,pub natural:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Select {pub items:Vec<Item>,pub distinct:bool,pub from:Vec<Join>,pub filter:Option<E>,pub group:Vec<E>,pub having:Option<E>,pub values:Vec<Vec<E>>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Query {pub ctes:Vec<(String,Vec<String>,Query)>,pub recursive:bool,pub cores:Vec<(String,Select)>,pub order:Vec<Order>,pub limit:Option<E>,pub offset:Option<E>}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Column {pub name:String,pub typ:String,pub notnull:bool,pub pk:usize,pub unique:bool,pub default:Option<E>,pub default_sql:Option<String>,pub coll:String,pub generated:Option<E>,pub stored:bool,pub auto:bool,pub pkdesc:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Foreign {pub cols:Vec<String>,pub table:String,pub target:Vec<String>,pub delete:String,pub update:String,pub deferred:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
pub struct Definition {pub columns:Vec<Column>,pub uniques:Vec<Vec<String>>,pub checks:Vec<E>,pub foreign:Vec<Foreign>,pub strict:bool,pub without:bool}
#[derive(Clone,Debug)]
pub enum Stmt {Query(Query),CreateTable(String,bool,Definition,Option<Query>),CreateView(String,bool,Vec<String>,Query),CreateIndex(String,String,bool,bool,Vec<E>,Option<E>),Drop(String,String,bool),Insert{table:String,cols:Vec<String>,values:Option<Query>,default:bool,conflict:String,upsert:Option<Upsert>,returning:Vec<Item>},Update{table:String,alias:Option<String>,sets:Vec<(String,E)>,filter:Option<E>,conflict:String,returning:Vec<Item>,order:Vec<Order>,limit:Option<E>},Delete{table:String,alias:Option<String>,filter:Option<E>,returning:Vec<Item>,order:Vec<Order>,limit:Option<E>},Transaction(String,Option<String>),Pragma(String,Option<E>),Alter(String,Alter),Noop}
#[derive(Clone,Debug)]
pub struct Upsert {pub target:Vec<String>,pub sets:Vec<(String,E)>,pub filter:Option<E>,pub nothing:bool}
#[derive(Clone,Debug)]
pub enum Alter {Rename(String),RenameCol(String,String),Add(Column),Drop(String)}
