exec(open('tests/smoke.py').read().split("assert request(op='open'")[0])
path='/work/storage-test.db'
try:os.unlink(path)
except FileNotFoundError:pass
request(op='open',path=path)
sql('CREATE TABLE data(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, b BLOB, g INTEGER AS (length(name)) STORED)')
sql('BEGIN')
for chunk in range(6):
 vals=','.join("(%d,'name%04d',x'%s')"%(i,i,('00ff%02x'%(i%256))*1000) for i in range(chunk*50+1,chunk*50+51))
 sql('INSERT INTO data(id,name,b) VALUES '+vals)
sql('COMMIT')
sql('CREATE INDEX exp ON data(substr(name,5))')
sql('CREATE TABLE nr(a TEXT,b INTEGER,c TEXT,PRIMARY KEY(a,b)) WITHOUT ROWID')
sql("WITH RECURSIVE n(x) AS (VALUES(1) UNION ALL SELECT x+1 FROM n WHERE x<400) INSERT INTO nr SELECT 'k'||x,x,printf('%0500d',x) FROM n")
sql('CREATE TABLE ct AS SELECT id,name FROM data WHERE id<=3')
sql('ALTER TABLE data ADD COLUMN added INTEGER NOT NULL DEFAULT 77')
sql('PRAGMA user_version=42')
sql('PRAGMA application_id=12345')
sql('CREATE TABLE neg(x INTEGER PRIMARY KEY)')
sql('INSERT INTO neg VALUES(-9223372036854775808),(-1),(9223372036854775807)')
request(op='close')
raw=open(path,'rb').read();assert raw[:16]==b'SQLite format 3\0';ps=int.from_bytes(raw[16:18],'big');assert ps==4096
assert len(raw)==int.from_bytes(raw[28:32],'big')*ps
assert int.from_bytes(raw[60:64],'big')==42
assert int.from_bytes(raw[68:72],'big')==12345
assert request(op='open',path=path)['ok']
sql('SELECT count(*),sum(id),sum(length(b)),min(g),max(added) FROM data',[[300,45150,900000,8,77]])
sql('SELECT count(*),sum(b),min(length(c)) FROM nr',[[400,80200,500]])
sql('SELECT * FROM ct',[[1,'name0001'],[2,'name0002'],[3,'name0003']])
sql('SELECT x FROM neg ORDER BY x',[[-9223372036854775808],[-1],[9223372036854775807]])
sql("INSERT INTO data(name) VALUES('next') RETURNING id",[[301]])
sql("INSERT INTO data(name) VALUES('name0001')",error=True)
sql('PRAGMA user_version',[[42]])
request(op='close');p.terminate();os.unlink(path)
print('storage tests passed; database used',len(raw)//ps,'pages')
