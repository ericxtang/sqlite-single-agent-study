import subprocess,json,os
path='/work/concurrency-test.db'
try:os.unlink(path)
except FileNotFoundError:pass
ps=[subprocess.Popen(['target/release/sqlite-agent'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True) for _ in range(2)]
def req(i,**r):
 p=ps[i];p.stdin.write(json.dumps(r)+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
def sql(i,s,ok=True):
 r=req(i,op='execute',sql=s);assert r['ok']==ok,(s,r);return r
for i in range(2):assert req(i,op='open',path=path)['ok']
sql(0,'CREATE TABLE t(x)');sql(0,'INSERT INTO t VALUES(1)')
assert sql(1,'SELECT x FROM t')['rows'][0][0]['value']=='1'
sql(0,'BEGIN IMMEDIATE');sql(0,'INSERT INTO t VALUES(2)')
sql(1,'INSERT INTO t VALUES(3)',False)
assert len(sql(1,'SELECT * FROM t')['rows'])==1
sql(0,'COMMIT');sql(1,'INSERT INTO t VALUES(3)')
assert len(sql(0,'SELECT * FROM t')['rows'])==3
sql(0,'BEGIN');sql(0,'SELECT * FROM t');sql(1,'INSERT INTO t VALUES(4)')
assert len(sql(0,'SELECT * FROM t')['rows'])==3
sql(0,'UPDATE t SET x=99',False);sql(0,'ROLLBACK')
assert len(sql(0,'SELECT * FROM t')['rows'])==4
sql(0,'BEGIN IMMEDIATE');sql(0,'DELETE FROM t');ps[0].kill();ps[0].wait()
sql(1,'INSERT INTO t VALUES(5)');assert len(sql(1,'SELECT * FROM t')['rows'])==5
ps[1].terminate();ps[1].wait();os.unlink(path)
print('concurrency tests passed')
